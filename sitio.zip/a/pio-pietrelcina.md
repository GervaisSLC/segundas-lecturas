# San Pío de Pietrelcina

1887–1968 · St. Padre Pio · 1 lecturas

- [Piedras del edificio eterno](../r/db3002c2e5.md) — San Pío de Pietrelcina · Edición 1994: II, 87-90, n. 8 · 23 de septiembre San Pío de Pietrelcina, presbítero — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
