# San Atanasio de Alejandría

c. 296–373 · St. Athanasius · 12 lecturas

- [La Palabra tomó de María nuestra condición](../r/8f640cd3d0.md) — San Atanasio de Alejandría · Carta a Epicteto, 5-9: PG 26,1058.1062-1066 · 1 de Enero. SANTA MARÍA, MADRE DE DIOS — Santoral, año par
- [El Verbo de Dios vino por su benignidad hacia nosotros](../r/55d9831093.md) — San Atanasio de Alejandría · Núm. 8-9: PG 25, 110-111 · Viernes de la semana III de Adviento (semana 3), año impar
- [De la encarnación del Verbo](../r/d9ad87be06.md) — San Atanasio de Alejandría · Sermón sobre la encarnación del Verbo, 8-9: PG 25,110-111 · 2 de mayo. San Atanasio, Obispo y Doctor de la Iglesia — Santoral, año par
- [El Salvador ha resucitado; Cristo vive; Cristo es la vida misma](../r/19fcd0f9a3.md) — San Atanasio de Alejandría · 29-30: PG 25, 146-147 · Domingo de la semana XII del Tiempo Ordinario (semana 12), año impar
- [Luz, resplandor y gracia en la Trinidad y por la Trinidad](../r/eb232b122f.md) — San Atanasio de Alejandría · Carta a Serapión 1, 28-30: PG 26, 594-595. 599 · Domingo después de Pentecostés LA SANTÍSIMA TRINIDAD — Solemnidades del Señor, año impar
- [La vocación de san Antonio](../r/89aa82679d.md) — San Atanasio de Alejandría · Caps. 2-4: PG 26, 842-846 · 17 de enero San Antonio, Abad — Santoral, año impar
- [Renueva los tiempos pasados](../r/39c4d616d3.md) — San Atanasio de Alejandría · 10: PG 25, 111-114 · Martes de la semana V del Tiempo Ordinario (semana 5), año par
- [El conocimiento del Padre por medio de la Sabiduría creadora y hecha carne](../r/0a92a088e9.md) — San Atanasio de Alejandría · 78.81-82: PG 26, 311.319 · Martes de la semana XIV del Tiempo Ordinario (semana 14), año par
- [Al hombre le toca sembrar; a Dios, dar el crecimiento](../r/ef908b46ce.md) — San Atanasio de Alejandría · Homilía [atribuida] sobre la sementera, 2.3.4: PG 28, 146-150 · Domingo de la semana XV del Tiempo Ordinario (semana 15), año par
- [El Señor otorgó a la mujer el fruto de su fe](../r/a991414d70.md) — San Atanasio de Alejandría · Carta Pascual 7, 6-8: PG 26, 1393-1394 · SEMANA XX del tiempo ordinario, año impar
- [El Verbo del Padre embellece, ordena y contiene todas las cosas](../r/bdb1867799.md) — San Atanasio de Alejandría · Sermón 40-42: PG 25, 79-83 · Viernes de la semana XXIX del Tiempo Ordinario (semana 29), año par
- [Las obras de la creación, reflejo de la Sabiduría eterna](../r/929ecafbef.md) — San Atanasio de Alejandría · Sermón 2, 78.79: PG 26, 311.314 · Sábado de la semana XXX del Tiempo Ordinario (semana 30), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
