# Éste es el trabajo que Dios quiere: que creáis en el que Él ha enviado

**San Agustín de Hipona** (354–430) · Segunda lectura del Oficio de Lectura

- id: `fdba8b81d1`
- Fuente: De los sermones de San Agustín, obispo
- Cita patrística: Sermón 49 sobre el Antiguo Testamento, 2-3 CCL 41, 614-616
- Se lee: 11 de Enero o Viernes después del Domingo de Epifanía — Santoral, año par; 11 de Enero o Viernes después del Domingo de Epifanía — Santoral, año impar
- Escritura: [Ba 4, 5-29](../escritura/ba.md) (primera lectura del día); [Jn 3, 35-36](../escritura/jn.md) (responsorio); [Jn 20, 31](../escritura/jn.md) (responsorio)
- Temas (automáticos): [Trabajo y bienes](../temas/trabajo.md), [Fe](../temas/fe.md), [Misión y evangelización](../temas/mision.md)
- Cómo citar: San Agustín de Hipona, Sermón 49 sobre el Antiguo Testamento, 2-3 CCL 41, 614-616, «Éste es el trabajo que Dios quiere: que creáis en el que Él ha enviado». Liturgia de las Horas, Oficio de Lectura, segunda lectura, 11 de Enero o Viernes después del Domingo de Epifanía — Santoral, año par. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-fdba8b81d1](../index.html#r-fdba8b81d1)
- Autor: [San Agustín de Hipona](../a/agustin.md)

## Texto

Interrogado el Señor cuál era el trabajo de Dios, respondió: Este es el trabajo que Dios quiere: que creáis en el que Él ha enviado. Podría haber contestado nuestro piadoso Dios: El trabajo de Dios es la justicia. Ahora bien: si la justicia es el trabajo de Dios, según acabo de decir, ¿cómo puede consistir el trabajo de Dios en lo que el Señor afirma, es decir, en creer en él, si creer en él no fuera la misma justicia? Pero —me dirás— acabamos de oír al Señor: Éste es el trabajo de Dios: que creáis en él; en cambio, tú nos dices que el trabajo de Dios es la justicia. Demuéstranos que creer en Cristo es la justicia.

¿Te parece —y con esto respondo a tu justa objeción—, te parece que creer en Cristo no es justicia? ¿Qué es, entonces? Ponle un nombre a este trabajo. Si reflexionas atentamente sobre lo que has oído, estoy seguro que me responderás: Este trabajo se llama fe: creer en Cristo se llama fe. De acuerdo: creer en Cristo se llama fe. Escucha ahora tú otro texto de la Escritura: El justo vive de la fe. Obrad la justicia, creed: El justo vive de la fe. Es difícil que viva mal quien cree bien. Creed de todo corazón, creed sin claudicaciones, creed sin vacilaciones, sin argumentar contra esta misma fe acudiendo a humanas sospechas. Se llama fe precisamente porque se hace lo que se dice (fit quod dicitur).

Si ahora yo te pregunto: ¿Crees?, tú me respondes: Creo. Pues bien, haz lo que dices y eso es la fe. Yo, es verdad, puedo oír la voz del que me contesta, pero no me es posible ver el corazón del que cree. ¿Pero es que yo conduje a la viña, yo que no puedo ver el corazón? Ni conduzco, ni asigno la tarea, ni preparo el denario de la paga. Soy vuestro compañero de trabajo. Trabajo en la viña según las posibilidades que él se ha dignado poner a mi alcance. El que me contrató conoce el espíritu con que trabajo. Para mí —dice el Apóstol—, lo de menos es que me pidáis cuentas vosotros. Vosotros podéis oír mi voz, pero no podéis ver mi corazón. Presentémonos todos ante Dios con el corazón en la mano y realicemos nuestra tarea con ahínco. No disgustemos al que nos ha contratado, para poder recibir el salario con la frente bien alta.

También nosotros, carísimos, podremos contemplar recíprocamente nuestro corazón, pero más tarde. De momento nos hallamos rodeados de las tinieblas de nuestra mortalidad, y caminamos guiados por la antorcha de la Escritura, como dijo el apóstol Pedro: Esto nos confirma la palabra de los profetas, y hacéis muy bien en prestarle atención, como a una lámpara que brilla en un lugar oscuro, hasta que despunte el día, y el lucero nazca en vuestros corazones.

Por lo cual, carísimos, y en fuerza a esta fe por la que creemos en Dios, en comparación con los infieles, nosotros somos el día. Cuando aún no éramos creyentes, éramos, como ellos, noche; ahora somos luz, como dice el Apóstol: En otro tiempo erais tinieblas, ahora sois luz en el Señor. Tinieblas en vosotros, luz en el Señor. El mismo Apóstol dice en otro lugar: Porque todos sois hijos de la luz e hijos del día; no lo sois de la noche ni de las tinieblas. Conduzcámonos como en pleno día, con dignidad. Somos, pues, día en comparación con los infieles. Mas en comparación con aquel día en que resucitarán los muertos y esto corruptible se vista de incorrupción, y esto mortal se vista de inmortalidad, somos noche todavía. A nosotros, como si estuviéramos ya en el día, nos dice el apóstol Juan: Queridos, ahora somos hijos de Dios. Y comoquiera que aún es de noche, ¿qué es lo que sigue?: Y aún no se ha manifestado lo que seremos. Sabemos que, cuando se manifieste, seremos semejantes a él, porque le veremos tal cual es. Pero esto no es ya el trabajo: es la recompensa. Le veremos tal cual es: ésta es la recompensa. Entonces brillará el día más luminoso. Pero ya en este día conduzcámonos con dignidad; ahora que todavía es noche no nos juzguemos unos a otros. Considerad que cuando el apóstol Pablo dice: Conduzcámonos como en pleno día, con dignidad, no se opone ni disiente de su coapóstol Pedro, que dice: Hacéis muy bien en prestarle atención —se refiere a la palabra divina—, como a una lámpara que brilla en un lugar oscuro, hasta que despunte el día, y el lucero nazca en vuestros corazones.

## Responsorio (Jn 3, 35-36; 20, 31)

R. El Padre ama al Hijo y lo ha puesto todo en su mano. * El que cree en el Hijo tiene vida eterna; el que rehusa creer en el Hijo, no verá la vida, sino que la cólera de Dios permanece sobre él.  
V. Éstas han sido escritas para que creáis que Jesús es el Cristo, el Hijo de Dios, y para que creyendo tengáis vida en su nombre.  
R. El que cree en el Hijo tiene vida eterna; el que rehusa creer en el Hijo, no verá la vida, sino que la cólera de Dios permanece sobre él.  

## Oración

Dios todopoderoso, tú que has anunciado al mundo por medio de la estrella, el nacimiento del Salvador, manifiéstanos siempre este misterio y haz que cada día avancemos en su contemplación. Por nuestro Señor Jesucristo.

## Primera lectura del día

**Del libro del profeta Baruc 4, 5-29** — *Sión anima a sus hijos y los consuela*

¡Ánimo, pueblo mío, que llevas el nombre de Israel!

Os vendieron a naciones extranjeras, pero no para ser aniquilados. Por la cólera de Dios contra vosotros, os entregaron en poder del enemigo,

porque irritasteis a vuestro Creador, sacrificando a demonios, no a Dios;

os olvidasteis del Señor eterno, del Señor que os había alimentado, y afligisteis a Jerusalén que os criaba.

Cuando ella vio que el castigo de Dios se avecinaba, dijo: Escuchad, habitantes de Sión, Dios me ha cubierto de aflicción. He visto que el Eterno ha mandado cautivos a mis hijos y a mis hijas; los había criado con alegría, los despedí con lágrimas de pena.

Que nadie se alegre cuando vea a esta viuda abandonada de todos. Si ahora me encuentro desierta, es por los pecados de mis hijos, que se apartaron de la ley de Dios. No reconocieron sus mandatos, no siguieron la senda de sus preceptos, se resistieron a caminar rectamente.

Acercaos, vecinas de Sión, recordad que el Eterno decidió desterrar a mis hijos y a mis hijas. El Eterno envió contra ellos a un pueblo lejano y despiadado, a un pueblo de extraño lenguaje, que no respetaba a los ancianos ni tenía piedad de los niños. A pesar de que era yo viuda, se llevaron a mis hijos queridos, me dejaron sola y sin hijas.

¿Y qué puedo hacer por vosotros? El que os causó semejante desgracia os librará del poder del enemigo. Marchad, hijos míos, marchad, que aquí quedo yo abandonada.

Me he quitado el vestido de la paz y me he puesto el sayal de suplicante para clamar ante el Eterno mientras viva.

¡Ánimo, hijos! Gritad a Dios que os libre del poder enemigo. Yo espero que el Eterno os salvará, el Santo ya me llena de alegría, pues muy pronto el Eterno, vuestro Salvador, tendrá misericordia de vosotros. Os despedí entre llantos y duelo, pero Dios os devolverá a mí, me colmará de alegría para siempre. Si las vecinas de Sión hace poco os vieron caminar al destierro, muy pronto verán la salvación que Dios os va a conceder, pues va a venir acompañada de la gloria y el esplendor del Eterno.

Hijos míos, llevad con paciencia el castigo enviado por Dios. Si te ha perseguido el enemigo, pronto lo verás derrotado, con el cuello sometido a tu pie. Mis hijos delicados recorrieron duros y ásperos caminos, como rebaño que robó el enemigo.

¡Ánimo, hijos! Gritad a Dios, os castigó pero se acordará de vosotros.

Si un día os empeñasteis en alejaros de Dios, volveos a buscarlo con redoblado empeño. El mismo que os mandó las desgracias os mandará el gozo eterno de vuestra salvación.

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
