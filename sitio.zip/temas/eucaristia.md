# Eucaristía

36 lecturas (tema asignado automáticamente).

[Todos los temas](index.md) · [Guía para IAs](../llms.txt)

- [Preciosa es la muerte de los mártires, comprada con el precio de la muerte de Cristo](../r/737c0b2c30.md) — San Agustín de Hipona · Sermón 329, en el natalicio de los mártires, 1-2: PL 38,1454-1456 · Para un mártir — Comunes, año par
- [La plenitud del amor](../r/94d6859b80.md) — San Agustín de Hipona · Tratado 84, 1-2: CCL 36, 536-538 · Miércoles Santo — Cuaresma y Pascua, año par
- [El valor de la sangre de Cristo](../r/256817152a.md) — San Juan Crisóstomo · Catequesis 3, 13-19: SC 50, 174-177 · Triduo pascual — Cuaresma y Pascua, año par
- [La encarnación del Verbo y el sacramento de la Eucaristía nos hacen partícipes de la naturaleza divina](../r/89efb41c8a.md) — San Hilario de Poitiers · Lib 8, 13-16: CCL 62A, 325-328 · Domingo de la semana IV de Pascua (semana 4), año par
- [Si moramos en Cristo, ¿qué más podemos desear?](../r/d18f6b0c49.md) — San Nicolás Cabasilas · Lib. 4: PG 150, 582-583 · Miércoles de la semana V de Pascua (semana 5), año par
- [Protector y custodio fiel](../r/4cce2cca16.md) — San Bernardino de Siena · Sermón 2, Sobre san José: Opera omnia 7,16. 27-30 · 19 de marzo. SAN JOSÉ, Esposo de la Virgen María — Santoral, año par
- [La Iglesia nos ofrece a Cristo en la Eucaristía](../r/eecf988e6c.md) — Beata Mariana de Jesús · Ed. Madrid 1965, pág. 254 · 17 de abril. Beata Mariana de Jesús Navarro, Virgen — Santoral, año par
- [La Eucaristía, vínculo de paz y de unidad](../r/d393e9f40d.md) — Papa León XIII · 28 de noviembre de 1897 · 17 de mayo. San Pascual Bailón, Religioso — Santoral, año par
- [La plenitud del amor](../r/24728f67a7.md) — San Agustín de Hipona · Tratado 84, 1-2: CCL 36, 536-538 · Viernes de la semana V de Cuaresma (semana 5), año impar
- [El pan celestial y la bebida de salvación](../r/dd269a4df0.md) — Sin identificar · Catequesis 22 [Mistagógica 4], 1. 3-6. 9: PG 33, 1098-1106 · Sábado de la Octava de Pascua — Cuaresma y Pascua, año impar
- [La eucaristía, arras de la resurrección](../r/25954fa224.md) — San Ireneo de Lyon · Lib. 5, 2, 2-3: SC 153, 30-38 · Miércoles de la semana III de Pascua (semana 3), año impar
- [Los sacramentos vitales](../r/552b0fdedc.md) — San Cipriano de Cartago · Carta 63, 8-9: CSEL 3, parte 2, 706-708 · Viernes de la semana V de Pascua (semana 5), año impar
- [La eucaristía, Pascua del Señor](../r/f73693864a.md) — San Gaudencio de Brescia · Tratado 2: CSEL 68, 26. 29-30 · Sábado de la semana V de Pascua (semana 5), año impar
- [Dios busca a los hombres, no las cosas de los hombres](../r/997afad38a.md) — San Pedro Crisólogo · Sermón 18 : PL 52, 246-249 · Domingo de la semana V del Tiempo Ordinario (semana 5), año impar
- [La semilla de todos es Cristo](../r/953f5c18ae.md) — San Ambrosio de Milán · Comentario 36-39, sobre el salmo 43: CSEL 64, 288-290 · Sábado de la semana V del Tiempo Ordinario (semana 5), año impar
- [Los misterios, tan pletóricos de gracia de salvación que celebramos en cada reunión, reciben el nombre de Eucaristía](../r/d6488f9494.md) — San Juan Crisóstomo · Homilía 3-4: PG 57, 331 · Domingo de la semana VIII del Tiempo Ordinario (semana 8), año impar
- [Pedimos de modo que nuestra oración recabe la salvación de todos](../r/ed27a80d31.md) — San Cipriano de Cartago · Tratado 17-18: CSEL 3, 279-281 · Domingo de la semana XII del Tiempo Ordinario (semana 12), año impar
- [Acerca de la eucaristía](../r/db7079df63.md) — Didaché · Caps. 9, 1-10, 6; 14, 1-3: Funk 2, 19-22. 26 · Martes de la semana XVI del Tiempo Ordinario (semana 16), año impar
- [Se nos invita a la fe, que es el trabajo de Dios](../r/ce3b699180.md) — Balduino de Canterbury · Parte 2,3: SC 93, 248-252 · Domingo de la semana XVII del Tiempo Ordinario (semana 17), año impar
- [¡Oh banquete precioso y admirable!](../r/6f01011f6d.md) — Santo Tomás de Aquino · Opúsculo 57, En la fiesta del Cuerpo de Cristo, lect. 1-4 · Domingo después de la Santísima Trinidad EL SANTÍSIMO CUERPO Y SANGRE DE CRISTO — Solemnidades del Señor, año impar
- [Partícipes de la pasión de Cristo](../r/051b1721c1.md) — San Juan Crisóstomo · Homilía 65, 2-4: PG 58, 619-622 · 25 de julioSANTIAGO, APÓSTOL, PATRONO DE ESPAÑA — Santoral, año impar
- [Eucaristía: Sacramento de vida](../r/93f52ebe30.md) — San Pedro Julián Eymard · La Présence réelle, vol. 1, París, 1950, pp. 270-271 et 307-308). · El mismo día 2 de agosto San Pedro Julián Eymard, presbítero — Santoral, año impar
- [Hambre de oír la palabra del Señor](../r/3ad0ac9e0d.md) — Orígenes · 16, 4: PG 12, 249-250 · Viernes de la semana V del Tiempo Ordinario (semana 5), año par
- [La participación del cuerpo y sangre de Cristo nos santifica](../r/04f4dd0742.md) — San Fulgencio de Ruspe · Cap 28, 16-19: CCL 91A, 813-814 · Jueves de la semana XI del Tiempo Ordinario (semana 11), año par
- [Sobre el pueblo bien dispuesto que se prepara para el Señor](../r/f502198632.md) — San Elredo de Rievaulx · Edit C.H. Talbot, SSOC, I, 1952, 40-41 · Sábado de la semana XIV del Tiempo Ordinario (semana 14), año par
- [Cristo bebió mis amarguras para darme la suavidad de su gracia](../r/82b165e619.md) — San Ambrosio de Milán · Sermón 18, 26-29: PL 15, 1461-1463 · Domingo de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [Instrucción a los recién bautizados sobre la eucaristía](../r/aad5c1eb73.md) — San Ambrosio de Milán · Tratado 43. 47-49: SC 25bis, 178-180. 182 · Miércoles de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [Por la participación en la mesa eucarística, Cristo en nosotros y nosotros en Cristo formamos una sola realidad](../r/65a1d59c60.md) — San Cirilo de Alejandría · Lib. 10: PG 74, 342 · Miércoles de la semana XX del Tiempo Ordinario (semana 20), año impar
- [Éstos son los pastos que dio Dios a los creyentes](../r/a34aa0b1e4.md) — San Juan Crisóstomo · Homilía 50: PLS 4, 825-826. 828-830 · Lunes de la semana XXIII del Tiempo Ordinario (semana 23), año impar
- [Somos el pueblo de Dios](../r/9c470a3e48.md) — San Beda el Venerable · Homilía 1, 16: CCL 122, 117-118 · Martes de la semana XXIII del Tiempo Ordinario (semana 23), año impar
- [Lo que se aprende en la escuela de Cristo maestro](../r/8c5179b2ac.md) — San Agustín de Hipona · Sermón 33 A,4 sobre el antiguo Testamento : CCL 41, 421-422 · Domingo de la semana XXVI del Tiempo Ordinario (semana 26), año impar
- [El traje de fiesta es el amor](../r/2c74d5d1e8.md) — San Agustín de Hipona · Sermón 90,1.5.6: PL 38, 559.561-563 · Domingo de la semana XXVIII del Tiempo Ordinario (semana 28), año impar
- [No es tiempo de coronas y de premios, sino de luchas](../r/003d3e3372.md) — San Juan Crisóstomo · Homilía 7, 4-5: PG 48, 773-775 · Semana XXIX DEL TIEMPO ORDINARIO, año impar
- [Preciosa es la muerte de los mártires, comparada con el precio de la muerte de Cristo](../r/ec8c61e83f.md) — San Agustín de Hipona · Sermón 329: En el natalicio de los mártires, 1-2: PL 38,1454-1455 · 26 de septiembre San Cosme y San Damián, mártires — Santoral, año impar
- [Mi corazón se alegra en el Señor](../r/c2d6bdb3e8.md) — San Gregorio de Agrigento · Lib 8, 6: PG 98, 1071-1074 · Viernes de la semana XX del Tiempo Ordinario (semana 20), año par
- [Éste es el grupo que busca al Señor](../r/06878379d0.md) — San Gregorio de Nisa · Sermón sobre la ascensión de Cristo : PG 46, 690-691 · Jueves de la semana XXV del Tiempo Ordinario (semana 25), año par
