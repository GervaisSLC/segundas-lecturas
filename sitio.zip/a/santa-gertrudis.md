# Santa Gertrudis

None · None · 1 lecturas

- [Tuviste sobre mí designios de paz y no de aflicción](../r/28e0b01b3e.md) — Santa Gertrudis · Libro 2, 23,1. 3. 5. 8.10: SC 139, 330-340 · El mismo día 16 de noviembre Santa Gertrudis, virgen — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
