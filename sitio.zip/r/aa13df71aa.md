# Cristo, luz de las naciones y cabeza de la Iglesia

**San Agustín de Hipona** (354–430) · Segunda lectura del Oficio de Lectura

- id: `aa13df71aa`
- Fuente: De los sermones de san Agustín, obispo
- Cita patrística: Sermón 137, 1-3: PL 38, 754-756
- Se lee: Miércoles de la semana IV de Pascua (semana 4), año impar
- Escritura: [Ap 15, 4](../escritura/ap.md) (primera lectura del día); [Col 1, 17-19](../escritura/col.md) (responsorio); [Mi 4, 7](../escritura/mi.md) (responsorio)
- Temas (automáticos): [Iglesia](../temas/iglesia.md), [Resurrección](../temas/resurreccion.md), [Pastores y ministerio](../temas/pastores.md), [Misión y evangelización](../temas/mision.md)
- Cómo citar: San Agustín de Hipona, Sermón 137, 1-3: PL 38, 754-756, «Cristo, luz de las naciones y cabeza de la Iglesia». Liturgia de las Horas, Oficio de Lectura, segunda lectura, Miércoles de la semana IV de Pascua (semana 4), año impar. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-aa13df71aa](../index.html#r-aa13df71aa)
- Autor: [San Agustín de Hipona](../a/agustin.md)

## Texto

Carísimos: Vuestra fe no ignora –y estamos seguros de este vuestro conocimiento porque así nos lo asegura el Maestro celestial, en quien habéis depositado vuestra esperanza– que nuestro Señor Jesucristo –que por nosotros padeció y resucitó– es cabeza de la Iglesia y la Iglesia es su cuerpo y que, en este cuerpo, la unidad de los miembros y la trabazón de la caridad es el equivalente de la salud del cuerpo.

Por consiguiente, quien se enfría en la caridad, enferma en el cuerpo de Cristo. Pero el que exaltó ya a nuestra cabeza, tiene poder para sanar hasta los miembros enfermos, con tal de que no haya que amputarlos por su redomada impiedad y permanezcan unidos al cuerpo hasta lograr la salud. Pues no puede desesperarse de la salud de lo que todavía está unido al cuerpo, mientras que lo que una vez ha sido amputado, ni puede ser curado ni sanado. Siendo, pues, él la cabeza de la Iglesia y siendo la Iglesia el cuerpo de Cristo, el Cristo total se compone de cabeza y cuerpo. El ya ha resucitado. Por tanto, tenemos la cabeza en el cielo. Nuestra cabeza intercede por nosotros.

Nuestra cabeza, libre ya del pecado y de la muerte, nos hace propicio a Dios por nuestros pecados, de modo que, resucitando finalmente también nosotros y transformados en la gloria celeste, sigamos a nuestra cabeza. Pues donde está la cabeza, allí debe estar el resto de los miembros. Pero mientras permanecemos aquí, somos miembros, no desesperemos: seguiremos a nuestra cabeza.

Considerad, hermanos, el amor de nuestra cabeza. Está ya en el cielo y trabaja aquí en la tierra, mientras en la tierra se fatiga la Iglesia. Aquí, en la tierra, Cristo padece hambre, tiene sed, está desnudo, es huésped, enferma, está en la cárcel. Y todo lo que aquí padece su cuerpo, afirma padecerlo él. Al final, poniendo a su cuerpo a la derecha y separando a su izquierda al resto de los que ahora le vejan dirá a los de la derecha: Venid vosotros, benditos de mi Padre; heredad el reino preparado para vosotros desde la creación del mundo.

Cuando hace un momento nos hablaba Cristo, nos decía que él es el buen pastor, nos decía que él es asimismo la puerta. Ambas afirmaciones encuentras en el texto: Yo soy la puerta y Yo soy el pastor. Es puerta como cabeza, pastor en relación al cuerpo. Pues dice a Pedro, sobre el que exclusivamente cimenta la Iglesia: Pedro, ¿me amas? El contestó: Señor, te amo. Pastorea mis ovejas. Y por tercera vez: Pedro, ¿me amas? Se entristeció Pedro de que le preguntara por tercera vez: como si el que leyó en la conciencia del negador, no viera la fe del creyente.

Por tanto, después de su resurrección, el Señor le interrogó no porque desconociera con qué ánimo confesaba él su amor a Cristo, sino para que con la triple confesión del amor, borrase la triple negación del temor.

## Responsorio (Col 1, 17-19; Mi 4, 7)

R. Él es anterior a todo, y todo subsiste en él. * Él es también la cabeza del cuerpo, de la Iglesia; el primogénito de los que resucitan de entre los muertos, para que sea él el primero en todo. Aleluya.  
V. El Señor reinará sobre ellos en el monte Sión, desde ahora y por siempre.  
R. Él es también la cabeza del cuerpo, de la Iglesia; el primogénito de los que resucitan de entre los muertos, para que sea él el primero en todo. Aleluya.  

## Oración

Señor, tú que eres la vida de los fieles, la gloria de los humildes y la felicidad de los santos, escucha nuestras súplicas y sacia con la abundancia de tus dones a los que tienen sed de tus promesas. Por nuestro Señor Jesucristo.

## Primera lectura del día

**Del libro del Apocalipsis 14, 14— 15, 4** — *La cosecha de los últimos tiempos*

Yo, Juan, tuve otra visión:

Miré, y apareció una nube blanca; y sentado sobre la nube alguien como un Hijo de hombre, que tenía en la cabeza una corona de oro y en su mano una hoz afilada.

Salió otro ángel del santuario clamando con gran voz al que estaba sentado sobre la nube:

«Mete tu hoz y siega; ha llegado la hora de la siega, pues ya está seca la mies de la tierra».

El que estaba sentado encima de la nube metió su hoz sobre la tierra y la tierra quedó segada. Otro ángel salió del santuario del cielo, llevando él también una hoz afilada. Y del altar salió otro ángel, el que tiene poder sobre el fuego, y gritó con gran voz al que tenía la hoz afilada, diciendo:

«Mete tu hoz afilada y vendimia los racimos de la viña de la tierra, porque los racimos están maduros».

El ángel metió su hoz en la tierra y vendimió la viña de la tierra y echó las uvas en el gran lagar de la ira de Dios. Pisotearon el lagar fuera de la ciudad, y salió tanta sangre del lagar, que subió hasta los frenos de los caballos en un radio de mil seiscientos estadios.

Vi en el cielo otro signo, grande y maravilloso: Siete ángeles que llevaban siete plagas, las últimas, pues con ellas se consuma la ira de Dios. Vi una especie de mar de vidrio mezclado con fuego; los vencedores de la bestia, de su imagen y del número de su nombre estaban de pie sobre el mar cristalino; tenían en la mano las cítaras de Dios. Y cantan el cántico de Moisés, el siervo de Dios, y el cántico del Cordero, diciendo:

«Grandes y admirables son tus obras, Señor, Dios omnipotente; justos y verdaderos tus caminos, rey de los pueblos. ¿Quién no temerá y no dará gloria a tu nombre? Porque vendrán todas las naciones y se postrarán ante ti, porque tú solo eres santo y tus justas sentencias han quedado manifiestas».

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
