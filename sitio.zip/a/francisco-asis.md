# San Francisco de Asís

1181–1226 · St. Francis of Assisi · 1 lecturas

- [Debemos ser sencillos, humildes y puros](../r/7e2f62c5d1.md) — San Francisco de Asís · Opúsculos, edición Quaracchi, Florencia [1949], 87-94 · 4 de octubre San Francisco de Asís — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
