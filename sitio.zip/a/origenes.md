# Orígenes

c. 185–254 · Origen · 46 lecturas

- [Allanad los senderos del Señor](../r/ab8b4447c4.md) — Orígenes · Hom. 22, 1-2: SC 87, 301-302 · Domingo de la semana II de Adviento (semana 2), año par
- [Seamos un edificio sólido, que ninguna tormenta consiga derribar](../r/1851822d39.md) — Orígenes · Hom. 26, 3-5: SC 87, 341-343 · Domingo de la semana III de Adviento (semana 3), año par
- [Angustiados buscamos a Jesús](../r/fcd955ab28.md) — Orígenes · Homilía 18, 2-5: Edit GCS 9, 112-113 · Navidad y su Octava — Adviento y Navidad, año par
- [Somos edificados a manera de piedras vivas como casa de Dios](../r/12127aa4a0.md) — Orígenes · Homilía 9, 1-2: SC 71, 244-246 · Común de la dedicación de una iglesia — Comunes, año par
- [Jesús fue tentado por el diablo para que la Iglesia aprendiera que a Cristo se llega a través de muchas tribulaciones y tentaciones](../r/f5f6e62054.md) — Orígenes · Hom 3: GCS t. 8, 221, 19-223, 5 · Semana I de Cuaresma — Cuaresma y Pascua, año par
- [Angosto y estrecho es el callejón que lleva a la vida](../r/7690c32b46.md) — Orígenes · Homilía 5 sobre el libro del Exodo, 3-4: Ed. Maurist. t. 2, 145-146 · Semana II de Cuaresma — Cuaresma y Pascua, año par
- [Cristo es nuestro sumo sacerdote, nuestra propiciación](../r/72b0cb876b.md) — Orígenes · Homilía 9, 5. 10: PG 12, 515. 523 · Domingo de la semana IV de Cuaresma (semana 4) - Año A: Jn 9, 1-41, año par
- [Por la penitencia, nos purificamos de la impureza de nuestra lepra](../r/e7a3484ec0.md) — Orígenes · Homilía 7, 1-2, Ed. GCS t. 8, 37 40: SC 29, 133-136 · Semana V de Cuaresma — Cuaresma y Pascua, año par
- [Cristo, al tiempo de su pasión, no rehusó morir por los impíos y los injustos](../r/00b8df9b92.md) — Orígenes · 4, 10. 11: PG 14, 997-999 · Martes de la semana V de Cuaresma (semana 5), año par
- [Si alguien ha sido reconciliado por la sangre de Cristo, que no se relacione más con lo que es enemigo de Dios](../r/7e2f8b4b9f.md) — Orígenes · Lib. 4, 7: PG 14, 986-988 · Miércoles de la Octava de Pascua — Cuaresma y Pascua, año par
- [Los que son compañeros de Cristo en el sufrir también lo son en el buen ánimo](../r/f4e240914f.md) — Orígenes · Núms. 41-42: PG 11, 618-619 · 2 de junio. San Marcelino y San Pedro, Mártires — Santoral, año par
- [Sin derramamiento de sangre no hay perdón](../r/1c8148e765.md) — Orígenes · Lib. 3, 8: PG 14, 950-951 · Jueves de la semana IV de Cuaresma (semana 4), año impar
- [La muerte de Cristo se ha convertido en espiga de trigo](../r/baebf3a56e.md) — Orígenes · Homilía 10, 1-3: PG 13, 358-362 · Domingo de Ramos - Año A: Mt 21, 1-11 — Cuaresma y Pascua, año impar
- [Esta fe que profesan los romanos es la misma que se anuncia y crece en todo el mundo](../r/271e4463ea.md) — Orígenes · Lib. 1, 7-9: PG 14, 852-855 · En lugar del Domingo I del tiempo ordinario se tiene la fiesta del Bautismo del Señor., año impar
- [Dios no es parcial con nadie](../r/49c7857711.md) — Orígenes · Lib. 2, 7: PG 14, 887-889 · Miércoles de la semana I del Tiempo Ordinario (semana 1), año impar
- [Abrahán creyó en lo que había de venir, nosotros creemos en lo que ya ha venido](../r/ec0db05da8.md) — Orígenes · Lib. 7: PG 14, 981-985 · Domingo de la semana II del Tiempo Ordinario (semana 2), año impar
- [También vosotros habéis resucitado juntamente con él](../r/26b1ffd050.md) — Orígenes · Miércoles de la semana II del Tiempo Ordinario (semana 2), año impar
- [Hoy, en esta reunión, habla el Señor](../r/eb688c45c6.md) — Orígenes · Hom. 32, 2-6: SC 87, 386-392 · Domingo de la semana III del Tiempo Ordinario (semana 3), año impar
- [Todos los miembros de la Iglesia ofrecen la hostia viva](../r/97e05e1649.md) — Orígenes · Lib. 91: PG 14, 1204-1205. 1206-1207 · Lunes de la semana IV del Tiempo Ordinario (semana 4), año impar
- [En la Iglesia, que es el cuerpo de Cristo, cada uno ejercemos distintas funciones](../r/39a0050e30.md) — Orígenes · Lib. 9, 2: PG 14, 1211-1212 · De las Homilías sobre la primera carta a los Corintios de San Juan Crisóstomo, obispo — Tiempo Ordinario, año impar
- [Qué significa resucitar con Cristo](../r/a7407ce584.md) — Orígenes · Lib. 5, 8: PG 14, 1041-1042 · Lunes de la semana VIII del Tiempo Ordinario (semana 8), año impar
- [El perdón de los pecados](../r/dadcef5dbc.md) — Orígenes · Homilía 2, 4: PG 12, 417-419 · Sábado de la semana IX del Tiempo Ordinario (semana 9), año impar
- [El paso del Jordán](../r/d9f05c795d.md) — Orígenes · Homilía 4, 11: PG 12, 842-843 · Miércoles de la semana X del Tiempo Ordinario (semana 10), año impar
- [La conquista de Jericó](../r/8a95135e92.md) — Orígenes · Homilía 6, 4: PG 12, 855-856 · Jueves de la semana X del Tiempo Ordinario (semana 10), año impar
- [Las perlas finas conducen a la perla de gran valor](../r/63588c45c3.md) — Orígenes · Lib. 10, 9-10: SC 162, 173-177 · Domingo de la semana XVII del Tiempo Ordinario (semana 17), año impar
- [Purificados por su palabra, Dios hace resplandecer en nosotros la imagen del hombre celestial](../r/9af756d022.md) — Orígenes · Hom. 4: PG 12, 234-235 · En lugar del Domingo I del tiempo ordinario se tiene la fiesta del Bautismo del Señor., año par
- [Producid el fruto que la conversión pide](../r/e7160069cd.md) — Orígenes · Hom. 22, 7-10: SC 87. 306-308 · Viernes de la semana I del Tiempo Ordinario (semana 1), año par
- [Hambre de oír la palabra del Señor](../r/3ad0ac9e0d.md) — Orígenes · 16, 4: PG 12, 249-250 · Viernes de la semana V del Tiempo Ordinario (semana 5), año par
- [Cristo lava a su Iglesia con el baño del segundo nacimiento](../r/05bf451db9.md) — Orígenes · 17, 8.9: PG 12,260-261 · Sábado de la semana V del Tiempo Ordinario (semana 5), año par
- [El sacrificio de Abrahán](../r/49961f1e03.md) — Orígenes · Hom. 8, 6.8.9: PG 12, 206-209 · Martes de la semana IX del Tiempo Ordinario (semana 9), año par
- [¡Ánimo, soy yo!](../r/be670aeb6d.md) — Orígenes · Lib 11, 6: PG 13, 919-923 · Viernes de la semana XV del Tiempo Ordinario (semana 15), año par
- [El justo siembra para el espíritu, y del Espíritu cosechará vida eterna](../r/edeb5e425e.md) — Orígenes · nn. 68-69: PG 13, 1709-1710 · Semana XXXIII DEL TIEMPO ORDINARIO, año impar
- [Venga a nosotros tu reino](../r/3690d04b07.md) — Orígenes · Cap. 25: PG 11, 495-499 · Domingo de la semana XXXIV del Tiempo Ordinario (semana 34) JESUCRISTO, REY DEL UNIVERSO, año impar
- [Esto es lo que hay que pedir en la oración](../r/e4760ca876.md) — Orígenes · 1-2: PG 11,415-418 · Domingo de la semana XXVI del Tiempo Ordinario (semana 26) - Año A: Mt 21, 28-32, año par
- [Cómo hemos de orar](../r/181d11236a.md) — Orígenes · 2: PG 11, 418-422 · Martes de la semana XXVI del Tiempo Ordinario (semana 26), año par
- [Dios lo sabe todo antes de que suceda](../r/f9f5e440af.md) — Orígenes · 2.5: PG 11, 422-423. 430-434 · Miércoles de la semana XXVI del Tiempo Ordinario (semana 26), año par
- [Dios preordena todas las cosas](../r/0d5ca5be23.md) — Orígenes · 6: PG 11, 438 · Jueves de la semana XXVI del Tiempo Ordinario (semana 26), año par
- [Sobre la oración asidua](../r/eed65ad257.md) — Orígenes · 7-8: PG 11, 439-442 · Viernes de la semana XXVI del Tiempo Ordinario (semana 26), año par
- [Sobre la oración pura](../r/e6eab0e084.md) — Orígenes · 9-10: PG 11, 442-446 · Sábado de la semana XXVI del Tiempo Ordinario (semana 26), año par
- [Nuestro ángel custodio reza con nosotros](../r/353befe22e.md) — Orígenes · 10-11 PG 11, 446- · Domingo de la semana XXVII del Tiempo Ordinario (semana 27), año par
- [Ser constantes en orar](../r/15231c1c18.md) — Orígenes · 12-13: PG 11, 451-455 · Domingo de la semana XXVII del Tiempo Ordinario (semana 27) - Año A: Mt 21, 33-43, año par
- [Vosotros que aspiráis a ser espirituales, pedid bienes celestiales en la oración](../r/b1cc2948aa.md) — Orígenes · 13-14: PG 11, 455-459 · Martes de la semana XXVII del Tiempo Ordinario (semana 27), año par
- [Da a cada uno lo que le es debido](../r/142dab8662.md) — Orígenes · 28: PG 11, 522-523 · Miércoles de la semana XXVII del Tiempo Ordinario (semana 27), año par
- [Todos tenemos potestad para perdonar los pecados cometidos contra nosotros](../r/09bcf23721.md) — Orígenes · 28-33: PG 11, 526. 527.558-562 · Jueves de la semana XXVII del Tiempo Ordinario (semana 27), año par
- [Sobre el misterio de la encarnación del Verbo](../r/3b74049bd7.md) — Orígenes · Lib 2, 6, 2: PG 11, 210-211 · Domingo de la semana XXXI del Tiempo Ordinario (semana 31) - Año A: Mt 23, 1-12, año par
- [Cristo hablaba del templo de su cuerpo](../r/851038a444.md) — Orígenes · Tomo 10, 20: PG, 14, 370-371 · Sábado de la semana XXXIV del Tiempo Ordinario (semana 34), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
