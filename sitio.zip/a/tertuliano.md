# Tertuliano

c. 155–220 · Tertullian · 3 lecturas

- [El sacrificio espiritual](../r/08aecd5e23.md) — Tertuliano · Caps. 28-29: CCL 1, 273-274 · Jueves de la semana III de Cuaresma (semana 3), año par
- [La predicación apostólica](../r/3507799aac.md) — Tertuliano · Caps. 20,1-9; 21, 3; 22, 8-10: CCL 1, 201-204 · 3 de mayo. SAN FELIPE Y SANTIAGO, Apóstoles — Santoral, año par
- [Arrepiéntete y te salvaré](../r/eb29316629.md) — Tertuliano · 2, 3-7; 4,1-3: CCL 1, 322-323; 326 · Domingo de la semana III del Tiempo Ordinario (semana 3), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
