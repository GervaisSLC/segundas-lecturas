# San Gregorio de Agrigento

c. 559–630 · St. Gregory of Agrigento · 2 lecturas

- [Mi corazón se alegra en el Señor](../r/c2d6bdb3e8.md) — San Gregorio de Agrigento · Lib 8, 6: PG 98, 1071-1074 · Viernes de la semana XX del Tiempo Ordinario (semana 20), año par
- [Contemplad al Señor, y quedaréis radiantes](../r/10c778e2a7.md) — San Gregorio de Agrigento · Lib 10, 2: PG 98, 1138-1139 · Sábado de la semana XX del Tiempo Ordinario (semana 20), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
