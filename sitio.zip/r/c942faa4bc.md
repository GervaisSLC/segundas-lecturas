# Toda la vida del buen cristiano es un santo deseo

**San Agustín de Hipona** (354–430) · Segunda lectura del Oficio de Lectura

- id: `c942faa4bc`
- Fuente: Del tratado de san Agustín, obispo, sobre la primera carta de san Juan
- Cita patrística: Tratado 4, 4-6: SC 75, 224-232
- Se lee: Viernes de la semana VI de Pascua (semana 6) antes de la Ascensión, año impar; Sábado de la semana VI de Pascua (semana 6) después de la Ascensión, año impar
- Escritura: [1 Jn 3, 11-17](../escritura/1jn.md) (primera lectura del día); [Flp 3, 20-21](../escritura/flp.md) (responsorio); [Tt 2, 12-13](../escritura/tt.md) (responsorio)
- Temas (automáticos): [Esperanza y vida eterna](../temas/esperanza.md), [Bautismo](../temas/bautismo.md)
- Cómo citar: San Agustín de Hipona, Tratado 4, 4-6: SC 75, 224-232, «Toda la vida del buen cristiano es un santo deseo». Liturgia de las Horas, Oficio de Lectura, segunda lectura, Viernes de la semana VI de Pascua (semana 6) antes de la Ascensión, año impar. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-c942faa4bc](../index.html#r-c942faa4bc)
- Traducción inglesa antigua (dominio público, no litúrgica): https://www.newadvent.org/fathers/170204.htm
- Autor: [San Agustín de Hipona](../a/agustin.md)

## Texto

Mirad qué amor nos ha tenido el Padre para llamarnos hijos de Dios, pues, ¡lo somos! Pues quienes se llaman y no son, ¿de qué les aprovecha el nombre si no responde a la realidad? ¡Cuántos se llaman médicos y no saben curar! ¡Cuántos se llaman serenos y se pasan la noche durmiendo! Igualmente abundan los que se llaman cristianos cuya conducta no rima con su nombre, pues no son lo que dicen ser: en la vida, en las costumbres, en la fe, en la esperanza, en el amor. Todo el mundo es cristiano, y todo el mundo es impío; hay impíos por todo el mundo, y por todo el mundo hay píos: unos y otros no se reconocen entre sí. Por eso el mundo no nos conoce, porque no le conoció a él. El mismo Señor Jesús caminaba, en la carne era Dios, oculto en la debilidad de la carne. Y ¿por qué no fue reconocido? Porque reprochaba a los hombres todos sus pecados. Ellos, amando los deleites del pecado, no reconocían a Dios; amando lo que la fiebre de las pasiones les sugería, injuriaban al médico.

Y nosotros, ¿qué? Hemos ya nacido de él; pero como vivimos bajo la economía de la esperanza, dijo: Queridos, ahora somos hijos de Dios. ¿Ya desde ahora? Entonces, ¿qué es lo que esperamos, si somos ya hijos de Dios? Y aún –dice– no se ha manifestado lo que seremos. ¿Es que seremos otra cosa que hijos de Dios? Oíd lo que sigue: Sabemos que, cuando se manifieste, seremos semejantes a él, porque le veremos tal cual es. ¿Qué es lo que se nos ha prometido? Seremos semejantes a él porque le veremos tal cual es. La lengua ha expresado lo que ha podido; lo restante ha de ser meditado por el corazón. En comparación de aquel que es, ¿qué pudo decir el mismo Juan? ¿Y qué podemos decir nosotros, que tan lejos estamos de igualar sus méritos?

Volvamos, pues, a aquella unción de Cristo, volvamos a aquella unción que nos enseña desde dentro lo que nosotros no podemos expresar, y, ya que ahora os es imposible la visión, sea vuestra tarea el deseo. Toda la vida del buen cristiano es un santo deseo. Lo que deseas no lo ves todavía, mas por tu deseo te haces capaz de ser saciado cuando llegue el momento de la visión.

Deseemos, pues, hermanos, ya que hemos de ser colmados. Ved de qué manera Pablo ensancha su deseo, para hacerse capaz de recibir lo que ha de venir. Dice, en efecto: No es que ya haya conseguido el premio, o que ya esté en la meta; hermanos, yo no pienso haber conseguido el premio. ¿Qué haces, pues, en esta vida, si aún no has conseguido el premio? Sólo busco una cosa: olvidándome de lo que queda atrás y lanzándome hacia lo que está por delante, corro hacia la meta para ganar el premio, al que Dios desde arriba me llama.

Afirma de sí mismo que está lanzado hacia lo que está por delante y que va corriendo hacia la meta final. Es porque se sentía demasiado pequeño para captar aquello que ni el ojo vio, ni el oído oyó, ni el hombre puede pensar. Tal es nuestra vida: ejercitarnos en el deseo. Ahora bien: este santo deseo está en proporción directa de nuestro desasimiento de los deseos que suscita el amor del mundo. Ensanchemos, pues, nuestro corazón, para que, cuando venga, nos llene, ya que seremos semejantes a él, porque lo veremos tal cual es.

## Nota

> Señor, Dios nuestro, que has otorgado a tu pueblo el don de la redención, concédenos vivir eternamente la alegría de la resurrección de tu Hijo. Que vive y reina contigo.

## Responsorio (Flp 3, 20-21; Tt 2, 12-13)

R. Esperamos como Salvador al Señor Jesucristo, * el cual transfigurará nuestro cuerpo para conformarlo a su cuerpo glorioso. Aleluya.  
V. Vivamos con sobriedad, justicia y piedad, en este mundo, mientras aguardamos la feliz esperanza y la manifestación de la gloria de nuestro gran Dios.  
R. El cual transfigurará nuestro cuerpo para conformarlo a su cuerpo glorioso. Aleluya.  

## Oración

Antes de la Ascensión

## Primera lectura del día

**De la primera carta del apóstol san Juan 3, 11-17** — *La caridad hacia nuestros hermanos*

Queridos hermanos:

Este es el mensaje que habéis oído desde el principio: que nos amemos unos a otros. No seamos como Caín, que procedía del Maligno y asesinó a su hermano. ¿Y por qué lo asesinó? Porque sus obras eran malas, mientras que las de su hermano eran justas. No os sorprenda, hermanos, que el mundo os odie; nosotros sabemos que hemos pasado de la muerte a la vida porque amamos a los hermanos. El que no ama permanece en la muerte.

El que odia a su hermano es un homicida. Y sabéis que ningún homicida lleva permanentemente en sí vida eterna. En esto hemos conocido el amor: en que él dio su vida por nosotros. También nosotros debemos dar nuestra vida por los hermanos. Pero si uno tiene bienes del mundo y, viendo a su hermano en necesidad, le cierra sus entrañas, ¿cómo va a estar en él el amor de Dios?

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
