# Ruperto de Deutz

c. 1075–1129 · Rupert of Deutz · 3 lecturas

- [En medio de vosotros hay uno que no conocéis](../r/c891ecfb3c.md) — Ruperto de Deutz · Lib. III, cap 3: SC 165, 26-28 · Domingo de la semana III de Adviento (semana 3), año par
- [Y el pan que yo daré es mi carne, para la vida del mundo](../r/8d3ac54668.md) — Ruperto de Deutz · Lib 6, 51-52: CCL CM 9, 356-357 · Domingo de la semana XIX del Tiempo Ordinario (semana 19), año impar
- [La gracia del perdón es una e idéntica para todos](../r/d3eeb474de.md) — Ruperto de Deutz · Lib 2: CCL CM 9, 60-62 · Martes de la semana XX del Tiempo Ordinario (semana 20), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
