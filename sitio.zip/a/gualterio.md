# Gualterio de San Víctor

d. c. 1180 · Walter of Saint Victor · 2 lecturas

- [La cruz de Cristo, remedio, ejemplo y misterio](../r/714af941f8.md) — Gualterio de San Víctor · Sermón 3, 2.3.4: CCL CM 30, 250.251.252 · Viernes de la semana VIII del Tiempo Ordinario (semana 8), año impar
- [El soldado de Cristo debe renunciar a su propia voluntad](../r/39a2ae4fc0.md) — Gualterio de San Víctor · Sermón 3, 5.6.7.9: CCL CM 30, 252.253.254.255 · Sábado de la semana IX del Tiempo Ordinario (semana 9), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
