# San Gregorio de Neocesarea

None · None · 1 lecturas

- [Vino a nosotros el que es el esplendor de la gloria del Padre](../r/7316e75b00.md) — San Gregorio de Neocesarea · Homilía 4 en la santa Teofanía: PG 10, 1182-1183 · Domingo después del 6 de Enero. EL BAUTISMO DEL SEÑOR — Adviento y Navidad, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
