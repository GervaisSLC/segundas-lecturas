# Ardía en deseos de Cristo, a quien pensaba que se lo habían llevado

**San Gregorio Magno** (c. 540–604) · Segunda lectura del Oficio de Lectura

- id: `ae5efbefb4`
- Fuente: De las homilías de san Gregorio Magno, papa, sobre los evangelios
- Cita patrística: Homilía 25,1-2. 4-5: PL 76,1189-1193
- Se lee: 22 de julio Santa María Magdalena — Santoral, año impar; 22 de julio Santa María Magdalena — Santoral, año par
- Temas (automáticos): [Muerte y difuntos](../temas/muerte.md), [Virgen María](../temas/maria.md)
- Cómo citar: San Gregorio Magno, Homilía 25,1-2. 4-5: PL 76,1189-1193, «Ardía en deseos de Cristo, a quien pensaba que se lo habían llevado». Liturgia de las Horas, Oficio de Lectura, segunda lectura, 22 de julio Santa María Magdalena — Santoral, año impar. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-ae5efbefb4](../index.html#r-ae5efbefb4)
- Autor: [San Gregorio Magno](../a/gregorio-magno.md)

## Texto

María Magdalena, cuando llegó al sepulcro y no encontró allí el cuerpo del Señor, creyó que alguien se lo había llevado y así lo comunicó a los discípulos. Ellos fueron también al sepulcro, miraron dentro y creyeron que era tal como aquella mujer les había dicho. Y dice el evangelio acerca de ellos: Los discípulos se volvieron a su casa. Y añade, a continuación: Fuera, junto al sepulcro, estaba María, llorando.

Lo que hay que considerar en estos hechos es la intensidad del amor que ardía en el corazón de aquella mujer, que no se apartaba del sepulcro, aunque los discípulos se habían marchado de allí. Buscaba al que no había hallado, lo buscaba llorando y, encendida en el fuego de su amor, ardía en deseos de aquel a quien pensaba que se lo habían llevado. Por esto, ella fue la única en verlo entonces, porque se había quedado buscándolo, pues lo que da fuerza a las buenas obras es la perseverancia en ellas, tal como afirma la voz de aquel que es la Verdad en persona: El que persevere hasta el final se salvará.

Primero lo buscó, sin encontrarlo; perseveró luego en la búsqueda, y así fue como lo encontró; con la dilación, iba aumentando su deseo, y este deseo aumentado le valió hallar lo que buscaba. Los santos deseos, en efecto, aumentan con la dilación. Si la dilación los enfría es porque no son o no eran verdaderos deseos. Todo aquel que ha sido capaz de llegar a la verdad es porque ha sentido la fuerza de este amor. Por esto dice David: Mi alma tiene sed de Dios vivo: ¿cuándo entraré a ver el rostro de Dios? Idénticos sentimientos expresa la Iglesia cuando dice, en el Cantar de los cantares: Estoy enferma de amor; y también: Mi alma se derrite.

Mujer, ¿por qué lloras? ¿a quién buscas? Se le pregunta la causa de su dolor con la finalidad de aumentar su deseo, ya que, al recordarle a quién busca, se enciende con más fuerza el fuego de su amor.

Jesús le dice: "¡María!" Después de haberla llamado con el nombre genérico de "mujer", sin haber sido reconocido, la llama ahora por su nombre propio. Es como si le dijera: “Reconoce a aquel que te reconoce a ti. Yo te conozco, no de un modo genérico, como a los demás, sino en especial”.

María, al sentirse llamada por su nombre, reconoce al que lo ha pronunciado, y, al momento, lo llama: "Rabboni", es decir: "Maestro", ya que el mismo a quien ella buscaba exteriormente era el que interiormente la instruía para que lo buscase.

## Nota

> Formó parte de los discípulos de Cristo, estuvo presente en el momento de su muerte y, en la madrugada del día de Pascua, tuvo el privilegio de ser la primera en ver al Redentor resucitado de entre los muertos (Mc 16, 9). Fue sobre todo durante el siglo XII cuando su culto se difundió en la Iglesia occidental.

> Del Común de santas mujeres, excepto lo siguiente:

## Responsorio

R. Cuando volvió del sepulcro del Señor, María Magdalena anunció a los discípulos: «He visto al Señor.» * Dichosa ella que fue digna de llevar la noticia de la resurrección de la Vida.  
V. Llorando al que amaba, encontró al que buscaba, y anunció luego al que había encontrado.  
R. Dichosa ella que fue digna de llevar la noticia de la resurrección de la Vida.  

## Oración

Señor, Dios nuestro, Cristo, tu Unigénito, confió, antes que a nadie, a María Magdalena la misión de anunciar a los suyos la alegría pascual; concédenos a nosotros, por la intercesión y el ejemplo de aquella cuya fiesta celebramos, anunciar siempre a Cristo resucitado y verle un día glorioso en el reino de los cielos. Por Jesucristo nuestro Señor.

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
