# San Beda

None · None · 1 lecturas

- [Deseo ver a Cristo](../r/7150e5a01f.md) — San Beda · Núms. 4-6: PL 90, 64-66 · 25 de mayo. San Beda el Venerable, Presbítero y Doctor de la Iglesia — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
