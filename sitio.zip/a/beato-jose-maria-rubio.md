# Beato José María Rubio

None · None · 1 lecturas

- [Humildad y oración](../r/6c4e388f42.md) — Beato José María Rubio · Escritos del P. José María Rubio, Apostolado de la Prensa, Madrid 1932, pp. 159-160 · 4 de mayo. Beato José María Rubio, Presbítero — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
