# Juan Casiano

c. 360–435 · John Cassian · 1 lecturas

- [Sobre las tres renuncias](../r/6366588797.md) — Juan Casiano · Conf 3, cap 6-7: PL 564-567 · Domingo de la semana XXIII del Tiempo Ordinario (semana 23), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
