# San Pablo VI

1897–1978 · St. Paul VI · 6 lecturas

- [El ejemplo de Nazaret](../r/be0ff28b89.md) — San Pablo VI · Alocución en Nazaret, 5 de enero de 1964 · Domingo dentro de la Octava de Navidad. LA SAGRADA FAMILIA DE JESÚS, MARÍA Y JOSÉ — Adviento y Navidad, año impar
- [Convertíos y creed en la Buena Noticia](../r/291db60636.md) — San Pablo VI · AAS t. 58, 1966, pp. 179-180 · Semana III de Cuaresma — Cuaresma y Pascua, año par
- [La gloria de los mártires, signo de regeneración](../r/c7750dd522.md) — San Pablo VI · AAS 56 (1964), 905-906 · 3 de junio. San Carlos Luanga y Compañeros, Mártires — Santoral, año par
- [Rasgad los corazones, no las vestiduras](../r/889c5a098c.md) — San Pablo VI · AAS t. 58. 1966, 178-179 · Sábado después de Ceniza — Cuaresma y Pascua, año impar
- [Estuve enfermo, y me visitasteis](../r/3ee6be000e.md) — San Pablo VI · 25 de enero de 1970: AAS 62, 1970, 82-88 · El mismo día 10 de octubre San Luis Beltrán, presbítero — Santoral, año impar
- [Eficacia pastoral del culto tributado a la Virgen](../r/bfb9dd4e7e.md) — San Pablo VI · AAS 66 [1974),113-168 · 12 de octubre NUESTRA SEÑORA DEL PILAR — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
