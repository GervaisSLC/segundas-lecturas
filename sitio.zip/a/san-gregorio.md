# San Gregorio

None · None · 1 lecturas

- [Una Iglesia libre, casta y católica](../r/34885c585c.md) — San Gregorio · Carta 64 extra Registrum: PL 148, 709-710 · El mismo día 25 de mayo. San Gregorio VII, Papa — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
