# Solemnidades del Señor — año impar

[Volver al calendario](index.md) · [Guía para IAs](../llms.txt)

## Solemnidades del Señor que se celebran durante el Tiempo Ordinario

- **Domingo después de Pentecostés LA SANTÍSIMA TRINIDAD** — [Luz, resplandor y gracia en la Trinidad y por la Trinidad](../r/eb232b122f.md) — San Atanasio de Alejandría · Carta a Serapión 1, 28-30: PG 26, 594-595. 599
- **Domingo después de la Santísima Trinidad EL SANTÍSIMO CUERPO Y SANGRE DE CRISTO** — [¡Oh banquete precioso y admirable!](../r/6f01011f6d.md) — Santo Tomás de Aquino · Opúsculo 57, En la fiesta del Cuerpo de Cristo, lect. 1-4
- **Viernes posterior al segundo domingo después de Pentecostés EL SAGRADO CORAZÓN DE JESÚS** — [En ti está la fuente de la vida](../r/84ab7d9f98.md) — San Buenaventura · Opúsculo 3, El árbol de la vida, 29-30. 47: Opera omnia 8, 79
