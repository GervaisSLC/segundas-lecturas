# Ayuno y Cuaresma

11 lecturas (tema asignado automáticamente).

[Todos los temas](index.md) · [Guía para IAs](../llms.txt)

- [Purificación espiritual por el ayuno y la misericordia](../r/1429eb9b65.md) — San León Magno · Sermón sobre la Cuaresma, 1-2; PL 54, 285-287 · Jueves después de Ceniza — Cuaresma y Pascua, año par
- [Esta cruz no es cruz de solos cuarenta días, sino de toda la vida](../r/f8c9c8f957.md) — San Agustín de Hipona · Sermón 205, 1: 1 de Cuaresma: Edit. Maurist., t. 5, 919-920 · Domingo de la semana III de Cuaresma (semana 3) - Año A: Jn 4, 5-42, año par
- [La oración llama, el ayuno intercede, la misericordia recibe](../r/715216298e.md) — San Pedro Crisólogo · Sermón 43: PL 52, 320. 322 · Martes de la semana III de Cuaresma (semana 3), año par
- [Con razón en estos días desbordamos de gozo, como si ya estuviéramos con el Esposo](../r/9068ddd6c2.md) — Eusebio de Cesarea · Tratado 4-5: PG 24, 698-699 · Martes de la Octava de Pascua — Cuaresma y Pascua, año par
- [El aleluya pascual](../r/7d316b21f6.md) — San Agustín de Hipona · Salmo 148, 1-2: CCL 40, 2165-2166 · Sábado de la semana V de Pascua (semana 5), año par
- [Ayunamos por nuestros pecados, pues vamos a acercarnos a los sagrados misterios](../r/bd3dfce7fa.md) — San Juan Crisóstomo · Discurso 3, contra los judíos: PG 48, 867-868 · Jueves después de Ceniza — Cuaresma y Pascua, año impar
- [Buena es la oración con el ayuno y la limosna](../r/4d60a58aa9.md) — San Cipriano de Cartago · Tratado 32-33: CSEL 3, 290-292 · Domingo de la semana XIII del Tiempo Ordinario (semana 13), año impar
- [La nueva ley de nuestro Señor](../r/030e029d3e.md) — Carta de Bernabé · Caps. 2, 6-10; 3, 1. 3, 4, 10-14: Funk 1, 7-9. 13 · Martes de la semana XXII del Tiempo Ordinario (semana 22), año impar
- [El altar celestial, figura del altar eclesial](../r/a6336379cd.md) — San Juan Crisóstomo · Homilía sobre el serafín 6, 3: PG 56, 138-139 · Domingo de la semana XXV del Tiempo Ordinario (semana 25), año impar
- [Amemos el camino angosto y trillado que conduce a la verdadera vida](../r/e3c9e99f5c.md) — San Gregorio Palamás · Homilía 10 : PG 151, 111-114 · Martes de la semana XXIX del Tiempo Ordinario (semana 29), año impar
- [Tendía siempre hacia Dios](../r/3d4c2ac009.md) — Actas y escritos anónimos · Acta Sanctorum Octobris 8, 1853, 201-202 · 16 de octubre Santa Eduvigis, religiosa — Santoral, año impar
