# San Buenaventura

1221–1274 · St. Bonaventure · 4 lecturas

- [Del conocimiento de Jesucristo dimana la comprensión de toda la sagrada Escritura](../r/305dbf7e7f.md) — San Buenaventura · Prólogo: Opera omnia 5, 201-202 · Sábado de la semana II del Tiempo Ordinario (semana 2), año impar
- [En ti está la fuente de la vida](../r/84ab7d9f98.md) — San Buenaventura · Opúsculo 3, El árbol de la vida, 29-30. 47: Opera omnia 8, 79 · Viernes posterior al segundo domingo después de Pentecostés EL SAGRADO CORAZÓN DE JESÚS — Solemnidades del Señor, año impar
- [La sabiduría misteriosa revelada por el Espíritu Santo](../r/00d16fcf12.md) — San Buenaventura · Cap. 7, 1. 2. 4. 6: Opera omnia 5, 312-313 · 15 de julio San Buenaventura, Obispo y Doctor de la Iglesia — Santoral, año impar
- [La sabiduría misteriosa revelada por el Espíritu Santo](../r/58fbf6a843.md) — San Buenaventura · Opúsculo sobre el itinerario de la mente hacia Dios, 7,1,2,6: Opera omnia 5, 312-313 · 15 de julio San Buenaventura, Obispo y Doctor de la Iglesia — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
