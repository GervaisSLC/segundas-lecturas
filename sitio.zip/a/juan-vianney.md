# San Juan María Vianney

1786–1859 · St. John Vianney · 1 lecturas

- [Hermosa obligación del hombre: orar y amar](../r/2678b3de36.md) — San Juan María Vianney · A. Monnin, Esprit du Curé d'Ars, París 1899, pp. 87-89 · 4 de agosto San Juan María Vianney, presbítero — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
