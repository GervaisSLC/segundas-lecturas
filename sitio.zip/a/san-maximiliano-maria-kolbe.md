# San Maximiliano María Kolbe

None · None · 1 lecturas

- [El ideal de la vida apostólica es la salvación y santificación de las almas](../r/b3f383e146.md) — San Maximiliano María Kolbe · Gli scritti di Massimiliano Kolbe eroe di Oswiecim e beato della Chiesa, vol. I, Città di Vita, Florencia 1975, pp. 44-46. 113-114 · 14 de agosto San Maximiliano María Kolbe, presbítero y mártir — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
