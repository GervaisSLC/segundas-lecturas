# San Epifanio de Salamina

None · None · 1 lecturas

- [Misterios antiguos y nuevos](../r/aa2d5ece60.md) — San Epifanio de Salamina · Homilía 3 [atribuida] sobre la santa resurrección de Cristo: PG: 43, 466-470 · Jueves de la semana II de Pascua (semana 2), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
