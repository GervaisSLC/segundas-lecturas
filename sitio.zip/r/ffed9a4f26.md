# Os saluda mi espíritu y la caridad de las Iglesias

**San Ignacio de Antioquía** (c. 35–107) · Segunda lectura del Oficio de Lectura

- id: `ffed9a4f26`
- Fuente: De la carta de san Ignacio de Antioquía, obispo y mártir, a los Romanos
- Cita patrística: 9-10: Funck 1, 223
- Se lee: Sábado de la semana IV del Tiempo Ordinario (semana 4), año impar
- Escritura: [Rm 16, 1-27](../escritura/rm.md) (primera lectura del día); [1 Co 10, 33](../escritura/1co.md) (responsorio); [1 Co 9, 23](../escritura/1co.md) (responsorio)
- Temas (automáticos): [Pastores y ministerio](../temas/pastores.md), [Iglesia](../temas/iglesia.md), [Caridad y amor fraterno](../temas/caridad.md)
- Cómo citar: San Ignacio de Antioquía, 9-10: Funck 1, 223, «Os saluda mi espíritu y la caridad de las Iglesias». Liturgia de las Horas, Oficio de Lectura, segunda lectura, Sábado de la semana IV del Tiempo Ordinario (semana 4), año impar. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-ffed9a4f26](../index.html#r-ffed9a4f26)
- Traducción inglesa antigua (dominio público, no litúrgica): https://www.newadvent.org/fathers/0107.htm
- Autor: [San Ignacio de Antioquía](../a/ignacio-antioquia.md)

## Texto

Acordaos en vuestras oraciones de la iglesia de Siria, que privada ahora de mí, no tiene otro pastor que el mismo Dios. Sólo Jesucristo y vuestro amor harán para con ella el oficio de obispo. Yo me avergüenzo de pertenecer al número de los obispos; no soy digno de ello, ya que soy el último de todos y un abortivo. Sin embargo, llegaré a ser algo, si llego a la posesión de Dios, por su misericordia.

Os saluda mi espíritu y la caridad de las Iglesias que me han acogido en el nombre de Jesucristo, y no como un transeúnte. En efecto, incluso las Iglesias que no entraban en mi itinerario corporal acudían en cada una de las ciudades por las que pasaba.

Os escribo desde Esmirna, por medio de unos efesios verdaderamente dignos de ser proclamados bienaventurados. Entre otros, está también conmigo Croco, que me es muy querido. Respecto a los que, desde Siria, me han precedido a Roma a gloria de Dios, creo que los conocéis, decidles que llegaré pronto. Todos son dignos de Dios y de vosotros, y conviene que les agasajéis en todo. Adiós. Sed fuertes hasta el fin, soportándolo todo por Jesucristo.

## Responsorio (1Co 10, 33; 9, 23)

R. Me esfuerzo por agradar a todos en todo, * sin buscar mi propio interés, sino el de todos, para que se salven.  
V. Todo lo hago por el evangelio, para ser partícipe con ellos.  
R. Sin buscar mi propio interés, sino el de todos, para que se salven.  

## Oración

Señor, concédenos, amarte con todo el corazón y que nuestro amor se extienda también a todos los hombres. Por nuestro Señor Jesucristo.

## Primera lectura del día

**De la carta del apóstol san Pablo a los Romanos 16, 1-27** — *Recomendaciones, saludos y doxología*

Hermanos:

Os recomiendo a Febe, nuestra hermana, que además es servidora de la Iglesia que está en Cencreas; recibidla en el Señor de un modo que sea digno de los santos y asistidla en cualquier cosa que necesite de vosotros. Pues también ella ha sido protectora de muchos, e incluso de mí mismo.

Saludad a Prisca y Áquila, mis colaboradores en la obra de Cristo Jesús, que expusieron sus cabezas por salvar mi vida; no soy yo solo quien les está agradecido, también todas las iglesias de los gentiles. Saludad asimismo a la Iglesia que se reúne en su casa.

Saludad a mi querido Epéneto, primicias de Asia para Cristo. Saludad a María, que con tanto afán ha trabajado en vuestro favor. Saludad a Andrónico y a Junia, mis parientes y compañeros de prisión, que son ilustres entre los apóstoles y además llegaron a Cristo antes que yo.

Saludad a Ampliato, a quien quiero en el Señor. Saludad a Urbano, colaborador nuestro en la obra de Cristo, y a mi querido Estaquio. Saludad a Apeles, acreditado en Cristo. Saludad a la familia de Aristóbulo. Saludad a Herodión, mi pariente.

De la familia de Narciso saludad a los que están en el Señor. Saludad a Trifena y Trifosa, que han trabajado afanosamente en el Señor. Saludad a la querida Pérside, que ha trabajado con mucho afán en el Señor. Saludad a Rufo, elegido en el Señor, y a su madre, que es también madre mía.

Saludad a Asíncrito, Flegón, Hermes, Patrobas, Hermas y a todos los hermanos que están con ellos. Saludad a Filólogo y a Julia, a Nereo y a su hermana, y a Olimpas y a todos los santos que están con ellos. Saludaos unos a otros con el beso santo. Os saludan todas las Iglesias de Cristo.

Os ruego, hermanos, que tengáis cuidado con los que crean disensiones y escándalos contra la doctrina que vosotros habéis aprendido; alejaos de ellos. Pues estos tales no sirven a Cristo nuestro Señor sino a su vientre, y a través de palabras suaves y de lisonjas seducen los corazones de los ingenuos.

La fama de vuestra obediencia se ha divulgado por todas partes; de aquí que yo me alegre por vosotros; pero deseo que seáis sensatos para el bien e inmunes al mal. Y el Dios de la paz aplastará pronto a Satanás bajo vuestros pies. Que la gracia de nuestro Señor Jesús esté con vosotros.

Os saluda Timoteo, mi colaborador, y Lucio, Jasón y Sosípatro, mis parientes. Yo, Tercio, que escribo la carta, os saludo en el Señor. Os saluda Gayo, que me hospeda a mí y a toda esta Iglesia. Os saluda Erasto, tesorero de la ciudad, y Cuarto, el hermano.

Al que puede consolidaros según mi Evangelio y el mensaje de Jesucristo que proclamo, conforme a la revelación del misterio mantenido en secreto durante siglos eternos y manifestado ahora mediante las Escrituras proféticas, dado a conocer según disposición del Dios eterno para que todas las gentes llegaran a la obediencia de la fe; a Dios, único Sabio, por Jesucristo, la gloria por los siglos de los siglos. Amén.

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
