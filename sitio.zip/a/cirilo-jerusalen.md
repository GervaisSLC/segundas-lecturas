# San Cirilo de Jerusalén

c. 313–386 · St. Cyril of Jerusalem · 10 lecturas

- [Las dos venidas de Cristo](../r/74b4e0fdd3.md) — San Cirilo de Jerusalén · Catequesis 15,1-3: PG 33, 870-874 · Domingo de la semana I de Adviento (semana 1), año par
- [El agua viva del Espíritu Santo](../r/35035c1f6b.md) — San Cirilo de Jerusalén · Catequesis sobre el Espíritu Santo, 16, 1, 11-12. 16: PG 33, 931-935. 939-942 · Domingo de la semana VII de Pascua (semana 7) - Año A: Jn 17, 1-11a, año par
- [Preparad limpios los vasos para recibir al Espíritu Santo](../r/70548f1247.md) — San Cirilo de Jerusalén · Catequesis 3 1-3: PG 33, 426-430 · 18 de marzo. San Cirilo de JerusalénObispo y Doctor de la Iglesia — Santoral, año par
- [La Iglesia o convocación del pueblo de Dios](../r/d9e6653345.md) — San Cirilo de Jerusalén · Catequesis 18, 23 25: PG 33,1043-1047 · Miércoles de la semana VIII del Tiempo Ordinario (semana 8), año impar
- [La Iglesia es la esposa de Cristo](../r/f37a58b599.md) — San Cirilo de Jerusalén · Catequesis 18, 26-29: PG 33,1047-1050 · Jueves de la semana VIII del Tiempo Ordinario (semana 8), año impar
- [La salvación proviene de la misericordia de Dios](../r/0462812923.md) — San Cirilo de Jerusalén · Catequesis 2, 5-8: Edit Reisch 1, 445-449 · Viernes de la semana XIII del Tiempo Ordinario (semana 13), año impar
- [Reconoce el mal que has hecho, ahora que es el tiempo propicio](../r/e98c202850.md) — San Cirilo de Jerusalén · Catequesis 1, 2-3. 5-6: PG 33, 371. 375-378 · Viernes de la semana XV del Tiempo Ordinario (semana 15), año impar
- [Que la cruz sea tu gozo también en tiempo de persecución](../r/48bf85a08e.md) — San Cirilo de Jerusalén · Catequesis 13, 1.3.6.23: PG 33, 771-774.779.799.802 · Jueves de la semana VI del Tiempo Ordinario (semana 6), año par
- [La fe realiza obras que superan las fuerzas humanas](../r/f03cdc315f.md) — San Cirilo de Jerusalén · Catequesis 5, 10-11, sobre la fe y el símbolo : PG 33, 518-519 · Sábado de la semana XXXII del Tiempo Ordinario (semana 32), año par
- [Sobre el símbolo de la fe](../r/1d590d4f81.md) — San Cirilo de Jerusalén · Catequesis 5, 12-13, sobre la fe y el símbolo : PG 33, 519-523 · Domingo de la semana XXXIII del Tiempo Ordinario (semana 33), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
