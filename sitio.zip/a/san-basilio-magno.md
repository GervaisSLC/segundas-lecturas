# San Basilio Magno

None · None · 2 lecturas

- [Si os mantenéis en mi palabra, seréis de verdad discípulos míos](../r/2eb4de2277.md) — San Basilio Magno · Lib 1, 1-2: PG 31,1514-1515 · Sábado de la semana XXVII del Tiempo Ordinario (semana 27), año par
- [Vivo yo, pero no soy yo, es Cristo quien vive en mí](../r/f77a852684.md) — San Basilio Magno · Lib 1, 2.3: PG 31,1515-1519 · Domingo de la semana XXVIII del Tiempo Ordinario (semana 28), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
