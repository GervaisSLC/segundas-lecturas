# San Vicente de Paúl

1581–1660 · St. Vincent de Paul · 1 lecturas

- [El servicio a los pobres ha de ser preferido a todo](../r/f4e8746467.md) — San Vicente de Paúl · Carta 2.546: Correspondance, entretiens, documents, París 1922-1925, 7 · 27 de septiembre San Vicente de Paúl, presbítero — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
