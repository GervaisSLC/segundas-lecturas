# La oración es luz del alma

**San Juan Crisóstomo** (c. 349–407) · Segunda lectura del Oficio de Lectura

- id: `b8f4cab50c`
- Fuente: De las Homilías de San Juan Crisóstomo, obispo
- Cita patrística: Homilía 6 sobre la oración, suplemento: PG 64, 462-466
- Se lee: Viernes después de Ceniza — Cuaresma y Pascua, año par; Domingo de la semana XXVI del Tiempo Ordinario (semana 26), año par
- Escritura: [Ex 2, 1-22](../escritura/ex.md) (primera lectura del día); [Lm 5, 20-21](../escritura/lm.md) (responsorio); [Mt 8, 25](../escritura/mt.md) (responsorio)
- Temas (automáticos): [Oración](../temas/oracion.md), [Contemplación y conocimiento de Dios](../temas/contemplacion.md)
- Cómo citar: San Juan Crisóstomo, Homilía 6 sobre la oración, suplemento: PG 64, 462-466, «La oración es luz del alma». Liturgia de las Horas, Oficio de Lectura, segunda lectura, Viernes después de Ceniza — Cuaresma y Pascua, año par. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-b8f4cab50c](../index.html#r-b8f4cab50c)
- Autor: [San Juan Crisóstomo](../a/juan-crisostomo.md)

## Texto

El sumo bien está en la plegaria y en el diálogo con Dios, porque equivale a una íntima unión con él: y así como los ojos del cuerpo se iluminan cuando contemplan la luz, así también el alma dirigida hacia Dios se ilumina con su inefable luz. Una plegaria, por supuesto, que no sea de rutina, sino hecha de corazón; que no esté limitada a un tiempo concreto o a unas horas determinadas, sino que se prolongue día y noche sin interrupción.

Conviene, en efecto, que elevemos la mente a Dios no sólo cuando nos dedicamos expresamente a la oración, sino también cuando atendemos a otras ocupaciones, como el cuidado de los pobres o las útiles tareas de la munificencia, en todas las cuales debemos mezclar el anhelo y el recuerdo de Dios, de modo que todas nuestras obras, como si estuvieran condimentadas con la sal del amor de Dios, se conviertan en un alimento dulcísimo para el Señor. Pero sólo podremos disfrutar perpetuamente de la abundancia que de Dios brota, si le dedicamos mucho tiempo.

La oración es luz del alma, verdadero conocimiento de Dios, mediadora entre Dios y los hombres. Hace que el alma se eleve hasta el cielo y abrace a Dios con inefables abrazos, apeteciendo la leche divina, como el niño que, llorando, llama a su madre; por la oración, el alma expone sus propios deseos y recibe dones mejores que toda la naturaleza visible.

Pues la oración se presenta ante Dios como venerable intermediaria, alegra nuestro espíritu y tranquiliza sus afectos. Me estoy refiriendo a la oración de verdad, no a las simples palabras: la oración que es un deseo de Dios, una inefable piedad, no otorgada por los hombres, sino concedida por la gracia divina, de la que también dice el Apóstol: Nosotros no sabemos pedir lo que nos conviene, pero el Espíritu mismo intercede por nosotros con gemidos inefables.

El don de semejante súplica, cuando Dios lo otorga a alguien, es una riqueza inagotable y un alimento celestial que satura el alma; quien lo saborea se enciende en un deseo indeficiente del Señor, como en un fuego ardiente que inflama su alma.

Cuando quieras reconstruir en ti aquella morada que Dios se edificó en el primer hombre, adórnate con la modestia y la humildad y hazte resplandeciente con la luz de la justicia; decora tu ser con buenas obras, como con oro acrisolado, y embellécelo con la fe y la grandeza de alma, a manera de muros y piedras; y, por encima de todo, como quien pone la cúspide para coronar un edificio, coloca la oración, a fin de preparar a Dios una casa perfecta y poderle recibir en ella como si fuera una mansión regia y espléndida, ya que, por la gracia divina, es como si poseyeras la misma imagen de Dios colocada en el templo del alma.

## Responsorio (Lm 5, 20-21a; Mt 8, 25)

R. ¿Por qué has de olvidarnos para siempre? ¿Por qué toda la vida abandonarnos? * Haz que volvamos a ti, Señor, y volveremos.  
V. ¡Señor, sálvanos, que perecemos!  
R. Haz que volvamos a ti, Señor, y volveremos.  

## Oración

Confírmanos, Señor, en el espíritu de penitencia con que hemos empezado la Cuaresma, y que la austeridad exterior que practicamos vaya siempre acompañada por la sinceridad de corazón. Por nuestro Señor Jesucristo.

## Primera lectura del día

**Del libro del Éxodo 2, 1-22** — *Nacimiento y huida de Moisés*

En aquellos días, un hombre de la tribu de Leví se casó con una mujer de la misma tribu. Ella concibió y dio a luz un niño. Viendo que era hermoso, lo tuvo escondido tres meses. Pero, no pudiendo tenerlo escondido por más tiempo, tomó una cesta de mimbre, la embadurnó de barro y pez, colocó en ella a la criatura y la depositó entre los juncos, junto a la orilla del Nilo. Una hermana del niño observaba a distancia para ver en qué paraba todo aquello.

La hija del faraón bajó a bañarse en el Nilo, mientras sus criadas la seguían por la orilla del río. Al descubrir ella la cesta entre los juncos, mandó una criada a recogerla. La abrió, miró dentro y encontró un niño llorando.

Conmovida comentó:

«Es un niño de los hebreos».

Entonces la hermana del niño dijo a la hija del faraón:

«¿Quieres que vaya a buscarle una nodriza hebrea que críe al niño?».

Respondió la hija del faraón:

«Vete».

La muchacha fue y llamó a la madre del niño.

La hija del faraón le dijo:

«Llévate al niño y críamelo, y yo te pagaré».

La mujer tomó al niño y lo crió.

Cuando creció el muchacho, se lo llevó a la hija del faraón, que lo adoptó como hijo y lo llamó Moisés, diciendo: «lo he sacado del agua».

Pasaron los años. Un día, cuando Moisés ya era mayor, fue a donde estaban sus hermanos y los encontró transportando cargas. Y vio cómo un egipcio mataba a un hebreo, uno de sus hermanos. Miró a un lado y a otro y, viendo que no había nadie, mató al egipcio y lo enterró en la arena.

Al día siguiente salió y encontró a dos hebreos riñendo y dijo al culpable:

«¿Por qué golpeas a tu compañero?».

Él le contestó:

«¿Quién te ha nombrado jefe y juez nuestro? ¿Es que pretendes matarme como mataste al egipcio?».

Moisés se asustó y pensó:

«Seguro que saben lo ocurrido».

Cuando el faraón se enteró del hecho, buscó a Moisés para matarlo.

Pero Moisés huyó del faraón y se refugió en la tierra de Madián. Allí se sentó junto a un pozo. El sacerdote de Madián tenía siete hijas, que salían a sacar agua y a llenar los abrevaderos para abrevar el rebaño de su padre. Llegaron unos pastores e intentaron echarlas. Entonces Moisés se levantó, defendió a las muchachas y abrevó su rebaño.

Ellas volvieron a casa de su padre Reuel, que les preguntó:

«¿Cómo habéis vuelto hoy tan pronto?».

Contestaron:

«Un egipcio nos ha librado de los pastores, nos ha sacado agua y ha abrevado el rebaño».

Dijo él a sus hijas:

«¿Dónde está?, ¿cómo lo habéis dejado marchar? Llamadlo para que venga a comer».

Moisés accedió a vivir con aquel hombre, que le dio a su hija Séfora por esposa. Ella dio a luz a un niño y Moisés lo llamó Guersón, diciendo: «Soy emigrante en tierra extranjera».

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
