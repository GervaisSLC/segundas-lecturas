# Catálogo de lecturas

1184 lecturas, agrupadas por autor. Formato: título — autor · cita · día en que se lee.

## Actas y escritos anónimos

- [La voz de la tórtola se ha escuchado en nuestra tierra](r/381f17998a.md) — Actas y escritos anónimos · «Nicán Mupohua», 12ª edición, Buena Prensa, México, D. F., 1971, pp. 3-19. 21 · MES DE DiCIEMBRE — Santoral, año par
- [Nos fue enviado el Señor como redentor, vida y salvación](r/6400a7b0f1.md) — Actas y escritos anónimos · Sermón 12: PLS 4, 770-771 · 22 de Diciembre — Santoral, año impar
- [El descenso del Señor al abismo](r/7f9072e0fa.md) — Actas y escritos anónimos · PG 43, 439. 451. 462-463 · Sábado Santo — Cuaresma y Pascua, año par
- [La Pascua espiritual](r/c9ce7e6e34.md) — Actas y escritos anónimos · PG 59, 723-724 · Domingo de la Octava de Pascua — Cuaresma y Pascua, año par
- [El bautismo, un injerto para la inmortalidad](r/571941439e.md) — Actas y escritos anónimos · PG 28, 1080-1082 · Martes de la semana II de Pascua (semana 2), año par
- [La unidad de la Iglesia se manifiesta en la pluralidad de lenguas](r/9295660c2b.md) — Actas y escritos anónimos · Sermón 8, 1-3: PL 65, 743-744 · Sábado de la semana VII de Pascua (semana 7), año par
- [Seréis mis testigos](r/896dfc62cf.md) — Actas y escritos anónimos · Cap. 14,109-110: Acta Sanctorum Februarii,1, 769 · 6 de febrero. San Pablo Miki y Compañeros, Mártires — Santoral, año par
- [Acrecienta tu Iglesia y reúne a todos sus miembros en la unidad](r/22f1964afd.md) — Actas y escritos anónimos · Cap. 18: Denkschriften der kaiserl. Akademie der Wissei schaften 19, Viena 1870, p. 246 · 14 de febrero. San Cirilo, Monje, y San Metodio, Obispo, Patronos de Europa — Santoral, año par
- [Hagamos el elogio de los hombres ilustres](r/7ae9f1b7dd.md) — Actas y escritos anónimos · Monumenta Ordinis Servorum Beatae Maríae Virginis, 1, 3. 5. 6. 9.11: pp. 71 ss. · Mes de febrero — Santoral, año par
- [Como un sacrificio enjundioso y agradable](r/4d7cf6151b.md) — Actas y escritos anónimos · Caps. 13, 2-5, 2: Funk 1, 297-299 · 23 de febrero. San Policarpo, Obispo y Mártir — Santoral, año par
- [Invirtió su tesoro según el mandato del Altísimo](r/5dc0bc6209.md) — Actas y escritos anónimos · Caps. 2-3: Acta Sanctorum Martii 1, 347-348 · 4 de marzo. San Casimiro — Santoral, año par
- [Llamados y elegidos para gloria del Señor](r/c29a94cdbf.md) — Actas y escritos anónimos · Caps. 18. 20-21: edición van Beek, Nimega 1936, pp. 42. 46-52 · 7 de marzo. Santas Perpetua y Felicidad, Mártires — Santoral, año par
- [La paciencia y caridad de Santa Francisca](r/cf156644ef.md) — Actas y escritos anónimos · Caps. 6-7: Acta Sanctorum Martii 2, *188—*189 · 9 de marzo. Santa Francisca Romana, Religiosa — Santoral, año par
- [Se abrazó a la cruz con todo su cuerpo](r/6888b00d7f.md) — Actas y escritos anónimos · Acta Sanctorum, Aprilis, III, pp. 186-187). · El mismo día 23 de abril. San Adalberto, Obispo y Mártir — Santoral, año par
- [Hombre fiel por su nombre y por su vida](r/6742f68988.md) — Actas y escritos anónimos · 24 de abril. San Fidel de Sigmaringa, Presbítero y Mártir — Santoral, año par
- [Fue un prelado de grandísima caridad y amor de Dios](r/45f4053157.md) — Actas y escritos anónimos · Archivo Secreto Vaticano, Riti-Proces., vol. 1581). · Mes de abril — Santoral, año par
- [La sangre de los mártires es semilla de cristianos](r/d09503e9f3.md) — Actas y escritos anónimos · 28 de abril. San Pedro Chanel, Presbítero y Mártir — Santoral, año par
- [El amor lo puede todo](r/f00fa1090a.md) — Actas y escritos anónimos · 22 de mayo. Santa Joaquina Vedruna, Religiosa — Santoral, año par
- [El poder temporal puesto al servicio de Dios y de la Iglesia](r/a21903eec0.md) — Actas y escritos anónimos · 30 de mayo. San Fernando — Santoral, año par
- [](r/f9f3790f54.md) — Actas y escritos anónimos · 6 de junio. San Norberto, Obispo — Santoral, año par
- [Cristo, autor de la resurrección y de la vida](r/7a644be5b5.md) — Actas y escritos anónimos · Sermón 35, 6-9: PL 17 [ed. 1879], 696-697 · Miércoles de la Octava de Pascua — Cuaresma y Pascua, año impar
- [Por la unción recibida, los cristianos están consagrados de por vida a la cruz de Cristo](r/49deef3d29.md) — Actas y escritos anónimos · Homilía 17, 1-4: PG 34, 623-626 · Semana XVI del Tiempo Ordinario, año impar
- [Alegría en el martirio](r/1a55b69402.md) — Actas y escritos anónimos · Caps. 3-4 · 20 de enero San Fructuoso, Obispo y Mártir y sus Diáconos, Santos Augurio y Eulogio — Santoral, año impar
- [Proveía a la paz y tranquilidad de la Iglesia](r/48d1a10586.md) — Actas y escritos anónimos · MGH, Scriptores 4, 792-799 · Tiempo Ordinario, año impar
- [Servidor de Cristo en la persona de los hermanos](r/511d93b32e.md) — Actas y escritos anónimos · S. Cicatelli, Vita del P. Camillo de Lellis, Viterbo 1615 · 14 de julio San Camilo de Lelis, Presbítero — Santoral, año impar
- [¡Dios, vida mía, qué suave eres: seas siempre bendito!](r/b3b0350d74.md) — Actas y escritos anónimos · Acta Sanctorum julii V, París 1868, pp. 884-886). · El mismo día 14 de julio San Francisco Solano, Presbítero — Tiempo Ordinario, año impar
- [Llegaréis a vuestra plenitud, según la plenitud total de Cristo](r/f9b2209e6f.md) — Actas y escritos anónimos · 18, 7-11: PG 34, 639-642 · Viernes de la semana VI del Tiempo Ordinario (semana 6), año par
- [Sobre el fundamento de la oración](r/ed22e2548f.md) — Actas y escritos anónimos · Hom 6, 1-3: PG 34, 518-519 · Jueves de la semana XII del Tiempo Ordinario (semana 12), año par
- [Conviene orar y hacer votos a Dios continua y atentamente](r/eaaa797aeb.md) — Actas y escritos anónimos · Hom 33: PG 34, 741-743 · Lunes de la semana XIII del Tiempo Ordinario (semana 13), año par
- [Haz penitencia y vuelve al Señor](r/df54d31b6c.md) — Actas y escritos anónimos · Patericon 196: CSCO, Scriptores Aethiopici, t. 54, 118-121 · Sábado de la semana XIII del Tiempo Ordinario (semana 13), año par
- [Considérate pecador si quieres llegar a ser justo](r/087e405f59.md) — Actas y escritos anónimos · Patericon 142b: CSCO, Scriptores Aethiopici, t. 54, 62-64 · Viernes de la semana XIV del Tiempo Ordinario (semana 14), año par
- [Sobre la perfecta fe en Dios](r/a92602f258.md) — Actas y escritos anónimos · Homilía 48,1-6: PG 34, 807-811 · Domingo de la semana XXV del Tiempo Ordinario (semana 25), año impar
- [Éste es el camino que recorrió Cristo](r/545404835a.md) — Actas y escritos anónimos · PL 3, 312-313 · Semana XXX DEL TIEMPO ORDINARIO, año impar
- [Hablaba con Dios o de Dios](r/64341a1ba6.md) — Actas y escritos anónimos · Libellus de principiis Ordinis Praedicatorum; Acta canonizationis sancti Dominici: Monumenta Ordinis Praedicatorum historica 16, Roma 1935, pp: 30ss.146-147 · 8 de agosto Santo Domingo de Guzmán, presbítero — Santoral, año impar
- [Es fuerte el amor como la muerte](r/49ed6516bb.md) — Actas y escritos anónimos · Françoise-Madeleine de Chaugy, Mémoires sur la vie et les vertus de sainte Jeanne- Françoise de Chantal, III, 3: 3.a edición, París 1853, pp. 306-307 · 12 de agosto Santa Juana Francisca de Chantal, religiosa — Santoral, año impar
- [Cuando un rey juzga lealmente a los desvalidos, su trono está siempre firme](r/811539dbd2.md) — Actas y escritos anónimos · Edición M. Weingart, Praga 1934, 974-983 · 28 de septiembre San Wenceslao, mártir — Santoral, año impar
- [El Pilar, lugar privilegiado de oración t de gracia](r/12e42598a5.md) — Actas y escritos anónimos · 12 de octubre NUESTRA SEÑORA DEL PILAR — Santoral, año impar
- [Tendía siempre hacia Dios](r/3d4c2ac009.md) — Actas y escritos anónimos · Acta Sanctorum Octobris 8, 1853, 201-202 · 16 de octubre Santa Eduvigis, religiosa — Santoral, año impar
- [Isabel reconoció y amó a Cristo en la persona de los pobres](r/1096e82e1a.md) — Actas y escritos anónimos · Al Sumo pontífice, año 1232: A. Wyss, Hessisches Urkundenbuch 1, Leipzig 1879, 31-35 · 17 de noviembre Santa Isabel de Hungría — Santoral, año impar
- [Que nadie desespere por la gravedad de sus pecados](r/2e16f6e3c8.md) — Actas y escritos anónimos · Sermón 4, 2-7: SC 161, 170-175 · Martes de la semana XXI del Tiempo Ordinario (semana 21), año par
- [Cristo quiso salvar a los que estaban a punto de perecer](r/9044b9826e.md) — Actas y escritos anónimos · Caps 1, 1-2,7: Funk 1, 145-149 · Jueves de la semana XXXIII del Tiempo Ordinario (semana 33), año par
- [Confesemos a Dios con nuestras obras](r/342902a7bd.md) — Actas y escritos anónimos · Caps 3-4, 5; 7, 1-6: Funk 1, 149-152 · Viernes de la semana XXXIII del Tiempo Ordinario (semana 33), año par
- [El arrepentimiento de un corazón sincero](r/d20a4e07ea.md) — Actas y escritos anónimos · Caps 8, 1-9,11: Funk 1, 152-156 · Sábado de la semana XXXIII del Tiempo Ordinario (semana 33), año par
- [Perseveremos en la esperanza](r/488932356d.md) — Actas y escritos anónimos · 10, 1-12,1; 13, 1: Funk 1, 157-159 · Domingo de la semana XXXIV del Tiempo Ordinario (semana 34) - Año A: Mt 25, 31-46, año par
- [La Iglesia viva es el cuerpo de Cristo](r/b6823698de.md) — Actas y escritos anónimos · Caps 13, 2-14, 5: Funk 1, 159-161 · Martes de la semana XXXIV del Tiempo Ordinario (semana 34), año par
- [Convirtámonos a Dios, que nos llama](r/fcca96fd11.md) — Actas y escritos anónimos · Caps 15, 1-17, 2: Funk 1, 161-167 · Miércoles de la semana XXXIV del Tiempo Ordinario (semana 34), año par
- [Practiquemos el bien, para que al fin nos salvemos](r/71016dbe6c.md) — Actas y escritos anónimos · Caps 18,1—20,5 Funk 1, 167-171 · Jueves de la semana XXXIV del Tiempo Ordinario (semana 34), año par

## Afraates

- [La circuncisión del corazón](r/d7258f781c.md) — Afraates · Demostración 11, Sobre la circuncisión, 11-12: PS 1, 498-503 · Miércoles de la semana I de Cuaresma (semana 1), año par

## San Agustín de Hipona

- [A Dios no le gusta condenar, sino salvar](r/7509359350.md) — San Agustín de Hipona · Sermón 18, 1-2: CCL 61, 245-246 · Domingo de la semana I de Adviento (semana 1), año par
- [Convertíos, porque está cerca el Reino de los cielos](r/6aaa580a0d.md) — San Agustín de Hipona · Serm. 109 1 : PL 38,636 · Domingo de la semana II de Adviento (semana 2), año par
- [Las promesas de Dios se nos conceden por su Hijo](r/146fff1983.md) — San Agustín de Hipona · Sal 109 1-3: CCL 40, 1061-1063 · Miércoles de la semana II de Adviento (semana 2), año par
- [Juan era la voz, Cristo es la Palabra](r/c0b46ce61f.md) — San Agustín de Hipona · Sermón 293 3: PL 38, 1328-1329 · Domingo de la semana III de Adviento (semana 3), año par
- [Tu deseo es tu oración](r/78252551b4.md) — San Agustín de Hipona · Salmo 37, 13-14: CCL 38, 391-392 · Viernes de la semana III de Adviento (semana 3), año par
- [La fidelidad brota de la tierra y la justicia mira desde el cielo](r/16ce118d06.md) — San Agustín de Hipona · Sermón 185 PL 38, 997-999 · 24 de Diciembre — Santoral, año par
- [La misma Vida se ha manifestado en la carne](r/97ed0ea4b9.md) — San Agustín de Hipona · Tratado 1,1. 3: PL 35,1978.1980 · 27 de Diciembre. San Juan Apóstol y Evangelista — Santoral, año par
- [Éste es el trabajo que Dios quiere: que creáis en el que Él ha enviado](r/fdba8b81d1.md) — San Agustín de Hipona · Sermón 49 sobre el Antiguo Testamento, 2-3 CCL 41, 614-616 · 11 de Enero o Viernes después del Domingo de Epifanía — Santoral, año par
- [Que la fuerza del amor supere el pesar por la muerte](r/7c42633cea.md) — San Agustín de Hipona · Tratado 123, 5: CCL 36, 678-680 · 6 de diciembre. San Nicolás, Obispo — Santoral, año par
- [Damos culto a los mártires con un culto de amor y participación](r/63dab05df0.md) — San Agustín de Hipona · Lib. 20, 21: CSEL 25, 562-563 · 11 de diciembre. San Dámaso I, papa — Santoral, año par
- [Edificación y consagración de la casa de Dios en nosotros](r/07fa52d6fc.md) — San Agustín de Hipona · Sermón 336, 1. 6: PL 38 [ed. 1861], 1471-1472. 1475 · Común de la dedicación de una iglesia — Comunes, año par
- [Preciosa es la muerte de los mártires, comprada con el precio de la muerte de Cristo](r/737c0b2c30.md) — San Agustín de Hipona · Sermón 329, en el natalicio de los mártires, 1-2: PL 38,1454-1456 · Para un mártir — Comunes, año par
- [Sobre la vocación universal a la santidad](r/a7d31d4110.md) — San Agustín de Hipona · Sermón 96,1. 4. 9: PL 38, 584. 586. 588 · Común de santos varones — Comunes, año par
- [El deseado de las naciones](r/2ad10d5549.md) — San Agustín de Hipona · Sermón 20,1: Comentario al Salmo 118, 81 · Domingo de la semana III de Adviento (semana 3), año impar
- [El doble precepto de la caridad](r/415a57d86e.md) — San Agustín de Hipona · Tratado 17, 7-9: CCL 36, 174-175 · Ferias anteriores a la Epifanía — Adviento y Navidad, año impar
- [Seremos saciados con la visión de la Palabra](r/55b6bf2fd1.md) — San Agustín de Hipona · Sermón 194, 3-4: PL 38, 1016-1017 · Ferias anteriores a la Epifanía — Adviento y Navidad, año impar
- [En Cristo fuimos tentados, en él vencimos al diablo](r/de2cf91fb5.md) — San Agustín de Hipona · Comentario sobre el salmo 60, 2-3: CCL 39, 766 · Semana I de Cuaresma — Cuaresma y Pascua, año par
- [La pasión de Cristo como premio de la piedad](r/15aaa03b4f.md) — San Agustín de Hipona · Carta 140, 13-15, Libro sobre la gracia del nuevo Testamento: CSEL 44, 164-166 · Semana I de Cuaresma — Cuaresma y Pascua, año par
- [La pasión de todo el cuerpo de Cristo](r/c2d0870d12.md) — San Agustín de Hipona · Comentario sobre el Salmo 140, 4-6: CCL 40, 2028-2029 · Martes de la semana II de Cuaresma (semana 2), año par
- [Llega una mujer de Samaria a sacar agua](r/e18bd75a0d.md) — San Agustín de Hipona · Tratado 15, 10-12.16-17: CCL 36, 154-156 · Semana III de Cuaresma — Cuaresma y Pascua, año par
- [Somos las piedras vivas con las que se edifica el templo de Dios](r/2f18b12780.md) — San Agustín de Hipona · Comentario sobre el salmo 130, nn. 1-3: CCL 40, 1198-1200 · Semana III de Cuaresma — Cuaresma y Pascua, año par
- [Esta cruz no es cruz de solos cuarenta días, sino de toda la vida](r/f8c9c8f957.md) — San Agustín de Hipona · Sermón 205, 1: 1 de Cuaresma: Edit. Maurist., t. 5, 919-920 · Domingo de la semana III de Cuaresma (semana 3) - Año A: Jn 4, 5-42, año par
- [Me alejé mucho, y tú estabas aquí](r/20f6f15993.md) — San Agustín de Hipona · Comentario sobre el salmo 138, nn. 5-6: CCL 40, 1992-1993 · Semana IV de Cuaresma — Cuaresma y Pascua, año par
- [Por nosotros los hombres, envió Dios a su único Hijo, para ser muerto por nosotros y para nosotros](r/5af1abe6e9.md) — San Agustín de Hipona · 31-32. 33.39: PL 40, 333-334. 338 · Viernes de la semana V de Cuaresma (semana 5), año par
- [Gloriémonos también nosotros en la cruz de nuestro Señor Jesucristo](r/9fae8afd89.md) — San Agustín de Hipona · PLS 2, 545-546 · Sábado de la semana V de Cuaresma (semana 5), año par
- [Si aquella sangre no hubiese sido derramada, el mundo no hubiera sido redimido](r/ef03a2b0aa.md) — San Agustín de Hipona · Tratado 37, 9-10: CCL 36, 336-338 · Domingo de Ramos en la Pasión del Señor — Cuaresma y Pascua, año par
- [Gloriémonos también nosotros en la cruz del Señor](r/9d3c1c5d11.md) — San Agustín de Hipona · Sermón Güelferbitano 3: PLS 2, 545-546 · Domingo de Ramos - Año A: Mt 21, 1-11 — Cuaresma y Pascua, año par
- [La plenitud del amor](r/94d6859b80.md) — San Agustín de Hipona · Tratado 84, 1-2: CCL 36, 536-538 · Miércoles Santo — Cuaresma y Pascua, año par
- [El que era inmortal se revistió de mortalidad para poder morir por nosotros](r/e099b4ea76.md) — San Agustín de Hipona · Sermón sobre el Antiguo Testamento, 23A, 2-3: CCL 41, 322 · Jueves Santo — Cuaresma y Pascua, año par
- [¿Qué mejor noticia podemos dar que ésta: el Salvador ha resucitado?](r/fc844bb028.md) — San Agustín de Hipona · Sermón 45, 5 sobre el Antiguo Testamento: CCL 41, 519-520 · Sábado de la Octava de Pascua — Cuaresma y Pascua, año par
- [Gran mérito tiene nuestra fe](r/105f657142.md) — San Agustín de Hipona · Sermón 88, 1-2: Edit Maurist t. 5 469-470 · Domingo de la Octava de Pascua — Cuaresma y Pascua, año par
- [No es lícito mentir a Dios](r/b79c98b140.md) — San Agustín de Hipona · Sermón 148: PL 38, 799-800 · Domingo de la semana II de Pascua (semana 2) - Año A: Jn 20, 19-31, año par
- [Cantemos al Señor el cántico del amor](r/6da14eecd8.md) — San Agustín de Hipona · Sermón 34, 13. 56: CCL 41, 424. 426 · Domingo de la semana III de Pascua (semana 3), año par
- [Sobre la resurrección de Cristo](r/d366e72497.md) — San Agustín de Hipona · Sermón 234,1-2: Edit Maurist t. 5, 987-988 · Domingo de la semana III de Pascua (semana 3), año par
- [Interrogando a Pedro, el Señor nos interroga a todos](r/5ccc1963f5.md) — San Agustín de Hipona · Sermón Güelferbitano 16 (2-3: PLS 2, 580-581 · Domingo de la semana III de Pascua (semana 3), año par
- [Nadie opta por una vida nueva sin antes arrepentirse de la pasada](r/4d45e5d467.md) — San Agustín de Hipona · Sermón 352, 2: PL 39, 1550-1551 · Domingo de la semana IV de Pascua (semana 4), año par
- [La ley vivificante del Espíritu en Cristo Jesús](r/2e06527521.md) — San Agustín de Hipona · Sermón 155, 65-66: PL 38, 843-844 · Miércoles de la semana IV de Pascua (semana 4), año par
- [El Señor creó y redimió a sus siervos](r/49e81f538f.md) — San Agustín de Hipona · Sermón 130, 2: Edit. Maurist. t. 5, 637-638 · Jueves de la semana IV de Pascua (semana 4), año par
- [El mandamiento nuevo](r/90887759f2.md) — San Agustín de Hipona · Tratado 65, 1-3: CCL 36, 490-492 · Domingo de la semana V de Pascua (semana 5), año par
- [El aleluya pascual](r/7d316b21f6.md) — San Agustín de Hipona · Salmo 148, 1-2: CCL 40, 2165-2166 · Sábado de la semana V de Pascua (semana 5), año par
- [Amamos a Cristo en la medida en que guardamos sus mandamientos](r/fdb02dc490.md) — San Agustín de Hipona · Tratado sobre el evangelio de san Juan, 82, 1-4: CCL 36, 532-534 · Domingo de la semana VI de Pascua (semana 6), año par
- [Nadie ha subido al cielo sino aquel que ha bajado del cielo](r/b30382d55d.md) — San Agustín de Hipona · Sermón Mai 98, Sobre la Ascensión del Señor, 1-2: PLS 2, 494-495 · Solemnidad — Cuaresma y Pascua, año par
- [Creemos en Jesús, a quien no hemos visto](r/3f8f65031e.md) — San Agustín de Hipona · Tratado 4 sobre la primera carta de san Juan, 2-3: SC 75, 220-224 · Solemnidad — Cuaresma y Pascua, año par
- [En vosotros se realiza lo que se preanunciaba en los días de la venida del Espíritu Santo](r/890db2a56e.md) — San Agustín de Hipona · Sermón 271 : PL 38, 1245-1246 · Domingo de Pentecostés — Cuaresma y Pascua, año par
- [Bienaventurados los limpios de corazón porque ellos verán a Dios](r/7681e334e8.md) — San Agustín de Hipona · Sermón 53, 1-6: Revue bénédictine 104, 1994, 21-24 · El mismo día 8 de febrero. Santa Josefina Bakhita, Virgen — Santoral, año par
- [La Iglesia está fundada sobre la piedra que confesó Pedro](r/7a51c183a2.md) — San Agustín de Hipona · Tratado 124, 5: CCL 36, 684-685 · Mes de abril — Santoral, año par
- [La pasión de Cristo no se limita únicamente a Cristo](r/c2fa285511.md) — San Agustín de Hipona · SALMO 61, 4: CCL 39, 773-775 · 12 de mayo. San Nereo y San Aquiles, Mártires — Santoral, año par
- [Sembrad siempre buenas obras](r/353503c8c8.md) — San Agustín de Hipona · Sermón Morin 11, sobre las bienaventuranzas · 15 de mayo. San Isidro, Labrador — Santoral, año par
- [Las palabras de Jesucristo permanecen en nosotros](r/911754a371.md) — San Agustín de Hipona · Tratado 81, 4: CCL 36, 531-532 · El mismo día 22 de mayo. Santa Rita de Casia, Religiosa — Santoral, año par
- [Estad siempre alegres en el Señor](r/be75181c92.md) — San Agustín de Hipona · Sermón 171,1-3. 5: PL 38, 933-935 · 26 de mayo. San Felipe Neri, Presbítero — Santoral, año par
- [Jesucristo ora por nosotros, ora en nosotros y es invocado por nosotros](r/6605249262.md) — San Agustín de Hipona · Comentario sobre el Salmo 85, n. 1: CCL 39, 1176-1177 · Sábado de la semana III de Cuaresma (semana 3), año impar
- [Todo se escribió como ya ocurrido, pero preanunciando el futuro](r/c15094bce5.md) — San Agustín de Hipona · Sermón 22, 1: Edit. Maurist. t. 5, 116-118 · Martes de la semana V de Cuaresma (semana 5), año impar
- [La plenitud del amor](r/24728f67a7.md) — San Agustín de Hipona · Tratado 84, 1-2: CCL 36, 536-538 · Viernes de la semana V de Cuaresma (semana 5), año impar
- [La nueva creación en Cristo](r/6379fd7d82.md) — San Agustín de Hipona · Sermón 8, 1, 4 en la Octava de Pascua: PL 46, 838.841 · Domingo de la Octava de Pascua — Cuaresma y Pascua, año impar
- [Sermón 234 (1-2: Edit Maurist t. 5, 987-988)](r/eac61a56e4.md) — San Agustín de Hipona · Domingo de la semana III de Pascua (semana 3), año impar
- [Esperamos la eterna felicidad de la ciudad celeste](r/d3547436b4.md) — San Agustín de Hipona · Carta 137, 16: PL 33, 523-524 · Sábado de la semana III de Pascua (semana 3), año impar
- [Cristo, luz de las naciones y cabeza de la Iglesia](r/aa13df71aa.md) — San Agustín de Hipona · Sermón 137, 1-3: PL 38, 754-756 · Miércoles de la semana IV de Pascua (semana 4), año impar
- [El amor cubre la multitud de los pecados](r/cb4d49e820.md) — San Agustín de Hipona · Tratado 1, 5-6: SC 75, 124-126 · Domingo de la semana VI de Pascua (semana 6), año impar
- [En la unidad de la caridad consiste el amor fraterno](r/52b53c044d.md) — San Agustín de Hipona · Tratado 1, 9. 12: SC 75, 132-144 · Domingo de la semana VI de Pascua (semana 6) - Año A: Jn 14, 15-21, año impar
- [El que hace la voluntad de Dios permanece para siempre](r/3ba330fd62.md) — San Agustín de Hipona · Tratado 2, 8. 9. 11. 14: SC 75, 166-181 · Martes de la semana VI de Pascua (semana 6), año impar
- [Es el momento final](r/b164a79c2a.md) — San Agustín de Hipona · Tratado 3, 1. 3. 4. 5: SC 75, 186-194 · Miércoles de la semana VI de Pascua (semana 6), año impar
- [La unción del Espíritu](r/4be3f46943.md) — San Agustín de Hipona · Tratado 4, 1-2: SC 75, 218-220 · Donde la Ascensión se celebra el Domingo — Cuaresma y Pascua, año impar
- [Toda la vida del buen cristiano es un santo deseo](r/c942faa4bc.md) — San Agustín de Hipona · Tratado 4, 4-6: SC 75, 224-232 · Viernes de la semana VI de Pascua (semana 6) antes de la Ascensión, año impar
- [No amemos de palabra y de boca, sino de verdad y con obras](r/c54ed23a22.md) — San Agustín de Hipona · Tratado 5, 11-13: SC 75, 266-271 · Sábado de la semana VI de Pascua (semana 6) antes de la Ascensión, año impar
- [Últimas palabras de Cristo antes de subir al cielo](r/9ae5524e17.md) — San Agustín de Hipona · Tratado 10, 9: SC 75, 432-436 · Solemnidad — Cuaresma y Pascua, año impar
- [Pregunta a tu corazón si hay en él un lugar para el amor fraterno](r/8fde50d24c.md) — San Agustín de Hipona · Tratado 6, 9-10: SC 75, 296-300 · Domingo de la semana VII de Pascua (semana 7), año impar
- [Por medio del Espíritu Santo el alma es purificada y alimentada](r/1c186349b4.md) — San Agustín de Hipona · Tratado 6, 11: SC 75, 300-304 · Domingo de la semana VII de Pascua (semana 7) - Año A: Jn 17, 1-11a, año impar
- [Después de la partida de Cristo, era necesario el Consolador](r/c7c17308bb.md) — San Agustín de Hipona · Tratado 94, 1-3: CCL 36, 561-563 · Martes de la semana VII de Pascua (semana 7), año impar
- [Por la caridad nos amamos mutuamente, por la caridad amamos a Dios](r/0ba6533013.md) — San Agustín de Hipona · Tratado 87, 1: CCL 36, 543-544 · Miércoles de la semana VII de Pascua (semana 7), año impar
- [Dos vidas](r/5c33060ba1.md) — San Agustín de Hipona · Tratado 124, 5. 7: CCL 36, 685-687 · Jueves de la semana VII de Pascua (semana 7), año impar
- [El amor de Dios, que ha sido derramado en nuestros corazones con el Espíritu Santo nos dará valentía para ser sus testigos](r/eaa81b8909.md) — San Agustín de Hipona · Tratado 92, 1-2: CCL 36, 555-556 · Viernes de la semana VII de Pascua (semana 7), año impar
- [Emigremos por la caridad, habitemos allá arriba.](r/f512af401c.md) — San Agustín de Hipona · Tratado 33, 9: CCL 36, 305-306 · Del comentario de san Cirilo de Alejandría, obispo, sobre el evangelio de san Juan — Tiempo Ordinario, año impar
- [El medio que separa es el pecado, el mediador que reconcilia es el Señor Jesús](r/5293bff5d8.md) — San Agustín de Hipona · Tratado 41, 4-5: CCL 36, 360 · Jueves de la semana II del Tiempo Ordinario (semana 2), año impar
- [La única descendencia de Abrahán: Cristo y la Iglesia](r/73f7393eb9.md) — San Agustín de Hipona · Lib. 1, 27-28: CSEL 84, 92-94 · Miércoles de la semana III del Tiempo Ordinario (semana 3), año impar
- [Cristo eligió para apóstoles a unos pescadores](r/b671c49b45.md) — San Agustín de Hipona · Sermón 43, 5-6: PL 38, 256-257 · Domingo de la semana V del Tiempo Ordinario (semana 5), año impar
- [Para que conservemos la inocencia en el corazón](r/5afb02b4e2.md) — San Agustín de Hipona · Sermón sobre el discurso del Monte 1, 9, 21: CCL 35, 22-23 · Domingo de la semana VI del Tiempo Ordinario (semana 6), año impar
- [Debemos amar todos a la Iglesia como a una madre](r/5ff347b3af.md) — San Agustín de Hipona · Sermón 37 sobre perícopas del Antiguo Testamento n. 2-3: CCL 41, 448-451 · Lunes de la semana VI del Tiempo Ordinario (semana 6), año impar
- [Han variado los tiempos, no la fe](r/cf0ba170ae.md) — San Agustín de Hipona · Tratado 45, 9: CCL 36, 392-393 · Sábado de la semana VI del Tiempo Ordinario (semana 6), año impar
- [Cristo es cabeza del hombre](r/4123eda5b6.md) — San Agustín de Hipona · Comentario 19-20, sobre el Salmo 44: CCL 38, 507-508 · Lunes de la semana VII del Tiempo Ordinario (semana 7), año impar
- [Somos el incienso de Cristo](r/280c02e6ee.md) — San Agustín de Hipona · Comentario 2, sobre el salmo 92: CCL 39, 1292 · Martes de la semana VII del Tiempo Ordinario (semana 7), año impar
- [Necesidad de la penitencia cotidiana](r/4c89525d86.md) — San Agustín de Hipona · Carta 265, 7-8: CSEL 57, 645-646 · Sábado de la semana VIII del Tiempo Ordinario (semana 8), año impar
- [Nuestro sábado es el gozo en el sosiego de nuestra esperanza](r/05a0e26e98.md) — San Agustín de Hipona · Comentario 1-2 sobre el Salmo 91: CCL 39, 1278-1280 · Domingo de la semana IX del Tiempo Ordinario (semana 9), año impar
- [La humilde fe del centurión](r/d54992b215.md) — San Agustín de Hipona · Sermón 62, 1.3-4: PL 38, 414-416 · Domingo de la semana IX del Tiempo Ordinario (semana 9), año impar
- [He venido a llamar a los pecadores a que se conviertan](r/5b9d807bc8.md) — San Agustín de Hipona · 1,7: CCL, 39, 733-734 · Domingo de la semana X del Tiempo Ordinario (semana 10), año impar
- [La penitencia obtiene el perdón en esta vida, valedero para la futura](r/7d1afd160f.md) — San Agustín de Hipona · Sermón 71,1.13.14.19.20: PL 38, 445.451-452.454-456 · Domingo de la semana X del Tiempo Ordinario (semana 10), año impar
- [La Madre Iglesia se regocija por los hombres que cada día resucitan espiritualmente](r/afd3c7afa4.md) — San Agustín de Hipona · Sermón 98, 1-3: PL 38, 591-592 · Domingo de la semana X del Tiempo Ordinario (semana 10), año impar
- [Así se alegran lo mismo el sembrador y el segador](r/4b78f47a8f.md) — San Agustín de Hipona · Tratado 15, 32: CCL 36, 163-164 · Domingo de la semana XI del Tiempo Ordinario (semana 11), año impar
- [A una orden de Cristo se produce la calma](r/84e338d484.md) — San Agustín de Hipona · Sermón 43, 1-3: PL 38, 424-425 · Domingo de la semana XII del Tiempo Ordinario (semana 12), año impar
- [Si quieres seguir a Cristo, vuélvete a la cruz; soporta, aguanta, manténte firme](r/4c4859e6de.md) — San Agustín de Hipona · Sermón 96, 1-4: PL 38, 584-586 · Domingo de la semana XIII del Tiempo Ordinario (semana 13), año impar
- [Cristo es Rey, Cristo es Sacerdote: alegrémonos en él](r/5e97cedfc5.md) — San Agustín de Hipona · Comentario al Salmo 149,6: CCL 40, 2182-2183 · Miércoles de la semana XIII del Tiempo Ordinario (semana 13), año impar
- [El Padre mismo me ha enviado](r/22272b79e1.md) — San Agustín de Hipona · Tratado 31, 3-4: CCL 36, 294-295 · Domingo de la semana XIV del Tiempo Ordinario (semana 14), año impar
- [Envió Cristo a los segadores con la hoz del evangelio](r/14e11815c2.md) — San Agustín de Hipona · Sermón 101 (1.2.3.11: PL 38, 605.606.607.610 · Domingo de la semana XIV del Tiempo Ordinario (semana 14), año impar
- [El Señor es nuestro Dios, y nosotros su pueblo, el rebaño que él guía](r/88a1259124.md) — San Agustín de Hipona · Sermón sobre las ovejas, 47, 1. 2. 3. 6: CCL 41, 572-573. 575-576 · Domingo de la semana XV del Tiempo Ordinario (semana 15), año impar
- [Si buscare agradar a los hombres no sería siervo de Cristo](r/3b1bd7b318.md) — San Agustín de Hipona · Sermón sobre las ovejas, 47, 12-14: CCL 41, 582-584 · Lunes de la semana XV del Tiempo Ordinario (semana 15), año impar
- [Jesucristo es del linaje de David según la carne](r/dc6dfeea18.md) — San Agustín de Hipona · Cap. 15, 30-31: PL 44, 981-983 · Jueves de la semana XV del Tiempo Ordinario (semana 15), año impar
- [Mi sacrificio es un espíritu quebrantado](r/62960979d6.md) — San Agustín de Hipona · Sermón 19, 2-3: CCL 41, 252-254 · Sábado de la semana XV del Tiempo Ordinario (semana 15), año impar
- [Los de fuera, lo quieran o no, son hermanos nuestros](r/fed425a575.md) — San Agustín de Hipona · Comentario sobre el salmo 32, n. 29: CCL 38, 272-273 · Ciclo B Mc 6, 30-34 — Tiempo Ordinario, año impar
- [Honrar a los mártires es honrar a Dios](r/63fd664665.md) — San Agustín de Hipona · Sermón 273, En el día de los santos Fructuoso, Augurio y Eulogio, 2-3. 9: PL 38,1248-1249.1252 · 20 de enero San Fructuoso, Obispo y Mártir y sus Diáconos, Santos Augurio y Eulogio — Santoral, año impar
- [Vicente venció en aquel por quien había sido vencido el mundo](r/5a6cbeffdb.md) — San Agustín de Hipona · Sermón 276,1-2: PL 38,1256 · 22 de enero San Vicente, Diácono y Mártir — Santoral, año impar
- [Vicente, por su fe, fue vencedor en todo](r/6f5a6d7d55.md) — San Agustín de Hipona · Sermón 274, sobre el martirio de san Vicente: PL 38, 1252.1253 · 22 de enero San Vicente, Diácono y Mártir — Santoral, año impar
- [Sufre por mis ovejas](r/9826817596.md) — San Agustín de Hipona · Sermón Güelferbitano 32, Sobre la ordenación episcopal: PLS 2, 639-640 · 3 de febrero San Blas, Obispo y Mártir — Santoral, año impar
- [La voz que clama en el desierto](r/9bad57d0fc.md) — San Agustín de Hipona · Sermón 293, 1-3: PL 38, 1327-1328 · 24 de junio NATIVIDAD DE SAN JUAN BAUTISTA — Santoral, año impar
- [Estos mártires, en su predicación, daban testimonio de lo que habían visto](r/2f712d8edb.md) — San Agustín de Hipona · Sermón 295, 1-2. 4. 7-8: PL 38, 1348-1352 · 29 de junio SAN PEDRO Y SAN PABLO, Apóstoles — Santoral, año impar
- [Dichosos los que pudieron hospedar al Señor en su casa](r/92817b23ce.md) — San Agustín de Hipona · Sermón 103,1-2. 6: PL 38, 613. 615 · 29 de julio Santa Marta — Santoral, año impar
- [Han cambiado los signos, no la fe](r/e67c28db12.md) — San Agustín de Hipona · 19 3: CCL 41, 253-254 · Sábado de la semana I del Tiempo Ordinario (semana 1), año par
- [Entendamos la gracia de Dios](r/b5028b7176.md) — San Agustín de Hipona · Prefacio: PL 35, 2105-2107 · Domingo de la semana IX del Tiempo Ordinario (semana 9), año par
- [Hasta ver a Cristo formado en vosotros](r/17402f5f03.md) — San Agustín de Hipona · 37-38: PL 35, 2131-2132 · Jueves de la semana IX del Tiempo Ordinario (semana 9), año par
- [Si el Señor no construye la casa, en vano se cansan los albañiles](r/ba889777d2.md) — San Agustín de Hipona · Sal. 126, 2-3: CCL 40, 1857-1859 · Martes de la semana XI del Tiempo Ordinario (semana 11), año par
- [El Señor mandó que todo se hiciese en paz y concordia](r/673425bb2f.md) — San Agustín de Hipona · 146, 4-5.6: CCL 40, 2124-2125.2126 · Sábado de la semana XI del Tiempo Ordinario (semana 11), año par
- [Yo salvaré a mi pueblo](r/b2f4fb2da2.md) — San Agustín de Hipona · 4-6: CCL 36, 261-263 · Lunes de la semana XII del Tiempo Ordinario (semana 12), año par
- [A ti, Señor, me manifiesto tal como soy](r/48a69222f7.md) — San Agustín de Hipona · Lib 10,1,1—2, 2; 5,7: CSEL 33, 226-227.230-231 · Martes de la semana XV del Tiempo Ordinario (semana 15), año par
- [Cristo murió por todos](r/b9878f6295.md) — San Agustín de Hipona · Lib 10, 43, 68-70: CSEL 33, 278-280 · Miércoles de la semana XV del Tiempo Ordinario (semana 15), año par
- [Señor, Dios mío, atiende a mi súplica](r/00d00e544b.md) — San Agustín de Hipona · Lib 11, 1, 1-2, 3: CSEL 33, 283-285 · Jueves de la semana XV del Tiempo Ordinario (semana 15), año par
- [Toda mi esperanza está puesta en tu gran misericordia](r/4aeecbf94e.md) — San Agustín de Hipona · Lib 10, 26, 37—29, 40: CSEL 33, 255-256 · Sábado de la semana XV del Tiempo Ordinario (semana 15), año par
- [Mira, tu voz es mi gozo](r/8f60202a79.md) — San Agustín de Hipona · Lib 11, 2, 3-3, 5: CSEL 33, 282-284 · Miércoles de la semana XVI del Tiempo Ordinario (semana 16), año par
- [Me llamaste para que te invocara](r/943e15e5f2.md) — San Agustín de Hipona · Lib 13, 1, 1—2, 3 CSEL 33, 344-347 · Jueves de la semana XVI del Tiempo Ordinario (semana 16), año par
- [Tu palabra, oh Dios, es fuente de vida eterna](r/cd790af346.md) — San Agustín de Hipona · Lib 13, 21, 31—22, 32: CSEL 33, 369-371 · Viernes de la semana XVI del Tiempo Ordinario (semana 16), año par
- [Señor, nos lo has dado todo: la paz del descanso, la paz del sábado, la paz sin ocaso](r/041bfd6f1e.md) — San Agustín de Hipona · Lib 13, 35, 50—38, 53: CSEL 33, 386-388 · Sábado de la semana XVI del Tiempo Ordinario (semana 16), año par
- [Nuestro corazón no halla sosiego hasta que descanse en ti](r/bb670e480b.md) — San Agustín de Hipona · Lib 1, 1,1—2, 2; 5, 5: CSEL 33, 1-5 · Domingo de la semana XVII del Tiempo Ordinario (semana 17), año par
- [¡Señor, sálvame, que me hundo!](r/02dc062052.md) — San Agustín de Hipona · Sermón 76, 1. 4.-6. 8-9: PL 38, 479-483 · Domingo de la semana XIX del Tiempo Ordinario (semana 19), año impar
- [Perdónanos nuestras deudas, así como nosotros perdonamos a nuestros deudores](r/a4550dd350.md) — San Agustín de Hipona · Sermón 83, 2-4: PL 38, 515-516 · Domingo de la semana XXIV del Tiempo Ordinario (semana 24), año impar
- [El denario es la vida eterna](r/9541849bd8.md) — San Agustín de Hipona · Sermón 87, 1.5.6: PL 38, 530. 531.532.533 · Domingo de la semana XXV del Tiempo Ordinario (semana 25), año impar
- [El que persevere hasta el final se salvará](r/461da55541.md) — San Agustín de Hipona · Sermón Caillau-Saint-Yves 2, 92: PLS 2, 441-552 · Jueves de la semana XXV del Tiempo Ordinario (semana 25), año impar
- [Lo que se aprende en la escuela de Cristo maestro](r/8c5179b2ac.md) — San Agustín de Hipona · Sermón 33 A,4 sobre el antiguo Testamento : CCL 41, 421-422 · Domingo de la semana XXVI del Tiempo Ordinario (semana 26), año impar
- [Despierta a tu fe, mira la vida futura con los ojos de la fe](r/f65efc4d12.md) — San Agustín de Hipona · 3: CCL 40, 2140-2141 · Domingo de la semana XXVII del Tiempo Ordinario (semana 27), año impar
- [Vamos a subir al monte del Señor](r/5d62be4f4f.md) — San Agustín de Hipona · Comentario sobre el Salmo 47, 7: CCL 38, 543-545 · Martes de la semana XXVII del Tiempo Ordinario (semana 27), año impar
- [El traje de fiesta es el amor](r/2c74d5d1e8.md) — San Agustín de Hipona · Sermón 90,1.5.6: PL 38, 559.561-563 · Domingo de la semana XXVIII del Tiempo Ordinario (semana 28), año impar
- [Al crecer el amor, el alma se siente segura](r/2833bd0914.md) — San Agustín de Hipona · Sermón Mai 14,1-2: PLS 2, 449-450 · Semana XXXI DEL TIEMPO ORDINARIO, año impar
- [Somos cristianos y somos obispos](r/d835377faf.md) — San Agustín de Hipona · Sermón 46, 1-2: CCL 41, 529-530 · Semana XXXII DEL TIEMPO ORDINARIO, año impar
- [Los pastores que se apacientan a sí mismos](r/a4a03a7f7b.md) — San Agustín de Hipona · Sermón 46, 3-4: CCL 41, 530-531 · Lunes de la semana XXXII del Tiempo Ordinario (semana 32), año impar
- [El ejemplo de Pablo](r/fbce0e7abc.md) — San Agustín de Hipona · Sermón 46, 4-5 CCL 41, 531-533 · Martes de la semana XXXII del Tiempo Ordinario (semana 32), año impar
- [Que nadie busque su interés, sino el de Jesucristo](r/23484ff7cf.md) — San Agustín de Hipona · Sermón 46, 6-7: CCL 41, 533-534 · Miércoles de la semana XXXII del Tiempo Ordinario (semana 32), año impar
- [Sé un modelo para los fieles](r/7f94983d82.md) — San Agustín de Hipona · Sermón 46, 9: CCL 41, 535-536 · Jueves de la semana XXXII del Tiempo Ordinario (semana 32), año impar
- [Prepárate para las pruebas](r/8726c3cf1a.md) — San Agustín de Hipona · Sermón 46, 10-11: CCL 41, 536-538 · Viernes de la semana XXXII del Tiempo Ordinario (semana 32), año impar
- [Ofrece el alivio de la consolación](r/2771143b3d.md) — San Agustín de Hipona · Sermón 46, 11-12: CCL 41, 538-539 · Sabado XXXII — Tiempo Ordinario, año impar
- [Los cristianos débiles](r/0c8ce890d8.md) — San Agustín de Hipona · Sermón 46, 13: CCL 41, 539-540 · Semana XXXIII DEL TIEMPO ORDINARIO, año impar
- [No pongamos resistencia a su primera venida, y no temeremos la segunda](r/605a7a962e.md) — San Agustín de Hipona · 14.15: CCL 39, 1351-1353 · Semana XXXIII DEL TIEMPO ORDINARIO, año impar
- [Insiste a tiempo y a destiempo](r/1e37fbea34.md) — San Agustín de Hipona · Sermón 46, 14-15: CCL 41, 541-542 · Lunes de la semana XXXIII del Tiempo Ordinario (semana 33), año impar
- [La Iglesia, como una vid que crece y se difunde por doquier](r/a7c852c4d9.md) — San Agustín de Hipona · Sermón 46, 18-19: CCL 41, 544-546 · Martes de la semana XXXIII del Tiempo Ordinario (semana 33), año impar
- [Haced lo que os digan, pero no hagáis lo que ellos hacen](r/0a34227076.md) — San Agustín de Hipona · Sermón 46, 20-21: CCL 41, 546-548 · Miércoles de la semana XXXIII del Tiempo Ordinario (semana 33), año impar
- [Apacentaré a mis ovejas en ricos pastizales](r/90859682aa.md) — San Agustín de Hipona · Sermón 46, 24-25. 27: CCL 41, 551-553 · Jueves de la semana XXXIII del Tiempo Ordinario (semana 33), año impar
- [Todos los buenos pastores se identifican con el único pastor](r/0de8e1b2ca.md) — San Agustín de Hipona · Sermón 46, 29-30: CCL 41, 555-557 · Viernes de la semana XXXIII del Tiempo Ordinario (semana 33), año impar
- [El reino de Cristo hasta el fin del mundo](r/5a7223397d.md) — San Agustín de Hipona · Tratado 115, 2-5: CCL 36, 644-646). · Domingo de la semana XXXIV del Tiempo Ordinario (semana 34) JESUCRISTO, REY DEL UNIVERSO, año impar
- [Administró la Sangre sagrada de Cristo](r/2d45b0d77d.md) — San Agustín de Hipona · Sermón 304, 1-4: PL 38, 1395-1397 · 10 de agosto San Lorenzo, diácono y mártir — Santoral, año impar
- [Alcancemos la sabiduría eterna](r/92c6c73b5f.md) — San Agustín de Hipona · Libro 9,10, 23-11, 28: CSEL 33, 215-219 · 27 de agosto Santa Mónica — Santoral, año impar
- [¡Oh eterna verdad, verdadera caridad y cara eternidad!](r/89c0804da9.md) — San Agustín de Hipona · Libros 7, 10. 18; 10, 27: CSEL 33, 157-163. 255 · 28 de agosto San Agustín, obispo y doctor de la Iglesia — Santoral, año impar
- [Soy obispo para vosotros, soy cristiano con vosotros](r/8598d9c073.md) — San Agustín de Hipona · Sermón 340,1: PL 38,1483-1484 · 19 de septiembre San Jenaro, obispo y mártir — Santoral, año impar
- [Preciosa es la muerte de los mártires, comparada con el precio de la muerte de Cristo](r/ec8c61e83f.md) — San Agustín de Hipona · Sermón 329: En el natalicio de los mártires, 1-2: PL 38,1454-1455 · 26 de septiembre San Cosme y San Damián, mártires — Santoral, año impar
- [Dio fe al mensaje divino y concibió por su fe](r/8710ce6aa9.md) — San Agustín de Hipona · Sermón 25, 7-8: PL 46, 937-938 · 21 de noviembre La Presentación de la Santísima Virgen — Santoral, año impar
- [Cantad a Dios con maestría y con júbilo](r/134d9d8640.md) — San Agustín de Hipona · Salmo 32, sermón 1, 7-8: CCL 38, 253-254 · 22 de noviembre Santa Cecilia, virgen y mártir — Santoral, año impar
- [En todo lugar ofrecerán incienso a mi nombre y una ofrenda pura](r/88d8325c07.md) — San Agustín de Hipona · Lib 10, 6: CCL 47, 278-279 · Viernes de la semana XVIII del Tiempo Ordinario (semana 18), año par
- [El corazón del justo se gozará en el Señor](r/50c05378a5.md) — San Agustín de Hipona · Sermón 21, 1-4: CCL 41, 276-278 · Miércoles de la semana XIX del Tiempo Ordinario (semana 19), año par
- [Llegarás a la fuente, verás la luz](r/7631cdbf18.md) — San Agustín de Hipona · Tratado 35, 8-9: CCL 36, 321-323 · Domingo de la semana XXIII del Tiempo Ordinario (semana 23) - Año A: Mt 18, 15-20, año par
- [Cantemos el Aleluya al Dios bueno que nos libra del mal](r/b74d1f4513.md) — San Agustín de Hipona · Sermón 256, 1.2.3: PL 38, 1191-1193 · Sábado de la semana XXIII del Tiempo Ordinario (semana 23), año par
- [Que nuestro deseo de la vida eterna se ejercite en la oración](r/0573eb6e12.md) — San Agustín de Hipona · Carta 130, 8, 15.17-9 18 a Proba: CSEL 44, 6-57.59-60 · Domingo de la semana XXIV del Tiempo Ordinario (semana 24), año par
- [Debemos, en ciertos momentos, amonestarnos a nosotros mismos con la oración vocal](r/bbe052a0b3.md) — San Agustín de Hipona · Carta 130, 9,18—10, 20 a Proba: CSEL 44, 60-63 · Domingo de la semana XXIV del Tiempo Ordinario (semana 24) - Año A: Mt 18, 21-35, año par
- [Sobre la oración dominical](r/2542b38d42.md) — San Agustín de Hipona · Carta 130, 11, 21-12, 22 a Proba: CSEL 44, 63-64 · Martes de la semana XXIV del Tiempo Ordinario (semana 24), año par
- [Nada hallarás que no se encuentre en esta oración dominical](r/189d6951dc.md) — San Agustín de Hipona · Carta 130, 12, 22-13, 24 a Proba: CSEL 44, 65-68 · Miércoles de la semana XXIV del Tiempo Ordinario (semana 24), año par
- [No sabemos pedir lo que nos conviene](r/551dcea6e8.md) — San Agustín de Hipona · Carta 130, 14, 25-26 a Proba: CSEL 44, 68-71 · Jueves de la semana XXIV del Tiempo Ordinario (semana 24), año par
- [El Espíritu intercede por nosotros](r/e8800b5b1c.md) — San Agustín de Hipona · Carta 130, 14, 27—15, 28 a Proba: CSEL 44, 71-73 · Viernes de la semana XXIV del Tiempo Ordinario (semana 24), año par
- [Ésta es la luz: es una y uno son todos cuantos la ven y la aman](r/d2c882c9f4.md) — San Agustín de Hipona · Lib 10,34: CSEL 33, 265-267 · Miércoles de la semana XXV del Tiempo Ordinario (semana 25), año par

## San Alberto Magno

- [Pastor y doctor para la edificación del Cuerpo de Cristo](r/e4c27abffa.md) — San Alberto Magno · Lc 22,19: Opera omnia, París 1890-1899, 23, 672-674 · 15 de noviembre San Alberto Magno, obispo y doctor de la Iglesia — Santoral, año impar

## San Alfonso María de Ligorio

- [El amor a Cristo](r/a31945179e.md) — San Alfonso María de Ligorio · Tratado sobre la práctica del amor a Jesucristo, edición latina, Roma 1909, pp. 9-14 · 1 de agosto San Alfonso María de Ligorio, obispo y doctor de la Iglesia — Santoral, año impar

## San Amadeo de Lausana

- [Reina del mundo y de la paz](r/295d6dd29c.md) — San Amadeo de Lausana · Homilía 7: SC 72, 188. 190.192. 200 · 22 de agosto Santa María Virgen, Reina — Santoral, año impar

## San Ambrosio de Milán

- [¿Eres tú el que ha de venir o tenemos que esperar a otro?](r/e89752cee2.md) — San Ambrosio de Milán · Lib. 5, 93-95.99-102.109: CCL 14, 165-166.167-168.171-177 · Domingo de la semana III de Adviento (semana 3), año par
- [La visitación de santa María Virgen](r/d737449272.md) — San Ambrosio de Milán · Lib. 2, 19.22-23.26-27: CCL 14, 39-42 · 21 de Diciembre — Santoral, año par
- [Del seno de la Virgen nació el que es Siervo y Señor a la vez](r/eee161dda5.md) — San Ambrosio de Milán · 4-5 : CCL 64, 52-53 · Domingo después del 6 de Enero. EL BAUTISMO DEL SEÑOR — Adviento y Navidad, año par
- [Que el encanto de tu palabra cautive el favor del pueblo](r/4b08893a78.md) — San Ambrosio de Milán · Carta 2,1-2. 4-5. 7: PL 16 [edición 1845], 847-881 · 7 de diciembre. San Ambrosio, Obispo y Doctor de la Iglesia — Santoral, año par
- [Con la claridad de tu mente iluminas la gracia de tu cuerpo](r/5f40c7680c.md) — San Ambrosio de Milán · Cap. 12, 68. 74-75; 13, 77-78: PL 16 [edición 1845], 281. 283. 285-286 · El mejor homenaje a María: amar a Dios y al prójimo — Santoral, año par
- [Adelantémonos a la salida del sol, salgamos a su encuentro](r/66ee500bf9.md) — San Ambrosio de Milán · Sermón 19, 30-32: CSEL 62, 437-439 · Domingo de la semana II de Adviento (semana 2), año impar
- [Vino el perdón, y saltaron las cadenas del pecado](r/5551e2ec10.md) — San Ambrosio de Milán · 45, 16-17: CSEL 64, 340-342 · Sábado de la semana II de Adviento (semana 2), año impar
- [Cristo es el camino para los que buscan a Dios](r/32418a9c47.md) — San Ambrosio de Milán · Sermón 11, 4-6: CSEL 62, 234-236 · Jueves de la semana III de Adviento (semana 3), año impar
- [Sólo Jesús es la luz verdadera y eterna](r/d1b313970e.md) — San Ambrosio de Milán · Comentario sobre el salmo 45, 2: PL 14, 1188-1189 · Semana II de Cuaresma — Cuaresma y Pascua, año par
- [Unirse a Dios, único bien verdadero](r/9a750ec3e1.md) — San Ambrosio de Milán · Caps. 6, 36; 7, 44; 9, 52 · Sábado de la semana II de Cuaresma (semana 2), año par
- [La carne de nuestro barro recibe la luz de la vida eterna, mediante el sacramento del bautismo](r/5ba10226c2.md) — San Ambrosio de Milán · Carta 80,1-6: PL 16, 1271- 1272 · Semana IV de Cuaresma — Cuaresma y Pascua, año par
- [Observa los misterios de Dios y la clemencia de Cristo](r/c99be23c72.md) — San Ambrosio de Milán · Carta 26 11-20: PL 16, 1088-1090 · Semana V de Cuaresma — Cuaresma y Pascua, año par
- [Carguemos con la cruz del Señor para que, crucificando nuestra carne, destruya el pecado](r/5a0c6c74bf.md) — San Ambrosio de Milán · Homilía 15, 37-40: PL 15, 1423-1424 · Domingo de Ramos en la Pasión del Señor — Cuaresma y Pascua, año par
- [El lugar: junto al Padre; el camino: Cristo](r/39a356a679.md) — San Ambrosio de Milán · Cap 12, 52-55: CSEL 32, 747-750 · Domingo de la semana V de Pascua (semana 5), año par
- [En el momento de la tentación, nos consuela la esperanza](r/c5e6ba0f4f.md) — San Ambrosio de Milán · Sermón 7, 6-7: CSEL 62, 130-131 · Viernes de la semana V de Pascua (semana 5), año par
- [Brille sobre nosotros la luz de tu rostro, Señor](r/21fc37b410.md) — San Ambrosio de Milán · PL 14. 1185 · Jueves de la II semana de Pascua. La Santa Faz de Nuestro Señor Jesucristo — Santoral, año par
- [Cristo no se arrogó el sacerdocio: lo aceptó](r/895fc9c055.md) — San Ambrosio de Milán · Carta 67, 47-50: PL 16, 1253-1254 · Viernes de la semana IV de Cuaresma (semana 4), año impar
- [En Cristo murió nuestra culpa, no nuestra vida](r/22d283df4d.md) — San Ambrosio de Milán · Lib. 1, 108-111: PL 16, 759-760 · Jueves de la semana IV de Pascua (semana 4), año impar
- [Sin motivo padece persecución, el que es combatido siendo inocente](r/3b515f48c1.md) — San Ambrosio de Milán · Sermón 21, 6-9: PL 15, 1581-1583 · Viernes de la semana IV de Pascua (semana 4), año impar
- [De la plenitud del Verbo todos hemos recibido](r/12ab1036e1.md) — San Ambrosio de Milán · Sermón 20, 54-55: CSEL 62, 471-472 · Domingo de la semana V de Pascua (semana 5) - Año A: Jn 14, 1-12, año impar
- [Sé hombre sujeto a Cristo, súbdito de la sabiduría de Dios](r/a354bce37b.md) — San Ambrosio de Milán · Comentario 16, sobre el salmo 36: PL 14, 973-974 · Jueves de la semana I del Tiempo Ordinario (semana 1), año impar
- [Esta carne que era sombra de muerte, comenzó a resplandecer gracias al Señor](r/50e412b781.md) — San Ambrosio de Milán · Comentario 75-77 sobre el salmo 43: PL 14, 1125-1126 · Viernes de la semana I del Tiempo Ordinario (semana 1), año impar
- [Dios nos amonestó por medio de la ley, los profetas, el evangelio y los apóstoles](r/6a4aa20a60.md) — San Ambrosio de Milán · Comentario 1, 14-15 sobre el Salmo 118: PL 15, 1270 · Sábado de la semana I del Tiempo Ordinario (semana 1), año impar
- [Asumió Cristo la obediencia para inoculárnosla a nosotros](r/d224627c36.md) — San Ambrosio de Milán · Comentario 4-6 sobre el salmo 61: PL 14, 1224-1225 · Martes de la semana II del Tiempo Ordinario (semana 2), año impar
- [Predicamos a Cristo](r/54f860650b.md) — San Ambrosio de Milán · Carta 29, 6-9: PL 16, 1100-1101 · Jueves de la semana III del Tiempo Ordinario (semana 3), año impar
- [La semilla de todos es Cristo](r/953f5c18ae.md) — San Ambrosio de Milán · Comentario 36-39, sobre el salmo 43: CSEL 64, 288-290 · Sábado de la semana V del Tiempo Ordinario (semana 5), año impar
- [Cantar salmos con el espíritu, pero cantarlos también con la mente](r/60e2a904e2.md) — San Ambrosio de Milán · Salmo 1, 9-12: CSEL 64, 7. 9-10 · Sábado de la semana VII del Tiempo Ordinario (semana 7), año impar
- [Como Adán es la primicia de la muerte, así Cristo es la primicia de la resurrección](r/956cb4a7fc.md) — San Ambrosio de Milán · Lib. 2, 89-93: CSEL 73, 298-300 · Martes de la semana VIII del Tiempo Ordinario (semana 8), año impar
- [Dulzura del libro de los salmos](r/1e92ea8fb1.md) — San Ambrosio de Milán · Comentario al Salmo 1, 4. 7-8: CSEL 64, 4-7 · Viernes de la semana X del Tiempo Ordinario (semana 10), año impar
- [Estudiad las Escrituras, pues ellas están dando testimonio de mí](r/0360ee18db.md) — San Ambrosio de Milán · Comentario sobre el Salmo 1, 33: CSEL 64, 28-30 · Sábado de la semana X del Tiempo Ordinario (semana 10), año impar
- [El templo de Dios es santo: ese templo sois vosotros](r/d33503e222.md) — San Ambrosio de Milán · Comentario sobre el salmo 118, n. 12, 13. 14: CSEL 62, 258-259 · Miércoles de la semana XVI del Tiempo Ordinario (semana 16), año impar
- [Catequesis sobre los ritos que preceden al bautismo](r/04fbacfbde.md) — San Ambrosio de Milán · Tratado 1-7: SC 25bis, 156-158 · Viernes de la semana XVII del Tiempo Ordinario (semana 17), año impar
- [Renacemos del agua y del Espíritu Santo](r/e5042d6cf5.md) — San Ambrosio de Milán · Tratado 8-11: SC 25bis, 158-160 · Sábado de la semana XVII del Tiempo Ordinario (semana 17), año impar
- [Testimonio fiel de Cristo](r/086fdbf619.md) — San Ambrosio de Milán · Cap. 20, 43-45. 48: CSEL 62, 466-468 · El mismo día 20 de enero San Sebastián, Mártir — Santoral, año impar
- [No tenía aún edad de ser condenada, pero estaba ya madura para la victoria](r/208e557c5b.md) — San Ambrosio de Milán · Libro 1, Caps. 2. 5. 7-9: PL 16 [edición 1845], 189-191 · 21 de enero Santa Inés, Virgen y Mártir — Santoral, año impar
- [El Señor colocó al hombre en el paraíso como el sol en el cielo, a la espera del reino de los cielos](r/f9daed8a78.md) — San Ambrosio de Milán · cap.1, 2-2, 6: CSEL 32, 266-267 · Martes de la semana I del Tiempo Ordinario (semana 1), año par
- [El sacrificio del justo Abel significó que el Señor Jesús iba a ofrecerse por nosotros](r/b0ade8e55e.md) — San Ambrosio de Milán · 39 11-14: PL 14, 1061-1062 · Jueves de la semana I del Tiempo Ordinario (semana 1), año par
- [Estad siempre alegres en el Señor](r/5bd4840128.md) — San Ambrosio de Milán · PLS 1, 617-618 · Domingo de la semana VI del Tiempo Ordinario (semana 6), año par
- [Ha resplandecido sobre nosotros la luz de tu rostro](r/7df7edd773.md) — San Ambrosio de Milán · Sal 43, 89-90: CSEL 64, 324-326 · Jueves de la semana VII del Tiempo Ordinario (semana 7), año par
- [Cristo reconcilió el mundo con Dios por su propia sangre](r/2bfe06e12f.md) — San Ambrosio de Milán · Salmo 48, 14-15: CSEL 64, 368-370 · Viernes de la semana VII del Tiempo Ordinario (semana 7), año par
- [Somos herederos de Dios y coherederos con Cristo](r/e26880d2c0.md) — San Ambrosio de Milán · Carta 35 4-6.13: PL 16 [ed. 1845] 1078-1079. 1081 · Miércoles de la semana IX del Tiempo Ordinario (semana 9), año par
- [Él mismo fundó su Iglesia](r/601a3ebc0d.md) — San Ambrosio de Milán · 16-17: PL 14, 1152-1153 · Viernes de la semana XIII del Tiempo Ordinario (semana 13), año par
- [Abre tu boca a la palabra de Dios](r/caa68ab4ff.md) — San Ambrosio de Milán · 65-66: CSEL 64, 123-125 · Jueves de la semana XIV del Tiempo Ordinario (semana 14), año par
- [Todo les sucedía como un ejemplo](r/8729068593.md) — San Ambrosio de Milán · Tratado 12-16. 19: SC 25bis, 162-164 · Domingo de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [Cristo bebió mis amarguras para darme la suavidad de su gracia](r/82b165e619.md) — San Ambrosio de Milán · Sermón 18, 26-29: PL 15, 1461-1463 · Domingo de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [El agua no purifica sin la acción del Espíritu Santo](r/3b061a82d0.md) — San Ambrosio de Milán · Tratado 19-21. 24. 26-38: SC 25bis, 164-170 · Lunes de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [Catequesis de los ritos que siguen al bautismo](r/248ffc6293.md) — San Ambrosio de Milán · Tratado 29-30. 34-35. 37. 42: SC 25bis, 172-178 · Martes de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [Instrucción a los recién bautizados sobre la eucaristía](r/aad5c1eb73.md) — San Ambrosio de Milán · Tratado 43. 47-49: SC 25bis, 178-180. 182 · Miércoles de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [Este sacramento que recibes se realiza por la palabra de Cristo](r/831f9b4b3b.md) — San Ambrosio de Milán · Tratado 52-54. 58: SC 25bis, 186-188. 190 · Jueves de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [Que la Palabra de Dios sea lámpara para mis pasos](r/5f72dc08c5.md) — San Ambrosio de Milán · Sermón 14, 11-13: PL 15, 1394-1395 · Domingo de la semana XIX del Tiempo Ordinario (semana 19), año impar
- [Haced resplandecer para vosotros la luz del conocimiento](r/ac70f5c570.md) — San Ambrosio de Milán · Sermón 1, 2 sobre el Salmo 118: PL 15, 1199-1200 · Martes de la semana XXIV del Tiempo Ordinario (semana 24), año impar
- [Uno solo es el mediador entre Dios y los hombres, el hombre Cristo Jesús](r/1ae4fbbe76.md) — San Ambrosio de Milán · Comentario sobre el Salmo 48, nn. 13-14: CSEL 64, 367-368 · Lunes de la semana XXVII del Tiempo Ordinario (semana 27), año impar
- [Dios prefirió que la salvación del hombre viniese por el camino de la fe, más que por el de las obras](r/029f292942.md) — San Ambrosio de Milán · Comentario sobre el Salmo 43, 10-14: CSEL 64, 268-272 · Lunes de la semana XXVIII del Tiempo Ordinario (semana 28), año impar
- [Aplastar bajo los pies a todos los prisioneros de la tierra](r/ab911b8f02.md) — San Ambrosio de Milán · Sermón 12, 3-6, sobre el Salmo 118: PL 15, 1361-1362 · Lunes de la semana XXX del Tiempo Ordinario (semana 30), año impar
- [Sé un testigo fiel y valeroso](r/39d638a42e.md) — San Ambrosio de Milán · Cap. 20, 47-50: CSEL 62, 467-469 · 9 de octubre San Dionisio, obispo, y Compañeros, mártires — Santoral, año impar
- [Muramos con Cristo, y viviremos con Él](r/67e74c703e.md) — San Ambrosio de Milán · Libro 2, 40. 41. 46. 47.132.133: CSEL 73, 270-274. 323-324 · 2 de noviembre CONMEMORACIÓN DE TODOS LOS FIELES DIFUNTOS — Santoral, año impar
- [Sobre el signo de Jonás](r/baf984048c.md) — San Ambrosio de Milán · 83-85: PL 14, 1129-1130 · Domingo de la semana XIX del Tiempo Ordinario (semana 19), año par
- [Hay que orar especialmente por todo el cuerpo de la Iglesia](r/01bd9472a1.md) — San Ambrosio de Milán · Lib 1, 9, 34. 38-39: CSEL 32, 369.371-372 · Domingo de la semana XXI del Tiempo Ordinario (semana 21) - Año A: Mt 16, 13-20, año par
- [En la sombra observamos las palabras de Dios](r/a2a9510017.md) — San Ambrosio de Milán · Sermón 3, 19-21: CSEL 62, 50-53 · Sábado de la semana XXIV del Tiempo Ordinario (semana 24), año par
- [Cristo penetra el alma y la ilumina cual reflejo de la luz eterna](r/39451898e8.md) — San Ambrosio de Milán · Sermón 19, 36-40: PL 15, 1480-1482 · Domingo de la semana XXX del Tiempo Ordinario (semana 30), año par
- [Eres, oh hombre, una obra maestra, animada por la potencia creadora de Dios](r/892a7ed985.md) — San Ambrosio de Milán · Sermón 10, 10-11: PL 14, 1332-1334 · Domingo de la semana XXX del Tiempo Ordinario (semana 30) - Año A: Mt 22, 34-40, año par
- [En el tiempo de nuestra humillación, la esperanza nos consuela](r/1391eb43d5.md) — San Ambrosio de Milán · Sermón 7, 7-8: PL 15, 1282-1283 · Viernes de la semana XXXI del Tiempo Ordinario (semana 31), año par
- [En toda ocasión, llevemos en el cuerpo la muerte de Jesús](r/8e4bec49b2.md) — San Ambrosio de Milán · Caps 3, 9; 4, 15: CSEL 32, 710.716-717 · Miércoles de la semana XXXIII del Tiempo Ordinario (semana 33), año par

## San Ammonas

- [Los que están cerca de Dios han sido constituidos médicos de almas](r/fc78f96a57.md) — San Ammonas · Ep 12: PO 10/6, 1973, 603-607 · 24 de julio San Sarbelio (Charbel) Makllüf, Presbítero — Santoral, año impar

## Beato Ammonio

- [Muchos son los males que sufre el justo](r/8753cd8196.md) — Beato Ammonio · Carta 9, 2-5: PO t. 10, fasc. 6, 590-593 · Martes de la semana XXXII del Tiempo Ordinario (semana 32), año par

## San Anastasio de Antioquía

- [Cristo transformará nuestro cuerpo humilde](r/c5d99279f1.md) — San Anastasio de Antioquía · Sermón 5, Sobre la resurrección de Cristo, 6-7. 9: PG 89, 1358-1359.1361-1362 · Oficio de Difuntos, año par
- [Era necesario que el Mesías padeciera para entrar en su gloria](r/1f49734426.md) — San Anastasio de Antioquía · Sermón 4, 1-2: PG 89, 1347-1349 · Martes de la Octava de Pascua — Cuaresma y Pascua, año impar

## San Anastasio Sinaíta

- [¡Qué bien se está aquí!](r/29e7d03d62.md) — San Anastasio Sinaíta · Núms. 6-10: Mélanges d'archéologie et d'histoire 67 (1955), 241-244 · 6 de agosto LA TRANSFIGURACIÓN DEL SEÑOR — Santoral, año impar

## San Andrés de Creta

- [Bendito el que viene, como rey, en nombre del Señor](r/1d1605e628.md) — San Andrés de Creta · Sermón 9 sobre el domingo de Ramos : PG 97, 990-994 · Domingo de Ramos en la Pasión del Señor — Cuaresma y Pascua, año par
- [Lo antiguo ha pasado, lo nuevo ha comenzado](r/33dfb5308a.md) — San Andrés de Creta · Sermón 1: PG 97, 806-810 · 8 de septiembre La Natividad de la Santísima Virgen María — Santoral, año impar
- [La cruz es la gloria y exaltación de Cristo](r/1985e28089.md) — San Andrés de Creta · Sermón 10, Sobre la Exaltación de la santa cruz: PG 97, 1018-1019. 1022-1023 · 14 de septiembre LA EXALTACIÓN DE LA SANTA CRUZ — Santoral, año impar
- [Mira a tu rey, que viene a ti justo y victorioso](r/b775312098.md) — San Andrés de Creta · Sermón 9, sobre el domingo de Ramos : PG 97, 1002 · Martes de la semana XIX del Tiempo Ordinario (semana 19), año par

## San Andrés Kim Taegon

- [La fe es coronada por el amor y la perseverancia](r/0ae24f8323.md) — San Andrés Kim Taegon · Pro Corea. Documenta. ed. Mission Catholique Séoul, Seúl/París 1938, vol. 1, 74-75 · Propio de los santos — Santoral, año impar

## Santa Ángela de Mérici

- [Lo dispuso todo con suavidad](r/87e9700f44.md) — Santa Ángela de Mérici · 27 de enero Santa Ángela de Mérici, Virgen — Santoral, año impar

## San Anselmo de Canterbury

- [El deseo de contemplar a Dios](r/690b901ab2.md) — San Anselmo de Canterbury · Libro 1: Opera omnia, ed. Schmitt, Seckau [Austria] 1938, 1, 97-100 · Viernes de la semana I de Adviento (semana 1), año par
- [¡Oh Virgen, por tu bendición queda bendita toda criatura!](r/5db8eda892.md) — San Anselmo de Canterbury · Sermón 52: PL 158, 955-956 · 8 de diciembre. LA INMACULADA CONCEPCIÓN DE SANTA MARÍA VIRGEN — Santoral, año par
- [Que te conozca y te ame para que encuentre en ti mi alegría](r/f1557cda4b.md) — San Anselmo de Canterbury · Caps. 14. 16. 26: Opera omnia, edición Schmitt, Seckau [Austria] 1938,1,111-113.121-122 · 21 de abril. San Anselmo, Obispo y Doctor de la Iglesia — Santoral, año par
- [Da amor y recibe el reino; ama y toma](r/35f4c22795.md) — San Anselmo de Canterbury · Carta 112 : Opera omnia, t. 3, 1946, 244-246 · Domingo de la semana XXI del Tiempo Ordinario (semana 21), año impar
- [La nueva Iglesia de los fieles fue reunida por la gracia del Espíritu Santo](r/d335a9a570.md) — San Anselmo de Canterbury · Lib. 1, 6: SC 118, 64-66 · Miércoles de la semana XXVI del Tiempo Ordinario (semana 26), año impar
- [No temas, que te he redimido: he dado mi vida por ti](r/01c8d07af0.md) — San Anselmo de Canterbury · Meditación 3 : Opera omnia, 1946, 88-90 · Lunes de la semana XXXI del Tiempo Ordinario (semana 31), año impar

## San Antonio de Padua

- [La palabra tiene fuerza cuando va acompañada de las obras](r/d22e844e93.md) — San Antonio de Padua · I, 226 · 13 de junio San Antonio de Padua, Presbítero y Doctor de la Iglesia — Santoral, año impar

## San Antonio María Claret

- [Nos apremia el amor de Cristo](r/dd13e3753f.md) — San Antonio María Claret · L'egoismo vinto, Roma 1869, 60; Autobiografía, cap. 34 · 24 de octubre San Antonio María Claret, obispo — Santoral, año impar

## San Antonio María Zaccaría

- [El discípulo del apóstol Pablo](r/a3d222ed9a.md) — San Antonio María Zaccaría · J. A. Gabutio, Historia Congregationis Clericorum Regularium sancti Pauli, 1, 8 · 5 de julio San Antonio María Zaccaría, Presbítero — Santoral, año impar

## San Asterio de Amasea

- [Él nos amó primero](r/cfe704d151.md) — San Asterio de Amasea · Núms. 9-11: SC 61, 90-96 · Semana III de Adviento — Adviento y Navidad, año par
- [Debemos buscar la inteligencia de la fe en el Espíritu Santo](r/b70aa2a23c.md) — San Asterio de Amasea · PL 180, 384 · Común de doctores de la iglesia — Comunes, año par
- [Imitemos el estilo pastoral que empleó el mismo Señor](r/28774edc68.md) — San Asterio de Amasea · Homilía 13, PG 40, 355-358. 362 · Viernes de la semana I de Cuaresma (semana 1), año impar

## San Atanasio de Alejandría

- [La Palabra tomó de María nuestra condición](r/8f640cd3d0.md) — San Atanasio de Alejandría · Carta a Epicteto, 5-9: PG 26,1058.1062-1066 · 1 de Enero. SANTA MARÍA, MADRE DE DIOS — Santoral, año par
- [El Verbo de Dios vino por su benignidad hacia nosotros](r/55d9831093.md) — San Atanasio de Alejandría · Núm. 8-9: PG 25, 110-111 · Viernes de la semana III de Adviento (semana 3), año impar
- [De la encarnación del Verbo](r/d9ad87be06.md) — San Atanasio de Alejandría · Sermón sobre la encarnación del Verbo, 8-9: PG 25,110-111 · 2 de mayo. San Atanasio, Obispo y Doctor de la Iglesia — Santoral, año par
- [El Salvador ha resucitado; Cristo vive; Cristo es la vida misma](r/19fcd0f9a3.md) — San Atanasio de Alejandría · 29-30: PG 25, 146-147 · Domingo de la semana XII del Tiempo Ordinario (semana 12), año impar
- [Luz, resplandor y gracia en la Trinidad y por la Trinidad](r/eb232b122f.md) — San Atanasio de Alejandría · Carta a Serapión 1, 28-30: PG 26, 594-595. 599 · Domingo después de Pentecostés LA SANTÍSIMA TRINIDAD — Solemnidades del Señor, año impar
- [La vocación de san Antonio](r/89aa82679d.md) — San Atanasio de Alejandría · Caps. 2-4: PG 26, 842-846 · 17 de enero San Antonio, Abad — Santoral, año impar
- [Renueva los tiempos pasados](r/39c4d616d3.md) — San Atanasio de Alejandría · 10: PG 25, 111-114 · Martes de la semana V del Tiempo Ordinario (semana 5), año par
- [El conocimiento del Padre por medio de la Sabiduría creadora y hecha carne](r/0a92a088e9.md) — San Atanasio de Alejandría · 78.81-82: PG 26, 311.319 · Martes de la semana XIV del Tiempo Ordinario (semana 14), año par
- [Al hombre le toca sembrar; a Dios, dar el crecimiento](r/ef908b46ce.md) — San Atanasio de Alejandría · Homilía [atribuida] sobre la sementera, 2.3.4: PG 28, 146-150 · Domingo de la semana XV del Tiempo Ordinario (semana 15), año par
- [El Señor otorgó a la mujer el fruto de su fe](r/a991414d70.md) — San Atanasio de Alejandría · Carta Pascual 7, 6-8: PG 26, 1393-1394 · SEMANA XX del tiempo ordinario, año impar
- [El Verbo del Padre embellece, ordena y contiene todas las cosas](r/bdb1867799.md) — San Atanasio de Alejandría · Sermón 40-42: PG 25, 79-83 · Viernes de la semana XXIX del Tiempo Ordinario (semana 29), año par
- [Las obras de la creación, reflejo de la Sabiduría eterna](r/929ecafbef.md) — San Atanasio de Alejandría · Sermón 2, 78.79: PG 26, 311.314 · Sábado de la semana XXX del Tiempo Ordinario (semana 30), año par

## Balduino de Canterbury

- [La sabiduría de la cruz del Señor](r/4b5ddff48a.md) — Balduino de Canterbury · 9: PL 204, 501-502. 504 · Lunes de la semana V del Tiempo Ordinario (semana 5), año impar
- [Dad pruebas continuamente de que sois servidores de Dios](r/a14ea2378f.md) — Balduino de Canterbury · PL 204, 413-414 · Jueves de la semana V del Tiempo Ordinario (semana 5), año impar
- [Sed siervos de los siervos](r/e53469763a.md) — Balduino de Canterbury · Tratado para los sacerdotes, 12: PL 204, 533-536 · Viernes de la semana VI del Tiempo Ordinario (semana 6), año impar
- [Se nos invita a la fe, que es el trabajo de Dios](r/ce3b699180.md) — Balduino de Canterbury · Parte 2,3: SC 93, 248-252 · Domingo de la semana XVII del Tiempo Ordinario (semana 17), año impar
- [El Señor discierne los pensamientos y sentimientos del corazón](r/d17c56f285.md) — Balduino de Canterbury · PL 204, 466-467 · Viernes de la semana XVII del Tiempo Ordinario (semana 17), año par
- [Cristo, en su dignidad, es siempre deseable](r/3a5a65ad35.md) — Balduino de Canterbury · Parte 2,3: SC 93, 252-254 · Domingo de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [Sobre la fe de los apóstoles](r/cd6c6d0a05.md) — Balduino de Canterbury · Parte 2, 3: SC 93, 296-300 · Domingo de la semana XXI del Tiempo Ordinario (semana 21), año impar
- [Es fuerte el amor como la muerte](r/bc06846301.md) — Balduino de Canterbury · Tratado 10: PL 204, 513-514. 516 · Miércoles de la semana XXIII del Tiempo Ordinario (semana 23), año impar
- [La salvación del mundo ha sido distribuida y ordenada en una escalonada serie de tiempos](r/5a87b09956.md) — Balduino de Canterbury · Sobre el sacramento del altar, parte 2, 1: SC 93, 178-182 · Domingo de la semana XXIV del Tiempo Ordinario (semana 24), año impar
- [¿Quién es el sabio capaz de entender estas cosas?](r/8e328d63f4.md) — Balduino de Canterbury · Parte 2, 1: SC 93, 194-200 · Sábado de la semana XXVIII del Tiempo Ordinario (semana 28), año impar
- [La palabra de Dios es viva y eficaz](r/32cd282677.md) — Balduino de Canterbury · Tratado 6 : PL 204, 451-453 · Domingo de la semana XXXI del Tiempo Ordinario (semana 31), año par

## San Basilio Magno

- [El Verbo se hizo carne y puso su morada entre nosotros](r/b9eb587bee.md) — San Basilio Magno · 2, 6; PG 31, 1459-1462. 1471-1474 · 25 de Diciembre. LA NATIVIDAD DEL SEÑOR — Santoral, año par
- [El Señor vivifica su cuerpo en el Espíritu](r/5c5447bf82.md) — San Basilio Magno · Cap. 26, 61. 64: PG 32, 179-182. 186 · 2 de Enero — Santoral, año impar
- [Es una sola la muerte en favor del mundo y una sola la resurrección de entre los muertos](r/6cfdbd8b87.md) — San Basilio Magno · Cap. 15, núm. 35: PG 32, 127-130 · Martes Santo — Cuaresma y Pascua, año par
- [La inefable benignidad de Cristo colmó a su Iglesia de innumerables dones](r/00147757ce.md) — San Basilio Magno · SC 187, 275-277 · Viernes de la semana II de Pascua (semana 2), año par
- [La acción del Espíritu Santo](r/669853f286.md) — San Basilio Magno · Cap. 9, núms. 22-23: PG 32, 107-110 · Martes de la semana VII de Pascua (semana 7), año par
- [Es una sola la muerte en favor del mundo y una sola la resurrección de entre los muertos](r/ea2526ef25.md) — San Basilio Magno · Capítulo 15, 35: PG 32, 127-130 · Miércoles de la semana V de Cuaresma (semana 5), año impar
- [El Espíritu, dador de vida](r/6e44231b61.md) — San Basilio Magno · Cap. 15, 35-36: PG 32, 130-131 · Domingo de la semana IV de Pascua (semana 4) - Año A: Jn 10, 1-10, año impar
- [¿Cómo pagaremos al Señor todo el bien que nos ha hecho?](r/71be3b19dd.md) — San Basilio Magno · Regla 2, 2-4: PG 31, 914-915 · Viernes de la semana II del Tiempo Ordinario (semana 2), año impar
- [Yo soy el que cura a las ovejas enfermas](r/ee25c94dcc.md) — San Basilio Magno · Homilía 26 (2: PG 85, 306-307 · Domingo de la semana XVI del Tiempo Ordinario (semana 16), año impar
- [Sembrad justicia, y cosecharéis misericordia](r/6d345c210a.md) — San Basilio Magno · Hom. 3 sobre la caridad, 6: PG 31, 266-267.275 · Martes de la semana VIII del Tiempo Ordinario (semana 8), año par
- [El que se gloríe, que se gloríe en el Señor](r/36c5b91118.md) — San Basilio Magno · Homilía sobre la humildad 20, 3: PG 31, 530-531 · Jueves de la semana XIX del Tiempo Ordinario (semana 19), año impar
- [Actúa con valentía, cual experto timonel](r/f787acc67d.md) — San Basilio Magno · Carta 161, 1-2 al obispo Anfiloquio : PG 32, 630-631 · Miércoles de la semana XXI del Tiempo Ordinario (semana 21), año par
- [El Espíritu Santo, que lo ha creado todo, es Dios](r/6133979ad2.md) — San Basilio Magno · Carta 8, 11: PG 32, 263-266 · Jueves de la semana XXXI del Tiempo Ordinario (semana 31), año par

## San Basilio Magno

- [Si os mantenéis en mi palabra, seréis de verdad discípulos míos](r/2eb4de2277.md) — San Basilio Magno · Lib 1, 1-2: PG 31,1514-1515 · Sábado de la semana XXVII del Tiempo Ordinario (semana 27), año par
- [Vivo yo, pero no soy yo, es Cristo quien vive en mí](r/f77a852684.md) — San Basilio Magno · Lib 1, 2.3: PG 31,1515-1519 · Domingo de la semana XXVIII del Tiempo Ordinario (semana 28), año par

## San Beda

- [Deseo ver a Cristo](r/7150e5a01f.md) — San Beda · Núms. 4-6: PL 90, 64-66 · 25 de mayo. San Beda el Venerable, Presbítero y Doctor de la Iglesia — Santoral, año par

## San Beda el Venerable

- [¡Oh grande e insondable misterio!](r/39b44efbb1.md) — San Beda el Venerable · Homilía 5 en la vigilia de Navidad: CCL 122, 32-36 · Viernes de la semana III de Adviento (semana 3), año par
- [Concebirás y darás a luz un hijo](r/3925679f6d.md) — San Beda el Venerable · Homilía 3 en el Adviento: CCL 122, 14-17 · Viernes de la semana III de Adviento (semana 3), año par
- [Cántico de María](r/5cfdcbf569.md) — San Beda el Venerable · Lib. 1, 46-55: CCL 120, 37-39 · 22 de Diciembre — Santoral, año par
- [Están de pie delante del Cordero contemplando su gloria](r/f89423ada3.md) — San Beda el Venerable · Homilía 1, 10: CCL 122, 68. 71-72 · 28 de Diciembre. Santos Inocentes — Santoral, año par
- [Jesús crecía en sabiduría, edad y gracia](r/1ff7c8bb58.md) — San Beda el Venerable · Hom. 1, 19: CCL. 122. 134-135. 138-139 · Domingo dentro de la Octava de Navidad. LA SAGRADA FAMILIA DE JESÚS, MARÍA Y JOSÉ — Adviento y Navidad, año impar
- [María proclama la grandeza del Señor por las obras que ha hecho en ella](r/28e9c7e8f9.md) — San Beda el Venerable · Libro 1, 4: CCL 122, 25-26. 30 · 31 de mayo. LA VISITACIÓN DE LA VIRGEN MARÍA — Santoral, año par
- [Raza elegida, sacerdocio real](r/f079f8544b.md) — San Beda el Venerable · Capítulo 2: PL 93, 50-51 · Domingo de la semana III de Pascua (semana 3) - Año A: Lc 24, 13-35, año impar
- [Éstos son los bienes que principalmente hemos de pedir](r/f06c6b1ae4.md) — San Beda el Venerable · Homilía 14 (CCL 122, 272-273.277-279 · Domingo de la semana XVII del Tiempo Ordinario (semana 17), año impar
- [Somos el pueblo de Dios](r/9c470a3e48.md) — San Beda el Venerable · Homilía 1, 16: CCL 122, 117-118 · Martes de la semana XXIII del Tiempo Ordinario (semana 23), año impar
- [Precursor del nacimiento y de la muerte de Cristo](r/1b3c5bc863.md) — San Beda el Venerable · Homilía 23: CCL 122, 354. 356-357 · 29 de agosto El Martirio de San Juan Bautista — Santoral, año impar
- [Jesús lo vio y, porque lo amó, lo eligió](r/3e1e13b480.md) — San Beda el Venerable · Homilía 21: CCL 122,149-151 · 21 de septiembre SAN MATEO, apóstol y evangelista — Santoral, año impar
- [El Hijo del hombre vendrá con la gloria de su Padre](r/45947dda33.md) — San Beda el Venerable · Hom. 1, 24: CCL 122, 170-171 · Viernes de la semana XXIII del Tiempo Ordinario (semana 23), año par
- [El tiempo de las bodas es aquel en que, por el misterio de la encarnación, el Señor se unió a la Iglesia](r/1db5456fa0.md) — San Beda el Venerable · Hom. 14 : CCL 122, 95-96 · Viernes de la semana XXV del Tiempo Ordinario (semana 25), año par

## San Benito

- [No antepongan nada absolutamente a Cristo](r/c944e80402.md) — San Benito · Prólogo, 4-22; cap. 72, I-12: CSEL 75, 2-5.162-163 · 11 de julio SAN BENITO, Abad, Patrono de Europa — Santoral, año par

## San Bernardino de Siena

- [El Nombre de Jesús, el gran fundamento de la fe](r/9ba66f290c.md) — San Bernardino de Siena · Sermón 49, art. 1: Opera omnia 4, 495ss. · 3 de enero. SANTO NOMBRE DE JESÚS — Santoral, año par
- [Protector y custodio fiel](r/4cce2cca16.md) — San Bernardino de Siena · Sermón 2, Sobre san José: Opera omnia 7,16. 27-30 · 19 de marzo. SAN JOSÉ, Esposo de la Virgen María — Santoral, año par
- [El Nombre de Jesús, luz de los predicadores](r/e8c6cdba6c.md) — San Bernardino de Siena · Sermón 49, sobre el glorioso nombre de Jesucristo, cap. 2: Opera omnia 4, 505-506 · 20 de mayo. San Bernardino de Siena, Presbítero — Santoral, año par

## San Bernardo de Claraval

- [Aguardamos al Salvador](r/8f5f226f2b.md) — San Bernardo de Claraval · Sermón 4 de Adviento 1, 3-4: Opera omnia, edit. cister. 4, 1966, 182-185 · Domingo de la semana I de Adviento (semana 1), año par
- [Vendrá a nosotros la Palabra del Señor](r/17144cafbe.md) — San Bernardo de Claraval · Sermón 5 en el Adviento del Señor, 1-3: Opera omnia, Edit. cister. 4, 1966, 188-190 · Miércoles de la semana I de Adviento (semana 1), año par
- [Todos verán la salvación de Dios](r/d22adc551d.md) — San Bernardo de Claraval · Sermón 1 en el Adviento, 9-10: Opera omnia, edit. Cist. 4, 1966, 167-169 · Domingo de la semana II de Adviento (semana 2), año par
- [Todo el mundo espera la respuesta de María](r/9e664bdca7.md) — San Bernardo de Claraval · Homilía 4, 8-9: Opera Omnia, Edit. Cister. 4, 1966, 53-54 · 20 de Diciembre — Santoral, año par
- [Jesús es miel en la boca, melodía en el oído, júbilo en el corazón](r/ec17481b39.md) — San Bernardo de Claraval · Sermón 15, 4-6: Opera omnia. Edit. Cister. 1957, 1, 84-86 · 2 de Enero — Santoral, año par
- [Habitaré y caminaré con ellos](r/33407fe91e.md) — San Bernardo de Claraval · Sermón 27, 7.9 Opera omnia. Edit. Cister. 1957, I, 186-188 · 3 de Enero — Santoral, año par
- [Él es el pastor, él es pasto, él es la redención](r/315d65ea42.md) — San Bernardo de Claraval · Sermón 31, 8-10: Opera omnia. Edit Cisterc. 1957, I, 224-226 · 5 de Enero — Santoral, año par
- [En la plenitud de los tiempos vino la plenitud de la divinidad](r/e242732ddb.md) — San Bernardo de Claraval · Sermón 1-2 en la Epifanía del Señor, 1-2: PL 183, 141-143 · 29 de Diciembre. Día V - Octava de Navidad — Santoral, año impar
- [Para tener un corazón sensible a la miseria ajena, es necesario que primero reconozcas la tuya propia](r/1b34d49f2e.md) — San Bernardo de Claraval · Tratado III, 6: Opera omnia, Edit. Cisterc. 3, 1963, 20-21 · Semana III de Cuaresma — Cuaresma y Pascua, año par
- [Si no tengo amor, no soy nada](r/f442fae2c7.md) — San Bernardo de Claraval · Sermón sobre el Cantar de los cantares, 27, 8-10: Opera omnia, Edit Cisterc 1, 1957, 187-189 · Domingo de la semana VI de Pascua (semana 6), año par
- [Con él estaré en la tribulación](r/68f5f8db1b.md) — San Bernardo de Claraval · Sermón 17 sobre el salmo 90: Tú que habitas, 4, 6: Opera omnia, edición cisterciense, 4 [1966), 489-491 · El mismo día 12 de mayo. San Pancracio, Mártir — Santoral, año par
- [Mira a María, estrella del mar](r/323913d51e.md) — San Bernardo de Claraval · Hom. 11 super Missus est, 17: PL 183, 7013-71A · 24 de mayo. SANTA MARÍA, Auxilio de los Cristianos — Santoral, año par
- [Si creció el pecado, más desbordante fue la gracia](r/5cdcd1cf90.md) — San Bernardo de Claraval · Sermón 61, 3-5: Opera omnia, edic. cisterciense, 2, 1958, 150-151 · Miércoles de la semana II de Cuaresma (semana 2), año impar
- [Preciosa la sabiduría que nos da a conocer a Dios](r/8ea4f062f5.md) — San Bernardo de Claraval · Sermón 7, en la Epifanía: Opera omnia, ed. Cister 1970, 671, 26-27 · Domingo de la semana XVII del Tiempo Ordinario (semana 17), año impar
- [La castidad sin la caridad no tiene valor](r/ad7c8157ac.md) — San Bernardo de Claraval · Carta 42, a Enrique, arzobispo de Sens [Tratado sobre las costumbres y el ministerio de los obispos]), 3, 8: PL 182, 816-817 · 26 de junio San Pelayo, Mártir — Santoral, año impar
- [Esperamos la celestial consolación](r/029e1ed3d1.md) — San Bernardo de Claraval · Sermón 5 sobre la Ascensión del Señor: Opera omnia Edit Cister. t. 5, 149 150. · Viernes de la semana XII del Tiempo Ordinario (semana 12), año par
- [Hay que buscar la sabiduría](r/d2a885ce99.md) — San Bernardo de Claraval · PL 184, 577 579 · Lunes de la semana XIV del Tiempo Ordinario (semana 14), año par
- [Adorna tu morada, Sión, porque el Señor te prefiere a ti](r/11dfef9993.md) — San Bernardo de Claraval · Sermón 2, 1. 2. 3 en la dedicación de la Iglesia: Opera omnia, Edic. Cister. t. 5, 375-377 · Miércoles de la semana XIX del Tiempo Ordinario (semana 19), año impar
- [Preparada por el Altísimo, designada anticipadamente por los padres antiguos](r/625e179c36.md) — San Bernardo de Claraval · Homilía 2, 1-2.4: Opera omnia ed. Cister, 4, 1966, 21-23 · Miércoles de la semana XXV del Tiempo Ordinario (semana 25), año impar
- [Me casaré contigo en misericordia y en fidelidad](r/da8d3f0224.md) — San Bernardo de Claraval · Sermón 27, 4. 6-7: Opera omnia, Edit. Cister. t. 1, 1957, 185-187 · Miércoles de la semana XXVII del Tiempo Ordinario (semana 27), año impar
- [Me pondré de centinela para escuchar lo que me dice](r/897154fd9d.md) — San Bernardo de Claraval · Sermón 5, 1-4: Opera omnia, Edit Cist. 6, 1, 1970, 98-103 · Miércoles de la semana XXIX del Tiempo Ordinario (semana 29), año impar
- [Sobre los grados de la contemplación](r/7c47dd64b0.md) — San Bernardo de Claraval · Sermón 5, 4-5: Opera omnia, Edit Cist. 6, 1, 1970, 103-104 · Jueves de la semana XXIX del Tiempo Ordinario (semana 29), año impar
- [Yo pienso designios de paz](r/e7d56ab0b4.md) — San Bernardo de Claraval · Sermón 2, 1-2 en el día de Pentecostés: Opera omnia, Edit. Cist. t. 5, 1968, 165-166 · Sábado de la semana XXX del Tiempo Ordinario (semana 30), año impar
- [No llores, Jerusalén, porque está para llegar tu salvación](r/ff059949c1.md) — San Bernardo de Claraval · Sermón 10-11: Opera omnia, Edit. Cister t. 6, 1, 1970, 19-20 · Sábado de la semana XXXI del Tiempo Ordinario (semana 31), año impar
- [Amo porque amo, amo por amar](r/850374fb91.md) — San Bernardo de Claraval · Sermón 83, 4-6: OPERA OMNIA, edición cisterciense, 2[1958], 300-302 · 20 de agosto San Bernardo, abad y doctor de la Iglesia — Santoral, año impar
- [Piensa en María e invócala en todos los momentos](r/a29a40b93f.md) — San Bernardo de Claraval · Homilía 2, 17, 1-33: SCh 390, 1993, 168-170 · 11 de septiembre Nuestra Señora de Coromoto — Santoral, año impar
- [La madre estaba junto a la cruz](r/d69f701fca.md) — San Bernardo de Claraval · Sermón en el Domingo infraoctava de la Asunción, 14-15: Opera Omnia, edición cisterciense, 5 (1968), (273-274 · 15 de septiembre Nuestra Señora de los Dolores — Santoral, año impar
- [Que te guarden en tus caminos](r/f5f990ea88.md) — San Bernardo de Claraval · Sermón 12 sobre el salmo 90 «Qui habitat», 3, 6-8: Opera omnia, edición cisterciense, 4 [1966], 458-462 · 2 de octubre Santos Ángeles Custodios — Santoral, año impar
- [Conviene meditar los misterios de salvación](r/47a8c5ac73.md) — San Bernardo de Claraval · Sermón sobre el acueducto: Opera omnia, edición cisterciense, 5 [1968], 282-283 · 7 de octubre Nuestra Señora del Rosario — Santoral, año impar
- [Apresurémonos hacia los hermanos que nos esperan](r/5983526009.md) — San Bernardo de Claraval · Sermón 2: Opera omnia, edición cisterciense, 5 (1968), 364-368 · Mes de octubre — Santoral, año impar
- [Vivimos en la esperanza](r/e911f8177e.md) — San Bernardo de Claraval · Sermón 7 sobre el salmo 90, 1.3.5.6.12: Opera omnia, edit Cister. t. 4, 1966, 412-416. 421 · Jueves de la semana XVIII del Tiempo Ordinario (semana 18), año par
- [Primicia de la sabiduría es el temor del Señor](r/b1c609f2f7.md) — San Bernardo de Claraval · Sermón 37, 5-7: Opera omnia, Edit. Cister. t. 2, 1958, 12-14 · Martes de la semana XXIII del Tiempo Ordinario (semana 23), año par
- [Apresurémonos al encuentro de los que nos esperan](r/5e7b4b54b7.md) — San Bernardo de Claraval · Sermón 5, 2-3.6 en la fiesta de Todos los Santos : Opera omnia, Edit. Cister. t. 5, 1968, 362-363.365 · Sábado de la semana XXV del Tiempo Ordinario (semana 25), año par
- [La ciencia de los santos consiste en sufrir aquí temporalmente y deleitarse eternamente.](r/fe313db7c0.md) — San Bernardo de Claraval · Sermón 21, 1-3: Opera omnia, Edit Cister t. 6, 1, 1970, 168-170 · Martes de la semana XXXI del Tiempo Ordinario (semana 31), año par

## San Bonifacio

- [Pastor solícito que vela sobre la grey de Cristo](r/be331c07b3.md) — San Bonifacio · Carta 78: MGH, Epistolae, 3, 352. 354 · 5 de junio. San Bonifacio, Obispo y Mártir — Santoral, año par

## San Braulio de Zaragoza

- [Cristo resucitado, esperanza de todos los creyentes](r/f7ced45d54.md) — San Braulio de Zaragoza · Carta 19: PL 80, 665-666 · Oficio de Difuntos, año par

## Santa Brígida

- [Elevación de la mente a Cristo Salvador](r/73ef712659.md) — Santa Brígida · Oración 2: Revelationum S. Birgittae libri, 2, Roma 1628, pp. 408-410 · 23 de julio SANTA BRÍGIDA, Religiosa, Patrona de Europa — Santoral, año impar

## San Bruno

- [Se alegra mi espíritu en el Señor](r/a3f7308201.md) — San Bruno · Núms. 1-3: SC 88, 82-84 · 6 de octubre San Bruno, presbítero — Santoral, año impar

## San Bruno de Segni

- [Grande es el poder de la fe](r/bb7c688e40.md) — San Bruno de Segni · Parte 2, 40: PL 165, 426-428 · Domingo de la semana XXVIII del Tiempo Ordinario (semana 28), año impar

## San Buenaventura

- [Del conocimiento de Jesucristo dimana la comprensión de toda la sagrada Escritura](r/305dbf7e7f.md) — San Buenaventura · Prólogo: Opera omnia 5, 201-202 · Sábado de la semana II del Tiempo Ordinario (semana 2), año impar
- [En ti está la fuente de la vida](r/84ab7d9f98.md) — San Buenaventura · Opúsculo 3, El árbol de la vida, 29-30. 47: Opera omnia 8, 79 · Viernes posterior al segundo domingo después de Pentecostés EL SAGRADO CORAZÓN DE JESÚS — Solemnidades del Señor, año impar
- [La sabiduría misteriosa revelada por el Espíritu Santo](r/00d16fcf12.md) — San Buenaventura · Cap. 7, 1. 2. 4. 6: Opera omnia 5, 312-313 · 15 de julio San Buenaventura, Obispo y Doctor de la Iglesia — Santoral, año impar
- [La sabiduría misteriosa revelada por el Espíritu Santo](r/58fbf6a843.md) — San Buenaventura · Opúsculo sobre el itinerario de la mente hacia Dios, 7,1,2,6: Opera omnia 5, 312-313 · 15 de julio San Buenaventura, Obispo y Doctor de la Iglesia — Santoral, año par

## San Carlos Borromeo

- [Sobre el tiempo de Adviento](r/eec858d849.md) — San Carlos Borromeo · Acta Ecclesiae Mediolanensis, t. 2, Lyon 1683, 916-917 · Lunes de la semana I de Adviento (semana 1), año par

## Carta a Diogneto

- [Dios ha revelado su caridad por medio de su Hijo](r/6eb29ef724.md) — Carta a Diogneto · Caps. 8, 5-9, 6 Funck 1, 325-327 · 18 de Diciembre — Santoral, año par
- [Los cristianos en el mundo](r/56f27a83e1.md) — Carta a Diogneto · Capítulos 5-6: Funck 1, 397-401 · Martes de la semana V de Pascua (semana 5), año impar

## Carta de Bernabé

- [La esperanza de la vida, principio y término de nuestra fe](r/25b6a5afa4.md) — Carta de Bernabé · Caps. 1, 1-8; 2, 1-5: Funk 1, 3-7 · Lunes de la semana XXII del Tiempo Ordinario (semana 22), año impar
- [La nueva ley de nuestro Señor](r/030e029d3e.md) — Carta de Bernabé · Caps. 2, 6-10; 3, 1. 3, 4, 10-14: Funk 1, 7-9. 13 · Martes de la semana XXII del Tiempo Ordinario (semana 22), año impar
- [La segunda creación](r/800e42d611.md) — Carta de Bernabé · Caps. 5, 1-8; 6, 11-16: Funk 1, 13-15. 19-21 · Miércoles de la semana XXII del Tiempo Ordinario (semana 22), año impar
- [El camino de la luz](r/d2a8a4e203.md) — Carta de Bernabé · Cap. 19, 1-3. 5-7. 8-12: Funk 1, 53-57 · Jueves de la semana XXII del Tiempo Ordinario (semana 22), año impar

## Santa Catalina de Siena

- [Gusté y vi](r/54eb3be049.md) — Santa Catalina de Siena · Cap. 167, Acción de gracias a la Santísima Trinidad: edición latina, Ingolstadt 1583, ff. 290v-291 · 29 de abril. Santa Catalina de Siena, Virgen y Doctora de la IglesiaPatrona de Europa — Santoral, año par
- [Con lazos de amor](r/00459668d3.md) — Santa Catalina de Siena · Cap. 4, 13 ed. latina, Ingolstadt 1583, ff. 19v-20 · Miércoles de la semana XXIV del Tiempo Ordinario (semana 24), año impar
- [Cuán bueno y cuán suave es, Señor, tu Espíritu para con todos nosotros](r/fabf5f6856.md) — Santa Catalina de Siena · Cap 134: ed. latina, Ingolstadt 1583, ff. 215v-216 · Miércoles de la semana XXXI del Tiempo Ordinario (semana 31), año par

## San Cayetano

- [Cristo habite por la fe en nuestros corazones](r/29658abbf5.md) — San Cayetano · Carta a Elisabet Porto: Studi e Testi 177, Ciudad del Vaticano 1954, pp. 50-51 · El mismo día 7 de agosto San Cayetano, presbítero — Santoral, año impar

## San Cesáreo de Arlés

- [El que dé testimonio de la verdad será mártir de Cristo](r/3f9a1fd8c0.md) — San Cesáreo de Arlés · Sermón 225, 1-2: CCL 104, 888-889 · 21 de mayo. San Cristóbal Magallanes, Presbítero, y Compañeros, Mártires — Santoral, año par
- [Inclinaos bajo la poderosísima mano de Dios](r/fe8a505dfd.md) — San Cesáreo de Arlés · Sermón 114, 1.4: CCL 104, 593-595 · Domingo de la semana III del Tiempo Ordinario (semana 3), año impar
- [La sabiduría de Dios en la obra de la redención](r/33ace1b87f.md) — San Cesáreo de Arlés · Sermón 11, 1. 4. 6: CCL 103, 54. 56-57 · Domingo de la semana IV del Tiempo Ordinario (semana 4), año impar
- [Alegrémonos, pues hemos merecido ser templo de Dios](r/36229c5e51.md) — San Cesáreo de Arlés · Sermón 229, 2: CCL 104, 905-907 · Sábado de la semana XVI del Tiempo Ordinario (semana 16), año impar
- [El pueblo cristiano, apoyándose en la humildad, se eleva a la cumbre de la virtud](r/82f5d5d1e4.md) — San Cesáreo de Arlés · Sermón 90, 4.6: CCL 103, 372.373. 374 · Miércoles de la semana V del Tiempo Ordinario (semana 5), año par
- [La misericordia divina y la misericordia humana](r/7313f6cdba.md) — San Cesáreo de Arlés · Sermón 25, 1: CCL 103, 111-112 · Lunes de la semana VIII del Tiempo Ordinario (semana 8), año par
- [No es duro lo que manda aquel que ayuda a realizar lo que ordena](r/cc26755d11.md) — San Cesáreo de Arlés · Sermón 159,1.4-6: CCL 104, 652-654 · Domingo de la semana XXIV del Tiempo Ordinario (semana 24), año impar
- [Todos, por el bautismo, hemos sido hechos templos de Dios](r/eace2796dd.md) — San Cesáreo de Arlés · Sermón 229,1-3: CCL 104, 905-908 · 6 de noviembre Mártires de España del Siglo XX — Santoral, año impar
- [¿Cómo seguir a Cristo?](r/4059fdf75c.md) — San Cesáreo de Arlés · Sermón 159, 1. 3-6: CCL 104, 650. 652-654 · 25 de noviembre Santa Catalina de Alejandría, virgen y mártir — Santoral, año impar

## San Cipriano

- [Es cristiano el que en todo imita a Cristo](r/d738f99d0e.md) — San Cipriano · PLS 1, 51-52 · Viernes de la semana IX del Tiempo Ordinario (semana 9), año impar

## San Cipriano de Cartago

- [La esperanza nos sostiene](r/05c8e6f390.md) — San Cipriano de Cartago · Tratado 13.15: CSEL 3, 406-408 · Sábado de la semana I de Adviento (semana 1), año par
- [Los mártires están reservados para la diadema del Señor](r/db808d8174.md) — San Cipriano de Cartago · Cap. 2: PL 4, 479-480 · 10 de diciembre. Santa Eulalia de Mérida Virgen y Mártir — Santoral, año par
- [Los que deseamos alcanzar las promesas del Señor debemos imitarle en todo](r/4a6dcb0d37.md) — San Cipriano de Cartago · Carta 6,1-2: CSEL 3, 480-482 · Para varios mártires — Comunes, año par
- [El coro numeroso de las vírgenes acrecienta el gozo de la madre Iglesia](r/c4251428aa.md) — San Cipriano de Cartago · Núms. 3-4. 22. 23: CSEL 3,189-190. 202-204 · Común de vírgenes — Comunes, año par
- [El que nos dio la vida nos enseñó también a orar](r/38e10541fe.md) — San Cipriano de Cartago · Caps. 1-3: CSEL 3, 267-268 · Martes de la semana I de Cuaresma (semana 1), año par
- [La lucha por la fe](r/068c24c3a0.md) — San Cipriano de Cartago · Carta 58, 8-9.11: CSEL 3, 663-666 · 11 de abril. San Estanislao, Obispo y Mártir — Santoral, año par
- [Los sacramentos vitales](r/552b0fdedc.md) — San Cipriano de Cartago · Carta 63, 8-9: CSEL 3, parte 2, 706-708 · Viernes de la semana V de Pascua (semana 5), año impar
- [Que nuestras obras proclamen la generosidad de Dios](r/12594d815b.md) — San Cipriano de Cartago · Trat. 12-13.15: CSEL 3, 427-430 · Domingo de la semana VII del Tiempo Ordinario (semana 7), año impar
- [La oración ha de salir de un corazón humilde](r/666e7df380.md) — San Cipriano de Cartago · Tratado 4-6: CSEL 3, 268-270 · Martes de la semana XI del Tiempo Ordinario (semana 11), año impar
- [Nuestra oración es pública y común](r/2094475dc3.md) — San Cipriano de Cartago · Tratado 8-9: CSEL 3, 271-272 · Alma mía, camina con brío. — Tiempo Ordinario, año impar
- [Santificado sea tu nombre](r/0f5b8c96e4.md) — San Cipriano de Cartago · Tratado 11-12: CSEL 3, 274-275 · Jueves de la semana XI del Tiempo Ordinario (semana 11), año impar
- [Venga a nosotros tu reino, hágase tu voluntad](r/8b192cfbaf.md) — San Cipriano de Cartago · Tratado 13-14: CSEL 3, 275-277 · Viernes de la semana XI del Tiempo Ordinario (semana 11), año impar
- [No anteponer nada a Cristo](r/e416f734b4.md) — San Cipriano de Cartago · Tratado 15-16: CSEL 3, 277-279 · Sábado de la semana XI del Tiempo Ordinario (semana 11), año impar
- [Pedimos de modo que nuestra oración recabe la salvación de todos](r/ed27a80d31.md) — San Cipriano de Cartago · Tratado 17-18: CSEL 3, 279-281 · Domingo de la semana XII del Tiempo Ordinario (semana 12), año impar
- [No os agobiéis por el mañana](r/ba194f7b71.md) — San Cipriano de Cartago · Tratado 19-20: CSEL 3, 281-282 · Lunes de la semana XII del Tiempo Ordinario (semana 12), año impar
- [Después del alimento, pedimos el perdón de los pecados](r/3304215b4f.md) — San Cipriano de Cartago · Tratado 22-23: CSEL 3, 283-285 · Martes de la semana XII del Tiempo Ordinario (semana 12), año impar
- [Que los que somos hijos de Dios permanezcamos en la paz de Dios](r/3c35940af5.md) — San Cipriano de Cartago · Tratado 24-25: CSEL 3, 285-286 · Miércoles de la semana XII del Tiempo Ordinario (semana 12), año impar
- [Velad y orad](r/0e919e3a25.md) — San Cipriano de Cartago · Tratado 26-27: CSEL 3, 286-287 · Jueves de la semana XII del Tiempo Ordinario (semana 12), año impar
- [Hay que orar no sólo con palabras, sino también con los hechos](r/b5c94abe00.md) — San Cipriano de Cartago · Tratado 28-29: CSEL 3, 287-288 · Viernes de la semana XII del Tiempo Ordinario (semana 12), año impar
- [El Señor oraba por nuestros pecados](r/d484a6587a.md) — San Cipriano de Cartago · Tratado 30-31: CSEL 3, 288-290 · Sábado de la semana XII del Tiempo Ordinario (semana 12), año impar
- [Buena es la oración con el ayuno y la limosna](r/4d60a58aa9.md) — San Cipriano de Cartago · Tratado 32-33: CSEL 3, 290-292 · Domingo de la semana XIII del Tiempo Ordinario (semana 13), año impar
- [Los cristianos han de adorar a Dios frecuentemente y siempre](r/0a855058aa.md) — San Cipriano de Cartago · Tratado 34-35: CSEL 3, 292-293 · Lunes de la semana XIII del Tiempo Ordinario (semana 13), año impar
- [Los que estamos siempre en Cristo, no cesemos de orar ni siquiera de noche](r/acf0e00bc7.md) — San Cipriano de Cartago · Tratado 36: CSEL 3, 293-294 · Martes de la semana XIII del Tiempo Ordinario (semana 13), año impar
- [Fabián nos da ejemplo de fe y de fortaleza](r/2f0e69b904.md) — San Cipriano de Cartago · Cartas 9,1; 8, 2-3: CSEL 3, 488-489. 487-488 · El mismo día 20 de enero San Fabián, Papa y Mártir — Santoral, año impar
- [Cristo nos dio la paz y nos mandó que tuviéramos un solo corazón y una sola alma](r/00176a31e1.md) — San Cipriano de Cartago · 12-14: CCL 3, 257-259 · Miércoles de la semana XIII del Tiempo Ordinario (semana 13), año par
- [Volved a mí, dice el Señor](r/41af6be4ba.md) — San Cipriano de Cartago · Tratado 3-4: CSEL 3, 398-399 · Viernes de la semana XXVII del Tiempo Ordinario (semana 27), año impar
- [Sabemos que los soldados de Cristo no son destruidos sino coronados](r/7aadec9b6e.md) — San Cipriano de Cartago · Carta 80: CSEL 3, 839-840 · 7 de agosto San Sixto, papay compañeros, mártires — Santoral, año impar
- [Fe inquebrantable](r/9dba0b4911.md) — San Cipriano de Cartago · Carta 10, 2-3. 5: CSEL 3, 491-492. 494-495 · 13 de agosto San Ponciano, papay San Hipólito, presbítero, mártires — Santoral, año impar
- [Una fe generosa y firme](r/fbfbe6ebca.md) — San Cipriano de Cartago · Carta 60,1-2. 5: CSEL 3, 691-692. 694-695 · 16 de septiembre San Cornelio, papa, y Cipriano, obispo, mártires — Santoral, año impar
- [Tratándose de un asunto tan claro, no hay por qué pensarlo más](r/e58894e986.md) — San Cipriano de Cartago · Cap. 3-6: CSEL 3,112-114 · Propio de los santos — Santoral, año impar
- [En la persecución se inflige la muerte, pero sigue la inmortalidad](r/9863921d18.md) — San Cipriano de Cartago · Cap. 13: CSEL 3, 346-347 · 14 de octubre San Calixto I, papa y mártir — Santoral, año impar

## San Cirilo

- [Su gloria llenará la tierra](r/c13c788e3c.md) — San Cirilo · Lib. 4, or. 1: PG 70, 859-861 · Miércoles de la semana II de Adviento (semana 2), año impar

## San Cirilo de Alejandría

- [Israel echará brotes y flores](r/780fd15fb1.md) — San Cirilo de Alejandría · Lib 3, t 1: PG 70, 593-594 · Viernes de la semana II de Adviento (semana 2), año par
- [Al asumir la condición de esclavo, Cristo, en cierto modo, fue contado entre los siervos](r/667d1c59bd.md) — San Cirilo de Alejandría · Homilía 12: PG 77, 1042. 1047. 1050 · Navidad y su Octava — Adviento y Navidad, año par
- [La santísima Virgen ha de ser llamada Madre de Dios](r/8fcc68c757.md) — San Cirilo de Alejandría · Homilía 15, 1-3 sobre la encarnación del Verbo: PG 77, 1090-1091 · 1 de Enero. SANTA MARÍA, MADRE DE DIOS — Santoral, año par
- [Alabanzas de la Madre de Dios](r/09a87d2250.md) — San Cirilo de Alejandría · Homilía 4: PG 77, 991. 995-996 · Común de Santa maría virgen — Comunes, año par
- [Visión escatológica de la Iglesia](r/bdd8c1c2cd.md) — San Cirilo de Alejandría · Lib. 1, 2: PG 70, 67-71 · Martes de la semana I de Adviento (semana 1), año impar
- [Nos llamamos cristianos y en Cristo está puesta toda nuestra esperanza](r/cdef373edf.md) — San Cirilo de Alejandría · Lib. 3, t. 5: PG 70, 850-851 · Viernes de la semana I de Adviento (semana 1), año impar
- [Por la fe en Cristo hemos sacudido el enojoso y pesado yugo del pecado](r/86fea11605.md) — San Cirilo de Alejandría · Lib 3, t l: PG 70, 563-566 · Jueves de la semana II de Adviento (semana 2), año impar
- [Los hombres de fe son los que reciben la bendición con Abrahán el fiel](r/d83ed7ae20.md) — San Cirilo de Alejandría · Num. 7, 72: PG 71, 774-775 · Semana III de Adviento — Adviento y Navidad, año impar
- [Vendrá el Señor y su doctrina superará a la ley](r/75064d122e.md) — San Cirilo de Alejandría · Núm. 3, 32: PG 72, 330-331 · Martes de la semana III de Adviento (semana 3), año impar
- [Dios Padre lo ha hecho para nosotros misericordia y justicia](r/cce15af3ee.md) — San Cirilo de Alejandría · Lib. 4, or. 2: PG 70, 955-958 · 17 de Diciembre — Santoral, año impar
- [Mirad: viene con su salario, y su recompensa lo precede](r/e077b6d8f6.md) — San Cirilo de Alejandría · Lib 3, t. 4: PG 70, 806-807 · 18 de Diciembre — Santoral, año impar
- [El profeta inspirado vaticinó al Dios-con-nosotros](r/cef9fba750.md) — San Cirilo de Alejandría · Lib. 4, or. 4: PG 70, 1035-1038 · 20 de Diciembre — Santoral, año impar
- [Todos verán la salvación de Dios](r/148463c667.md) — San Cirilo de Alejandría · Lib. 3, t. 4: PG 70, 802-803 · 24 de Diciembre — Santoral, año impar
- [El verdadero cordero se inmoló por nosotros](r/41363641c2.md) — San Cirilo de Alejandría · Homilía pascual 2: PG 77, 823-825 · Jueves de la semana I de Cuaresma (semana 1), año par
- [Hablaban de la muerte que Jesús iba a consumar en Jerusalén](r/a3bfdc045d.md) — San Cirilo de Alejandría · Homilía 9 en la transfiguración del Señor: PG 77, 1011-1014 · Semana II de Cuaresma — Cuaresma y Pascua, año par
- [Las brillantes gestas de Cristo](r/d5f38b47bf.md) — San Cirilo de Alejandría · Lib. 3: PG 68, 275-278 · Miércoles de la semana II de Cuaresma (semana 2), año par
- [Cristo se consagró a sí mismo por nuestros pecados](r/e847690f36.md) — San Cirilo de Alejandría · Lib. 11, cap. 10: PG 74, 543-546 · Viernes de la semana III de Cuaresma (semana 3), año par
- [La Iglesia sigue a Cristo doquiera que va](r/efddfb7a4e.md) — San Cirilo de Alejandría · Lib. 5: PG 68, 394-395 · Viernes de la semana IV de Cuaresma (semana 4), año par
- [Cristo brotó en medio de nosotros como una espiga de trigo; murió y produce mucho fruto](r/71e9db2881.md) — San Cirilo de Alejandría · 2: PG 69, 619-623 · Semana V de Cuaresma — Cuaresma y Pascua, año par
- [Hemos de adorar en espíritu y en verdad](r/ae219c9165.md) — San Cirilo de Alejandría · Lib. 9: PG 68, 587-589 · Miércoles de la semana V de Cuaresma (semana 5), año par
- [Mirad al Rey justo](r/141ee5d69e.md) — San Cirilo de Alejandría · Lib 4, orat 2: PG 70, 967-970 · Domingo de Ramos en la Pasión del Señor — Cuaresma y Pascua, año par
- [Cristo entregó su alma en manos del Padre, abriéndonos a nuevas y luminosas esperanzas](r/afc91a377d.md) — San Cirilo de Alejandría · Lib. 12: PG 74, 667-670 · Triduo pascual — Cuaresma y Pascua, año par
- [Los que gozan de la presencia de Cristo, es lógico que estén tranquilos](r/72cf11214d.md) — San Cirilo de Alejandría · Lib. 12, Cap. 1: PG 74, 703-706 · Domingo de la Octava de Pascua — Cuaresma y Pascua, año par
- [Dichosos los que crean sin haber visto](r/6c0243ea7f.md) — San Cirilo de Alejandría · Lib. 12, cap. 1: PG 74, 730-735 · Domingo de la semana III de Pascua (semana 3), año par
- [Nosotros os anunciamos la promesa que Dios hizo a nuestros padres](r/814402f643.md) — San Cirilo de Alejandría · Cap. 2, 14: PG 74, 925-926 · Martes de la semana IV de Pascua (semana 4), año par
- [Alcanzó a todos la misericordia divina y fue salvado todo el mundo](r/28d6555629.md) — San Cirilo de Alejandría · Cap. 15, 7: PG 74, 854-855 · Sábado de la semana IV de Pascua (semana 4), año par
- [Yo soy la vid, vosotros los sarmientos](r/fd8dc977cf.md) — San Cirilo de Alejandría · Lib 10, 2: PG 74, 331-334 · Domingo de la semana V de Pascua (semana 5), año par
- [Dios nos ha reconciliado por medio de Cristo y nos ha confiado el ministerio de esta reconciliación](r/ca0d5e5e88.md) — San Cirilo de Alejandría · Cap. 5, 5-6. 2: PG 74, 942-943 · Domingo de la semana VI de Pascua (semana 6), año par
- [Nuestro Señor Jesucristo nos ha inaugurado un camino nuevo y vivo](r/a102ae9b6f.md) — San Cirilo de Alejandría · Lib 9: PG 74, 182-183 · Solemnidad — Cuaresma y Pascua, año par
- [Jesucristo ruega no sólo por los Doce, sino por todos aquellos que, en diversas épocas, han de creer por la palabra de ellos](r/c1178a9714.md) — San Cirilo de Alejandría · Lib 11, cap 11: PG 74, 551-554 · Semana VII de Pascua — Cuaresma y Pascua, año par
- [Si no me voy, el Abogado no vendrá a vosotros](r/00e4683758.md) — San Cirilo de Alejandría · Libro 10, 16, 6-7: PG 74, 434 · Jueves de la semana VII de Pascua (semana 7), año par
- [Abiertamente se nos predica el misterio de Cristo](r/7c29394bc3.md) — San Cirilo de Alejandría · Lib. 3, cap. 3: PG 73, 427-434 · Semana II de Cuaresma — Cuaresma y Pascua, año impar
- [Después de Moisés y la ley, Cristo se ha hecho nuestro guía](r/6ed72fabc2.md) — San Cirilo de Alejandría · Lib. 8: PG 68, 574- 575 · Martes de la semana II de Cuaresma (semana 2), año impar
- [Cristo, pontífice y mediador](r/95854fee59.md) — San Cirilo de Alejandría · Lib. 11, cap. 8: PG 74, 506-507 · Martes de la semana III de Cuaresma (semana 3), año impar
- [Cristo se ofreció a sí mismo por nosotros y se sometió espontáneamente a la muerte](r/d43a1332eb.md) — San Cirilo de Alejandría · Lib. 3: PG 68, 290-291 · Miércoles de la semana III de Cuaresma (semana 3), año impar
- [Cristo se hizo pontífice misericordioso](r/8409d5862f.md) — San Cirilo de Alejandría · Homilía pascual 26, 3: PG 77, 926 · Jueves de la semana III de Cuaresma (semana 3), año impar
- [Estableció a Melquisedec como imagen y figura de Cristo](r/9adba4eed8.md) — San Cirilo de Alejandría · Lib. 2, 7-9: PG 69, 99-106 · Semana IV de Cuaresma — Cuaresma y Pascua, año impar
- [Por nuestra salvación, Cristo se hizo obediente al Padre](r/1d0b4f4639.md) — San Cirilo de Alejandría · Homilía Pascual 5, 7: PG 77, 495-498 · Domingo de la semana V de Cuaresma (semana 5) - Año A: Jn 11, 1-45, año impar
- [La pasión de Cristo y su preciosa cruz son seguridad y muro inaccesible para quien cree en él.](r/78ac7b9d75.md) — San Cirilo de Alejandría · Lib. 4, or. 4: PG 70, 1066-1067 · Domingo de Ramos en la Pasión del Señor — Cuaresma y Pascua, año impar
- [Hemos sido sacrificados con Cristo](r/0de6d2ffd6.md) — San Cirilo de Alejandría · Lib. 12: PG 74, 650-654 · Triduo pascual — Cuaresma y Pascua, año impar
- [Cristo entregó su cuerpo para la vida de todos](r/eaa5a84367.md) — San Cirilo de Alejandría · Lib. 4, cap. 2: PG 73, 563- 566 · Viernes de la semana III de Pascua (semana 3), año impar
- [Son peregrinos y extranjeros en la tierra quienes viven una vida celestial](r/11658d785d.md) — San Cirilo de Alejandría · Lib. 10: PG 74, 386-387 · Martes de la semana III del Tiempo Ordinario (semana 3), año impar
- [Se nos llama cristianos o pueblo de Dios](r/72d6678f8f.md) — San Cirilo de Alejandría · Lib. 4, or. 1: PG 70, 890-891 · Viernes de la semana III del Tiempo Ordinario (semana 3), año impar
- [Los apóstoles predican al mundo la alegría](r/d95128de92.md) — San Cirilo de Alejandría · Lib. 4, or. 2: PG 70, 938-939 · Jueves de la semana VI del Tiempo Ordinario (semana 6), año impar
- [Sobre todo buscad el reino de Dios y su justicia](r/44dce7017a.md) — San Cirilo de Alejandría · Hom. 62. Edit R.R. Tonneau: CSCO t. 70, 160-164 · Domingo de la semana VIII del Tiempo Ordinario (semana 8), año impar
- [Los discípulos llamados a ser los iniciadores y maestros del mundo entero](r/c14c90a2fa.md) — San Cirilo de Alejandría · Cap 6: PG 72, 602-603 · Domingo de la semana VIII del Tiempo Ordinario (semana 8), año impar
- [Liberados de una servidumbre espiritual](r/895f798eae.md) — San Cirilo de Alejandría · Lib. 4, orat. 1: PG 70, 859-862 · Domingo de la semana X del Tiempo Ordinario (semana 10), año impar
- [No nos pertenecemos: somos de quien nos compró y salvó](r/8e555ed88a.md) — San Cirilo de Alejandría · Lib. 4, or. 2: PG 70, 967-970 · Martes de la semana X del Tiempo Ordinario (semana 10), año impar
- [Pedro hace una precisa profesión de fe en Cristo](r/9e6b5865fb.md) — San Cirilo de Alejandría · Homilía 39 : Edit R.M. Tonneau, CSCO Script Syri 70,110-115 · Domingo de la semana XII del Tiempo Ordinario (semana 12), año impar
- [Cristo murió por todos](r/fda6608720.md) — San Cirilo de Alejandría · Lib. 5, t. 1: PG 70, 1190-1191 · Miércoles de la semana XVII del Tiempo Ordinario (semana 17), año impar
- [Institución del culto en espíritu y en verdad, por obra de los oráculos evangélicos](r/cbcd2b67d1.md) — San Cirilo de Alejandría · Lib. 5, t. 2: PG 70, 1223-1226 · Jueves de la semana XVII del Tiempo Ordinario (semana 17), año impar
- [Defensor de la maternidad divina de la virgen María](r/3b24f12532.md) — San Cirilo de Alejandría · Carta 1: PG 77,14-18. 27-30 · 27 de junio San Cirilo de Alejandría, Obispo y Doctor de la Iglesia — Santoral, año impar
- [Cuando se cumplió el tiempo, envió Dios a su Hijo para que recibiéramos el ser hijos por adopción](r/725fe8cb33.md) — San Cirilo de Alejandría · PG 77, 27-30 · Miércoles de la semana I del Tiempo Ordinario (semana 1), año par
- [Es grande mi nombre entre las naciones](r/589ee3d49b.md) — San Cirilo de Alejandría · 14: PG 71. 1047 1050 · Miércoles de la semana XI del Tiempo Ordinario (semana 11), año par
- [Llama al Monte Sión «madre de los primogénitos»; en ella estaremos juntamente con Cristo](r/80681d693a.md) — San Cirilo de Alejandría · Cap 3, 35-36; 37; 40; 41: PG 71, 689-692; 694; 702-703; 705. · Sábado de la semana XII del Tiempo Ordinario (semana 12), año par
- [Nuestro Señor Jesucristo nos alimenta para la vida eterna](r/4b38ea0581.md) — San Cirilo de Alejandría · Lib 2, 3: PG 69, 455-459 · SEMANA XX del tiempo ordinario, año impar
- [Por la participación en la mesa eucarística, Cristo en nosotros y nosotros en Cristo formamos una sola realidad](r/65a1d59c60.md) — San Cirilo de Alejandría · Lib. 10: PG 74, 342 · Miércoles de la semana XX del Tiempo Ordinario (semana 20), año impar
- [La Iglesia sigue a Cristo por doquier](r/b9c5d88962.md) — San Cirilo de Alejandría · Lib 5: PG 68, 391-395 · Domingo de la semana XXII del Tiempo Ordinario (semana 22), año impar
- [Dichoso el hombre que confía en Dios](r/61b7f26154.md) — San Cirilo de Alejandría · Lib. 2, 5: PG 70, 502-503 · Lunes de la semana XXIV del Tiempo Ordinario (semana 24), año impar
- [Toda nuestra esperanza está puesta en Cristo](r/5bdb3aebce.md) — San Cirilo de Alejandría · Lib. 3, t. 1: PG 70, 571-573 · Jueves de la semana XXIV del Tiempo Ordinario (semana 24), año impar
- [¡Habitantes de la tierra, aprended justicia!](r/1b4e67baf5.md) — San Cirilo de Alejandría · Lib. 3, 1: PG 70, 575-578 · Martes de la semana XXV del Tiempo Ordinario (semana 25), año impar
- [Esperamos el juicio futuro](r/293e757270.md) — San Cirilo de Alejandría · Lib. 3, t. 2: PG 70, 631-633 · Viernes de la semana XXV del Tiempo Ordinario (semana 25), año impar
- [Volveos a mí por la penitencia](r/409b07119b.md) — San Cirilo de Alejandría · Lib. 3, t. 5: PG 70, 826-828 · Lunes de la semana XXVI del Tiempo Ordinario (semana 26), año impar
- [Se nos llama cristianos o pueblo de Dios](r/cdc971a06b.md) — San Cirilo de Alejandría · Lib. 4, Sermón 1: PG 70, 887-890 · Viernes de la semana XXVI del Tiempo Ordinario (semana 26), año impar
- [Seremos posesión y herencia de Dios](r/35d77dd7b3.md) — San Cirilo de Alejandría · Lib. 3, t. 1: PG 70, 579-582 · Sábado de la semana XXVI del Tiempo Ordinario (semana 26), año impar
- [Dios Padre domina todas las cosas](r/16b2af142c.md) — San Cirilo de Alejandría · Homilía pascual 9, 6: PG 77, 599-602 · Domingo de la semana XXVII del Tiempo Ordinario (semana 27), año impar
- [Sobre el juicio pronunciado por el Padre](r/c5156a9791.md) — San Cirilo de Alejandría · Lib 4, Sermón 4: PG 70, 1042-1043 · Domingo de la semana XXVII del Tiempo Ordinario (semana 27), año impar
- [¿Quién es capaz de conocer el pensamiento de Dios?](r/85b3f009bf.md) — San Cirilo de Alejandría · Lib. 5, t. 2: PG 70, 1230-1231 · Viernes de la semana XXIX del Tiempo Ordinario (semana 29), año impar
- [No hubo tiempo alguno en que Dios no llamase a todos a la salvación](r/c8f52cda57.md) — San Cirilo de Alejandría · Homilía pascual 2, 8: PG 77, 447-450 · Martes de la semana XXX del Tiempo Ordinario (semana 30), año impar
- [La renovación ha sido llevada a cabo en Cristo](r/330fb94b71.md) — San Cirilo de Alejandría · Lib. 4, Sermón 1: PG 70, 891-894 · Miércoles de la semana XXXI del Tiempo Ordinario (semana 31), año impar
- [Cristo, en cuanto Hijo y Señor, se ha convertido en administrador del nuevo Testamento](r/3c773fdfda.md) — San Cirilo de Alejandría · Lib. 4, Sermón 1: PG 70, 858-859 · Jueves de la semana XXXI del Tiempo Ordinario (semana 31), año impar
- [Cuando aparezca Cristo, entonces también vosotros apareceréis juntamente con él, en la gloria](r/788d36160e.md) — San Cirilo de Alejandría · Lib 9: PG 74, 266 · Domingo de la semana XXXIV del Tiempo Ordinario (semana 34) JESUCRISTO, REY DEL UNIVERSO, año impar
- [Como el Padre me ha enviado, así también os envío yo](r/eae33b1529.md) — San Cirilo de Alejandría · Libro 12, cap. 1: PG 74, 707-710 · 28 de octubre SAN SIMÓN Y SAN JUDAS, apóstoles — Santoral, año impar
- [El Señor es pronto a la misericordia y salva a los que hacen penitencia](r/9a4312e08b.md) — San Cirilo de Alejandría · Cap 3, 23—4, 29: PG 71, 631.638 · Domingo de la semana XIX del Tiempo Ordinario (semana 19) - Año A: Mt 14, 22-33, año par
- [En Cristo nos convertimos en una criatura nueva](r/6dae77c3b2.md) — San Cirilo de Alejandría · Lib 4, Sermón 2: PG 70, 975-978 · Jueves de la semana XXIX del Tiempo Ordinario (semana 29), año par
- [Demos gracias a Dios Padre que nos ha sacado del dominio de las tinieblas](r/ae64e5bd70.md) — San Cirilo de Alejandría · Lib 4, Sermón 4: PG 70, 1090-1091 · Sábado de la semana XXIX del Tiempo Ordinario (semana 29), año par
- [Cristo se rebajó, para que siendo el primero en regresar al reino, fuera para nosotros el principio y el camino hacia la gloria real](r/81652d3bda.md) — San Cirilo de Alejandría · Lib 2: PG 73, 283-286 · Solemnidad — Tiempo Ordinario, año par
- [Ha aparecido Cristo, nuestra paz](r/b8b0574de8.md) — San Cirilo de Alejandría · Lib 5, t. 1: PG 70, 1151-1155 · Viernes de la semana XXXIV del Tiempo Ordinario (semana 34), año par

## San Cirilo de Jerusalén

- [Las dos venidas de Cristo](r/74b4e0fdd3.md) — San Cirilo de Jerusalén · Catequesis 15,1-3: PG 33, 870-874 · Domingo de la semana I de Adviento (semana 1), año par
- [El agua viva del Espíritu Santo](r/35035c1f6b.md) — San Cirilo de Jerusalén · Catequesis sobre el Espíritu Santo, 16, 1, 11-12. 16: PG 33, 931-935. 939-942 · Domingo de la semana VII de Pascua (semana 7) - Año A: Jn 17, 1-11a, año par
- [Preparad limpios los vasos para recibir al Espíritu Santo](r/70548f1247.md) — San Cirilo de Jerusalén · Catequesis 3 1-3: PG 33, 426-430 · 18 de marzo. San Cirilo de JerusalénObispo y Doctor de la Iglesia — Santoral, año par
- [La Iglesia o convocación del pueblo de Dios](r/d9e6653345.md) — San Cirilo de Jerusalén · Catequesis 18, 23 25: PG 33,1043-1047 · Miércoles de la semana VIII del Tiempo Ordinario (semana 8), año impar
- [La Iglesia es la esposa de Cristo](r/f37a58b599.md) — San Cirilo de Jerusalén · Catequesis 18, 26-29: PG 33,1047-1050 · Jueves de la semana VIII del Tiempo Ordinario (semana 8), año impar
- [La salvación proviene de la misericordia de Dios](r/0462812923.md) — San Cirilo de Jerusalén · Catequesis 2, 5-8: Edit Reisch 1, 445-449 · Viernes de la semana XIII del Tiempo Ordinario (semana 13), año impar
- [Reconoce el mal que has hecho, ahora que es el tiempo propicio](r/e98c202850.md) — San Cirilo de Jerusalén · Catequesis 1, 2-3. 5-6: PG 33, 371. 375-378 · Viernes de la semana XV del Tiempo Ordinario (semana 15), año impar
- [Que la cruz sea tu gozo también en tiempo de persecución](r/48bf85a08e.md) — San Cirilo de Jerusalén · Catequesis 13, 1.3.6.23: PG 33, 771-774.779.799.802 · Jueves de la semana VI del Tiempo Ordinario (semana 6), año par
- [La fe realiza obras que superan las fuerzas humanas](r/f03cdc315f.md) — San Cirilo de Jerusalén · Catequesis 5, 10-11, sobre la fe y el símbolo : PG 33, 518-519 · Sábado de la semana XXXII del Tiempo Ordinario (semana 32), año par
- [Sobre el símbolo de la fe](r/1d590d4f81.md) — San Cirilo de Jerusalén · Catequesis 5, 12-13, sobre la fe y el símbolo : PG 33, 519-523 · Domingo de la semana XXXIII del Tiempo Ordinario (semana 33), año par

## Santa Clara

- [Atiende a la pobreza, la humildad y la caridad de Cristo](r/c0c0f979b4.md) — Santa Clara · Escritos de santa Clara, edición Ignacio Omaechevarría, Madrid 1970, pp. 339-341 · 11 de agosto Santa Clara, virgen — Santoral, año impar

## Clemente de Alejandría

- [En seguir a Cristo está nuestra salvación](r/f42ba11338.md) — Clemente de Alejandría · Lib. 1, cap. 6, 2627. 3031: SC 70, 159. 161. 167 · Domingo de la semana III de Pascua (semana 3) - Año A: Lc 24, 13-35, año par
- [Yo soy vuestro preceptor](r/0f206e38b9.md) — Clemente de Alejandría · Lib 1, cap 7: PG 8, 315-318 · Martes de la semana XIII del Tiempo Ordinario (semana 13), año par
- [Hemos de honrar a Dios durante toda la vida](r/5a0b00949d.md) — Clemente de Alejandría · Lib 7, cap 7: PG 9, 450-451.458-459 · Jueves de la semana XIII del Tiempo Ordinario (semana 13), año par
- [Revistámonos con las armas de la paz](r/fcb1f322ec.md) — Clemente de Alejandría · Exhortación a los paganos, Cap. 11; PG 8, 235-238 · Viernes de la semana XXI del Tiempo Ordinario (semana 21), año impar
- [Adorar a Dios mediante la verdadera santidad de las obras y del conocimiento](r/d770b471d1.md) — Clemente de Alejandría · Lib. 6: PG 9, 295-298 · Domingo de la semana XXIII del Tiempo Ordinario (semana 23), año impar
- [La verdadera penitencia consiste en no recaer en las mismas faltas](r/43d600ead2.md) — Clemente de Alejandría · 39-40: PG 9, 643-646 · Domingo de la semana XXVI del Tiempo Ordinario (semana 26), año impar
- [Si quieres ser perfecto](r/c16b0fcd99.md) — Clemente de Alejandría · Caps 5.10: PG 9, 610.614 · Domingo de la semana XXVIII del Tiempo Ordinario (semana 28), año impar
- [Acojamos la luz y hagámonos discípulos del Señor](r/d870d7bad4.md) — Clemente de Alejandría · Cap 11: PG 8, 230-234 · Semana XXX DEL TIEMPO ORDINARIO, año impar
- [Llevemos desde ahora una vida sobria, honrada y religiosa aguardando la aparición gloriosa del gran Dios](r/b42ff5f42f.md) — Clemente de Alejandría · Cap 1: PG 8, 59-63 · Jueves de la semana XXIII del Tiempo Ordinario (semana 23), año par
- [El hombre inmortal es un magnífico himno de Dios](r/4abea81449.md) — Clemente de Alejandría · Cap 10: PG 8, 223-228 · Viernes de la semana XXVIII del Tiempo Ordinario (semana 28), año par
- [Dichosos los que derraman su sangre por causa de Dios](r/430d190746.md) — Clemente de Alejandría · Lib 4, 7: PG 8, 1255.1259.1263.1266.1267 · Miércoles de la semana XXXII del Tiempo Ordinario (semana 32), año par

## San Clemente I, papa

- [Convertíos](r/f1ef327991.md) — San Clemente I, papa · Caps. 7, 4-8, 5-9. 1; 13, 1-4; 19, 2: Funck 1, 71-73.77-78.87 · Miércoles de Ceniza — Cuaresma y Pascua, año par
- [Muchos son los senderos, pero uno solo es el camino](r/219f8f89fc.md) — San Clemente I, papa · Cap. 36, 1-2; 37-38: Funk 1, 145-149 · Viernes de la semana IV de Pascua (semana 4), año par
- [¿Quién será capaz de explicar el vínculo del amor divino?](r/ce13c14964.md) — San Clemente I, papa · 49-50: Funck 1, 123-125 · Semana I de Cuaresma — Cuaresma y Pascua, año impar
- [Habiendo sufrido por envidia, se han convertido en un magnífico ejemplo](r/25c228b1bc.md) — San Clemente I, papa · Caps. 5,1-7, 4: Funk 1, 67-71 · Mes de junio — Santoral, año impar
- [Gracia y paz a vosotros de parte del Dios omnipotente](r/f3d4f33212.md) — San Clemente I, papa · 1: Funk 1,61-62 · Domingo de la semana II del Tiempo Ordinario (semana 2), año par
- [Sed solícitos día y noche por la fraternidad universal](r/57ba417109.md) — San Clemente I, papa · 2-3: Funk 1, 63-65 · Del comentario de san Cirilo de Alejandría, obispo, sobre el evangelio de san Juan — Tiempo Ordinario, año par
- [Pongamos ante nuestros ojos a los santos apóstoles](r/fbde44fddc.md) — San Clemente I, papa · 4-5: Funk 1, 65-69 · Martes de la semana II del Tiempo Ordinario (semana 2), año par
- [De generación en generación, el Señor concedió un tiempo de penitencia a los que deseaban convertirse a él](r/81d6c4e5f2.md) — San Clemente I, papa · 6-8: Funk 1,69-73 · Miércoles de la semana II del Tiempo Ordinario (semana 2), año par
- [Abrahán, llamado amigo, fue hallado fiel](r/7b98ac4792.md) — San Clemente I, papa · 9-11: Funk 1, 73-75 · Jueves de la semana II del Tiempo Ordinario (semana 2), año par
- [Seamos humildes de corazón](r/0aff14047c.md) — San Clemente I, papa · 12-13: Funk 1, 75-79 · Viernes de la semana II del Tiempo Ordinario (semana 2), año par
- [Ved qué dechado se nos propone](r/6f6658c7d6.md) — San Clemente I, papa · 14-17: Funk 1, 79-85 · Sábado de la semana II del Tiempo Ordinario (semana 2), año par
- [El Señor del universo ha querido que reinara la paz y la concordia](r/c78db01ded.md) — San Clemente I, papa · 18-20: Funk 1, 85-89 · Domingo de la semana III del Tiempo Ordinario (semana 3), año par
- [No nos apartamos nunca de la voluntad de Dios](r/182965a898.md) — San Clemente I, papa · 21, 1—22, 5; 23, 1-2: Funk 1, 89-93 · Lunes de la semana III del Tiempo Ordinario (semana 3), año par
- [Dios es fiel en sus promesas](r/8498354e55.md) — San Clemente I, papa · 24, 1-5; 27, 1—29, 1 · Martes de la semana III del Tiempo Ordinario (semana 3), año par
- [Busquemos en Dios nuestra alabanza, no en nosotros mismos](r/8a27d297eb.md) — San Clemente I, papa · 30.31.32: Funk 1, 97-101 · Miércoles de la semana III del Tiempo Ordinario (semana 3), año par
- [Nuestra gloria y nuestra confianza estén siempre en Dios](r/3fe4e895e8.md) — San Clemente I, papa · 33-34: Funk 1, 101-103 · Jueves de la semana III del Tiempo Ordinario (semana 3), año par
- [¡Qué grandes y maravillosos son los dones de Dios!](r/fd3d8ee34f.md) — San Clemente I, papa · 35-36: Funk 1, 105-107 · Viernes de la semana III del Tiempo Ordinario (semana 3), año par
- [Tomemos como ejemplo a nuestro cuerpo](r/a75a5ecd6c.md) — San Clemente I, papa · 37-38: Funk 1, 107-109 · Sábado de la semana III del Tiempo Ordinario (semana 3), año par
- [Los apóstoles salieron a anunciar la llegada del reino de Dios](r/1b11eaab85.md) — San Clemente I, papa · 40-43: Funk 1, 109-115 · Domingo de la semana IV del Tiempo Ordinario (semana 4), año par
- [Los justos sufrieron persecución](r/4fa2e87fc4.md) — San Clemente I, papa · 44-45: Funk 1,115-119 · Lunes de la semana IV del Tiempo Ordinario (semana 4), año par
- [Busque cada uno no sólo su propio interés, sino también el de la comunidad](r/05272e8936.md) — San Clemente I, papa · 46, 2-47, 4; 48, 1-6: Funk 1,119-123 · Semana IV del Tiempo Ordinario, año par
- [Más le vale al hombre confesar sus caídas que endurecer su corazón](r/58742b75c4.md) — San Clemente I, papa · 51-52.54: Funk 1, 129.130 · Jueves de la semana IV del Tiempo Ordinario (semana 4), año par
- [Obedezcamos a su nombre santísimo y glorioso](r/2b24452bb1.md) — San Clemente I, papa · 56, 1-2.16; 57, 1-2; 58,1-2: Funk 1, 131-135 · Viernes de la semana IV del Tiempo Ordinario (semana 4), año par
- [La oración de los fieles](r/2b20a7925d.md) — San Clemente I, papa · 59, 1–60,4; 61, 3: Funk 1, 135-137 · Sábado de la semana IV del Tiempo Ordinario (semana 4), año par
- [Mantened la concordia en la caridad y en la paz](r/b47e1080e5.md) — San Clemente I, papa · 62-63: Funk 1, 141-143 · Domingo de la semana V del Tiempo Ordinario (semana 5), año par
- [La gracia de nuestro Señor Jesucristo esté con vosotros y con todos los llamados](r/1a3d34e7da.md) — San Clemente I, papa · 64-65: Funk 1, 143-145 · Lunes de la semana V del Tiempo Ordinario (semana 5), año par
- [Acción de gracias y petición del pueblo cristiano](r/c2ee26b2e1.md) — San Clemente I, papa · Caps. 59, 2-60, 4: Funk 1,135-141 · Mes de octubre — Santoral, año impar
- [Maravillosos son los dones de Dios](r/37a5d3ed03.md) — San Clemente I, papa · Caps. 35,1-5; 36,1-2; 37,1. 4-5; 38,1-2. 4: Funk 1,105-109 · 23 de noviembre San Clemente I, papa y mártir — Santoral, año impar

## San Columbano

- [Luz perenne en el templo del Pontífice eterno](r/dfba97fbd7.md) — San Columbano · 12, 2-3 Opera, Dublín 1957, pp. 112-114 · Viernes de la semana XI del Tiempo Ordinario (semana 11), año par
- [El que tenga sed que venga a mí y que beba](r/34e88ee304.md) — San Columbano · Instrucción sobre Cristo, fuente de vida 13, 1-2: Opera, Dublín 1957, pp. 116-118 · Martes de la semana XXVIII del Tiempo Ordinario (semana 28), año impar
- [Tú, Señor, eres todo lo nuestro](r/5ad1b14266.md) — San Columbano · Instrucción sobre Cristo, fuente de vida 13, 2-3: Opera, Dublín 1957, pp. 118-120 · Miércoles de la semana XXVIII del Tiempo Ordinario (semana 28), año impar
- [La grandeza del hombre consiste en su semejanza con Dios, con tal de que la conserve](r/1309b291b5.md) — San Columbano · Instrucción 11, Sobre el amor, 1-2: Opera, Dublín 1957, pp, 106-107 · El mismo día 23 de noviembre San Columbano, abad — Santoral, año impar
- [La insondable profundidad de Dios](r/a01fe6e6fa.md) — San Columbano · Instrucción 1, 3-5 sobre la fe: Opera omnia, Dublín 1957, pp. 62-66 · Jueves de la semana XX del Tiempo Ordinario (semana 20), año par

## Concilio Vaticano II

- [Índole escatológica de la Iglesia peregrinante](r/f0daad42ac.md) — Concilio Vaticano II · Núm 48 · Martes de la semana II de Adviento (semana 2), año par
- [Cristo, plenitud de la revelación](r/80f3938d24.md) — Concilio Vaticano II · Núms 3-4 · Jueves de la semana III de Adviento (semana 3), año par
- [La maternidad de María en la economía de la gracia](r/190be06986.md) — Concilio Vaticano II · Núms. 61-62 · Común de Santa maría virgen — Comunes, año par
- [María, tipo de la Iglesia](r/2bac0e17f0.md) — Concilio Vaticano II · Núms. 63-65 · Común de Santa maría virgen — Comunes, año par
- [Vocación de los presbíteros a la perfección](r/d10851fdfa.md) — Concilio Vaticano II · Núm. 12 · Común de pastores — Comunes, año par
- [Id y haced discípulos de todos los pueblos](r/f857dc5975.md) — Concilio Vaticano II · Núms. 4-5 · Común de pastores — Comunes, año par
- [Sobre la transmisión de la revelación divina](r/d3de893d40.md) — Concilio Vaticano II · Núms. 7-8 · Común de doctores de la iglesia — Comunes, año par
- [La Iglesia sigue a su único esposo, Cristo](r/14c03c5f33.md) — Concilio Vaticano II · Núms. 1. 5. 6.12 · Común de vírgenes — Comunes, año par
- [Los interrogantes más profundos del hombre](r/adec0c6885.md) — Concilio Vaticano II · Núms. 9-10 · Sábado de la semana I de Cuaresma (semana 1), año par
- [Que toda la actividad del hombre se purifique en el misterio pascual](r/86849e4b14.md) — Concilio Vaticano II · Núms. 37-38 · Sábado de la semana IV de Cuaresma (semana 4), año par
- [La Iglesia, sacramento visible de la unidad](r/7602f78e00.md) — Concilio Vaticano II · Núm. 9). · Domingo de la semana V de Cuaresma (semana 5) - Año A: Jn 11, 1-45, año par
- [La economía de la salvación](r/f248d4d4d4.md) — Concilio Vaticano II · Núms. 5-6 · Sábado de la semana II de Pascua (semana 2), año par
- [Cristo ha hecho partícipes de su consagración y de su misión a los obispos por medio de los apóstoles](r/1be233be4b.md) — Concilio Vaticano II · Capítulo III, n. 28 · Domingo de la semana IV de Pascua (semana 4) - Año A: Jn 10, 1-10, año par
- [La misión del Espíritu Santo en la Iglesia](r/28f5fcdbaf.md) — Concilio Vaticano II · Núms. 4. 12 · Miércoles de la semana VII de Pascua (semana 7), año par
- [Disponibles para toda obra buena](r/83e64cb458.md) — Concilio Vaticano II · Núms. 12-13.16 · 23 de marzo. Santo Toribio de Mogrovejo, Obispo — Santoral, año par
- [Sobre la actividad humana en todo el mundo](r/a04ff4c74d.md) — Concilio Vaticano II · Núms. 33-34 · 1 de mayo. San José, Obrero — Santoral, año par
- [Yo salvaré a mi pueblo](r/0acb14e1ad.md) — Concilio Vaticano II · Núms. 2.16 · Domingo de la semana I de Cuaresma (semana 1) - Año A: Mt 4, 1-11, año impar
- [Santidad del matrimonio y de la familia](r/939a0a6b7a.md) — Concilio Vaticano II · Núm. 48 · Domingo de la semana II de Cuaresma (semana 2) - Año A: Mt 17, 1-9, año impar
- [El misterio de la muerte](r/fe2805e65e.md) — Concilio Vaticano II · Núms. 18. 22 · Sábado de la semana II de Cuaresma (semana 2), año impar
- [La Iglesia es en Cristo como un sacramento o señal de la íntima unión con Dios](r/f3dec6e5a8.md) — Concilio Vaticano II · Núms. 1-3 · Domingo de la semana IV de Pascua (semana 4), año impar
- [Somos hijos de Dios y constituimos una familia en Cristo](r/fff850c4a1.md) — Concilio Vaticano II · Cap. 7, 50-51 · Jueves de la semana V de Pascua (semana 5), año impar
- [Id y haced discípulos de todos los pueblos](r/94532375d7.md) — Concilio Vaticano II · Núms. 4-5 · Sábado de la semana III del Tiempo Ordinario (semana 3), año impar
- [Hay que anunciar, con toda libertad, el misterio de Cristo](r/8a41c7d109.md) — Concilio Vaticano II · Núms. 23-24 · El mismo día 3 de febrero San Óscar, Obispo — Santoral, año impar
- [Naturaleza de la paz](r/376ee1621b.md) — Concilio Vaticano II · n. 78 · 28 de julio Nuestra Señora de la Paz — Santoral, año impar
- [La actividad humana](r/605dbf61df.md) — Concilio Vaticano II · Núms 33-36 · Sábado de la semana VI del Tiempo Ordinario (semana 6), año par
- [La esperanza de la tierra nueva](r/c49315d7b3.md) — Concilio Vaticano II · n. 39 · Sábado de la semana XXVII del Tiempo Ordinario (semana 27), año impar
- [Santidad del matrimonio y de la familia](r/29ededa159.md) — Concilio Vaticano II · Núm. 48 · 16 de noviembre Santa Margarita de Escocia — Santoral, año impar
- [Yo soy el alfa y la omega, el primero y el último](r/8c0c449131.md) — Concilio Vaticano II · núm. 40.45 · Sábado de la semana XVIII del Tiempo Ordinario (semana 18), año par
- [Naturaleza de la paz](r/36c5530c4b.md) — Concilio Vaticano II · N. 78 · Domingo de la semana XXXII del Tiempo Ordinario (semana 32), año par
- [Necesidad de inculcar sentimientos que llevan a la paz](r/c703d5c365.md) — Concilio Vaticano II · Nn. 82-83 · Domingo de la semana XXXII del Tiempo Ordinario (semana 32) - Año A: Mt 25, 1-13, año par
- [Papel de los cristianos en la construcción de la paz](r/eb6cacbd72.md) — Concilio Vaticano II · Nn. 88-90 · Viernes de la semana XXXII del Tiempo Ordinario (semana 32), año par

## San Cromacio de Aquilea

- [Vosotros sois la luz del mundo](r/487d673a65.md) — San Cromacio de Aquilea · Tratado 5,1. 3-4: CCL 9, 405-407 · 11 de junio. SAN BERNABÉ, Apóstol — Santoral, año par

## Diádoco de Fótice

- [Hay que amar solamente a Dios](r/c962725789.md) — Diádoco de Fótice · Caps. 12. 13. 14: PG 65, 1171- 1172 · Miércoles de la semana I de Cuaresma (semana 1), año impar
- [El discernimiento de espíritus se adquiere por el gusto espiritual](r/10093d4583.md) — Diádoco de Fótice · 6.26.27.30: PG 65, 1169.1175-1176 · Miércoles de la semana VI del Tiempo Ordinario (semana 6), año par

## Didaché

- [Acerca de la eucaristía](r/db7079df63.md) — Didaché · Caps. 9, 1-10, 6; 14, 1-3: Funk 2, 19-22. 26 · Martes de la semana XVI del Tiempo Ordinario (semana 16), año impar

## Dídimo de Alejandría

- [El misterio del agua](r/901aba4fc6.md) — Dídimo de Alejandría · Lib. 2, 13-14: PG 39, 691-698 · Jueves de la semana V de Cuaresma (semana 5), año par
- [El bautismo nos hace inmortales y nos deifica](r/f7c9c0463f.md) — Dídimo de Alejandría · Lib. 2, 14: PG 39, 710-718 · Viernes de la Octava de Pascua — Cuaresma y Pascua, año par
- [El Espíritu Santo nos renueva en el bautismo](r/ea8251735b.md) — Dídimo de Alejandría · Libro 2, 12: PG 39, 667-674 · Domingo de la semana VI de Pascua (semana 6) - Año A: Jn 14, 15-21, año par

## San Doroteo de Gaza

- [La causa de toda perturbación consiste en que nadie se acusa a sí mismo](r/1c903959cf.md) — San Doroteo de Gaza · 1-2: PG 88, 1695-1699 · Lunes de la semana XVII del Tiempo Ordinario (semana 17), año par
- [La falsa paz de espíritu](r/bf33aae1e6.md) — San Doroteo de Gaza · 2-3: PG 88, 1699 · Martes de la semana XVII del Tiempo Ordinario (semana 17), año par

## San Efrén

- [Vigilad, pues vendrá de nuevo](r/3664f76eff.md) — San Efrén · Cap. 18, 15-17: SC 121, 325-328 · Jueves de la semana I de Adviento (semana 1), año par
- [María sola abraza al que todo el universo no abarca](r/18a6be2e7f.md) — San Efrén · Sermón 3 de diversis: Opera omnia, III syr. et lat., Roma 1743, 607 · 13 de mayo. LA BIENAVENTURADA VIRGEN MARÍA DE FÁTIMA — Santoral, año par
- [Los designios divinos son figura del mundo espiritual](r/3bffdef142.md) — San Efrén · Sermón 3, De fine et admonitione; 2, 4-5: edición Lamy, 3, 216-222 · 9 de junio. San Efrén, Diácono y Doctor de la Iglesia — Santoral, año par
- [La cruz de Cristo, salvación del género humano](r/420a588dce.md) — San Efrén · Sermón 20, 3-4.9: Opera, ed. Lamy, 1, 152-158. 166-168 · Jueves de la semana III de Pascua (semana 3), año impar
- [La palabra de Dios, fuente inagotable de vida](r/99d985a24e.md) — San Efrén · Cap 1, 18-19: SC 121, 52-53 · Domingo de la semana XIV del Tiempo Ordinario (semana 14), año par

## San Elredo de Rievaulx

- [Hoy nos ha nacido un Salvador](r/59135e1d09.md) — San Elredo de Rievaulx · Sermón 1 de la Natividad del Señor : PL 195, 226-227 · 25 de Diciembre. LA NATIVIDAD DEL SEÑOR — Santoral, año par
- [¡Levántate, brilla, que llega tu luz!](r/b139d84e0d.md) — San Elredo de Rievaulx · Sermón 3 en la manifestación del Señor : PL 195, 228-229 · Ferias anteriores a la Epifanía — Adviento y Navidad, año par
- [María, Madre nuestra](r/7e3b7cf0fd.md) — San Elredo de Rievaulx · Sermón 20, en la Natividad de santa María: PL 195, 322-324 · Común de Santa maría virgen — Comunes, año par
- [Este tiempo nos recuerda las dos venidas del Señor](r/753cda82c5.md) — San Elredo de Rievaulx · Sermón 1 sobre la venida del Señor: PL 195, 209-210 · Domingo de la semana I de Adviento (semana 1), año impar
- [Debemos practicar la caridad fraterna según el ejemplo de Cristo](r/68613b723f.md) — San Elredo de Rievaulx · Lib. 3, 5: PL 195, 582 · Viernes de la semana I de Cuaresma (semana 1), año par
- [La amistad verdadera es perfecta y constante](r/014f6734cf.md) — San Elredo de Rievaulx · Lib. 3, 92. 93. 94. 96: CCL CM 1, 337-338 · Martes de la semana XIV del Tiempo Ordinario (semana 14), año impar
- [Sobre el pueblo bien dispuesto que se prepara para el Señor](r/f502198632.md) — San Elredo de Rievaulx · Edit C.H. Talbot, SSOC, I, 1952, 40-41 · Sábado de la semana XIV del Tiempo Ordinario (semana 14), año par
- [Considerad, hermanos, vuestra vocación](r/41bb11475e.md) — San Elredo de Rievaulx · Edit C.H. Talbot, SSOC vol 1, 102-103 · Viernes de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [Irá delante del Señor con el espíritu y poder de Elías](r/fa78490b30.md) — San Elredo de Rievaulx · Sermón «Quomodo referatur», Edit C.H. Talbot, SSOC vol 1, 120-121 · Sábado de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [Surgió un hombre enviado por Dios](r/3fed855ce6.md) — San Elredo de Rievaulx · Sermón sobre la interrelación Elías y Juan Bautista, Edit. C.H. Talbot, SSOC vol 1, p. 118 · Sábado de la semana XIX del Tiempo Ordinario (semana 19), año impar
- [Sobre la verdadera humildad](r/bd20d73331.md) — San Elredo de Rievaulx · Edit C.H. Talbot, SSOC vol 1, 78-80 · Domingo de la semana XXII del Tiempo Ordinario (semana 22), año impar
- [La tierra estaba llena de la gloria del Señor](r/d0b24ad571.md) — San Elredo de Rievaulx · Sermón sobre la venida del Señor, Edit. C.H. Talbot, SSOC, vol 1, Roma 1952, 32-33 · Sábado de la semana XXIV del Tiempo Ordinario (semana 24), año impar
- [En nuestra Pascua, Cristo es inmolado no en figura, sino en realidad](r/bd2259cb6c.md) — San Elredo de Rievaulx · Sermón en el día de Pascua, Edit. C.H. Talbot, SSOC, vol 1, 94-95 · Jueves de la semana XXVI del Tiempo Ordinario (semana 26), año impar
- [Un amigo fiel es un talismán](r/c2a57cb06a.md) — San Elredo de Rievaulx · Lib 2: Edit J. Dubois, 53-57 · Viernes de la semana XXVII del Tiempo Ordinario (semana 27), año par

## San Epifanio de Salamina

- [Misterios antiguos y nuevos](r/aa2d5ece60.md) — San Epifanio de Salamina · Homilía 3 [atribuida] sobre la santa resurrección de Cristo: PG: 43, 466-470 · Jueves de la semana II de Pascua (semana 2), año par

## San Esteban

- [Hijo mío, escucha la corrección de tu padre](r/bf33170d9e.md) — San Esteban · Caps. 1. 2.10: PL 151,1236-1237.1242-1244 · 16 de agosto San Esteban de Hungría — Santoral, año impar

## San Eulogio de Córdoba

- [El Señor nos ayuda en la tribulación y nos da fortaleza en los combates](r/c6ba7cec23.md) — San Eulogio de Córdoba · Documentum Martyrii, 25, epílogo: PL 115, 834 · 9 de enero. San Eulogio de Córdoba, Presbítero y Mártir — Santoral, año par

## San Eusebio de Alejandría

- [Este día os trajo el comienzo de toda gracia](r/00fe1ffb8c.md) — San Eusebio de Alejandría · Sermón 6, 1. 3. 6: PG 86, 415-418. 422 · Semana XXIX DEL TIEMPO ORDINARIO, año impar

## Eusebio de Cesarea

- [Una voz grita en el desierto](r/4cf2a921bf.md) — Eusebio de Cesarea · Cap 40: PG 24, 366-367 · Domingo de la semana II de Adviento (semana 2), año par
- [La paz de Constantino](r/355e1ea0d9.md) — Eusebio de Cesarea · Lib. 10,1-3: PG 20, 842-847 · 31 de diciembre. San Silvestre I, Papa — Santoral, año par
- [Y tal convenía que fuese nuestro Pontífice: santo, inocente, sin mancha](r/76e6c169aa.md) — Eusebio de Cesarea · Lib. 5, 3: PG 22, 366-367 · Semana IV de Cuaresma — Cuaresma y Pascua, año par
- [Con razón en estos días desbordamos de gozo, como si ya estuviéramos con el Esposo](r/9068ddd6c2.md) — Eusebio de Cesarea · Tratado 4-5: PG 24, 698-699 · Martes de la Octava de Pascua — Cuaresma y Pascua, año par
- [Constantemente somos saciados con el cuerpo del Salvador y constantemente participamos de la sangre del Cordero](r/50961e1f2f.md) — Eusebio de Cesarea · Tratado 7. 9. 10-12: PG 24, 702-706 · Jueves de la Octava de Pascua — Cuaresma y Pascua, año par

## San Eusebio de Vercelli

- [He corrido hasta la meta, he mantenido la fe](r/3769d68cf2.md) — San Eusebio de Vercelli · Carta 2,1, 3-2, 3; 10,1-11,1: CCL 9,104-105.109 · 2 de agosto San Eusebio de Vercelli, obispo — Santoral, año impar

## San Ezequiel Moreno

- [Tú eres mi fortaleza y refugio](r/5d89e65ef9.md) — San Ezequiel Moreno · Toribio Minguella, O.A. R., Cartas Pastorales, Circulares y otros Escritos del Ilmo. y Rmo. Sr. D. Fr. Ezequiel Moreno y Díaz, Madrid, 1908, pp. 171.173-4). · El mismo día 19 de agosto San Ezequiel Moreno, obispo — Santoral, año impar

## San Francisco de Asís

- [Debemos ser sencillos, humildes y puros](r/7e2f62c5d1.md) — San Francisco de Asís · Opúsculos, edición Quaracchi, Florencia [1949], 87-94 · 4 de octubre San Francisco de Asís — Santoral, año impar

## San Francisco de Borja

- [Sólo son grandes antes Dios los que se tienen por pequeños](r/ea2adada04.md) — San Francisco de Borja · Carta 7, año 1545: Monumenta historica Societatis Iesu, Madrid 1908, III, pp. 9-10 · 3 de octubre San Francisco de Borja, presbítero — Santoral, año impar

## San Francisco de Paula

- [Convertíos con sinceridad](r/ea1b735205.md) — San Francisco de Paula · Carta del año 1486: A. Galuzzi, Origini dell'Ordine dei Minimi, Roma 1967, pp.121-122 · 2 de abril. San Francisco de Paula, Ermitaño — Santoral, año par

## San Francisco de Sales

- [La devoción se ha de ejercitar de diversas maneras](r/2cd76a804d.md) — San Francisco de Sales · Parte 1, cap. 3 · 24 de enero San Francisco de Sales, Obispo y Doctor de la Iglesia — Santoral, año impar

## San Francisco Javier

- [¡Ay de mí si no anuncio el Evangelio!](r/33106bab51.md) — San Francisco Javier · Cartas 4 [1542]... y 5 [1544]: BAC 101, Cartas y escritos de san Francisco Javier, pp. 107-108. 115-116 · 3 de diciembre. San Francisco Javier, Presbítero — Santoral, año par

## San Fulberto de Chartres

- [El misterio de nuestra salvación](r/7cc7b1e9e5.md) — San Fulberto de Chartres · Carta 5: PL 141, 198-199 · 8 de Enero o Martes después del Domingo de Epifanía — Santoral, año par

## San Fulgencio de Ruspe

- [Las armas de la caridad](r/5fdf0ebeba.md) — San Fulgencio de Ruspe · Sermón 3,1-3. 5-6: CCL 91 A, 905-909 · 26 de diciembre. San Esteban, protomártir — Santoral, año par
- [Criado fiel y solícito](r/c754ee4157.md) — San Fulgencio de Ruspe · Sermón 1, 2-3: CCL 91 A, 889-890 · Común de pastores — Comunes, año par
- [Cristo vive siempre para interceder en nuestro favor](r/8973766e14.md) — San Fulgencio de Ruspe · Carta 14, 36-37: CCL 91, 429-431 · Jueves de la semana I de Cuaresma (semana 1), año impar
- [Él mismo se ofreció por nosotros](r/9acbac990e.md) — San Fulgencio de Ruspe · Cap. 22, 62: CCL 91A, 726. 750-751 · Domingo de la semana IV de Cuaresma (semana 4) - Año A: Jn 9, 1-41, año impar
- [Sacramento de unidad y de caridad](r/48a38a24fa.md) — San Fulgencio de Ruspe · Lib. 2, 11-12: CCL 91, 46-48 · Martes de la semana II de Pascua (semana 2), año impar
- [La caridad trabaja en el mundo, descansa en Dios](r/04c3565c0a.md) — San Fulgencio de Ruspe · Sermón 5, 5-6: CCL 91A, 921-923 · Martes de la semana IX del Tiempo Ordinario (semana 9), año impar
- [La participación del cuerpo y sangre de Cristo nos santifica](r/04f4dd0742.md) — San Fulgencio de Ruspe · Cap 28, 16-19: CCL 91A, 813-814 · Jueves de la semana XI del Tiempo Ordinario (semana 11), año par

## San Gaudencio de Brescia

- [La rica herencia del nuevo Testamento](r/3194ec0b23.md) — San Gaudencio de Brescia · Tratado 2, CSEL 68, 30-32 · Jueves de la semana II de Pascua (semana 2), año impar
- [La eucaristía, Pascua del Señor](r/f73693864a.md) — San Gaudencio de Brescia · Tratado 2: CSEL 68, 26. 29-30 · Sábado de la semana V de Pascua (semana 5), año impar

## San Germán de Constantinopla

- [Sobre la naturaleza de la Iglesia y sobre los sacramentos](r/0f4d4a3164.md) — San Germán de Constantinopla · PG 98, 383-387 · Martes de la semana XXVI del Tiempo Ordinario (semana 26), año impar
- [Todos nosotros te glorificamos a ti, Dios nuestro, en medio de una profunda tranquilidad](r/301204af5c.md) — San Germán de Constantinopla · PG 98, 442-443 · Martes de la semana XXV del Tiempo Ordinario (semana 25), año par

## Santa Gertrudis

- [Tuviste sobre mí designios de paz y no de aflicción](r/28e0b01b3e.md) — Santa Gertrudis · Libro 2, 23,1. 3. 5. 8.10: SC 139, 330-340 · El mismo día 16 de noviembre Santa Gertrudis, virgen — Santoral, año impar

## San Gregorio

- [Una Iglesia libre, casta y católica](r/34885c585c.md) — San Gregorio · Carta 64 extra Registrum: PL 148, 709-710 · El mismo día 25 de mayo. San Gregorio VII, Papa — Santoral, año par

## San Gregorio de Agrigento

- [Mi corazón se alegra en el Señor](r/c2d6bdb3e8.md) — San Gregorio de Agrigento · Lib 8, 6: PG 98, 1071-1074 · Viernes de la semana XX del Tiempo Ordinario (semana 20), año par
- [Contemplad al Señor, y quedaréis radiantes](r/10c778e2a7.md) — San Gregorio de Agrigento · Lib 10, 2: PG 98, 1138-1139 · Sábado de la semana XX del Tiempo Ordinario (semana 20), año par

## San Gregorio de Antioquía

- [Éste es mi Hijo, el amado, mi predilecto](r/df1cf7e154.md) — San Gregorio de Antioquía · Homilía 2, 5. 6. 9. 10 en el Bautismo de Cristo: PG 88, 1875-1879. 1882-1883 · Domingo después del 6 de Enero. EL BAUTISMO DEL SEÑOR — Adviento y Navidad, año par

## San Gregorio de Neocesarea

- [Vino a nosotros el que es el esplendor de la gloria del Padre](r/7316e75b00.md) — San Gregorio de Neocesarea · Homilía 4 en la santa Teofanía: PG 10, 1182-1183 · Domingo después del 6 de Enero. EL BAUTISMO DEL SEÑOR — Adviento y Navidad, año par

## San Gregorio de Nisa

- [El niño Jesús que nos ha nacido, es la verdadera luz, la verdadera vida y la justicia verdadera](r/214a7b77d8.md) — San Gregorio de Nisa · Homilía 3: PG 44, 827-830 · Navidad y su Octava — Adviento y Navidad, año par
- [Dichosos los perseguidos por mi causa](r/e0034f37e5.md) — San Gregorio de Nisa · Discurso 27, 9: PG 44, 1291-1295. 1299-1302 · 26 de diciembre. San Esteban, protomártir — Santoral, año par
- [Exultemos y alegrémonos en ti](r/9fec4075d4.md) — San Gregorio de Nisa · Hom 1: PG 44, 765-766.783.786 · 29 de Diciembre. Día V - Octava de Navidad — Santoral, año par
- [Oración al buen pastor](r/166af8ea5a.md) — San Gregorio de Nisa · Cap. 2: PG 44, 802 · 30 de Diciembre. Día VI - Octava de Navidad — Santoral, año par
- [Dios se ha manifestado en la carne](r/12af9921bd.md) — San Gregorio de Nisa · Homilía 5: PG 44, 859-862. 863. 874. 875 · 31 de Diciembre. Día VII - Octava de Navidad — Santoral, año par
- [Cristo, primogénito de entre los muertos](r/3f5cca1ed6.md) — San Gregorio de Nisa · Lib. 4: PG 45, 634-635. 638 · Martes de la semana III de Pascua (semana 3), año par
- [La voluntad de Cristo, norma de nuestra vida](r/a74cf9f7aa.md) — San Gregorio de Nisa · PG 46, 262-263 · Jueves de la semana III de Pascua (semana 3), año par
- [El cristiano es otro Cristo](r/25eec95cd9.md) — San Gregorio de Nisa · PG 46, 254-255 · Sábado de la semana III de Pascua (semana 3), año par
- [Yo les he dado la gloria que tú me diste](r/6b85e551c4.md) — San Gregorio de Nisa · Homilía 15: PG 44, 1115-1118 · Semana VII de Pascua — Cuaresma y Pascua, año par
- [Les di a ellos la gloria que me diste](r/82d00ca2ca.md) — San Gregorio de Nisa · Homilía 15 : PG 44, 1115-1118 · Semana VII de Pascua — Cuaresma y Pascua, año par
- [Primogénito de la nueva creación](r/29738f4708.md) — San Gregorio de Nisa · Sermón 1: PG 46, 603-606. 626-627 · Miércoles de la semana V de Pascua (semana 5), año impar
- [Dios es como una roca inaccesible](r/102aa17cf4.md) — San Gregorio de Nisa · Homilía 6 sobre las bienaventuranzas : PG 44, 1263-1266 · Miércoles de la semana XIV del Tiempo Ordinario (semana 14), año impar
- [La esperanza de ver a Dios](r/ee579cdb9d.md) — San Gregorio de Nisa · Homilía 6 sobre las bienaventuranzas : PG 44, 1266-1267 · Jueves de la semana XIV del Tiempo Ordinario (semana 14), año impar
- [Dios puede ser hallado en el corazón del hombre](r/44add5a207.md) — San Gregorio de Nisa · Homilía 6 sobre las bienaventuranzas: PG 44, 1270-1271 · Viernes de la semana XIV del Tiempo Ordinario (semana 14), año impar
- [El rey pacífico gobierna a su pueblo con justicia](r/9f55629b0e.md) — San Gregorio de Nisa · Homilía 7: PG 44, 907-910 · Viernes de la semana XVI del Tiempo Ordinario (semana 16), año impar
- [Tú que has sido crucificado juntamente con Cristo, ofrécete a Dios como sacerdote sin tacha](r/8f7e4d66a0.md) — San Gregorio de Nisa · Cap 24: PG 46, 414-416 · Miércoles de la semana XII del Tiempo Ordinario (semana 12), año par
- [Tenemos a Cristo que es nuestra paz y nuestra luz](r/ff2e247cbc.md) — San Gregorio de Nisa · PG 46, 259-262 · Lunes de la semana XX del Tiempo Ordinario (semana 20), año impar
- [El misterio de la Iglesia](r/262cc27437.md) — San Gregorio de Nisa · Hom. 8 : PG 44, 947-950 · Jueves de la semana XX del Tiempo Ordinario (semana 20), año impar
- [Se aparta de Dios quien no se une a él en la oración](r/a984b84447.md) — San Gregorio de Nisa · PG 44,1119. 1123-1126 · Semana XXIX DEL TIEMPO ORDINARIO, año impar
- [Sé benigno con los hermanos desgraciados](r/d378e3c3a1.md) — San Gregorio de Nisa · Homilía 1 sobre el amor a los pobres: PG 46, 458-459 · Viernes de la semana XXX del Tiempo Ordinario (semana 30), año impar
- [Venid a curaros los que os sentís enfermos](r/b4098e9edf.md) — San Gregorio de Nisa · Comienza el discurso sobre el bautismo (PG 415-418.419 · Domingo de la semana XVIII del Tiempo Ordinario (semana 18), año par
- [Abre tu alma a una educación esmerada](r/8f6adc85dc.md) — San Gregorio de Nisa · PG 46, 420-422.426 · Domingo de la semana XVIII del Tiempo Ordinario (semana 18) - Año A: Mt 14, 13-21, año par
- [Amad los trofeos y las coronas que Dios tiene preparados para sus atletas](r/d4fd282d4b.md) — San Gregorio de Nisa · PG 46, 427-430 · Martes de la semana XVIII del Tiempo Ordinario (semana 18), año par
- [Venid vosotros, benditos de mi Padre; heredad el reino preparado para vosotros desde la creación del mundo](r/bdc3de38da.md) — San Gregorio de Nisa · PG 46, 430-432 · Miércoles de la semana XVIII del Tiempo Ordinario (semana 18), año par
- [Oración del buen pastor](r/6083068f4d.md) — San Gregorio de Nisa · Cap 2: PG 44, 802 · Jueves de la semana XIX del Tiempo Ordinario (semana 19), año par
- [El sabio tiene sus ojos puestos en la cabeza](r/88dcfd0b52.md) — San Gregorio de Nisa · Hom. 5 : PG 44, 683-686 · Domingo de la semana XX del Tiempo Ordinario (semana 20) - Año A: Mt 15, 21-28, año par
- [Tiene su tiempo el nacer y su tiempo el morir](r/1f2d5b0c97.md) — San Gregorio de Nisa · Homilía 6 : PG 44, 702-703 · Martes de la semana XX del Tiempo Ordinario (semana 20), año par
- [No desprecies a los pobres como si fuesen de ningún valor](r/6509ff94e2.md) — San Gregorio de Nisa · Hom. 1 sobre el amor a los pobres : PG 46, 459-462 · Miércoles de la semana XXIII del Tiempo Ordinario (semana 23), año par
- [Éste es el grupo que busca al Señor](r/06878379d0.md) — San Gregorio de Nisa · Sermón sobre la ascensión de Cristo : PG 46, 690-691 · Jueves de la semana XXV del Tiempo Ordinario (semana 25), año par

## San Gregorio Magno

- [En el mundo, pero no del mundo](r/8682879c02.md) — San Gregorio Magno · Libro 2, homilía 36,11-13: PL 76,1272-1274 · Para los santos religiosos — Comunes, año par
- [El Señor ama a sus discípulos, y, sin embargo, los envía al mundo a padecer](r/2bbaebe809.md) — San Gregorio Magno · Homilía 26, 1-2: PL 76, 1197-1198 · Domingo de la Octava de Pascua — Cuaresma y Pascua, año par
- [Cristo, el buen Pastor](r/aa65a3247f.md) — San Gregorio Magno · Homilía 14 sobre los evangelios, 3-6: PL 76, 1129-1130 · Domingo de la semana IV de Pascua (semana 4), año par
- [Pudo más porque amó más](r/a6a4457c58.md) — San Gregorio Magno · Libro 2, 33: PL 66,194-196 · 10 de febrero. Santa Escolástica, Virgen — Santoral, año par
- [Los ingleses han sido revestidos por la luz de la santa fe](r/fedb6ce324.md) — San Gregorio Magno · Libro 9, 36: MGH, Epistolae 2, 305-306 · 27 de mayo. San Agustín de Cantorbery, Obispo — Santoral, año par
- [La voz de las almas es su amoroso deseo](r/3f8aa0ddbf.md) — San Gregorio Magno · Lib. 2, 11: SC 32, 188-190 · Domingo de la semana III de Pascua (semana 3), año impar
- [La carga del gobierno](r/68bafd79a7.md) — San Gregorio Magno · Parte 1, cap. 3: PL 177, 16-17 · Jueves de la semana XIII del Tiempo Ordinario (semana 13), año impar
- [Aplicaos, hermanos, a meditar las palabras de Dios](r/f462a86078.md) — San Gregorio Magno · Lib. 2, homilía 3, 18. 19. 21: CCL 142, 250. 252. 253. 254 · Sábado de la semana XIV del Tiempo Ordinario (semana 14), año impar
- [Sobre el servicio de la predicación](r/6167b0216d.md) — San Gregorio Magno · Homilía 17, 5.6.7.8: PL 76, 1140-1142 · Domingo de la semana XV del Tiempo Ordinario (semana 15), año impar
- [Sobre la vida activa y la vida contemplativa](r/58095cee69.md) — San Gregorio Magno · Lib 2, Hom 2, 8-9: CCL 142, 230-231 · Domingo de la semana XVI del Tiempo Ordinario (semana 16), año impar
- [¡Señor mío y Dios mío!](r/18d5ad7e62.md) — San Gregorio Magno · Homilía 26, 7-9: PL 76, 1201-1202 · 3 de julio SANTO TOMÁS, Apóstol — Santoral, año impar
- [Ardía en deseos de Cristo, a quien pensaba que se lo habían llevado](r/ae5efbefb4.md) — San Gregorio Magno · Homilía 25,1-2. 4-5: PL 76,1189-1193 · 22 de julio Santa María Magdalena — Santoral, año impar
- [La Jerusalén celestial está fundada como ciudad](r/13f817887a.md) — San Gregorio Magno · Lib 2, Hom 1, 5: CCL 142, 210-212 · Lunes de la semana XI del Tiempo Ordinario (semana 11), año par
- [Si aceptamos de Dios los bienes, ¿no vamos a aceptar los males?](r/12210ea6cb.md) — San Gregorio Magno · Lib 3, 15-16: PL 75, 606-608 · Lunes de la semana XV del Tiempo Ordinario (semana 15), año par
- [La ley del Señor abarca muchos aspectos](r/84ba8dfe58.md) — San Gregorio Magno · Lib 10, 7-8.10: PL 75. 922.925-926 · Domingo de la semana XVI del Tiempo Ordinario (semana 16), año par
- [El testigo interior](r/f9e6b6ff9e.md) — San Gregorio Magno · Lib 10, 47-48: PL 75, 946-947 · Ciclo B Mc 6, 30-34 — Tiempo Ordinario, año par
- [La verdadera enseñanza evita la arrogancia](r/06b4fcbe1f.md) — San Gregorio Magno · Lib 23, 23-24: PL 76, 265-266 · Miércoles de la semana XVII del Tiempo Ordinario (semana 17), año par
- [La Iglesia se asoma como el alba](r/48866c8da6.md) — San Gregorio Magno · Lib 29, 2-4: PL 76, 478-480 · Jueves de la semana XVII del Tiempo Ordinario (semana 17), año par
- [La esperanza de los premios celestiales](r/926ac40229.md) — San Gregorio Magno · Lib. 2, Homilía 1, 7: CCL 142, 213- 214 · Jueves de la semana XXI del Tiempo Ordinario (semana 21), año impar
- [Ataques por fuera y temores por dentro](r/7e1909eaad.md) — San Gregorio Magno · Lib. 3, 39-40: PL 75, 619-620 · Lunes de la semana XXV del Tiempo Ordinario (semana 25), año impar
- [Cristo se hizo carne para hacernos a nosotros espirituales](r/31e9531468.md) — San Gregorio Magno · Lib. 2, Hom. 4, 19-20: CCL 142, 271-273 · Sábado de la semana XXXIII del Tiempo Ordinario (semana 33), año impar
- [Por amor a Cristo, cuando hablo de Él, ni a mí mismo me perdono](r/c02be0247c.md) — San Gregorio Magno · Libro 1,11, 4-6: CCL 142,170-172 · Mes de septiembre — Santoral, año impar
- [El nombre de "ángel" designa la función, no el ser](r/f1cecca40a.md) — San Gregorio Magno · Homilía 34, 8-9: PL 76,1250-1251 · 29 de septiembre SANTOS ARCÁNGELES MIGUEL, GABRIEL Y RAFAEL — Santoral, año impar
- [El Señor viene detrás de sus predicadores](r/1a23f13cd3.md) — San Gregorio Magno · Homilía 17,1-3: PL 76,1139 · 18 de octubre SAN LUCAS, evangelista — Santoral, año impar
- [El pastor debe saber guardar silencio con discreción y hablar cuando es útil](r/1a4a086f98.md) — San Gregorio Magno · Lib 2, 4: PL 77, 30-31 · Domingo de la semana XXI del Tiempo Ordinario (semana 21), año par

## San Gregorio Nacianceno

- [¡Qué admirable intercambio!](r/a7d27195ee.md) — San Gregorio Nacianceno · Disertación 45, 9.22.26.28: PG 36, 634-635.654.658-659.662 · Martes de la semana I de Adviento (semana 1), año par
- [Como si una misma alma sustentase dos cuerpos](r/9956ad976a.md) — San Gregorio Nacianceno · Sermón 43, en alabanza de Basilio Magno, 15. 16-17. 19-21: PG 36, 514-523 · 2 de enero. San Basilio Magno y San Gregorio Nacianceno Obispos y Doctores de la Iglesia — Santoral, año par
- [El bautismo de Cristo](r/acb09b1995.md) — San Gregorio Nacianceno · Disertación 39, en las santas Luminarias, 14-16.20: PG 36, 350-351.354.358-359 · Ferias anteriores a la Epifanía — Adviento y Navidad, año impar
- [El cristiano dispone de medios para superar las tentaciones](r/ea0a56ed1a.md) — San Gregorio Nacianceno · Discurso 40, 10: PG 36, 370-371 · Semana I de Cuaresma — Cuaresma y Pascua, año par
- [Actualicemos unos con otros la bondad del Señor](r/f26d548244.md) — San Gregorio Nacianceno · Sermón 14, 23-25 sobre el amor a los pobres: PG 35, 887-890 · Domingo de la semana I de Cuaresma (semana 1) - Año A: Mt 4, 1-11, año par
- [Sirvamos a Cristo en los pobres](r/5ff73fcee1.md) — San Gregorio Nacianceno · Sermón 14, sobre el amor a los pobres, 38. 40: PG 35, 907-910 · Sábado de la semana III de Cuaresma (semana 3), año par
- [Vamos a participar en la Pascua](r/f91e84f3c0.md) — San Gregorio Nacianceno · Sermón 45, 23-24: PG 36, 654-655 · Miércoles de la semana IV de Cuaresma (semana 4), año par
- [Santa y piadosa es la idea de rezar por los muertos](r/6b354aa221.md) — San Gregorio Nacianceno · Sermón 7, 23-24: PG 35, 786-787 · Viernes de la semana IX del Tiempo Ordinario (semana 9), año par
- [Vayamos de una vez en pos del Verbo, busquemos aquel descanso](r/40d24d66d4.md) — San Gregorio Nacianceno · Sermón 14, 20-22 sobre el amor a los pobres: PG 35, 882-886 · Domingo de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [Demos a los pobres nuestros bienes, para enriquecernos con los del cielo](r/550ec07de8.md) — San Gregorio Nacianceno · Sermón 14, 21-22: PG 35, 883-886 · Sábado de la semana XXV del Tiempo Ordinario (semana 25), año impar
- [Es éste un gran misterio](r/38055f282f.md) — San Gregorio Nacianceno · Sermón 37, 5-7 sobre Mateo 19, 1-12: PG 36, 287-291 · Domingo de la semana XXVII del Tiempo Ordinario (semana 27), año impar
- [Salgamos al encuentro de Cristo, el esposo, con las espléndidas lámparas de la fe](r/1c56f81552.md) — San Gregorio Nacianceno · Sermón 40,46 en la festividad del bautismo : PG 36, 426-428 · Semana XXXII DEL TIEMPO ORDINARIO, año impar

## San Gregorio Palamás

- [Juan es aquel a quien Cristo amó con amor de predilección](r/5fa731094e.md) — San Gregorio Palamás · Homilía 20: PG 151, 266.271 · 27 de Diciembre. San Juan Apóstol y Evangelista — Santoral, año par
- [Amemos el camino angosto y trillado que conduce a la verdadera vida](r/e3c9e99f5c.md) — San Gregorio Palamás · Homilía 10 : PG 151, 111-114 · Martes de la semana XXIX del Tiempo Ordinario (semana 29), año impar
- [¿Qué no hizo nuestro Creador para lograr nuestra enmienda?](r/1d20141cad.md) — San Gregorio Palamás · Homilía 3 : PG, 151, 35 · Miércoles de la semana XXX del Tiempo Ordinario (semana 30), año impar
- [¡Ojalá que en el siglo futuro nos hallemos también nosotros agregados a la muchedumbre de los salvados!](r/261713739a.md) — San Gregorio Palamás · Homilía 26 : PG 151, 339-342 · Semana XXXIII DEL TIEMPO ORDINARIO, año impar
- [Dios es admirable en sus santos](r/4a4a71e856.md) — San Gregorio Palamás · Hom. 25 : PG 151, 322-323 · Martes de la semana XXX del Tiempo Ordinario (semana 30), año par

## Gualterio de San Víctor

- [La cruz de Cristo, remedio, ejemplo y misterio](r/714af941f8.md) — Gualterio de San Víctor · Sermón 3, 2.3.4: CCL CM 30, 250.251.252 · Viernes de la semana VIII del Tiempo Ordinario (semana 8), año impar
- [El soldado de Cristo debe renunciar a su propia voluntad](r/39a2ae4fc0.md) — Gualterio de San Víctor · Sermón 3, 5.6.7.9: CCL CM 30, 252.253.254.255 · Sábado de la semana IX del Tiempo Ordinario (semana 9), año par

## Beato Guerrico de Igny

- [¡Mira que viene el Rey!](r/275b04c469.md) — Beato Guerrico de Igny · Sermón 2 en el Adviento del Señor, 1-4: SC 166, 104-116 · Viernes de la semana III de Adviento (semana 3), año par
- [María, Madre de Cristo y Madre de los cristianos](r/8c0548eac7.md) — Beato Guerrico de Igny · Sermón 1 en la Asunción de santa María: PL 185,187-189 · Común de Santa maría virgen — Comunes, año par
- [Dios me libre de gloriarme si no es en la cruz de nuestro Señor Jesucristo](r/ec509944c5.md) — Beato Guerrico de Igny · Sermón 2, 1 en el Domingo de Ramos: PL 185, 130-131 · Miércoles Santo — Cuaresma y Pascua, año impar
- [Velad, para que os ilumine la luz de la mañana](r/d34dcc30b7.md) — Beato Guerrico de Igny · Sermón 3 sobre la Resurrección del Señor (3.5: SC 202,250-252.256-258 · Domingo de la semana XIII del Tiempo Ordinario (semana 13), año par
- [¡Oh preclara herencia de los pobres!](r/8f246de85c.md) — Beato Guerrico de Igny · Sermón 5.6.7 en la solemnidad de Todos los Santos: SC 202, 508.510.512.514 · Martes de la semana XXIX del Tiempo Ordinario (semana 29), año par

## Beato Guigo

- [Buscaba tu rostro, Señor](r/8840c50d4c.md) — Beato Guigo · Cap 3, 6-7: SC 163, 84-86.94-96 · Viernes de la semana XXX del Tiempo Ordinario (semana 30), año par

## Guillermo de Saint-Thierry

- [La palabra todopoderosa vino desde el trono real](r/0a14e9d96e.md) — Guillermo de Saint-Thierry · 10: SC 61, 91-94 · Sábado de la semana XXXI del Tiempo Ordinario (semana 31), año par

## San Hilario de Poitiers

- [¡Oh Dios, que te alaben los pueblos!](r/5f4bc601f1.md) — San Hilario de Poitiers · 3-5 : CSEL 22, 271-273 · 6 de Enero. LA EPIFANÍA DEL SEÑOR — Santoral, año par
- [Dios edifica y guarda su ciudad](r/288c413097.md) — San Hilario de Poitiers · Núms. 7-10: PL 9, 696-697 · Común de pastores — Comunes, año par
- [El cimiento de nuestro edificio es Cristo](r/e5660b242c.md) — San Hilario de Poitiers · Sal 14, 4-5: CSEL 22, 86-88 · Lunes de la semana I de Adviento (semana 1), año impar
- [El Hijo entregará al reinado de Dios, a los que él llamó al reino](r/b007b76509.md) — San Hilario de Poitiers · Lib. 11, 36-40: PL 10, 423-425 · Lunes de la semana II de Adviento (semana 2), año impar
- [Cristo regirá como pastor las naciones que se le han confiado](r/e1cb98b2ce.md) — San Hilario de Poitiers · Sal 2, 31.34 35.37: CSEL 22, 60.63.64.65 · Martes de la semana II de Adviento (semana 2), año impar
- [Cuando entregare el reino a Dios Padre, Cristo reinará con los que son reyes](r/1fb6dd186e.md) — San Hilario de Poitiers · Salmo 60, 5-6: CSEL 22, 205-207 · Miércoles de la semana III de Adviento (semana 3), año impar
- [Del verdadero temor de Dios](r/f2d6cd7f2c.md) — San Hilario de Poitiers · Sobre el salmo 127, 1-3: CSEL 24, 628-630 · Jueves de la semana II de Cuaresma (semana 2), año par
- [La encarnación del Verbo y el sacramento de la Eucaristía nos hacen partícipes de la naturaleza divina](r/89efb41c8a.md) — San Hilario de Poitiers · Lib 8, 13-16: CCL 62A, 325-328 · Domingo de la semana IV de Pascua (semana 4), año par
- [El don del Padre en Cristo](r/864ac189c6.md) — San Hilario de Poitiers · Libro 2, 1, 33. 35: PL 10, 50-51. 73-75 · Viernes de la semana VII de Pascua (semana 7), año par
- [Cristo, que es la vida, quiso morir para hacernos digna morada de Dios](r/219e92b59e.md) — San Hilario de Poitiers · Tratado 6-7 sobre el Salmo 131: CSEL 22, 666-667 · Martes Santo — Cuaresma y Pascua, año impar
- [Cristo promulga el código de la vida celestial](r/48f93d7eba.md) — San Hilario de Poitiers · Cap. 4, 1-3. 9: PL 9, 931-934 · Domingo de la semana IV del Tiempo Ordinario (semana 4), año impar
- [Paraos en el camino del Señor](r/25374fe54b.md) — San Hilario de Poitiers · Tratado sobre el Salmo 127, 2-3. 6: CSEL 22, 629-632 · Lunes de la semana X del Tiempo Ordinario (semana 10), año impar
- [Te serviré predicándote](r/c8c8b91dce.md) — San Hilario de Poitiers · Libro 1, 37-38: PL 10, 48-49 · 13 de enero San Hilario, obispo y Doctor de la Iglesia — Santoral, año impar
- [La multitud de los creyentes no era sino un solo corazón y una sola alma](r/4ff59ffcd4.md) — San Hilario de Poitiers · 132, PLS 1, 244-245 · Lunes de la semana VI del Tiempo Ordinario (semana 6), año par
- [Muy a gusto hemos de presumir de nuestras debilidades, para que así resida en nosotros la fuerza de Dios](r/50970e6693.md) — San Hilario de Poitiers · Tratado 3. 7. 11 sobre el Salmo 15: PL 9, 892. 894. 896. 897 · Jueves de la semana XXX del Tiempo Ordinario (semana 30), año impar
- [Toda la alabanza del Padre viene del Hijo](r/6a6033e644.md) — San Hilario de Poitiers · Lib. 3, 15-16: PL 10, 84-85 · Sábado de la semana XXXIV del Tiempo Ordinario (semana 34), año impar

## San Hipólito

- [¡Oh mística largueza! ¡Oh Pascua divina!](r/1078775c5c.md) — San Hipólito · Homilía 6, 1. 5 en la Pascua: PG 59, 735. 743-746 · Lunes de la Octava de Pascua — Cuaresma y Pascua, año par

## San Hipólito de Roma

- [Manifestación del misterio escondido](r/3f715f3c02.md) — San Hipólito de Roma · Caps. 9-12: PG 10, 815-819 · 23 de Diciembre — Santoral, año par
- [La Palabra hecha carne nos diviniza](r/e92981101e.md) — San Hipólito de Roma · Cap. 10, 33-34: PG 16, 3452-3453 · 30 de Diciembre. Día VI - Octava de Navidad — Santoral, año impar
- [David fue figura de Cristo](r/fc932760ff.md) — San Hipólito de Roma · Homilía 1, 1-4. 2 sobre David y Goliat: CSCO 264 [Scriptores Iberici t. 16] 1-3 · Lunes de la semana XIV del Tiempo Ordinario (semana 14), año impar
- [Los santos profetas se han convertido en ojos para nosotros](r/9408ff87e1.md) — San Hipólito de Roma · Tratado 2: Edit CSCO vol 264 [Scriptores Iberici t. 16], 55 · Lunes de la semana XXIX del Tiempo Ordinario (semana 29), año impar

## San Hipólito de Roma

- [¡Venid al bautismo de la inmortalidad!](r/bd9d6ef23f.md) — San Hipólito de Roma · En la santa Teofanía : PG 10, 858-859 · Domingo después del 6 de Enero. EL BAUTISMO DEL SEÑOR — Adviento y Navidad, año par
- [El agua y el Espíritu](r/deca38d75e.md) — San Hipólito de Roma · Sermón 2.6-8.10: PG 10.854.858-859.862 · 8 de Enero o Martes después del Domingo de Epifanía — Santoral, año impar

## San Ignacio

- [Examinad si los espíritus provienen de Dios](r/3270b9a50b.md) — San Ignacio · Cap. 1, 5-9: Acta Sanctorum Iulii 7 [1868], 647 · 31 de julio San Ignacio de Loyola, Presbítero — Santoral, año impar

## San Ignacio de Antioquía

- [No quiero agradar a los hombres, sino a Dios](r/aac0d1bb9b.md) — San Ignacio de Antioquía · 1, 1-2, 2: Funck 1, 213-215 · Martes de la semana IV del Tiempo Ordinario (semana 4), año impar
- [Ser cristiano no sólo de nombre, sino también de hecho](r/0e47fbe144.md) — San Ignacio de Antioquía · 3-4: Funck 1, 215-219 · Miércoles de la semana IV del Tiempo Ordinario (semana 4), año impar
- [Permitid que imite la pasión de mi Dios](r/6375a11b8c.md) — San Ignacio de Antioquía · 5-6: Funck 1, 219-221 · Jueves de la semana IV del Tiempo Ordinario (semana 4), año impar
- [Os escribo en vida, pero deseando morir](r/b460a51b8d.md) — San Ignacio de Antioquía · 7-8: Funck 1, 121-123 · Viernes de la semana IV del Tiempo Ordinario (semana 4), año impar
- [Os saluda mi espíritu y la caridad de las Iglesias](r/ffed9a4f26.md) — San Ignacio de Antioquía · 9-10: Funck 1, 223 · Sábado de la semana IV del Tiempo Ordinario (semana 4), año impar
- [Me ofrezco como víctima de expiación](r/986002afe9.md) — San Ignacio de Antioquía · Carta 6-8: Funck 1, 251 · Domingo de la semana IX del Tiempo Ordinario (semana 9), año impar
- [Es necesario no sólo llamarse cristianos, sino serlo en realidad](r/9bec4bf3f9.md) — San Ignacio de Antioquía · Caps 1, 1-5,2: Funk 1, 191-195 · Viernes de la semana X del Tiempo Ordinario (semana 10), año par
- [Una sola oración y una sola esperanza en la caridad y en la santa alegría](r/93fc0da3b2.md) — San Ignacio de Antioquía · Caps 6 1-9, 2: Funk 1,195-199 · Sábado de la semana X del Tiempo Ordinario (semana 10), año par
- [Tenéis a Cristo en vosotros](r/130f9e8ff3.md) — San Ignacio de Antioquía · Caps 10, 1—15: Funk 1, 199-203 · Domingo de la semana XI del Tiempo Ordinario (semana 11), año par
- [Soy trigo de Dios, y he de ser molido por los dientes de las fieras](r/12228c3735.md) — San Ignacio de Antioquía · Caps. 4, 1-2; 6, 1-8, 3: Funk 1, 217-223 · 17 de octubre San Ignacio de Antioquía, obispo y mártir — Santoral, año impar
- [Os quiero prevenir como a hijos míos amadísimos](r/2c1505fe25.md) — San Ignacio de Antioquía · Caps 1, 1-3; 2; 4,1-2; 6,1; 7, 1-8, 1: Funk 1, 203-209 · Viernes de la semana XXI del Tiempo Ordinario (semana 21), año par
- [Convertíos en criaturas nuevas por medio de la fe, que es como la carne del Señor, y por medio de la caridad, que es como su sangre](r/f31dedede1.md) — San Ignacio de Antioquía · Caps 8, 1-9, 2; 11, 1—13 3: Funk 1, 209-211 · Sábado de la semana XXI del Tiempo Ordinario (semana 21), año par
- [No os hablo con autoridad, como si fuera alguien](r/fc21868788.md) — San Ignacio de Antioquía · 1-3: Funk 2, 183-185 · Domingo de la semana XXII del Tiempo Ordinario (semana 22), año par
- [En la concordia de la unidad](r/6c2424659b.md) — San Ignacio de Antioquía · n. 4-6: Funk 2, 183-185 · Domingo de la semana XXII del Tiempo Ordinario (semana 22) - Año A: Mt 12, 21-27, año par
- [Todo lo hacéis en Cristo Jesús](r/a284268d38.md) — San Ignacio de Antioquía · 7-9: Funk 2, 189-193 · Martes de la semana XXII del Tiempo Ordinario (semana 22), año par
- [Las cadenas, perlas espirituales](r/2e388de472.md) — San Ignacio de Antioquía · 10-12: Funk 2, 195-197 · Miércoles de la semana XXII del Tiempo Ordinario (semana 22), año par
- [Nada mejor que la paz en Cristo](r/83a5ee7288.md) — San Ignacio de Antioquía · 13-15: Funk 2, 197-201 · Jueves de la semana XXII del Tiempo Ordinario (semana 22), año par
- [La cruz es para nosotros salvación y vida eterna](r/f0f069b8a1.md) — San Ignacio de Antioquía · 16-19: Funk 2,201-203 · Viernes de la semana XXII del Tiempo Ordinario (semana 22), año par
- [Doy mi vida por vosotros](r/c2af025683.md) — San Ignacio de Antioquía · 20-21: Funk 2, 203-205 · Sábado de la semana XXII del Tiempo Ordinario (semana 22), año par

## San Ildefonso de Toledo

- [En el Bautismo, Cristo es quien bautiza](r/f0cdccf1a9.md) — San Ildefonso de Toledo · Caps. 15-16: PL 96,117-118 · 23 de enero San Ildefonso, Obispo — Santoral, año impar

## San Ireneo de Lyon

- [Cuando venga Cristo, Dios será visto por todos los hombres](r/354f766de9.md) — San Ireneo de Lyon · Lib 4, 20, 4-5: SC 100, 634-640 · Miércoles de la semana III de Adviento (semana 3), año par
- [La economía de la encarnación redentora](r/86d68262d2.md) — San Ireneo de Lyon · Lib. 3, 20, 2-3: SC 34, 342-344 · 19 de Diciembre — Santoral, año par
- [Eva y María](r/f168e743bd.md) — San Ireneo de Lyon · Lib. 5,19, 1; 20, 2; 21, 1: SC 153, 248-250. 260-264 · Viernes de la semana II de Adviento (semana 2), año impar
- [La amistad de Dios](r/823ba7d8e6.md) — San Ireneo de Lyon · Lib. 4, 13—14, 1: SC 100, 534-540 · Sábado después de Ceniza — Cuaresma y Pascua, año par
- [La alianza del Señor](r/c65064c94e.md) — San Ireneo de Lyon · Lib. 4,16, 1-5: SC 100, 564-572 · Viernes de la semana II de Cuaresma (semana 2), año par
- [El envío del Espíritu Santo](r/5942ae421e.md) — San Ireneo de Lyon · Libro 3, 17, 1-3: SC 34, 302-306 · Domingo de Pentecostés — Cuaresma y Pascua, año par
- [La predicación de la verdad](r/565890ef23.md) — San Ireneo de Lyon · Libro 1,10,1-3: PG 7, 550-554 · 25 de abril. SAN MARCOS, Evangelista — Santoral, año par
- [La oblación pura de la Iglesia](r/6cc80a5fe1.md) — San Ireneo de Lyon · Lib. 4, 18, 1-2. 4. 5: SC 100, 596-598. 606. 610-612 · Sábado de la semana I de Cuaresma (semana 1), año impar
- [La eucaristía, arras de la resurrección](r/25954fa224.md) — San Ireneo de Lyon · Lib. 5, 2, 2-3: SC 153, 30-38 · Miércoles de la semana III de Pascua (semana 3), año impar
- [Cristo, primicias de nuestra resurrección](r/f0844ab785.md) — San Ireneo de Lyon · Lib. 3, 19, 1. 3-20, 1: SC 34, 332. 336-338 · Domingo de la semana VI del Tiempo Ordinario (semana 6), año impar
- [Trayéndose a sí mismo, Cristo nos trajo toda novedad](r/369a33f64a.md) — San Ireneo de Lyon · Lib 4, 34, 1.2.3: SC 100, 846-848; 850-854 · Domingo de la semana VIII del Tiempo Ordinario (semana 8), año impar
- [La gloria de Dios consiste en que el hombre viva, y la vida del hombre consiste en la visión de Dios](r/24a9abe2f2.md) — San Ireneo de Lyon · Libro 4, 20, 5-7: SC 100, 640-642. 644-648 · 28 de junio San Ireneo, Obispo y Mártir — Santoral, año impar
- [La economía del madero nos ha manifestado al Verbo, que estaba oculto a nuestros ojos](r/62832f273e.md) — San Ireneo de Lyon · Lib. 5, 17, 3-4: SC 153, 230-234 · Domingo de la semana XIX del Tiempo Ordinario (semana 19), año impar
- [Tanto en la ley como en el evangelio, el primero y principal mandamiento es amar a Dios](r/23eb3ac28c.md) — San Ireneo de Lyon · Lib 4, 12,1—13,3: SC 100, 508-516 · Domingo de la semana XXII del Tiempo Ordinario (semana 22), año impar
- [Quiero misericordia y no sacrificios](r/5b23edcf95.md) — San Ireneo de Lyon · Lib. 4, 17, 4-6: SC 100, 590-594 · Tiempo Ordinario, año impar
- [Yo soy la resurrección y la vida](r/7b0c930c6e.md) — San Ireneo de Lyon · Lib 4, 5, 2—5, 4: SC 100, 428-436 · Semana XXXII DEL TIEMPO ORDINARIO, año impar
- [El Padre es conocido por la manifestación del Hijo](r/e86b5adad4.md) — San Ireneo de Lyon · Lib 4, 6, 3.5.6.7: SC 100, 442.446.448-454 · Sábado de la semana XXVIII del Tiempo Ordinario (semana 28), año par

## Isaac de Stella

- [María y la Iglesia](r/2e003688b6.md) — Isaac de Stella · Sermón 51: PL 194, 1862-1863.1865 · Sábado de la semana II de Adviento (semana 2), año par
- [Primogénito de muchos hermanos](r/aecae9447b.md) — Isaac de Stella · Sermón 42: PL 194, 1831-1832 · Domingo de la semana V de Pascua (semana 5) - Año A: Jn 14, 1-12, año par
- [La preeminencia de la caridad](r/07b20b4aa7.md) — Isaac de Stella · Sermón 31: PL 194, 1292-1293 · Jueves de la semana IX del Tiempo Ordinario (semana 9), año impar

## San Isidoro de Sevilla

- [El obispo debe tener su puerta abierta a todo el que llegue](r/bec7de5d5e.md) — San Isidoro de Sevilla · Cap. 5,1. 2: PL 83, 785 · 4 de abril. San Isidoro de Sevilla, Obispo y Doctor de la Iglesia — Santoral, año par
- [Superaba a todo el mundo en sabiduría y, más aún, en obras de caridad](r/0775337ac3.md) — San Isidoro de Sevilla · PL 81,15-17 · Mes de abril — Santoral, año par
- [Defensor y restaurador de la fe](r/8d0e6ef591.md) — San Isidoro de Sevilla · Cap. 41: PL 83, 1103-1104 · Mes de octubre — Santoral, año impar

## San Jerónimo

- [El que nació una vez de María, nace a diario en nosotros](r/3408481e13.md) — San Jerónimo · Salmo 84: CCL 78, 107-108 · 23 de Diciembre — Santoral, año impar
- [Sólo en el Señor debemos confiar](r/59fcf49321.md) — San Jerónimo · Venecia, 21 de junio de 1535 · 8 de febrero. San Jerónimo Emiliani — Santoral, año par
- [Pasaré al lugar del tabernáculo admirable](r/436f6e04e0.md) — San Jerónimo · Homilía a los recién bautizados, sobre el salmo 41: CCL 78, 542-544 · Miércoles de la semana XV del Tiempo Ordinario (semana 15), año impar
- [Convertíos a mí](r/faf7967eca.md) — San Jerónimo · PL 25, 967-968 · Jueves de la semana XXVIII del Tiempo Ordinario (semana 28), año impar
- [Ignorar las Escrituras es ignorar a Cristo](r/d02922eeb5.md) — San Jerónimo · Núms. 1. 2: CCL 73,1-3 · 30 de septiembre San Jerónimo, presbítero y doctor de la Iglesia — Santoral, año impar
- [Buscad los bienes de arriba](r/c40d478a83.md) — San Jerónimo · PL 23, 1057-1059 · Miércoles de la semana XX del Tiempo Ordinario (semana 20), año par

## San José de Calasanz

- [Procuremos vivir unidos a Cristo y agradarle sólo a Él](r/c4ff714cf0.md) — San José de Calasanz · Memorial al cardenal M. A. Tonti, 1621: Ephemerides Calasantiae 36, 9-10, Roma 1967, pp. 473-474; L. Picanyol, Epistolario di S. Giuseppe Calasanzio, 9 volúmenes, edición calasancia, Roma 1951-1956, passim · El mismo día 25 de agosto San José Calasanz, presbítero — Santoral, año impar

## Beato José María Rubio

- [Humildad y oración](r/6c4e388f42.md) — Beato José María Rubio · Escritos del P. José María Rubio, Apostolado de la Prensa, Madrid 1932, pp. 159-160 · 4 de mayo. Beato José María Rubio, Presbítero — Santoral, año par

## San Josemaría Escrivá

- [Conducir en medio del mundo una vida verdaderamente contemplativa](r/d49c4ea199.md) — San Josemaría Escrivá · Hacia la santidad, ed. Palabra, Madrid 1973, pp. 7-9, 12-13, 20-21, 23-24, 32-33, 40-41, 52 · 26 de junio San Josémaría Escrivá de Balaguer, Presbítero — Santoral, año impar

## San Juan Bautista de la Salle

- [El amor de Cristo nos apremia](r/ef363b5269.md) — San Juan Bautista de la Salle · Meditación 201 · 7 de abril. San Juan Bautista de la Salle, Presbítero — Santoral, año par

## San Juan Bosco

- [Trabajé siempre por amor](r/cfb1e9932c.md) — San Juan Bosco · Epistolario, 4, 201-203: Turín 1959 · 31 de enero San Juan Bosco, Presbítero — Santoral, año impar

## Juan Casiano

- [Sobre las tres renuncias](r/6366588797.md) — Juan Casiano · Conf 3, cap 6-7: PL 564-567 · Domingo de la semana XXIII del Tiempo Ordinario (semana 23), año impar

## San Juan Crisóstomo

- [Junto al Niño Jesús están María y José](r/6ac6ae87ce.md) — San Juan Crisóstomo · Homilía sobre el día de Navidad: PG 56, 392 · Navidad y su Octava — Adviento y Navidad, año par
- [Hemos encontrado al Mesías](r/9f96e41641.md) — San Juan Crisóstomo · Homilía 19,1: PG 59,120-121 · 30 de noviembre. SAN ANDRÉS, APÓSTOL — Santoral, año par
- [Adán y Cristo, Eva y María](r/60cfbfae09.md) — San Juan Crisóstomo · Sobre el cementerio y la cruz, 2: PG 49, 396 · Común de Santa maría virgen — Comunes, año par
- [No puede ocultarse la luz de los cristianos](r/fdd1c7e7d5.md) — San Juan Crisóstomo · Homilía 20, 4: PG 60,162-164 · Común de santos varones — Comunes, año par
- [Cristo nos recomienda la misericordia](r/4f560b8b83.md) — San Juan Crisóstomo · Homilía 15, 6: PG 60, 547-548 · Para los que se han consagrado a una actividad caritativa — Comunes, año par
- [Tenemos que preocuparnos del bien de los niños](r/529ac855f4.md) — San Juan Crisóstomo · Homilía 59: PG 58, 580. 584 · Para los santos educadores — Comunes, año par
- [La oración es luz del alma](r/b8f4cab50c.md) — San Juan Crisóstomo · Homilía 6 sobre la oración, suplemento: PG 64, 462-466 · Viernes después de Ceniza — Cuaresma y Pascua, año par
- [Moisés y Cristo](r/a501777566.md) — San Juan Crisóstomo · Catequesis 3, 24-27: SC 50, 165-167 · Domingo de la semana II de Cuaresma (semana 2) - Año A: Mt 17, 1-9, año par
- [Dios no perdonó a su propio Hijo, sino que lo entregó a la muerte por nosotros](r/9126879a10.md) — San Juan Crisóstomo · 17, 1-8: PG 52, 516-518 · Semana IV de Cuaresma — Cuaresma y Pascua, año par
- [El valor de la sangre de Cristo](r/256817152a.md) — San Juan Crisóstomo · Catequesis 3, 13-19: SC 50, 174-177 · Triduo pascual — Cuaresma y Pascua, año par
- [No os dejaré desamparados](r/d75fddcbb0.md) — San Juan Crisóstomo · Homilía 75, 1: PG 59, 403-405 · Domingo de la semana VI de Pascua (semana 6), año par
- [La cruz es voluntad del Padre, gloria del Hijo, gozo del Espíritu Santo](r/13be837936.md) — San Juan Crisóstomo · Homilías sobre el nuevo Testamento : PG 51, 34-35 · Semana VII de Pascua — Cuaresma y Pascua, año par
- [La caridad, garantía de la unidad de la Iglesia](r/b0982856d5.md) — San Juan Crisóstomo · Homilía antes de partir en exilio: PG 52, 427*-430 · El mismo día 13 de abril. San Hermenegildo, Mártir — Santoral, año par
- [Muéstranos, Señor, cuál es el elegido](r/c3b74fdd55.md) — San Juan Crisóstomo · Homilía 3, 1. 2. 3: PG 60, 33-36. 38 · 14 de mayo. SAN MATÍAS, Apóstol — Santoral, año par
- [Ayunamos por nuestros pecados, pues vamos a acercarnos a los sagrados misterios](r/bd3dfce7fa.md) — San Juan Crisóstomo · Discurso 3, contra los judíos: PG 48, 867-868 · Jueves después de Ceniza — Cuaresma y Pascua, año impar
- [Cinco caminos de penitencia](r/b336a04d57.md) — San Juan Crisóstomo · Homilía 2, 6: PG 49, 263-264 · Viernes después de Ceniza — Cuaresma y Pascua, año impar
- [¿Qué es lo que Dios no ha hecho por nosotros?](r/03a7000c34.md) — San Juan Crisóstomo · Hom. 14, 8: PG 60, 534-535 · Martes de la semana I de Cuaresma (semana 1), año impar
- [Siendo como era Dios y Señor, no rehusó asumir la condición de esclavo](r/11f2e6f0fe.md) — San Juan Crisóstomo · Homilía 2, 3: PG 63, 23. 24-25 · Semana III de Cuaresma — Cuaresma y Pascua, año impar
- [Eficacia de la oración](r/a0995eb2f0.md) — San Juan Crisóstomo · Homilía 2, 4-5: PG 61, 397- 399 · Viernes de la semana III de Cuaresma (semana 3), año impar
- [Al que no había pecado, Dios lo hizo expiar nuestros pecados](r/fc6166a93c.md) — San Juan Crisóstomo · Homilía 11, 3-4: PG 61, 478-480 · Miércoles de la semana IV de Cuaresma (semana 4), año impar
- [Os hace falta constancia para cumplir la voluntad de Dios y alcanzar la promesa](r/e24c0953b8.md) — San Juan Crisóstomo · Homilía 21, 2-3: PG 63, 150-152 · Semana V de Cuaresma — Cuaresma y Pascua, año impar
- [Para aprender a correr rectamente, fijémonos en Cristo](r/1e7f383072.md) — San Juan Crisóstomo · Homilía 28, 2: PG 63, 195 · Jueves de la semana V de Cuaresma (semana 5), año impar
- [Jesús, para consagrar al pueblo con su propia sangre, murió fuera de las murallas](r/85e2ec453e.md) — San Juan Crisóstomo · Homilía 33, 3-4: PG 63, 229-230 · Sábado de la semana V de Cuaresma (semana 5), año impar
- [Somos justificados por la gracia](r/06c9c2a7ec.md) — San Juan Crisóstomo · Lib. 4: PG 73, 606-607 · Martes de la semana III de Pascua (semana 3), año impar
- [La fuerza del Espíritu Santo](r/906732113c.md) — San Juan Crisóstomo · Homilía 2, 1 en la solemnidad de Pentecostés: PG 50, 463-465 · Sábado de la semana VII de Pascua (semana 7), año impar
- [El error es múltiple; la virtud, una](r/c9144e902c.md) — San Juan Crisóstomo · Homilía 3, 1: PG 60, 411-412 · Martes de la semana I del Tiempo Ordinario (semana 1), año impar
- [Somos, no simplemente herederos, sino coherederos con Cristo](r/dbe2649821.md) — San Juan Crisóstomo · Homilía 14, 3: PG 60, 527-528 · Domingo de la semana III del Tiempo Ordinario (semana 3), año impar
- [Lo que parecía molesto, es lo que ha salvado a todo el mundo](r/c0d814f10b.md) — San Juan Crisóstomo · Homilía 15, 2: PG 60, 542-543 · Lunes de la semana III del Tiempo Ordinario (semana 3), año impar
- [Piensa, oh hombre, de cuántos y cuáles dones hoy has sido enriquecido](r/73cdd58cd1.md) — San Juan Crisóstomo · Homilía 3, sobre la limosna: PG 51, 263-265 · Domingo de la semana V del Tiempo Ordinario (semana 5), año impar
- [La lámpara no luce para sí, sino para los que viven en tinieblas](r/96eb272374.md) — San Juan Crisóstomo · Homilía 12, 20-2: PG 51, 174 · Domingo de la semana V del Tiempo Ordinario (semana 5), año impar
- [Enseñamos una sabiduría divina, misteriosa](r/c45afd4117.md) — San Juan Crisóstomo · Homilía 7, 1-2: PG 61, 55-56 · Martes de la semana V del Tiempo Ordinario (semana 5), año impar
- [Adhirámonos a Cristo, pues si estamos separados, perecemos](r/2627bffc61.md) — San Juan Crisóstomo · Homilía 8, 4: PG 61, 72-73 · Miércoles de la semana V del Tiempo Ordinario (semana 5), año impar
- [Qué significa comer la cena del Señor](r/9b6dd5b7f5.md) — San Juan Crisóstomo · Homilía 11, 19: PG 51, 257-258 · Domingo de la semana VII del Tiempo Ordinario (semana 7), año impar
- [Todas estas cosas las realizan las manos consagradas de los sacerdotes](r/bf3186e110.md) — San Juan Crisóstomo · Lib 3, 3-6: PG 48, 643-644 · Domingo de la semana VII del Tiempo Ordinario (semana 7), año impar
- [Los misterios, tan pletóricos de gracia de salvación que celebramos en cada reunión, reciben el nombre de Eucaristía](r/d6488f9494.md) — San Juan Crisóstomo · Homilía 3-4: PG 57, 331 · Domingo de la semana VIII del Tiempo Ordinario (semana 8), año impar
- [Cristo es el grano que ha disipado las tinieblas y ha renovado la Iglesia](r/69e8e87870.md) — San Juan Crisóstomo · Homilía 7 [atribuida] : PG 64, 21-26 · Domingo de la semana XI del Tiempo Ordinario (semana 11), año impar
- [Imitemos al Señor](r/b1a26e4086.md) — San Juan Crisóstomo · Homilía 1,5 sobre la cruz y el ladrón : PG 49, 405-408 · Domingo de la semana XIV del Tiempo Ordinario (semana 14), año impar
- [Debemos atender a todos por igual](r/e223ba2b3f.md) — San Juan Crisóstomo · Homilía 10, cap. 6, 4: PG 63, 88-89 · Domingo de la semana XV del Tiempo Ordinario (semana 15), año impar
- [Lo mismo que la levadura hace fermentar toda la masa, así vosotros convertiréis el mundo entero](r/332b82a482.md) — San Juan Crisóstomo · Homilía 46, 2-3: PG 58, 478-480 · Domingo de la semana XVI del Tiempo Ordinario (semana 16), año impar
- [Pablo lo sufrió todo por amor a Cristo](r/9f28295575.md) — San Juan Crisóstomo · Homilía 2 sobre las alabanzas de san Pablo: PG 50, 477-480 · 25 de enero LA CONVERSIÓN DEL APÓSTOL SAN PABLO — Santoral, año impar
- [He combatido bien mi combate](r/30a460dc53.md) — San Juan Crisóstomo · Homilía 2 sobre las alabanzas de san Pablo: PG 50, 480-484 · 26 de enero Santos Timoteo y Tito, Obispos — Santoral, año impar
- [Partícipes de la pasión de Cristo](r/051b1721c1.md) — San Juan Crisóstomo · Homilía 65, 2-4: PG 58, 619-622 · 25 de julioSANTIAGO, APÓSTOL, PATRONO DE ESPAÑA — Santoral, año impar
- [Comportémonos de modo que, arrebatados en la nube, estemos siempre con el Señor](r/00dcdf7ccf.md) — San Juan Crisóstomo · 6: PG 51, 352-353 · Martes de la semana VI del Tiempo Ordinario (semana 6), año par
- [Sentimos el corazón ensanchado](r/6c343c8be8.md) — San Juan Crisóstomo · Homilías 13 1-2: PG 61, 491-492 · Sábado de la semana VII del Tiempo Ordinario (semana 7), año par
- [En toda esta lucha me siento rebosando de alegría](r/d04fcccd5f.md) — San Juan Crisóstomo · 14, 1-2: PG 61, 497-499 · Domingo de la semana VIII del Tiempo Ordinario (semana 8), año par
- [Un certísimo ejemplo de paciencia](r/b7b2d31044.md) — San Juan Crisóstomo · PG 51, 62-63 · Domingo de la semana XV del Tiempo Ordinario (semana 15), año par
- [Gran cosa es que se nos hayan perdonado los pecados; pero lo es aún mayor que este perdón se nos haya otorgado por la sangre del Señor](r/c84f825e00.md) — San Juan Crisóstomo · Homilía 1, 3: PG 62, 13-14 · SEMANA XX del tiempo ordinario, año impar
- [Cristo entregó las llaves a aquel que extendió la Iglesia por todo el orbe de la tierra](r/f7ec2e21d8.md) — San Juan Crisóstomo · Homilía 54, 1-2: PG 58, 533-536 · Domingo de la semana XXI del Tiempo Ordinario (semana 21), año impar
- [Es éste un gran misterio](r/774d60a6f8.md) — San Juan Crisóstomo · Homilía 3, sobre cómo han de ser los desposados : PG 51, 229-230 · Miércoles de la semana XXI del Tiempo Ordinario (semana 21), año impar
- [Éstos son los pastos que dio Dios a los creyentes](r/a34aa0b1e4.md) — San Juan Crisóstomo · Homilía 50: PLS 4, 825-826. 828-830 · Lunes de la semana XXIII del Tiempo Ordinario (semana 23), año impar
- [El altar celestial, figura del altar eclesial](r/a6336379cd.md) — San Juan Crisóstomo · Homilía sobre el serafín 6, 3: PG 56, 138-139 · Domingo de la semana XXV del Tiempo Ordinario (semana 25), año impar
- [Al adornar el templo, no desprecies al hermano necesitado](r/0379d6bc51.md) — San Juan Crisóstomo · Homilía 50, 3-4: PG 58, 508-509 · Viernes de la semana XXVIII del Tiempo Ordinario (semana 28), año impar
- [No es tiempo de coronas y de premios, sino de luchas](r/003d3e3372.md) — San Juan Crisóstomo · Homilía 7, 4-5: PG 48, 773-775 · Semana XXIX DEL TIEMPO ORDINARIO, año impar
- [Sé humilde y te habrás librado de los lazos del pecado](r/3992da7d4f.md) — San Juan Crisóstomo · Homilía 2,4-5 sobre la penitencia : PG 49, 289-292 · Semana XXX DEL TIEMPO ORDINARIO, año impar
- [La cruz, símbolo del reino](r/5b5014cee9.md) — San Juan Crisóstomo · Homilía sobre la cruz y el ladrón 1, 3-4: PG 49, 403-404 · Domingo de la semana XXXIV del Tiempo Ordinario (semana 34) JESUCRISTO, REY DEL UNIVERSO, año impar
- [Lo débil de Dios es más fuerte que los hombres](r/d86318ca65.md) — San Juan Crisóstomo · Homilía 4, 3. 4: PG 61, 34-36 · 24 de agosto San Bartolomé, apóstol — Santoral, año impar
- [Para mí la vida es Cristo, y una ganancia el morir](r/45f2159664.md) — San Juan Crisóstomo · Homilía antes de partir en exilio, 1-3: PG 52, 427-430 · 13 de septiembre San Juan Crisóstomo, obispo y doctor de la Iglesia — Santoral, año impar
- [Que toda nuestra oración esté impregnada de acción de gracias](r/a23bb9a637.md) — San Juan Crisóstomo · Hom. 6, 1-2: PG 62, 529-531 · Jueves de la semana XXI del Tiempo Ordinario (semana 21), año par
- [Jesús es vida incluso para los que abandonan este mundo](r/3e38f9c873.md) — San Juan Crisóstomo · Sermón 1, 5-7: PG 56, 297-298 · Domingo de la semana XXV del Tiempo Ordinario (semana 25) - Año A: Mt 20, 1-16a, año par
- [Piensa en qué misterios te es dado participar](r/4f2f093cbc.md) — San Juan Crisóstomo · Hom. 4 : PG 51, 179-180 · Miércoles de la semana XXIX del Tiempo Ordinario (semana 29), año par
- [Cristo atestigua la resurrección futura, y, con él, los apóstoles, los mártires y la madre de los Macabeos](r/c2667f227c.md) — San Juan Crisóstomo · Sermón 2, 4-5 sobre la consolación de la muerte : PG 56, 301-302 · Jueves de la semana XXXII del Tiempo Ordinario (semana 32), año par

## San Juan Damasceno

- [Me llamaste, Señor, para servir a tus hijos](r/577f72f6e6.md) — San Juan Damasceno · Cap. l: PG 95, 417-419 · 4 de diciembre. San Juan Damasceno, Presbítero y Doctor de la Iglesia — Santoral, año par
- [Por sus frutos los conoceréis](r/acd120a7f7.md) — San Juan Damasceno · Sermón 6, Sobre la Natividad de la Virgen María, 2. 4. 5. 6: PG 96, 663. 667. 670 · 26 de julio Santos Joaquín y Ana, Padres de la Virgen María — Santoral, año impar

## San Juan de Ávila

- [El sacerdote debe ser santo](r/054f297271.md) — San Juan de Ávila · Plática enviada al padre Francisco Gómez, S. I:, para ser predicada en el Sínodo diocesano de Córdoba del año 1563: BAC 304, Obras completas del santo maestro Juan de Ávila, 3, pp. 364-365. 370. 373 · 10 de mayo. San Juan de Ávila, Presbítero — Santoral, año par
- [Porque la vida de Jesucristo sea manifestada en nosotros](r/f403aeea37.md) — San Juan de Ávila · Carta 58, a unos amigos suyos: BAC 313, Obras completas del santo maestro Juan de Ávila, 5, pp. 298-299 · 18 de mayo. San Juan I, Papa y Mártir — Santoral, año par

## San Juan de Brébeuf

- [No moriré sino por ti, Jesús, que te dignaste morir por mi](r/44d1167ac8.md) — San Juan de Brébeuf · The Jesuit Relations and Allied Documents, The Burrow Brothers Co, Cleveland 1898, 164.166 · Mes de octubre — Santoral, año impar

## San Juan de Capistrano

- [La vida de los clérigos virtuosos ilumina y serena](r/b6b2d876b3.md) — San Juan de Capistrano · Parte 1, Venecia 1580, 2 · 23 de octubre San Juan de Capistrano, presbítero — Santoral, año impar

## San Juan de Dios

- [Jesucristo es fiel, lo provee todo](r/2f14ed18c3.md) — San Juan de Dios · Archivo general de la Orden Hospitalaria, Cuaderno: De las cartas..., ff. 23v-24r, 27rv: O. Marcos, Cartas y escritos de nuestro glorioso padre san Juan de Dios, Madrid 1935, pp. 18-19. 48-50 · 8 de marzo. San Juan de Dios, Religioso — Santoral, año par

## San Juan de la Cruz

- [Dios nos habló por medio de su Hijo](r/252dff280e.md) — San Juan de la Cruz · Libro 2, cap 22, núms. 3-4 · Lunes de la semana II de Adviento (semana 2), año par
- [Conocimiento del misterio escondido en Cristo Jesús](r/9eaf4dc293.md) — San Juan de la Cruz · Canciones 37, 4 y 36, 13, declaración · 14 de diciembre. San Juan de la Cruz Presbítero y Doctor de la Iglesia — Santoral, año par
- [Me casaré contigo en matrimonio perpetuo](r/d2a792832d.md) — San Juan de la Cruz · Canción 39, 4-7 · Jueves de la semana XXIII del Tiempo Ordinario (semana 23), año impar

## San Juan Eudes

- [Fuente de salvación y de vida verdadera](r/641b034a73.md) — San Juan Eudes · Libro 1, 5: Opera omnia 6,107.113-115 · 19 de agosto San Juan Eudes, presbítero — Santoral, año impar
- [El misterio de Cristo en nosotros y en la Iglesia](r/233f2e3ced.md) — San Juan Eudes · Parte 3, 4: Opera omnia 1, 310-312 · Viernes de la semana XIX del Tiempo Ordinario (semana 19), año par

## San Juan Fisher

- [Las maravillas de Dios](r/0875a6071c.md) — San Juan Fisher · Opera omnia, edic. 1597, pp. 1588-1589 · Viernes de la semana II de Cuaresma (semana 2), año impar
- [Si alguno peca, tenemos a uno que abogue ante el Padre](r/9365cce2d2.md) — San Juan Fisher · Comentario sobre el Salmo 129, Opera omnia, ed. 1579 p. 1610 · Domingo de la semana III de Cuaresma (semana 3) - Año A: Jn 4, 5-42, año impar

## San Juan Leonardi

- [Te han explicado, hombre, lo que Dios desea de ti](r/ed41d2c2c8.md) — San Juan Leonardi · Cartas por la reforma universal de toda la Iglesia: en el Archivo de la Orden de Clérigos Regulares de la Madre de Dios · El mismo día 9 de octubre San Juan Leonardi, presbítero — Santoral, año impar

## San Juan María Vianney

- [Hermosa obligación del hombre: orar y amar](r/2678b3de36.md) — San Juan María Vianney · A. Monnin, Esprit du Curé d'Ars, París 1899, pp. 87-89 · 4 de agosto San Juan María Vianney, presbítero — Santoral, año impar

## San Juan Mediocre de Nápoles

- [Ama al Señor y sigue sus caminos](r/13baf76547.md) — San Juan Mediocre de Nápoles · Sermón 7: PLS 4, 785-786 · Jueves de la semana II de Cuaresma (semana 2), año impar

## San Juan Pablo II

- [La Virgen María consoló a Juan Diego](r/f955545fd0.md) — San Juan Pablo II · México, 31 de julio de 2002). · 9 de diciembre. San Juan Diego de Cuauhtlatoazin — Santoral, año par
- [La vocación, misterio de amor](r/b77a3e2728.md) — San Juan Pablo II · AAS 76 (1984) 513-546, n. 3 · 10 de enero. Beata Ana de los Ángeles Monteagudo — Santoral, año par
- [La sangre de los mártires da testimonio de la fe cristiana](r/e30d32dc17.md) — San Juan Pablo II · AAS 92, 2000, 849-850 · 9 de julio San Agustín Zhao Rong, Presbítero, y Compañeros, Mártires — Santoral, año impar
- ["Qué hermosos son sobre los montes los pies del mensajero que trae la Buena Nueva" (Is 52,7).](r/182d49209e.md) — San Juan Pablo II · Ecclesia, núm. 2346, 21 noviembre 1987, pp. 25 y 27, nn. 5-7. L'Osservatore Romano, edición española, 25 octubre 1987). · El mismo día 28 de septiembre San Lorenzo Ruiz y Compañeros, mártires — Santoral, año impar
- [¡No tengáis miedo! ¡Abrid las puertas a Cristo!](r/18f57e55ec.md) — San Juan Pablo II · 22 de octubre 1978 · 22 de octubre San Juan Pablo II, papa — Santoral, año impar

## San Juan XXIII

- [Martín de la caridad](r/5be67790ca.md) — San Juan XXIII · Día 6 de mayo de 1962: AAS 54 [1962], 306-309 · 3 de noviembre San Martín de Porres, religioso — Santoral, año impar

## San Justino

- [El baño de regeneración](r/73763c8cac.md) — San Justino · Cap. 61: PG 6, 419-422 · Viernes de la semana III de Pascua (semana 3), año par
- [Sigo las verdaderas doctrinas de los cristianos](r/e86943ce2b.md) — San Justino · Caps. 1-5: cf. PG 6,1366-1371 · 1 de junio. San Justino, Mártir — Santoral, año par

## San Leandro

- [Gozo de la unidad de la Iglesia](r/a37f865ee6.md) — San Leandro · PL 72, 894-895 · 13 de noviembre San Leandro, obispo — Santoral, año impar

## San León Magno

- [El misterio de nuestra reconciliación](r/04acdc5a17.md) — San León Magno · Carta 31, 2-3: PL 54, 791-793 · 17 de Diciembre — Santoral, año par
- [Reconoce, cristiano, tu dignidad](r/b95c5cacec.md) — San León Magno · Sermón 1 en la Navidad del Señor 13: PL 54, 190-193 · 25 de Diciembre. LA NATIVIDAD DEL SEÑOR — Santoral, año par
- [Y verán los confines de la tierra la victoria de nuestro Dios](r/c1839c131d.md) — San León Magno · Tratado 36 ,1-2 CCL 138, 195-196 · 9 de Enero o Miércoles después del Domingo de Epifanía — Santoral, año par
- [María, antes de concebir corporalmente, concibió en su espíritu](r/19a318fd82.md) — San León Magno · Sermón 1 en la Natividad del Señor, 2. 3: PL 54,191-192 · Común de Santa maría virgen — Comunes, año par
- [En Pedro permanece lo que Cristo instituyó](r/9066b6bf8b.md) — San León Magno · Sermón 3 en el aniversario de su consagración episcopal, 2-3: PL 54,145-146 · Común de pastores — Comunes, año par
- [El nacimiento del Señor es el nacimiento de la paz](r/70b8f9f18e.md) — San León Magno · Sermón 6, 2-3 en la Natividad del Señor: PL 54, 213-216 · 31 de Diciembre. Día VII - Octava de Navidad — Santoral, año impar
- [Dios ha manifestado su salvación en todo el mundo](r/a416ab5165.md) — San León Magno · Sermón en la Epifanía del Señor 3, 1-3. 5: PL 54, 240-244 · 6 de Enero. LA EPIFANÍA DEL SEÑOR — Santoral, año impar
- [Purificación espiritual por el ayuno y la misericordia](r/1429eb9b65.md) — San León Magno · Sermón sobre la Cuaresma, 1-2; PL 54, 285-287 · Jueves después de Ceniza — Cuaresma y Pascua, año par
- [La ley se dio por medio de Moisés, la gracia y la verdad vinieron por medio de Jesucristo](r/b1d42366fc.md) — San León Magno · Sermón 51, 3-4.8: PL 54, 310-311.313 · Semana II de Cuaresma — Cuaresma y Pascua, año par
- [Del bien de la caridad](r/4d875d01f1.md) — San León Magno · Sermón 10, 3-5 sobre la Cuaresma: PL 54, 299-301 · Martes de la semana IV de Cuaresma (semana 4), año par
- [Demos gracias por la divina economía](r/ec232e6688.md) — San León Magno · Sermón 73, 1-2: CCL 138A, 450-452 · Martes de la semana VI de Pascua (semana 6), año par
- [La ascensión de Cristo es nuestra propia exaltación](r/2803c22368.md) — San León Magno · Sermón sobre la Ascensión, 73, 3-5: CCL A 452-454 · Miércoles de la semana VI de Pascua (semana 6), año par
- [Lo que fue visible en nuestro Redentor, ha pasado a los ritos sacramentales](r/2516d02265.md) — San León Magno · Tratado 74 (1-2: CCL 138A 455-457 · Solemnidad — Cuaresma y Pascua, año par
- [La Ascensión del Señor alimenta nuestra fe](r/3d60196d53.md) — San León Magno · Sermón 2 sobre la Ascensión, 1-4: PL 54, 397-399 · Ascensión - Año A: Mt 28, 16-20 — Cuaresma y Pascua, año par
- [Por el camino del amor, también nosotros podemos ascender hasta Cristo](r/48a896fb12.md) — San León Magno · Tratado 74, 5: CCL 138 A, 459-461 · Después de la Ascensión — Cuaresma y Pascua, año par
- [Me he hecho Hijo del hombre, para que vosotros podáis ser hijos de Dios](r/4834ea815e.md) — San León Magno · Tratado 77, 4-6: CCL 138A, 490-493 · Domingo de Pentecostés — Cuaresma y Pascua, año par
- [El Espíritu de la verdad os guiará hasta la verdad plena](r/3007a374ff.md) — San León Magno · Tratado 75, 1-3: CCL 138A, 465-468 · Domingo de Pentecostés — Cuaresma y Pascua, año par
- [La Iglesia de Cristo se levanta sobre la firmeza de la fe de Pedro](r/cb45c59739.md) — San León Magno · Sermón 4 en el aniversario de su consagración episcopal, 2-3: PL 54,149-151 · 22 de febrero. La Cátedra del Apóstol San Pedro — Santoral, año par
- [El ministerio de nuestra reconciliación](r/b8b4044fec.md) — San León Magno · Carta 28, a Flaviano, 3-4: PL 54, 763-767 · 25 de marzo. LA ANUNCIACIÓN DEL SEÑOR — Santoral, año par
- [El hombre debe imitar a su Creador. Esto es un don de Dios](r/8bfdd611d3.md) — San León Magno · Homilías sobre el Año Litúrgico, 1 [12]. ed. M. Garrido Bonaño, OSB. BAC. Madrid, 1969, p. 45-46 · Jueves de la II semana de Pascua. La Santa Faz de Nuestro Señor Jesucristo — Santoral, año par
- [En la inmolación de Cristo está la verdadera Pascua y el único sacrificio](r/d1a5390486.md) — San León Magno · Sermón 60, 1-2, sobre la Pasión del Señor: CCL 138A, 363-365 · Martes de la semana IV de Cuaresma (semana 4), año impar
- [Contemplación de la pasión del Señor](r/930a5a9d33.md) — San León Magno · Sermón 15, 3-4 sobre la Pasión del Señor: PL 54, 366-367 · Sábado de la semana IV de Cuaresma (semana 4), año impar
- [La cruz de Cristo, fuente de todas las bendiciones y origen de todas las gracias](r/9052cd18d7.md) — San León Magno · Tratado 59, 4-6: CCL 138A, 354-359 · Triduo pascual — Cuaresma y Pascua, año impar
- [Entended el misterio de un amor tan grande](r/990f39ebd7.md) — San León Magno · Sermón 2, 3-5 en la resurrección del Señor: CCL 138A, 443-446 · Domingo de la semana II de Pascua (semana 2) - Año A: Jn 20, 19-31, año impar
- [Cristo vive en su Iglesia](r/fd859a409a.md) — San León Magno · Sermón 12, 3. 6. 7 sobre la Pasión del Señor: CCL 138A, 383-384. 386-388 · Miércoles de la semana II de Pascua (semana 2), año impar
- [El momento es apremiante](r/3847ae03e0.md) — San León Magno · Tratado 90, 2-3: CCL 138A, 558-561 · Martes de la semana VI del Tiempo Ordinario (semana 6), año impar
- [Tu bienhechor te quiere espléndido](r/fd2cdd2f44.md) — San León Magno · Tratado 17, 1-4: CCL 138, 68-71 · Domingo de la semana VII del Tiempo Ordinario (semana 7), año impar
- [Dios mismo será su más preciado galardón, él que es la encarnación del precepto](r/3b303920c9.md) — San León Magno · Sermón 16, 1-2: CCL 138, 61-62 · Miércoles de la semana IX del Tiempo Ordinario (semana 9), año impar
- [Somos templo del Dios vivo](r/0a8742f347.md) — San León Magno · 1.2.3.4: CCL 138A, 252.253.254.255 · Martes de la semana XII del Tiempo Ordinario (semana 12), año par
- [Meteré mi ley en su pecho](r/ce0979b035.md) — San León Magno · Sermón 95, 1-2: CCL 138A, 582-584 · Lunes de la semana XXXIV del Tiempo Ordinario (semana 34), año impar
- [Dichosos los pobres en el espíritu](r/39e3b6c454.md) — San León Magno · Sermón 95, 2-3: CCL 138A, 584-585 · Martes de la semana XXXIV del Tiempo Ordinario (semana 34), año impar
- [La dicha del reino de Cristo](r/eec49d0442.md) — San León Magno · Sermón 95, 4-5: CCL 138A, 585-587 · Miércoles de la semana XXXIV del Tiempo Ordinario (semana 34), año impar
- [Feliz el alma que ambiciona este manjar](r/c9c0bb105e.md) — San León Magno · Sermón 95, 6-7: CCL 138A, 587-588 · Jueves de la semana XXXIV del Tiempo Ordinario (semana 34), año impar
- [Mucha paz tienen los que aman tu nombre, Señor](r/8144211397.md) — San León Magno · Sermón 95, 8-9: CCL 138 A, 588-590 · Viernes de la semana XXXIV del Tiempo Ordinario (semana 34), año impar
- [El especial servicio de nuestro ministerio](r/0a12847b12.md) — San León Magno · Sermón 4,1-2: PL 54,148-149 · 10 de noviembre San León Magno, papa y doctor de la Iglesia — Santoral, año impar
- [Pedro y Pablo, dos vástagos plantados por Dios](r/fb437b6c70.md) — San León Magno · Sermón 82, En el natalicio de los apóstoles Pedro y Pablo, 1, 6-7: PL 54, 426-428 · 18 de noviembre La Dedicación de las Basílicas de los Apóstoles San Pedro y San Pablo — Santoral, año impar
- [Cual sea el trabajo de cada uno, tal será su ganancia](r/41cb16cc22.md) — San León Magno · Serm. 92, 1.2.3: PL 54, 454-455 · Domingo de la semana XXIII del Tiempo Ordinario (semana 23), año par

## San Lorenzo de Brindis

- [Llora Cristo por la sinagoga, a la que tanto amaba](r/6d03db7ff2.md) — San Lorenzo de Brindis · Homilía en el domingo noveno de Pentecostés 2, 6-7: Opera omnia, t. 8, 514-517 · Domingo de la semana XVI del Tiempo Ordinario (semana 16), año impar
- [Todo lo ha hecho bien](r/0a55e767ce.md) — San Lorenzo de Brindis · Homilía 1 en el domingo XI de Pentecostés, 1.9.11.12: Opera omnia, t. 8, 124.134.136-138 · Domingo de la semana XXIII del Tiempo Ordinario (semana 23), año impar
- [Tú, cristiano, eres la moneda del impuesto](r/dcd3aa2f3d.md) — San Lorenzo de Brindis · Homilía l,2.3.4.6 en el domingo 22 después de Pentecostés: Opera omnia, t. 8, 335-336.339-340.346 · Semana XXIX DEL TIEMPO ORDINARIO, año impar
- [Tanto amó Dios al mundo](r/edc954382f.md) — San Lorenzo de Brindis · Hom. 1, 5-6 en el lunes después de Pentecostés: Opera omnia, t. 8, 1943, 85-87 · Domingo de la semana XXIX del Tiempo Ordinario (semana 29), año par

## San Lorenzo de Brindis

- [La predicación es una función apostólica](r/d1e2fed48e.md) — San Lorenzo de Brindis · Sermón cuaresmal 2: Opera omnia 5,1, Núms. 48. 50. 52 · 21 de julio San Lorenzo de Brindis, Presbítero y Doctor de la Iglesia — Santoral, año impar

## San Lorenzo Justiniano

- [María conservaba todas estas cosas en su corazón](r/37ad439682.md) — San Lorenzo Justiniano · Sermón X, en la fiesta de la Purificación de la Santísima Virgen María: Opera 2, Venecia 1751, 38-39 · Mes de mayo — Santoral, año impar

## San Luis

- [El rey justo hace estable el país](r/045e51d163.md) — San Luis · Acta Sanctorum Augusti 5 [1868), 546 · 25 de agosto San Luis, rey de Francia — Santoral, año impar

## San Luis Gonzaga

- [Cantaré eternamente las misericordias del Señor](r/bb33ac5a90.md) — San Luis Gonzaga · Acta Sanctorum Iunii 5, 878 · 21 de junio San Luis Gonzaga, Religioso — Santoral, año impar

## San Luis María Grignion de Montfort

- [Todo tuyo](r/ae951caf61.md) — San Luis María Grignion de Montfort · nn. 120-121.125-126: oeuvres completes, Seuil, Paris 1966, 562-563.566-567). (cf. Obras completas, BAC, n. 451). · El mismo día 28 de abril. San Luis María Griñón de Montfort, Presbítero — Santoral, año par

## San Macario

- [¡Ay del alma en la que no habita Cristo!](r/70a0489e16.md) — San Macario · 28, PG 34, 710-711 · Jueves de la semana V del Tiempo Ordinario (semana 5), año par

## Santa Margarita María de Alacoque

- [Debemos conocer el amor de Cristo, que excede todo conocimiento](r/6368dac48a.md) — Santa Margarita María de Alacoque · Vie et oeuvres 2, París 1915, 321. 336. 493. 554 · El mismo día 16 de octubre Santa Margarita María de Alacoque, virgen — Santoral, año impar

## Santa María Bernarda Soubirous

- [La Señora me habló](r/0b0cc88cd1.md) — Santa María Bernarda Soubirous · Carta al padre Gondrand, año 1861: cf. A. Ravier, Les ècrits de sainte Bernadette Soubirous, París 1961, pp. 53-59 · 11 de febrero. NUESTRA SEÑORA DE LOURDES — Santoral, año par

## Santa María Magdalena de Pazzi

- [Ven, Espíritu Santo](r/42d74366c9.md) — Santa María Magdalena de Pazzi · Manuscritos III, 186. 264; IV, 716: Opere di santa María Magdalena de' Pazzi, Florencia 1965, 4, pp. 200. 269; 6, p.194 · El mismo día 25 de mayo. Santa María Magdalena de Pazzi, Virgen — Santoral, año par

## Santa María Micaela

- [Nada hay comparable a la dicha de servir a Dios](r/764c816e47.md) — Santa María Micaela · Cf. Archivo de la Santa, en Madrid · 15 de junio Santa María Micaela del Santísimo Sacramento — Santoral, año impar

## Beata Mariana de Jesús

- [La Iglesia nos ofrece a Cristo en la Eucaristía](r/eecf988e6c.md) — Beata Mariana de Jesús · Ed. Madrid 1965, pág. 254 · 17 de abril. Beata Mariana de Jesús Navarro, Virgen — Santoral, año par

## San Martín

- [El Señor está cerca, ¿por qué me voy a preocupar?](r/1db0476b40.md) — San Martín · Carta 17: PL 87, 203-204 · 13 de abril. San Martín I, Papa y Mártir — Santoral, año par

## San Martín de León

- [En su último discurso, Cristo consolidó más firmemente el amor en el corazón de sus discípulos con la palabra y el ejemplo](r/1b03f878b0.md) — San Martín de León · Sermón 21 en la Cena del Señor : PL 208, 839-840 · Viernes de la semana XX del Tiempo Ordinario (semana 20), año impar
- [Todas estas cosas tuvieron en Cristo su cumplimiento](r/430ac70c53.md) — San Martín de León · Sermón 26, en la resurrección del Señor: PL 208, 938-939 · Sábado de la semana XXIII del Tiempo Ordinario (semana 23), año impar
- [El vástago legítimo es el Verbo, coeterno siempre con Dios Padre](r/18088bc160.md) — San Martín de León · Sermón 1 en el Adviento del Señor : PL 208, 31-33. 38 · Semana XXX DEL TIEMPO ORDINARIO, año impar
- [Viene el Deseado de todas las naciones](r/a4e3adfbb5.md) — San Martín de León · Sermón 2 : PL 208, 37-39 · Viernes de la semana XXXI del Tiempo Ordinario (semana 31), año impar

## San Maximiliano María Kolbe

- [El ideal de la vida apostólica es la salvación y santificación de las almas](r/b3f383e146.md) — San Maximiliano María Kolbe · Gli scritti di Massimiliano Kolbe eroe di Oswiecim e beato della Chiesa, vol. I, Città di Vita, Florencia 1975, pp. 44-46. 113-114 · 14 de agosto San Maximiliano María Kolbe, presbítero y mártir — Santoral, año impar

## San Máximo de Turín

- [La navidad y el bautismo de Cristo son mi misterio y mi salvación](r/daf22ae4b0.md) — San Máximo de Turín · Sermón 45, 1-3 CCL 23, 182-183 · 12 de Enero oSábado después del Domingo de Epifanía — Santoral, año par
- [Todavía hoy la voz de Juan nos interpela](r/ee9adb7ce7.md) — San Máximo de Turín · Sermón 88, 1-3: CCL 23, 359-360 · Sábado de la semana I de Adviento (semana 1), año impar
- [La Navidad del Señor está cerca](r/e279750692.md) — San Máximo de Turín · Sermón 61a, 1-3: CCL 23, 249. 250-251 · 19 de Diciembre — Santoral, año impar
- [Cristo es el día](r/e220f9d839.md) — San Máximo de Turín · Sermón 53, 1-2. 4: CCL 23, 214-216 · Domingo de la semana V de Pascua (semana 5), año par
- [Cristo, día sin ocaso](r/7dd62bc313.md) — San Máximo de Turín · Sermón 53, 1-2. 4: CCL 23, 214-216 · Sábado de la semana IV de Pascua (semana 4), año impar
- [Hemos de bañarnos en la misma fuente en que Cristo se bañó para llegar a ser lo que Cristo es](r/1659ce947a.md) — San Máximo de Turín · Sermón 13, 1-4: CCL 23, 51-52 · Lunes de la semana XIX del Tiempo Ordinario (semana 19), año impar
- [El bautismo del Señor es nuestra sepultura](r/e26191fd7e.md) — San Máximo de Turín · Sermón 59, 2-4: CCL 23, 236-238 · Domingo de la semana XXI del Tiempo Ordinario (semana 21), año impar
- [Por la humildad se llega al reino; por la sencillez se entra en el cielo](r/48b8e98e34.md) — San Máximo de Turín · Sermón 48, 1-2: CCL 23, 187-188 · Domingo de la semana XXV del Tiempo Ordinario (semana 25), año impar
- [Todo para gloria de Dios](r/b128a96f35.md) — San Máximo de Turín · Sermón 73, 1-4: CCL 23, 305-307 · Domingo de la semana XXV del Tiempo Ordinario (semana 25), año par

## San Máximo el Confesor

- [Misterio siempre nuevo](r/9421a345dc.md) — San Máximo el Confesor · Centuria 1, 8-13: PG 90, 1182-86 · Ferias anteriores a la Epifanía — Adviento y Navidad, año impar
- [La misericordia de Dios para con los penitentes](r/b6f3fc8b09.md) — San Máximo el Confesor · Carta 11 : PG 91, 454-455 · Jueves de la semana IV de Cuaresma (semana 4), año par
- [La luz que alumbra a todo hombre](r/987e53bad8.md) — San Máximo el Confesor · Cuestiones a Talasio (63: PG 90, 667-670 · Domingo de la semana XII del Tiempo Ordinario (semana 12), año par
- [Sin la caridad, todo es vanidad de vanidades](r/a03ef7baec.md) — San Máximo el Confesor · Centuria 1, cap 1, 4-5.16-17.23-24.26-28.30-40: PG 90, 962-967 · Domingo de la semana XX del Tiempo Ordinario (semana 20), año par

## San Melitón de Sardes

- [El cordero inmolado nos ha hecho pasar de la muerte a la vida](r/9a88925868.md) — San Melitón de Sardes · Núms. 65-71: SC 123, 95-101 · Jueves Santo — Cuaresma y Pascua, año impar
- [Alabanza de Cristo](r/478f38dfc4.md) — San Melitón de Sardes · Homilía 2-7. 100-103: SC 123, 60-64. 120-122 · Lunes de la Octava de Pascua — Cuaresma y Pascua, año impar

## San Metodio de Sicilia

- [Su bondad provenía del mismo Dios, fuente de todo bien](r/4a33254134.md) — San Metodio de Sicilia · Analecta Bollandiana 68, 76-78 · 5 de febrero. Santa Águeda, Virgen y Mártir — Santoral, año par

## San Nicetas de Remesiana

- [La Iglesia, comunión de los santos](r/3c7d58442c.md) — San Nicetas de Remesiana · Núm. 8. 10. 11. 14: PL 52, 870-874 · Domingo de la semana XI del Tiempo Ordinario (semana 11), año impar
- [En la salmodia, todos deben salmodiar](r/27587121a3.md) — San Nicetas de Remesiana · 413-14: PLS 3, 196-198 · Martes de la semana XXI del Tiempo Ordinario (semana 21), año impar

## San Nicolás Cabasilas

- [Cristo nos ha abierto las puertas de la eternidad](r/d4939584b9.md) — San Nicolás Cabasilas · Lib. 1: PG 150, 510-511 · Miércoles de la semana II de Pascua (semana 2), año par
- [Los sagrados misterios nos unen a Cristo](r/0bb696bafd.md) — San Nicolás Cabasilas · Lib. 2: PG 150, 522-523 · Miércoles de la semana III de Pascua (semana 3), año par
- [Cristo es al mismo tiempo sacerdote y altar, ofrenda y oferente, sujeto y objeto de la ofrenda](r/9f9c046a35.md) — San Nicolás Cabasilas · Lib. 3: PG 150, 578-579 · Martes de la semana V de Pascua (semana 5), año par
- [Si moramos en Cristo, ¿qué más podemos desear?](r/d18f6b0c49.md) — San Nicolás Cabasilas · Lib. 4: PG 150, 582-583 · Miércoles de la semana V de Pascua (semana 5), año par
- [La unción del Espíritu Santo](r/8f4e53a22c.md) — San Nicolás Cabasilas · Lib. 6: PG 150, 574-575 · Jueves de la semana V de Pascua (semana 5), año par
- [Jesús mismo es el premio y la corona de los combatientes](r/2f3da720ed.md) — San Nicolás Cabasilas · Tratado 6: PG 150, 678-679 · Miércoles de la semana VI del Tiempo Ordinario (semana 6), año impar
- [He venido para que tengan vida](r/a3d804ce2b.md) — San Nicolás Cabasilas · Lib. 1: PG 150, 510-511 · Viernes de la semana XIX del Tiempo Ordinario (semana 19), año impar
- [Siento en mi interior la voz de un agua viva que me habla y me dice: «Ven al Padre»](r/8f48d496e5.md) — San Nicolás Cabasilas · Lib 1: PG 150, 494-495 · Domingo de la semana XXVIII del Tiempo Ordinario (semana 28) - Año A: Mt 22, 1-14, año par
- [A través de los sacramentos, el sol de justicia penetra en este mundo tenebroso](r/fcfac63708.md) — San Nicolás Cabasilas · Lib 1: PG 150, 502-503 · Martes de la semana XXVIII del Tiempo Ordinario (semana 28), año par
- [La bondad de Dios es inexplicable](r/ade73bb72c.md) — San Nicolás Cabasilas · Lib 1 PG 150, 498-499 · Jueves de la semana XXVIII del Tiempo Ordinario (semana 28), año par
- [Sobre la victoria de Cristo](r/b4f7430136.md) — San Nicolás Cabasilas · Lib 1: PG 150, 515-518 · Domingo de la semana XXIX del Tiempo Ordinario (semana 29) - Año A: Mt 22, 15-21, año par
- [Cristo en persona es nuestro arquetipo](r/cbb9bcbdc9.md) — San Nicolás Cabasilas · Lib 6: PG 150, 678-679 · Jueves de la semana XXX del Tiempo Ordinario (semana 30), año par

## San Odilón de Cluny

- [El que por nosotros se hizo mortal, es confesado Rey y Señor](r/a7d7fadb84.md) — San Odilón de Cluny · Sermón 9 en el día de Pentecostés : PL 142, 1015-1016 · 10 de Enero o Jueves después del Domingo de Epifanía — Santoral, año par
- [Mira, yo envío mi mensajero delante de ti](r/ad27e05cbb.md) — San Odilón de Cluny · Sermón 10, sobre San Juan Bautista: PL 142, 1019-1020 · Jueves de la semana I de Adviento (semana 1), año impar
- [Mirad, llegan días en que suscitaré a David un vástago legítimo](r/782290f4d1.md) — San Odilón de Cluny · Sermón 1 en la Navidad del Señor: PL 142, 993-994 · 21 de Diciembre — Santoral, año impar
- [Cristo resucitó para que no dude el cristiano de la propia resurrección](r/70bb6bef66.md) — San Odilón de Cluny · Sermón 5: PL 142, 1004-1005 · Oficio de Difuntos, año par

## Beato Ogerio de Lucedio

- [Ésta es la escuela de Cristo: la caridad](r/5640d397e2.md) — Beato Ogerio de Lucedio · Sermón 5: PL 184, 901-902 · Lunes de la semana XXI del Tiempo Ordinario (semana 21), año impar
- [Dios Padre flagela a la Iglesia para que crezca más vigorosa y fecunda](r/3f5f9d4fa9.md) — Beato Ogerio de Lucedio · Serm. 10, 13-14: PL 184, 927-928 · Viernes de la semana XXII del Tiempo Ordinario (semana 22), año impar

## Orígenes

- [Allanad los senderos del Señor](r/ab8b4447c4.md) — Orígenes · Hom. 22, 1-2: SC 87, 301-302 · Domingo de la semana II de Adviento (semana 2), año par
- [Seamos un edificio sólido, que ninguna tormenta consiga derribar](r/1851822d39.md) — Orígenes · Hom. 26, 3-5: SC 87, 341-343 · Domingo de la semana III de Adviento (semana 3), año par
- [Angustiados buscamos a Jesús](r/fcd955ab28.md) — Orígenes · Homilía 18, 2-5: Edit GCS 9, 112-113 · Navidad y su Octava — Adviento y Navidad, año par
- [Somos edificados a manera de piedras vivas como casa de Dios](r/12127aa4a0.md) — Orígenes · Homilía 9, 1-2: SC 71, 244-246 · Común de la dedicación de una iglesia — Comunes, año par
- [Jesús fue tentado por el diablo para que la Iglesia aprendiera que a Cristo se llega a través de muchas tribulaciones y tentaciones](r/f5f6e62054.md) — Orígenes · Hom 3: GCS t. 8, 221, 19-223, 5 · Semana I de Cuaresma — Cuaresma y Pascua, año par
- [Angosto y estrecho es el callejón que lleva a la vida](r/7690c32b46.md) — Orígenes · Homilía 5 sobre el libro del Exodo, 3-4: Ed. Maurist. t. 2, 145-146 · Semana II de Cuaresma — Cuaresma y Pascua, año par
- [Cristo es nuestro sumo sacerdote, nuestra propiciación](r/72b0cb876b.md) — Orígenes · Homilía 9, 5. 10: PG 12, 515. 523 · Domingo de la semana IV de Cuaresma (semana 4) - Año A: Jn 9, 1-41, año par
- [Por la penitencia, nos purificamos de la impureza de nuestra lepra](r/e7a3484ec0.md) — Orígenes · Homilía 7, 1-2, Ed. GCS t. 8, 37 40: SC 29, 133-136 · Semana V de Cuaresma — Cuaresma y Pascua, año par
- [Cristo, al tiempo de su pasión, no rehusó morir por los impíos y los injustos](r/00b8df9b92.md) — Orígenes · 4, 10. 11: PG 14, 997-999 · Martes de la semana V de Cuaresma (semana 5), año par
- [Si alguien ha sido reconciliado por la sangre de Cristo, que no se relacione más con lo que es enemigo de Dios](r/7e2f8b4b9f.md) — Orígenes · Lib. 4, 7: PG 14, 986-988 · Miércoles de la Octava de Pascua — Cuaresma y Pascua, año par
- [Los que son compañeros de Cristo en el sufrir también lo son en el buen ánimo](r/f4e240914f.md) — Orígenes · Núms. 41-42: PG 11, 618-619 · 2 de junio. San Marcelino y San Pedro, Mártires — Santoral, año par
- [Sin derramamiento de sangre no hay perdón](r/1c8148e765.md) — Orígenes · Lib. 3, 8: PG 14, 950-951 · Jueves de la semana IV de Cuaresma (semana 4), año impar
- [La muerte de Cristo se ha convertido en espiga de trigo](r/baebf3a56e.md) — Orígenes · Homilía 10, 1-3: PG 13, 358-362 · Domingo de Ramos - Año A: Mt 21, 1-11 — Cuaresma y Pascua, año impar
- [Esta fe que profesan los romanos es la misma que se anuncia y crece en todo el mundo](r/271e4463ea.md) — Orígenes · Lib. 1, 7-9: PG 14, 852-855 · En lugar del Domingo I del tiempo ordinario se tiene la fiesta del Bautismo del Señor., año impar
- [Dios no es parcial con nadie](r/49c7857711.md) — Orígenes · Lib. 2, 7: PG 14, 887-889 · Miércoles de la semana I del Tiempo Ordinario (semana 1), año impar
- [Abrahán creyó en lo que había de venir, nosotros creemos en lo que ya ha venido](r/ec0db05da8.md) — Orígenes · Lib. 7: PG 14, 981-985 · Domingo de la semana II del Tiempo Ordinario (semana 2), año impar
- [También vosotros habéis resucitado juntamente con él](r/26b1ffd050.md) — Orígenes · Miércoles de la semana II del Tiempo Ordinario (semana 2), año impar
- [Hoy, en esta reunión, habla el Señor](r/eb688c45c6.md) — Orígenes · Hom. 32, 2-6: SC 87, 386-392 · Domingo de la semana III del Tiempo Ordinario (semana 3), año impar
- [Todos los miembros de la Iglesia ofrecen la hostia viva](r/97e05e1649.md) — Orígenes · Lib. 91: PG 14, 1204-1205. 1206-1207 · Lunes de la semana IV del Tiempo Ordinario (semana 4), año impar
- [En la Iglesia, que es el cuerpo de Cristo, cada uno ejercemos distintas funciones](r/39a0050e30.md) — Orígenes · Lib. 9, 2: PG 14, 1211-1212 · De las Homilías sobre la primera carta a los Corintios de San Juan Crisóstomo, obispo — Tiempo Ordinario, año impar
- [Qué significa resucitar con Cristo](r/a7407ce584.md) — Orígenes · Lib. 5, 8: PG 14, 1041-1042 · Lunes de la semana VIII del Tiempo Ordinario (semana 8), año impar
- [El perdón de los pecados](r/dadcef5dbc.md) — Orígenes · Homilía 2, 4: PG 12, 417-419 · Sábado de la semana IX del Tiempo Ordinario (semana 9), año impar
- [El paso del Jordán](r/d9f05c795d.md) — Orígenes · Homilía 4, 11: PG 12, 842-843 · Miércoles de la semana X del Tiempo Ordinario (semana 10), año impar
- [La conquista de Jericó](r/8a95135e92.md) — Orígenes · Homilía 6, 4: PG 12, 855-856 · Jueves de la semana X del Tiempo Ordinario (semana 10), año impar
- [Las perlas finas conducen a la perla de gran valor](r/63588c45c3.md) — Orígenes · Lib. 10, 9-10: SC 162, 173-177 · Domingo de la semana XVII del Tiempo Ordinario (semana 17), año impar
- [Purificados por su palabra, Dios hace resplandecer en nosotros la imagen del hombre celestial](r/9af756d022.md) — Orígenes · Hom. 4: PG 12, 234-235 · En lugar del Domingo I del tiempo ordinario se tiene la fiesta del Bautismo del Señor., año par
- [Producid el fruto que la conversión pide](r/e7160069cd.md) — Orígenes · Hom. 22, 7-10: SC 87. 306-308 · Viernes de la semana I del Tiempo Ordinario (semana 1), año par
- [Hambre de oír la palabra del Señor](r/3ad0ac9e0d.md) — Orígenes · 16, 4: PG 12, 249-250 · Viernes de la semana V del Tiempo Ordinario (semana 5), año par
- [Cristo lava a su Iglesia con el baño del segundo nacimiento](r/05bf451db9.md) — Orígenes · 17, 8.9: PG 12,260-261 · Sábado de la semana V del Tiempo Ordinario (semana 5), año par
- [El sacrificio de Abrahán](r/49961f1e03.md) — Orígenes · Hom. 8, 6.8.9: PG 12, 206-209 · Martes de la semana IX del Tiempo Ordinario (semana 9), año par
- [¡Ánimo, soy yo!](r/be670aeb6d.md) — Orígenes · Lib 11, 6: PG 13, 919-923 · Viernes de la semana XV del Tiempo Ordinario (semana 15), año par
- [El justo siembra para el espíritu, y del Espíritu cosechará vida eterna](r/edeb5e425e.md) — Orígenes · nn. 68-69: PG 13, 1709-1710 · Semana XXXIII DEL TIEMPO ORDINARIO, año impar
- [Venga a nosotros tu reino](r/3690d04b07.md) — Orígenes · Cap. 25: PG 11, 495-499 · Domingo de la semana XXXIV del Tiempo Ordinario (semana 34) JESUCRISTO, REY DEL UNIVERSO, año impar
- [Esto es lo que hay que pedir en la oración](r/e4760ca876.md) — Orígenes · 1-2: PG 11,415-418 · Domingo de la semana XXVI del Tiempo Ordinario (semana 26) - Año A: Mt 21, 28-32, año par
- [Cómo hemos de orar](r/181d11236a.md) — Orígenes · 2: PG 11, 418-422 · Martes de la semana XXVI del Tiempo Ordinario (semana 26), año par
- [Dios lo sabe todo antes de que suceda](r/f9f5e440af.md) — Orígenes · 2.5: PG 11, 422-423. 430-434 · Miércoles de la semana XXVI del Tiempo Ordinario (semana 26), año par
- [Dios preordena todas las cosas](r/0d5ca5be23.md) — Orígenes · 6: PG 11, 438 · Jueves de la semana XXVI del Tiempo Ordinario (semana 26), año par
- [Sobre la oración asidua](r/eed65ad257.md) — Orígenes · 7-8: PG 11, 439-442 · Viernes de la semana XXVI del Tiempo Ordinario (semana 26), año par
- [Sobre la oración pura](r/e6eab0e084.md) — Orígenes · 9-10: PG 11, 442-446 · Sábado de la semana XXVI del Tiempo Ordinario (semana 26), año par
- [Nuestro ángel custodio reza con nosotros](r/353befe22e.md) — Orígenes · 10-11 PG 11, 446- · Domingo de la semana XXVII del Tiempo Ordinario (semana 27), año par
- [Ser constantes en orar](r/15231c1c18.md) — Orígenes · 12-13: PG 11, 451-455 · Domingo de la semana XXVII del Tiempo Ordinario (semana 27) - Año A: Mt 21, 33-43, año par
- [Vosotros que aspiráis a ser espirituales, pedid bienes celestiales en la oración](r/b1cc2948aa.md) — Orígenes · 13-14: PG 11, 455-459 · Martes de la semana XXVII del Tiempo Ordinario (semana 27), año par
- [Da a cada uno lo que le es debido](r/142dab8662.md) — Orígenes · 28: PG 11, 522-523 · Miércoles de la semana XXVII del Tiempo Ordinario (semana 27), año par
- [Todos tenemos potestad para perdonar los pecados cometidos contra nosotros](r/09bcf23721.md) — Orígenes · 28-33: PG 11, 526. 527.558-562 · Jueves de la semana XXVII del Tiempo Ordinario (semana 27), año par
- [Sobre el misterio de la encarnación del Verbo](r/3b74049bd7.md) — Orígenes · Lib 2, 6, 2: PG 11, 210-211 · Domingo de la semana XXXI del Tiempo Ordinario (semana 31) - Año A: Mt 23, 1-12, año par
- [Cristo hablaba del templo de su cuerpo](r/851038a444.md) — Orígenes · Tomo 10, 20: PG, 14, 370-371 · Sábado de la semana XXXIV del Tiempo Ordinario (semana 34), año par

## San Orsiesio

- [Somos hombres de fe para salvar el alma](r/7061e4609d.md) — San Orsiesio · Nn. 23,35.38: ed. Lefort, Louvain 1932, 124-125; 132-133.134 · Semana XXXI DEL TIEMPO ORDINARIO, año impar

## San Pablo

- [Cristo, una vez resucitado de entre los muertos, ya no muere más](r/2de3a46031.md) — San Pablo · Domingo de Pascua de la Resurrección del Señor — Cuaresma y Pascua, año par

## San Pablo de la Cruz

- [Predicamos a Cristo crucificado](r/4b924471f4.md) — San Pablo de la Cruz · Carta 1, 43; 2, 440. 825 · El mismo día 19 de octubre San Pablo de la Cruz, presbítero — Santoral, año impar

## San Pablo Le-Bao-Tinh

- [Alabad al Señor, todas las naciones](r/9889934434.md) — San Pablo Le-Bao-Tinh · Launay, A.: Le clergé tonkinois et ses prétres martyrs, MEP París. 1925, pp. 80-83). · 24 de noviembre San Andrés Dung-Lac y Compañeros, mártires — Santoral, año impar

## San Pablo VI

- [El ejemplo de Nazaret](r/be0ff28b89.md) — San Pablo VI · Alocución en Nazaret, 5 de enero de 1964 · Domingo dentro de la Octava de Navidad. LA SAGRADA FAMILIA DE JESÚS, MARÍA Y JOSÉ — Adviento y Navidad, año impar
- [Convertíos y creed en la Buena Noticia](r/291db60636.md) — San Pablo VI · AAS t. 58, 1966, pp. 179-180 · Semana III de Cuaresma — Cuaresma y Pascua, año par
- [La gloria de los mártires, signo de regeneración](r/c7750dd522.md) — San Pablo VI · AAS 56 (1964), 905-906 · 3 de junio. San Carlos Luanga y Compañeros, Mártires — Santoral, año par
- [Rasgad los corazones, no las vestiduras](r/889c5a098c.md) — San Pablo VI · AAS t. 58. 1966, 178-179 · Sábado después de Ceniza — Cuaresma y Pascua, año impar
- [Estuve enfermo, y me visitasteis](r/3ee6be000e.md) — San Pablo VI · 25 de enero de 1970: AAS 62, 1970, 82-88 · El mismo día 10 de octubre San Luis Beltrán, presbítero — Santoral, año impar
- [Eficacia pastoral del culto tributado a la Virgen](r/bfb9dd4e7e.md) — San Pablo VI · AAS 66 [1974),113-168 · 12 de octubre NUESTRA SEÑORA DEL PILAR — Santoral, año impar

## San Paciano de Barcelona

- [Reformemos nuestras costumbres en Cristo, por el Espíritu Santo](r/2c20a66f69.md) — San Paciano de Barcelona · Sobre el bautismo, Sermón 5-6: PL 13, 1092-1093 · Sábado de la semana XXI del Tiempo Ordinario (semana 21), año impar
- [¿Qué Dios como tú, que perdonas el pecado?](r/a461f30df9.md) — San Paciano de Barcelona · Sermón sobre el bautismo, 6-7: PL 13, 1093-1094 · Domingo de la semana XXII del Tiempo Ordinario (semana 22), año impar

## Papa León XIII

- [La Eucaristía, vínculo de paz y de unidad](r/d393e9f40d.md) — Papa León XIII · 28 de noviembre de 1897 · 17 de mayo. San Pascual Bailón, Religioso — Santoral, año par

## Papa Pío XI

- [Derramó su sangre por la unidad de la Iglesia](r/57601a8dee.md) — Papa Pío XI · AAS 15 [1923], 573-582 · 12 de noviembre San Josafat, obispo y mártir — Santoral, año impar

## Papa Pío XII

- [La esposa es el sol de la familia](r/b6123f0872.md) — Papa Pío XII · Discorsi e radiomessaggi, 11 de marzo de 1942:3,385-390 · Común de santas mujeres — Comunes, año par
- [No sólo buscaba su propia santificación, sino la salvación del prójimo](r/ed5558d4de.md) — Papa Pío XII · 9 de junio de 1950). · El mismo día 26 de mayo. Santa Mariana de Jesús Paredes — Santoral, año par
- [Cristo, sacerdote y víctima](r/ea78c8c7bd.md) — Papa Pío XII · AAS 39 [1947], 552-553 · Jueves después de Pentecostés JESUCRISTO, SUMO Y ETERNO SACERDOTE — Santoral, año impar
- [Nada temo, porque tú vas conmigo](r/e3b561ace2.md) — Papa Pío XII · AAS 42 (1950), 581-582 · 6 de julio Santa María Goretti, Virgen y Mártir — Santoral, año impar
- [Tu cuerpo es santo y sobremanera glorioso](r/76c41f39be.md) — Papa Pío XII · AAS 42 [1950), 760-762. 767-769 · 15 de agosto LA ASUNCIÓN DE LA VIRGEN MARÍA — Santoral, año impar

## San Pascasio Radberto

- [Velad, para estar preparados](r/560f5ec606.md) — San Pascasio Radberto · Lib. 11, cap 24: PL 120, 799-800 · Domingo de la semana I de Adviento (semana 1), año par
- [¡Fijaos qué esperanza tan cierta de salvación se ha dado a los creyentes!](r/b267d1cb80.md) — San Pascasio Radberto · Lib. 4, cap. 6: PL 120, 280-281 · Sábado de la semana XX del Tiempo Ordinario (semana 20), año impar

## San Patricio

- [Muchos pueblos renacieron a Dios por mí](r/8a72452eac.md) — San Patricio · Caps. 14-16: PL 53, 808-809 · 17 de marzo. San Patricio, Obispo — Santoral, año par

## San Paulino de Nola

- [Dios infunde su amor en los suyos por toda la tierra, por obra del Espíritu Santo](r/58f9d7b911.md) — San Paulino de Nola · Carta 3, a Alipio,1. 5. 6: CSEL 29,13-14.17-18 · 22 de junio San Paulino de Nola, Obispo — Santoral, año impar
- [Purificados nuestros sentidos de toda levadura de maldad, con mucho gusto habitará en nosotros nuestro Señor Jesucristo](r/7ab2ace5dc.md) — San Paulino de Nola · Carta 32, 23-24. 25: CSEL 29, 297-300 · Martes de la semana XIX del Tiempo Ordinario (semana 19), año impar
- [Nuestra gloria, posesión y reino es Cristo](r/b3a3bc94e1.md) — San Paulino de Nola · Carta 38, 3-4. 6: CSEL 29, 326-327. 329 · Martes de la semana XXXI del Tiempo Ordinario (semana 31), año impar
- [Demos al Señor, que recibe en la persona de cada pobre](r/bcdcdd3aa2.md) — San Paulino de Nola · Carta 34,2-4: CSEL 29, 305-306 · Semana XXXII DEL TIEMPO ORDINARIO, año impar

## Beato Pedro

- [La misericordia y la fidelidad se encuentran en el camino, que es Cristo](r/1e792e302c.md) — Beato Pedro · 165-167: CCL CM 10, 97. 99. 100 · Semana XXXI DEL TIEMPO ORDINARIO, año impar

## San Pedro Canisio

- [Una plegaria de San Pedro Canisio](r/e2930f2779.md) — San Pedro Canisio · Edición O. Braunsberger, Petri Canisii Epistulae et Acta, I, Friburgo de Brisgovia 1896, pp. 53-55 · 21 de diciembre. San Pedro Canisio Presbítero y Doctor de la Iglesia — Santoral, año par

## San Pedro Claver

- [Enviado para dar la Buena Noticia a los que sufren, para vendar los corazones desgarrados, para proclamar la amnistía a los cautivos.](r/1d47679640.md) — San Pedro Claver · Epist. diei 31 maii 1627 ad Superiorem suum data; Edit (in lingua hispanica) A. Valtierra, S.L., San Pedro Claver, Cartagena, 1964, pp. 140-141 · 9 de septiembre San Pedro Claver, presbítero — Santoral, año impar

## San Pedro Crisólogo

- [El amor desea ver a Dios](r/f2165f25b8.md) — San Pedro Crisólogo · Sermón 147 : PL 52, 594-595 · Jueves de la semana II de Adviento (semana 2), año par
- [Mirad: la virgen concebirá y dará a luz un hijo, y le pondrá por nombre Emmanuel](r/d752733d49.md) — San Pedro Crisólogo · Sermón 145: PL 52, 588 · 25 de Diciembre. LA NATIVIDAD DEL SEÑOR — Santoral, año par
- [Paz es el nombre personal de Cristo](r/a0b35f89fd.md) — San Pedro Crisólogo · Sermón 149: PL 52, 598-599 · 25 de Diciembre. LA NATIVIDAD DEL SEÑOR — Santoral, año impar
- [El que por nosotros quiso nacer no quiso ser ignorado por nosotros](r/819e4b9081.md) — San Pedro Crisólogo · Sermón 160: PL 52, 620-622 · 7 de Enero — Santoral, año impar
- [La oración llama, el ayuno intercede, la misericordia recibe](r/715216298e.md) — San Pedro Crisólogo · Sermón 43: PL 52, 320. 322 · Martes de la semana III de Cuaresma (semana 3), año par
- [Era necesaria la muerte de Lázaro para que, con Lázaro ya en el sepulcro, resucitase la fe de los discípulos](r/aff6915957.md) — San Pedro Crisólogo · Sermón 6 : PL 52, 375-377 · Semana V de Cuaresma — Cuaresma y Pascua, año par
- [Del cielo vino el Pastor para reconducir las ovejas descarriadas a los pastos de la vida](r/8d7fa4584f.md) — San Pedro Crisólogo · Sermón 6 (CCL 24, 44-47 · Domingo de la semana IV de Pascua (semana 4), año par
- [Sé tú mismo el sacrificio y el sacerdote de Dios](r/b5c37bd1d9.md) — San Pedro Crisólogo · Sermón 108 :PL 52, 499-500 · Martes de la semana IV de Pascua (semana 4), año impar
- [Dios busca a los hombres, no las cosas de los hombres](r/997afad38a.md) — San Pedro Crisólogo · Sermón 18 : PL 52, 246-249 · Domingo de la semana V del Tiempo Ordinario (semana 5), año impar
- [Realmente, para Dios la muerte es un sueño](r/be5df8c8d9.md) — San Pedro Crisólogo · Sermón 34, 1.5: CCL 34,193.197-199 · Domingo de la semana XIII del Tiempo Ordinario (semana 13), año impar
- [Convertíos, porque está cerca el reino de los cielos](r/a1796f64d3.md) — San Pedro Crisólogo · Sermón 167: PL 52, 637-638 · Martes de la semana XVII del Tiempo Ordinario (semana 17), año impar
- [Dichosos los que trabajan por la paz](r/e108731d63.md) — San Pedro Crisólogo · Sobre la paz: PL 52,347-348 · 4 de julio Santa Isabel de Portugal — Santoral, año impar
- [El mártir reina y vive](r/f44ec989d7.md) — San Pedro Crisólogo · Sermón 128, 1-3: CCL 24A, 789-791 · 20 de julio San Apolinar, Obispo y Mártir — Santoral, año impar
- [El misterio de la Encarnación](r/1b5c4949b3.md) — San Pedro Crisólogo · Sermón 148: PL 52, 596-598 · 30 de julio San Pedro Crisólogo, Obispo y Doctor de la Iglesia — Santoral, año impar
- [El número prescrito no limita, sino que dilata el perdón](r/886620014a.md) — San Pedro Crisólogo · Sermón 139 : PL 52, 573-575 · Domingo de la semana XXIII del Tiempo Ordinario (semana 23), año impar
- [Cristo nos buscó en la tierra: busquémosle nosotros en el cielo](r/b5869e43f5.md) — San Pedro Crisólogo · Sermón 168 :PL 52, 639-641 · Domingo de la semana XXIV del Tiempo Ordinario (semana 24), año impar

## San Pedro Damiani

- [Tras la tristeza, espera con alegría el gozo](r/a4e4ddf3a0.md) — San Pedro Damiani · Libro 8, 6: PL 144, 473-476 · 21 de febrero. San Pedro Damiani, Obispo y Doctor de la Iglesia — Santoral, año par
- [Protegido inexpugnablemente con el estandarte de la cruz](r/be481cb2ad.md) — San Pedro Damiani · Sermón 3, Sobre san Jorge: PL 144, 567-571 · 23 de abril. San Jorge, Mártir — Santoral, año par
- [Se negó a sí mismo para seguir a Cristo](r/b8e63fc831.md) — San Pedro Damiani · Caps. 31 y 69: PL 144, 982-983.1005-1006 · 19 de junio San Romualdo, Abad — Santoral, año impar
- [La comunión de los santos en la unidad de la fe](r/2926f32127.md) — San Pedro Damiani · Opúsculo 11, 56.10: PL 145, 235-236. 239 · Miércoles de la semana XXX del Tiempo Ordinario (semana 30), año par

## Pedro de Blois

- [Mira, llego en seguida y traigo conmigo mi salario, para pagar a cada uno su propio trabajo](r/8f821e61bc.md) — Pedro de Blois · Sermón 3 sobre la venida del Señor: PL 207, 569-572 · Miércoles de la semana I de Adviento (semana 1), año impar
- [Cristo es la sabiduría](r/1125d61f8f.md) — Pedro de Blois · Sermón 53: PL 207, 715-716 · Lunes de la semana XVII del Tiempo Ordinario (semana 17), año impar
- [He venido a prender fuego en el mundo](r/d72fd096ca.md) — Pedro de Blois · Sermón 25 : PL 207, 635-637 · SEMANA XX del tiempo ordinario, año impar
- [Cristo por nosotros se hizo pan](r/716852074c.md) — Pedro de Blois · Sermón 54, sobre el sacrificio del altar : PL 207, 720-721 · Miércoles de la semana XXVIII del Tiempo Ordinario (semana 28), año par

## San Pedro Julián Eymard

- [Eucaristía: Sacramento de vida](r/93f52ebe30.md) — San Pedro Julián Eymard · La Présence réelle, vol. 1, París, 1950, pp. 270-271 et 307-308). · El mismo día 2 de agosto San Pedro Julián Eymard, presbítero — Santoral, año impar

## San Pío de Pietrelcina

- [Piedras del edificio eterno](r/db3002c2e5.md) — San Pío de Pietrelcina · Edición 1994: II, 87-90, n. 8 · 23 de septiembre San Pío de Pietrelcina, presbítero — Santoral, año impar

## San Pío X

- [La voz de la Iglesia que resuena dulcemente](r/c0afaadb69.md) — San Pío X · AAS 3 [1911), 633-635 · 21 de agosto San Pío X, papa — Santoral, año impar

## San Policarpo de Esmirna

- [Estáis salvados por gracia](r/085faee859.md) — San Policarpo de Esmirna · Caps 1, 1-2,3: Funk 1, 267-269 · Domingo de la semana X del Tiempo Ordinario (semana 10), año par
- [Armémonos con las armas de la justicia](r/3083347799.md) — San Policarpo de Esmirna · Caps 3 1-5, 2: Funk 1, 269-273 · Lunes de la semana X del Tiempo Ordinario (semana 10), año par
- [Cristo nos ha dejado un ejemplo en su propia persona](r/fc4eeed4c1.md) — San Policarpo de Esmirna · Caps 6, 1-8, 2: Funk 1, 273-275 · Martes de la semana X del Tiempo Ordinario (semana 10), año par
- [Andemos en la fe y en la justicia](r/15f0e83e8c.md) — San Policarpo de Esmirna · Caps 9, 1-11, 4: Funk 1, 275-279 · Miércoles de la semana X del Tiempo Ordinario (semana 10), año par
- [Que Jesucristo os haga crecer en la fe y en la verdad](r/988e466f02.md) — San Policarpo de Esmirna · Caps. 12 1-14: Funk 1, 279-283 · Jueves de la semana X del Tiempo Ordinario (semana 10), año par

## San Proclo de Constantinopla

- [Venía a salvar, pero le era también necesario morir](r/ed41f518b9.md) — San Proclo de Constantinopla · Sermón 1 en alabanza de santa María, 4. 5. 6. 9. 10 : PG 65, 683-687. 690-691 · 7 de Enero — Santoral, año par
- [El amigo de los hombres se ha hecho hombre, naciendo de la Virgen](r/c519c14650.md) — San Proclo de Constantinopla · Sobre la Natividad del Señor, 1-2: PG 65, 843-846 · Común de Santa maría virgen — Comunes, año par

## San Quodvultdeus

- [Todavía no hablan, y ya confiesan a Cristo](r/d7169f3b32.md) — San Quodvultdeus · Sermón 2 sobre el Símbolo: PL 40, 655 · 28 de Diciembre. Santos Inocentes — Santoral, año par

## San Raimundo de Peñafort

- [Que el Dios del amor y de la paz purifique vuestros corazones](r/2e76c8c221.md) — San Raimundo de Peñafort · Monumenta Ordinis Praedicatorum Historica 6, 2, Roma 1901, pp. 84-85 · 7 de enero. San Raimundo de Peñafort, Presbítero — Santoral, año par

## Ricardo de San Víctor

- [Sed imitadores de Dios, como hijos queridos](r/2eb63dac29.md) — Ricardo de San Víctor · 42-45: Ed. G. Dumeige, Paris 1955, 171-175 · Domingo de la semana XXVI del Tiempo Ordinario (semana 26), año impar

## San Roberto Belarmino

- [Inclina mi corazón a tus preceptos](r/a963061ee9.md) — San Roberto Belarmino · Grado 1: Opera omnia 6, edición de 1862, 214 · El mismo día 16 de septiembre San Juan Macías, religioso — Santoral, año impar

## Santa Rosa de Lima

- [Conozcamos el amor de Cristo, que excede todo conocimiento](r/2647f393eb.md) — Santa Rosa de Lima · Al médico Castillo: edición L. Getino, La patrona de América, Madrid 1928, pp. 54-55 · 23 de agosto Santa Rosa de Lima, virgenPatrona de América Latina — Santoral, año impar

## Ruperto de Deutz

- [En medio de vosotros hay uno que no conocéis](r/c891ecfb3c.md) — Ruperto de Deutz · Lib. III, cap 3: SC 165, 26-28 · Domingo de la semana III de Adviento (semana 3), año par
- [Y el pan que yo daré es mi carne, para la vida del mundo](r/8d3ac54668.md) — Ruperto de Deutz · Lib 6, 51-52: CCL CM 9, 356-357 · Domingo de la semana XIX del Tiempo Ordinario (semana 19), año impar
- [La gracia del perdón es una e idéntica para todos](r/d3eeb474de.md) — Ruperto de Deutz · Lib 2: CCL CM 9, 60-62 · Martes de la semana XX del Tiempo Ordinario (semana 20), año impar

## Sin identificar

- [El Dueño de todo vino en forma de siervo](r/44914f3857.md) — Sin identificar · En la Natividad del Salvador Edic Schwartz, ACO t. 3, parte 1,157-159. · 25 de Diciembre. LA NATIVIDAD DEL SEÑOR — Santoral, año par
- [Venga también ahora la Palabra del Señor a quienes la esperamos en silencio](r/5f39d26e02.md) — Sin identificar · Sermón 1: SC 192, 45. 52. 60 · 4 de Enero — Santoral, año par
- [Dios era el mismo en su corazón y en sus labios](r/0945932565.md) — Sin identificar · 2 de febrero de 1767: Bullarii romani continuatio IV parte II, Prato 1843, pp.1314-1316 · 23 de diciembre. San Juan de Kety, Presbítero — Santoral, año par
- [Derramaré sobre vosotros un agua pura, y os daré un corazón nuevo](r/161f6bc7e1.md) — Sin identificar · Domingo de Pascua de la Resurrección del Señor — Cuaresma y Pascua, año par
- [R. Amémonos unos a otros, ya que el amor es de Dios * y todo el que ama ha nacido de Dios y conoce a Dios.](r/98c5f7d321.md) — Sin identificar · Cuando se celebra como solemnidad: — Santoral, año par
- [El bautismo, figura de la pasión de Cristo](r/b34c016f27.md) — Sin identificar · Catequesis 20 [Mistagógica 2], 4-6: PG 33, 1079-1082 · Jueves de la Octava de Pascua — Cuaresma y Pascua, año impar
- [La unción del Espíritu Santo](r/5586a31718.md) — Sin identificar · Catequesis 21 [Mistagógica 3], 1-3: PG 33, 1087-1091 · Viernes de la Octava de Pascua — Cuaresma y Pascua, año impar
- [El pan celestial y la bebida de salvación](r/dd269a4df0.md) — Sin identificar · Catequesis 22 [Mistagógica 4], 1. 3-6. 9: PG 33, 1098-1106 · Sábado de la Octava de Pascua — Cuaresma y Pascua, año impar
- [Fundemos en Cristo nuestra fe](r/5abe0bb926.md) — Sin identificar · Hom 21: PLS 3, 854-855 · Domingo de la semana IX del Tiempo Ordinario (semana 9), año impar
- [Dios no nos pide otra cosa que la conversión](r/322d41302c.md) — Sin identificar · PG 61, 745-751 · Domingo de la semana XI del Tiempo Ordinario (semana 11), año impar
- [Cristo es rey y sacerdote eterno](r/bb6ef23e3c.md) — Sin identificar · Tratado 39-40: CCL 69, 340-341 · Sábado de la semana XIII del Tiempo Ordinario (semana 13), año impar
- [Los apóstoles predicaban a Jesús crucificado](r/ddc0985751.md) — Sin identificar · 14, 7-8: ed. E. M. Buytaert, Spicilegium S. Lovaniense 26 [1953], 326-328 · Lunes de la semana VII del Tiempo Ordinario (semana 7), año par
- [La sabiduría de Dios nos mezcló su vino y puso su mesa](r/2e681c01ed.md) — Sin identificar · Cap 9: PG 87, 1,1299-1303 · Miércoles de la semana XIV del Tiempo Ordinario (semana 14), año par
- [Jesucristo es el mismo ayer y hoy y siempre](r/97d65785e5.md) — Sin identificar · PLS 4, 34-35 · Viernes de la semana XXIII del Tiempo Ordinario (semana 23), año impar
- [La perfecta conversión a Dios](r/dc871aa846.md) — Sin identificar · Hom. en la dedicación de una iglesia : Opera omnia, t. 1, 1888, 701-702 · Semana XXXI DEL TIEMPO ORDINARIO, año impar
- [](r/eacbbc81c5.md) — Sin identificar · 22 de septiembre Beato José Aparicio Sanz y Compañeros, mártires — Santoral, año impar
- [Martín, pobre y humilde](r/f59b7706a1.md) — Sin identificar · Carta 3, 6. 9-10. 11.14-17. 21: SC 133, 336-344 · 11 de noviembre San Martín de Tours, obispo — Santoral, año impar
- [Cristo, como buen pastor, intercede por nosotros, miserables](r/9c2948857b.md) — Sin identificar · Parte 2, 3-4: Ed. J. Leclercq, 1946, 125-126 · Martes de la semana XXXIII del Tiempo Ordinario (semana 33), año par

## San Sofronio de Jerusalén

- [La bendición del Padre ha brillado para los hombres por medio de María](r/d7928279c6.md) — San Sofronio de Jerusalén · Sermón 2, en la Anunciación de la Santísima Virgen, 21-22. 26: PG 87, 3, 3242. 3250 · Común de Santa maría virgen — Comunes, año par
- [Acojamos la luz clara y eterna](r/eea7e82284.md) — San Sofronio de Jerusalén · Sermón 3, Sobre el Hypapanté, 6. 7: PG 87, 3, 3291-3293 · 2 de febrero LA PRESENTACIÓN DEL SEÑOR — Santoral, año impar

## Teodoreto de Ciro

- [Yo curaré sus extravíos](r/5d275096d6.md) — Teodoreto de Ciro · Tratado 26-27: PG 75, 1466-1467 · Viernes de la semana XXIV del Tiempo Ordinario (semana 24), año impar
- [Sus cicatrices nos curaron](r/3d444b91bc.md) — Teodoreto de Ciro · Tratado 28: PG 75, 1467-1470 · Domingo de la semana XXVI del Tiempo Ordinario (semana 26), año impar

## San Teodoro de Studion

- [Preciosa y vivificante es la cruz de Cristo](r/cfe15187f0.md) — San Teodoro de Studion · PG 99, 691-694. 695 · Viernes de la semana II de Pascua (semana 2), año impar

## San Teófilo de Antioquía

- [Dichosos los limpios de corazón, porque ellos verán a Dios](r/f9227e0c2e.md) — San Teófilo de Antioquía · Lib. 1, 2. 7: PG 6, 1026-1027. 1035 · Miércoles de la semana III de Cuaresma (semana 3), año par

## Santa Teresa Benedicta de la Cruz

- [La puerta de la vida se abre a los que creen en el Crucificado](r/14dfaee560.md) — Santa Teresa Benedicta de la Cruz · Propio de los santos — Santoral, año impar

## Santa Teresa de Jesús

- [Acordémonos del amor de Cristo](r/c5303cd3e6.md) — Santa Teresa de Jesús · Cap. 22, 6-7. 12. 14 · 15 de octubre Santa Teresa de Jesús, virgen y doctora de la Iglesia — Santoral, año impar
- [Necesidad de la oración](r/d1b0a650be.md) — Santa Teresa de Jesús · Cap. 8,1-4 · Mes de octubre — Santoral, año impar
- [Pobreza, austeridad y dulzura de Pedro](r/6237f64728.md) — Santa Teresa de Jesús · Cap. 27,16-20 · 19 de octubre San Pedro de Alcántara, presbítero — Santoral, año impar

## Santa Teresa de Jesús

- [Venga a nosotros tu reino](r/986f957467.md) — Santa Teresa de Jesús · Cap 51: BAC 120, 221-224 · Martes de la semana XV del Tiempo Ordinario (semana 15), año impar
- [Hemos de imitar la pobreza de Jesús](r/7b8d5e9f9b.md) — Santa Teresa de Jesús · Carta 201: Cartas. Copias auténticas, t. 1. Archivo general de la Congregación, Valencia: Causa de beatificación y canonización de la sierva de Dios Teresa de Jesús Jornet e lbars). · 26 de agosto Santa Teresa de Jesús Jornet e Ibars, virgen, Patrona de la Ancianidad — Santoral, año impar

## Santa Teresa del Niño Jesús

- [En el corazón de la Iglesia, yo seré el amor](r/199a075336.md) — Santa Teresa del Niño Jesús · Manuscrits autobiographiques, Lisieux 1957, 227-229 · 1 de octubre Santa Teresa del Niño Jesús, virgen y doctora de la Iglesia — Santoral, año impar

## Tertuliano

- [El sacrificio espiritual](r/08aecd5e23.md) — Tertuliano · Caps. 28-29: CCL 1, 273-274 · Jueves de la semana III de Cuaresma (semana 3), año par
- [La predicación apostólica](r/3507799aac.md) — Tertuliano · Caps. 20,1-9; 21, 3; 22, 8-10: CCL 1, 201-204 · 3 de mayo. SAN FELIPE Y SANTIAGO, Apóstoles — Santoral, año par
- [Arrepiéntete y te salvaré](r/eb29316629.md) — Tertuliano · 2, 3-7; 4,1-3: CCL 1, 322-323; 326 · Domingo de la semana III del Tiempo Ordinario (semana 3), año impar

## Santo Tomás Becket

- [Nadie recibe el premio si no compite conforme al reglamento](r/8ea94cc172.md) — Santo Tomás Becket · Carta 74: PL 190, 533-536 · 29 de diciembre. Santo Tomás Becket, Obispo y Mártir — Santoral, año par

## Santo Tomás de Aquino

- [¡Oh banquete precioso y admirable!](r/6f01011f6d.md) — Santo Tomás de Aquino · Opúsculo 57, En la fiesta del Cuerpo de Cristo, lect. 1-4 · Domingo después de la Santísima Trinidad EL SANTÍSIMO CUERPO Y SANGRE DE CRISTO — Solemnidades del Señor, año impar
- [En la cruz hallamos el ejemplo de todas las virtudes](r/b545ad6f4f.md) — Santo Tomás de Aquino · Conferencia 6 sobre el Credo · 28 de enero Santo Tomás de Aquino, Presbítero y Doctor de la Iglesia — Santoral, año impar
- [El camino para llegar a la vida verdadera](r/b2065445a8.md) — Santo Tomás de Aquino · Cap 14, lec. 2 · Sábado de la semana XVII del Tiempo Ordinario (semana 17), año par
- [El resto de Israel pastará y se tenderá sin sobresaltos](r/ded54e0dc5.md) — Santo Tomás de Aquino · Cap. 10, lección 3 · Domingo de la semana XXVIII del Tiempo Ordinario (semana 28), año impar
- [Me saciaré de tu semblante](r/a30f280228.md) — Santo Tomás de Aquino · Opúsculos teológicos 2, Turín 1954, pp. 216-217 · Sábado de la semana XIX del Tiempo Ordinario (semana 19), año par

## Tomás de Kempis (Imitación de Cristo)

- [Sobre la humildad y la paz](r/cc03e08036.md) — Tomás de Kempis (Imitación de Cristo) · Lib. 2, cap. 2-3 · Martes de la semana III de Adviento (semana 3), año par
- [La fidelidad del Señor dura por siempre](r/110fa39002.md) — Tomás de Kempis (Imitación de Cristo) · Lib. 3, cap. 14 · Miércoles de la semana VII del Tiempo Ordinario (semana 7), año impar
- [Yo instruiré a mis profetas](r/3a6b6d9e42.md) — Tomás de Kempis (Imitación de Cristo) · Lib. 3, cap. 3 · Sábado de la semana XXIX del Tiempo Ordinario (semana 29), año impar

## Santo Tomás de Villanueva

- [María, elegida para ser nuestra abogada](r/98f163b2ae.md) — Santo Tomás de Villanueva · Sermón 3, de la Natividad de la B. V.M. Sermones de la Virgen, Madrid 1952, pp. 208-212). · Sábado anterior al segundo domingo de mayo. NUESTRA SEÑORA DE LOS DESAMPARADOS — Santoral, año par
- [Santidad e integridad de vida, virtudes indispensables del buen prelado](r/c5a518b588.md) — Santo Tomás de Villanueva · Jn, 10, 1-11: Divi Thomae a Villanueva, Opera omnia, Manila, 1822, pp. 324-325 · 10 de octubre Santo Tomás de Villanueva, obispo — Santoral, año impar

## Santo Tomás Moro

- [Me pongo totalmente en manos de Dios con absoluta esperanza y confianza](r/6b6d1b1273.md) — Santo Tomás Moro · The English Works of Sir Thomas More, Londres 1557, p.1454 · El mismo día 22 de junio San Juan Fisher, Obispo, y Santo Tomás Moro, Mártires — Santoral, año impar

## Santa Vicenta María López Vicuña

- [La caridad](r/a1d0a2e9f3.md) — Santa Vicenta María López Vicuña · Cartas I, Madrid 1976, c. 407 · El mismo día 25 de mayo. Santa Vicenta María López Vicuña, Virgen — Santoral, año par

## San Vicente de Lerins

- [El progreso del dogma cristiano](r/49144faee1.md) — San Vicente de Lerins · Capítulo 23: PL 50, 667-668 · Viernes de la semana V del Tiempo Ordinario (semana 5), año impar

## San Vicente de Paúl

- [El servicio a los pobres ha de ser preferido a todo](r/f4e8746467.md) — San Vicente de Paúl · Carta 2.546: Correspondance, entretiens, documents, París 1922-1925, 7 · 27 de septiembre San Vicente de Paúl, presbítero — Santoral, año impar

## San Vicente Ferrer

- [Del modo de predicar](r/441538d456.md) — San Vicente Ferrer · Cap. 13: edición Garganta-Forcada, pp. 513-514 · 5 de abril. San Vicente Ferrer, Presbítero — Santoral, año par

## San Zenón de Verona

- [Job era figura de Cristo](r/e1071ac4f3.md) — San Zenón de Verona · Tratado 15, 2: PL 11, 441-443 · Martes de la semana XVI del Tiempo Ordinario (semana 16), año par
