# Segundas Lecturas del Oficio

Buscador de las segundas lecturas del Oficio de Lectura (Leccionario Bienal), en español.

- Para personas: abre `index.html`.
- Para IAs: empieza por [`llms.txt`](llms.txt).

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso.
