# San Francisco de Sales

1567–1622 · St. Francis de Sales · 1 lecturas

- [La devoción se ha de ejercitar de diversas maneras](../r/2cd76a804d.md) — San Francisco de Sales · Parte 1, cap. 3 · 24 de enero San Francisco de Sales, Obispo y Doctor de la Iglesia — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
