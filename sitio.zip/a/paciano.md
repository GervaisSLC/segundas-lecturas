# San Paciano de Barcelona

d. c. 390 · St. Pacian of Barcelona · 2 lecturas

- [Reformemos nuestras costumbres en Cristo, por el Espíritu Santo](../r/2c20a66f69.md) — San Paciano de Barcelona · Sobre el bautismo, Sermón 5-6: PL 13, 1092-1093 · Sábado de la semana XXI del Tiempo Ordinario (semana 21), año impar
- [¿Qué Dios como tú, que perdonas el pecado?](../r/a461f30df9.md) — San Paciano de Barcelona · Sermón sobre el bautismo, 6-7: PL 13, 1093-1094 · Domingo de la semana XXII del Tiempo Ordinario (semana 22), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
