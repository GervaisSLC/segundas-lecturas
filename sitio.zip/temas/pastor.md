# Cristo, Buen Pastor

47 lecturas (tema asignado automáticamente).

[Todos los temas](index.md) · [Guía para IAs](../llms.txt)

- [¡Qué admirable intercambio!](../r/a7d27195ee.md) — San Gregorio Nacianceno · Disertación 45, 9.22.26.28: PG 36, 634-635.654.658-659.662 · Martes de la semana I de Adviento (semana 1), año par
- [Oración al buen pastor](../r/166af8ea5a.md) — San Gregorio de Nisa · Cap. 2: PG 44, 802 · 30 de Diciembre. Día VI - Octava de Navidad — Santoral, año par
- [Él es el pastor, él es pasto, él es la redención](../r/315d65ea42.md) — San Bernardo de Claraval · Sermón 31, 8-10: Opera omnia. Edit Cisterc. 1957, I, 224-226 · 5 de Enero — Santoral, año par
- [Éste es mi Hijo, el amado, mi predilecto](../r/df1cf7e154.md) — San Gregorio de Antioquía · Homilía 2, 5. 6. 9. 10 en el Bautismo de Cristo: PG 88, 1875-1879. 1882-1883 · Domingo después del 6 de Enero. EL BAUTISMO DEL SEÑOR — Adviento y Navidad, año par
- [Que la fuerza del amor supere el pesar por la muerte](../r/7c42633cea.md) — San Agustín de Hipona · Tratado 123, 5: CCL 36, 678-680 · 6 de diciembre. San Nicolás, Obispo — Santoral, año par
- [Criado fiel y solícito](../r/c754ee4157.md) — San Fulgencio de Ruspe · Sermón 1, 2-3: CCL 91 A, 889-890 · Común de pastores — Comunes, año par
- [Cristo regirá como pastor las naciones que se le han confiado](../r/e1cb98b2ce.md) — San Hilario de Poitiers · Sal 2, 31.34 35.37: CSEL 22, 60.63.64.65 · Martes de la semana II de Adviento (semana 2), año impar
- [Mirad: viene con su salario, y su recompensa lo precede](../r/e077b6d8f6.md) — San Cirilo de Alejandría · Lib 3, t. 4: PG 70, 806-807 · 18 de Diciembre — Santoral, año impar
- [La misericordia de Dios para con los penitentes](../r/b6f3fc8b09.md) — San Máximo el Confesor · Carta 11 : PG 91, 454-455 · Jueves de la semana IV de Cuaresma (semana 4), año par
- [Interrogando a Pedro, el Señor nos interroga a todos](../r/5ccc1963f5.md) — San Agustín de Hipona · Sermón Güelferbitano 16 (2-3: PLS 2, 580-581 · Domingo de la semana III de Pascua (semana 3), año par
- [Cristo, el buen Pastor](../r/aa65a3247f.md) — San Gregorio Magno · Homilía 14 sobre los evangelios, 3-6: PL 76, 1129-1130 · Domingo de la semana IV de Pascua (semana 4), año par
- [Del cielo vino el Pastor para reconducir las ovejas descarriadas a los pastos de la vida](../r/8d7fa4584f.md) — San Pedro Crisólogo · Sermón 6 (CCL 24, 44-47 · Domingo de la semana IV de Pascua (semana 4), año par
- [La cruz es voluntad del Padre, gloria del Hijo, gozo del Espíritu Santo](../r/13be837936.md) — San Juan Crisóstomo · Homilías sobre el nuevo Testamento : PG 51, 34-35 · Semana VII de Pascua — Cuaresma y Pascua, año par
- [Imitemos el estilo pastoral que empleó el mismo Señor](../r/28774edc68.md) — San Asterio de Amasea · Homilía 13, PG 40, 355-358. 362 · Viernes de la semana I de Cuaresma (semana 1), año impar
- [Cristo se ofreció a sí mismo por nosotros y se sometió espontáneamente a la muerte](../r/d43a1332eb.md) — San Cirilo de Alejandría · Lib. 3: PG 68, 290-291 · Miércoles de la semana III de Cuaresma (semana 3), año impar
- [Cristo vive en su Iglesia](../r/fd859a409a.md) — San León Magno · Sermón 12, 3. 6. 7 sobre la Pasión del Señor: CCL 138A, 383-384. 386-388 · Miércoles de la semana II de Pascua (semana 2), año impar
- [Preciosa y vivificante es la cruz de Cristo](../r/cfe15187f0.md) — San Teodoro de Studion · PG 99, 691-694. 695 · Viernes de la semana II de Pascua (semana 2), año impar
- [No amemos de palabra y de boca, sino de verdad y con obras](../r/c54ed23a22.md) — San Agustín de Hipona · Tratado 5, 11-13: SC 75, 266-271 · Sábado de la semana VI de Pascua (semana 6) antes de la Ascensión, año impar
- [La semilla de todos es Cristo](../r/953f5c18ae.md) — San Ambrosio de Milán · Comentario 36-39, sobre el salmo 43: CSEL 64, 288-290 · Sábado de la semana V del Tiempo Ordinario (semana 5), año impar
- [Sed siervos de los siervos](../r/e53469763a.md) — Balduino de Canterbury · Tratado para los sacerdotes, 12: PL 204, 533-536 · Viernes de la semana VI del Tiempo Ordinario (semana 6), año impar
- [Que nuestras obras proclamen la generosidad de Dios](../r/12594d815b.md) — San Cipriano de Cartago · Trat. 12-13.15: CSEL 3, 427-430 · Domingo de la semana VII del Tiempo Ordinario (semana 7), año impar
- [El Señor es nuestro Dios, y nosotros su pueblo, el rebaño que él guía](../r/88a1259124.md) — San Agustín de Hipona · Sermón sobre las ovejas, 47, 1. 2. 3. 6: CCL 41, 572-573. 575-576 · Domingo de la semana XV del Tiempo Ordinario (semana 15), año impar
- [Si buscare agradar a los hombres no sería siervo de Cristo](../r/3b1bd7b318.md) — San Agustín de Hipona · Sermón sobre las ovejas, 47, 12-14: CCL 41, 582-584 · Lunes de la semana XV del Tiempo Ordinario (semana 15), año impar
- [Mi sacrificio es un espíritu quebrantado](../r/62960979d6.md) — San Agustín de Hipona · Sermón 19, 2-3: CCL 41, 252-254 · Sábado de la semana XV del Tiempo Ordinario (semana 15), año impar
- [Yo soy el que cura a las ovejas enfermas](../r/ee25c94dcc.md) — San Basilio Magno · Homilía 26 (2: PG 85, 306-307 · Domingo de la semana XVI del Tiempo Ordinario (semana 16), año impar
- [Sufre por mis ovejas](../r/9826817596.md) — San Agustín de Hipona · Sermón Güelferbitano 32, Sobre la ordenación episcopal: PLS 2, 639-640 · 3 de febrero San Blas, Obispo y Mártir — Santoral, año impar
- [Han cambiado los signos, no la fe](../r/e67c28db12.md) — San Agustín de Hipona · 19 3: CCL 41, 253-254 · Sábado de la semana I del Tiempo Ordinario (semana 1), año par
- [Ved qué dechado se nos propone](../r/6f6658c7d6.md) — San Clemente I, papa · 14-17: Funk 1, 79-85 · Sábado de la semana II del Tiempo Ordinario (semana 2), año par
- [Cristo nos buscó en la tierra: busquémosle nosotros en el cielo](../r/b5869e43f5.md) — San Pedro Crisólogo · Sermón 168 :PL 52, 639-641 · Domingo de la semana XXIV del Tiempo Ordinario (semana 24), año impar
- [Me casaré contigo en misericordia y en fidelidad](../r/da8d3f0224.md) — San Bernardo de Claraval · Sermón 27, 4. 6-7: Opera omnia, Edit. Cister. t. 1, 1957, 185-187 · Miércoles de la semana XXVII del Tiempo Ordinario (semana 27), año impar
- [El resto de Israel pastará y se tenderá sin sobresaltos](../r/ded54e0dc5.md) — Santo Tomás de Aquino · Cap. 10, lección 3 · Domingo de la semana XXVIII del Tiempo Ordinario (semana 28), año impar
- [Me pondré de centinela para escuchar lo que me dice](../r/897154fd9d.md) — San Bernardo de Claraval · Sermón 5, 1-4: Opera omnia, Edit Cist. 6, 1, 1970, 98-103 · Miércoles de la semana XXIX del Tiempo Ordinario (semana 29), año impar
- [Somos cristianos y somos obispos](../r/d835377faf.md) — San Agustín de Hipona · Sermón 46, 1-2: CCL 41, 529-530 · Semana XXXII DEL TIEMPO ORDINARIO, año impar
- [Los pastores que se apacientan a sí mismos](../r/a4a03a7f7b.md) — San Agustín de Hipona · Sermón 46, 3-4: CCL 41, 530-531 · Lunes de la semana XXXII del Tiempo Ordinario (semana 32), año impar
- [El ejemplo de Pablo](../r/fbce0e7abc.md) — San Agustín de Hipona · Sermón 46, 4-5 CCL 41, 531-533 · Martes de la semana XXXII del Tiempo Ordinario (semana 32), año impar
- [Que nadie busque su interés, sino el de Jesucristo](../r/23484ff7cf.md) — San Agustín de Hipona · Sermón 46, 6-7: CCL 41, 533-534 · Miércoles de la semana XXXII del Tiempo Ordinario (semana 32), año impar
- [Sé un modelo para los fieles](../r/7f94983d82.md) — San Agustín de Hipona · Sermón 46, 9: CCL 41, 535-536 · Jueves de la semana XXXII del Tiempo Ordinario (semana 32), año impar
- [Los cristianos débiles](../r/0c8ce890d8.md) — San Agustín de Hipona · Sermón 46, 13: CCL 41, 539-540 · Semana XXXIII DEL TIEMPO ORDINARIO, año impar
- [Insiste a tiempo y a destiempo](../r/1e37fbea34.md) — San Agustín de Hipona · Sermón 46, 14-15: CCL 41, 541-542 · Lunes de la semana XXXIII del Tiempo Ordinario (semana 33), año impar
- [La Iglesia, como una vid que crece y se difunde por doquier](../r/a7c852c4d9.md) — San Agustín de Hipona · Sermón 46, 18-19: CCL 41, 544-546 · Martes de la semana XXXIII del Tiempo Ordinario (semana 33), año impar
- [Haced lo que os digan, pero no hagáis lo que ellos hacen](../r/0a34227076.md) — San Agustín de Hipona · Sermón 46, 20-21: CCL 41, 546-548 · Miércoles de la semana XXXIII del Tiempo Ordinario (semana 33), año impar
- [Apacentaré a mis ovejas en ricos pastizales](../r/90859682aa.md) — San Agustín de Hipona · Sermón 46, 24-25. 27: CCL 41, 551-553 · Jueves de la semana XXXIII del Tiempo Ordinario (semana 33), año impar
- [Todos los buenos pastores se identifican con el único pastor](../r/0de8e1b2ca.md) — San Agustín de Hipona · Sermón 46, 29-30: CCL 41, 555-557 · Viernes de la semana XXXIII del Tiempo Ordinario (semana 33), año impar
- [La cruz, símbolo del reino](../r/5b5014cee9.md) — San Juan Crisóstomo · Homilía sobre la cruz y el ladrón 1, 3-4: PG 49, 403-404 · Domingo de la semana XXXIV del Tiempo Ordinario (semana 34) JESUCRISTO, REY DEL UNIVERSO, año impar
- [Soy obispo para vosotros, soy cristiano con vosotros](../r/8598d9c073.md) — San Agustín de Hipona · Sermón 340,1: PL 38,1483-1484 · 19 de septiembre San Jenaro, obispo y mártir — Santoral, año impar
- [Santidad e integridad de vida, virtudes indispensables del buen prelado](../r/c5a518b588.md) — Santo Tomás de Villanueva · Jn, 10, 1-11: Divi Thomae a Villanueva, Opera omnia, Manila, 1822, pp. 324-325 · 10 de octubre Santo Tomás de Villanueva, obispo — Santoral, año impar
- [Oración del buen pastor](../r/6083068f4d.md) — San Gregorio de Nisa · Cap 2: PG 44, 802 · Jueves de la semana XIX del Tiempo Ordinario (semana 19), año par
