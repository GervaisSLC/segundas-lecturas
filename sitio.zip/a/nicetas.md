# San Nicetas de Remesiana

c. 335–414 · St. Niceta of Remesiana · 2 lecturas

- [La Iglesia, comunión de los santos](../r/3c7d58442c.md) — San Nicetas de Remesiana · Núm. 8. 10. 11. 14: PL 52, 870-874 · Domingo de la semana XI del Tiempo Ordinario (semana 11), año impar
- [En la salmodia, todos deben salmodiar](../r/27587121a3.md) — San Nicetas de Remesiana · 413-14: PLS 3, 196-198 · Martes de la semana XXI del Tiempo Ordinario (semana 21), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
