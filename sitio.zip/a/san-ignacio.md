# San Ignacio

None · None · 1 lecturas

- [Examinad si los espíritus provienen de Dios](../r/3270b9a50b.md) — San Ignacio · Cap. 1, 5-9: Acta Sanctorum Iulii 7 [1868], 647 · 31 de julio San Ignacio de Loyola, Presbítero — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
