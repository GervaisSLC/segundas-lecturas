# San Juan de la Cruz

1542–1591 · St. John of the Cross · 3 lecturas

- [Dios nos habló por medio de su Hijo](../r/252dff280e.md) — San Juan de la Cruz · Libro 2, cap 22, núms. 3-4 · Lunes de la semana II de Adviento (semana 2), año par
- [Conocimiento del misterio escondido en Cristo Jesús](../r/9eaf4dc293.md) — San Juan de la Cruz · Canciones 37, 4 y 36, 13, declaración · 14 de diciembre. San Juan de la Cruz Presbítero y Doctor de la Iglesia — Santoral, año par
- [Me casaré contigo en matrimonio perpetuo](../r/d2a792832d.md) — San Juan de la Cruz · Canción 39, 4-7 · Jueves de la semana XXIII del Tiempo Ordinario (semana 23), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
