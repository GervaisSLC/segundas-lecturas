# San Juan de Brébeuf

None · None · 1 lecturas

- [No moriré sino por ti, Jesús, que te dignaste morir por mi](../r/44d1167ac8.md) — San Juan de Brébeuf · The Jesuit Relations and Allied Documents, The Burrow Brothers Co, Cleveland 1898, 164.166 · Mes de octubre — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
