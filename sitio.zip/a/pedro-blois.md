# Pedro de Blois

c. 1135–1211 · Peter of Blois · 4 lecturas

- [Mira, llego en seguida y traigo conmigo mi salario, para pagar a cada uno su propio trabajo](../r/8f821e61bc.md) — Pedro de Blois · Sermón 3 sobre la venida del Señor: PL 207, 569-572 · Miércoles de la semana I de Adviento (semana 1), año impar
- [Cristo es la sabiduría](../r/1125d61f8f.md) — Pedro de Blois · Sermón 53: PL 207, 715-716 · Lunes de la semana XVII del Tiempo Ordinario (semana 17), año impar
- [He venido a prender fuego en el mundo](../r/d72fd096ca.md) — Pedro de Blois · Sermón 25 : PL 207, 635-637 · SEMANA XX del tiempo ordinario, año impar
- [Cristo por nosotros se hizo pan](../r/716852074c.md) — Pedro de Blois · Sermón 54, sobre el sacrificio del altar : PL 207, 720-721 · Miércoles de la semana XXVIII del Tiempo Ordinario (semana 28), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
