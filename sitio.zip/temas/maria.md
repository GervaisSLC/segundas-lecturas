# Virgen María

51 lecturas (tema asignado automáticamente).

[Todos los temas](index.md) · [Guía para IAs](../llms.txt)

- [María y la Iglesia](../r/2e003688b6.md) — Isaac de Stella · Sermón 51: PL 194, 1862-1863.1865 · Sábado de la semana II de Adviento (semana 2), año par
- [¡Oh grande e insondable misterio!](../r/39b44efbb1.md) — San Beda el Venerable · Homilía 5 en la vigilia de Navidad: CCL 122, 32-36 · Viernes de la semana III de Adviento (semana 3), año par
- [Concebirás y darás a luz un hijo](../r/3925679f6d.md) — San Beda el Venerable · Homilía 3 en el Adviento: CCL 122, 14-17 · Viernes de la semana III de Adviento (semana 3), año par
- [El misterio de nuestra reconciliación](../r/04acdc5a17.md) — San León Magno · Carta 31, 2-3: PL 54, 791-793 · 17 de Diciembre — Santoral, año par
- [Todo el mundo espera la respuesta de María](../r/9e664bdca7.md) — San Bernardo de Claraval · Homilía 4, 8-9: Opera Omnia, Edit. Cister. 4, 1966, 53-54 · 20 de Diciembre — Santoral, año par
- [La visitación de santa María Virgen](../r/d737449272.md) — San Ambrosio de Milán · Lib. 2, 19.22-23.26-27: CCL 14, 39-42 · 21 de Diciembre — Santoral, año par
- [Cántico de María](../r/5cfdcbf569.md) — San Beda el Venerable · Lib. 1, 46-55: CCL 120, 37-39 · 22 de Diciembre — Santoral, año par
- [Junto al Niño Jesús están María y José](../r/6ac6ae87ce.md) — San Juan Crisóstomo · Homilía sobre el día de Navidad: PG 56, 392 · Navidad y su Octava — Adviento y Navidad, año par
- [Angustiados buscamos a Jesús](../r/fcd955ab28.md) — Orígenes · Homilía 18, 2-5: Edit GCS 9, 112-113 · Navidad y su Octava — Adviento y Navidad, año par
- [Juan es aquel a quien Cristo amó con amor de predilección](../r/5fa731094e.md) — San Gregorio Palamás · Homilía 20: PG 151, 266.271 · 27 de Diciembre. San Juan Apóstol y Evangelista — Santoral, año par
- [La Palabra tomó de María nuestra condición](../r/8f640cd3d0.md) — San Atanasio de Alejandría · Carta a Epicteto, 5-9: PG 26,1058.1062-1066 · 1 de Enero. SANTA MARÍA, MADRE DE DIOS — Santoral, año par
- [La santísima Virgen ha de ser llamada Madre de Dios](../r/8fcc68c757.md) — San Cirilo de Alejandría · Homilía 15, 1-3 sobre la encarnación del Verbo: PG 77, 1090-1091 · 1 de Enero. SANTA MARÍA, MADRE DE DIOS — Santoral, año par
- [¡Ay de mí si no anuncio el Evangelio!](../r/33106bab51.md) — San Francisco Javier · Cartas 4 [1542]... y 5 [1544]: BAC 101, Cartas y escritos de san Francisco Javier, pp. 107-108. 115-116 · 3 de diciembre. San Francisco Javier, Presbítero — Santoral, año par
- [¡Oh Virgen, por tu bendición queda bendita toda criatura!](../r/5db8eda892.md) — San Anselmo de Canterbury · Sermón 52: PL 158, 955-956 · 8 de diciembre. LA INMACULADA CONCEPCIÓN DE SANTA MARÍA VIRGEN — Santoral, año par
- [La Virgen María consoló a Juan Diego](../r/f955545fd0.md) — San Juan Pablo II · México, 31 de julio de 2002). · 9 de diciembre. San Juan Diego de Cuauhtlatoazin — Santoral, año par
- [La voz de la tórtola se ha escuchado en nuestra tierra](../r/381f17998a.md) — Actas y escritos anónimos · «Nicán Mupohua», 12ª edición, Buena Prensa, México, D. F., 1971, pp. 3-19. 21 · MES DE DiCIEMBRE — Santoral, año par
- [La bendición del Padre ha brillado para los hombres por medio de María](../r/d7928279c6.md) — San Sofronio de Jerusalén · Sermón 2, en la Anunciación de la Santísima Virgen, 21-22. 26: PG 87, 3, 3242. 3250 · Común de Santa maría virgen — Comunes, año par
- [María, Madre nuestra](../r/7e3b7cf0fd.md) — San Elredo de Rievaulx · Sermón 20, en la Natividad de santa María: PL 195, 322-324 · Común de Santa maría virgen — Comunes, año par
- [La maternidad de María en la economía de la gracia](../r/190be06986.md) — Concilio Vaticano II · Núms. 61-62 · Común de Santa maría virgen — Comunes, año par
- [María, antes de concebir corporalmente, concibió en su espíritu](../r/19a318fd82.md) — San León Magno · Sermón 1 en la Natividad del Señor, 2. 3: PL 54,191-192 · Común de Santa maría virgen — Comunes, año par
- [Alabanzas de la Madre de Dios](../r/09a87d2250.md) — San Cirilo de Alejandría · Homilía 4: PG 77, 991. 995-996 · Común de Santa maría virgen — Comunes, año par
- [El amigo de los hombres se ha hecho hombre, naciendo de la Virgen](../r/c519c14650.md) — San Proclo de Constantinopla · Sobre la Natividad del Señor, 1-2: PG 65, 843-846 · Común de Santa maría virgen — Comunes, año par
- [María, Madre de Cristo y Madre de los cristianos](../r/8c0548eac7.md) — Beato Guerrico de Igny · Sermón 1 en la Asunción de santa María: PL 185,187-189 · Común de Santa maría virgen — Comunes, año par
- [Adán y Cristo, Eva y María](../r/60cfbfae09.md) — San Juan Crisóstomo · Sobre el cementerio y la cruz, 2: PG 49, 396 · Común de Santa maría virgen — Comunes, año par
- [María, tipo de la Iglesia](../r/2bac0e17f0.md) — Concilio Vaticano II · Núms. 63-65 · Común de Santa maría virgen — Comunes, año par
- [Eva y María](../r/f168e743bd.md) — San Ireneo de Lyon · Lib. 5,19, 1; 20, 2; 21, 1: SC 153, 248-250. 260-264 · Viernes de la semana II de Adviento (semana 2), año impar
- [El profeta inspirado vaticinó al Dios-con-nosotros](../r/cef9fba750.md) — San Cirilo de Alejandría · Lib. 4, or. 4: PG 70, 1035-1038 · 20 de Diciembre — Santoral, año impar
- [El que nació una vez de María, nace a diario en nosotros](../r/3408481e13.md) — San Jerónimo · Salmo 84: CCL 78, 107-108 · 23 de Diciembre — Santoral, año impar
- [Por la penitencia, nos purificamos de la impureza de nuestra lepra](../r/e7a3484ec0.md) — Orígenes · Homilía 7, 1-2, Ed. GCS t. 8, 37 40: SC 29, 133-136 · Semana V de Cuaresma — Cuaresma y Pascua, año par
- [Seréis mis testigos](../r/896dfc62cf.md) — Actas y escritos anónimos · Cap. 14,109-110: Acta Sanctorum Februarii,1, 769 · 6 de febrero. San Pablo Miki y Compañeros, Mártires — Santoral, año par
- [Todo tuyo](../r/ae951caf61.md) — San Luis María Grignion de Montfort · nn. 120-121.125-126: oeuvres completes, Seuil, Paris 1966, 562-563.566-567). (cf. Obras completas, BAC, n. 451). · El mismo día 28 de abril. San Luis María Griñón de Montfort, Presbítero — Santoral, año par
- [María sola abraza al que todo el universo no abarca](../r/18a6be2e7f.md) — San Efrén · Sermón 3 de diversis: Opera omnia, III syr. et lat., Roma 1743, 607 · 13 de mayo. LA BIENAVENTURADA VIRGEN MARÍA DE FÁTIMA — Santoral, año par
- [Mira a María, estrella del mar](../r/323913d51e.md) — San Bernardo de Claraval · Hom. 11 super Missus est, 17: PL 183, 7013-71A · 24 de mayo. SANTA MARÍA, Auxilio de los Cristianos — Santoral, año par
- [María proclama la grandeza del Señor por las obras que ha hecho en ella](../r/28e9c7e8f9.md) — San Beda el Venerable · Libro 1, 4: CCL 122, 25-26. 30 · 31 de mayo. LA VISITACIÓN DE LA VIRGEN MARÍA — Santoral, año par
- [María, elegida para ser nuestra abogada](../r/98f163b2ae.md) — Santo Tomás de Villanueva · Sermón 3, de la Natividad de la B. V.M. Sermones de la Virgen, Madrid 1952, pp. 208-212). · Sábado anterior al segundo domingo de mayo. NUESTRA SEÑORA DE LOS DESAMPARADOS — Santoral, año par
- [Sobre la vida activa y la vida contemplativa](../r/58095cee69.md) — San Gregorio Magno · Lib 2, Hom 2, 8-9: CCL 142, 230-231 · Domingo de la semana XVI del Tiempo Ordinario (semana 16), año impar
- [María conservaba todas estas cosas en su corazón](../r/37ad439682.md) — San Lorenzo Justiniano · Sermón X, en la fiesta de la Purificación de la Santísima Virgen María: Opera 2, Venecia 1751, 38-39 · Mes de mayo — Santoral, año impar
- [Defensor de la maternidad divina de la virgen María](../r/3b24f12532.md) — San Cirilo de Alejandría · Carta 1: PG 77,14-18. 27-30 · 27 de junio San Cirilo de Alejandría, Obispo y Doctor de la Iglesia — Santoral, año impar
- [Ardía en deseos de Cristo, a quien pensaba que se lo habían llevado](../r/ae5efbefb4.md) — San Gregorio Magno · Homilía 25,1-2. 4-5: PL 76,1189-1193 · 22 de julio Santa María Magdalena — Santoral, año impar
- [Por sus frutos los conoceréis](../r/acd120a7f7.md) — San Juan Damasceno · Sermón 6, Sobre la Natividad de la Virgen María, 2. 4. 5. 6: PG 96, 663. 667. 670 · 26 de julio Santos Joaquín y Ana, Padres de la Virgen María — Santoral, año impar
- [Dichosos los que pudieron hospedar al Señor en su casa](../r/92817b23ce.md) — San Agustín de Hipona · Sermón 103,1-2. 6: PL 38, 613. 615 · 29 de julio Santa Marta — Santoral, año impar
- [Cristo habite por la fe en nuestros corazones](../r/29658abbf5.md) — San Cayetano · Carta a Elisabet Porto: Studi e Testi 177, Ciudad del Vaticano 1954, pp. 50-51 · El mismo día 7 de agosto San Cayetano, presbítero — Santoral, año impar
- [Tu cuerpo es santo y sobremanera glorioso](../r/76c41f39be.md) — Papa Pío XII · AAS 42 [1950), 760-762. 767-769 · 15 de agosto LA ASUNCIÓN DE LA VIRGEN MARÍA — Santoral, año impar
- [Reina del mundo y de la paz](../r/295d6dd29c.md) — San Amadeo de Lausana · Homilía 7: SC 72, 188. 190.192. 200 · 22 de agosto Santa María Virgen, Reina — Santoral, año impar
- [Lo antiguo ha pasado, lo nuevo ha comenzado](../r/33dfb5308a.md) — San Andrés de Creta · Sermón 1: PG 97, 806-810 · 8 de septiembre La Natividad de la Santísima Virgen María — Santoral, año impar
- [Piensa en María e invócala en todos los momentos](../r/a29a40b93f.md) — San Bernardo de Claraval · Homilía 2, 17, 1-33: SCh 390, 1993, 168-170 · 11 de septiembre Nuestra Señora de Coromoto — Santoral, año impar
- [La madre estaba junto a la cruz](../r/d69f701fca.md) — San Bernardo de Claraval · Sermón en el Domingo infraoctava de la Asunción, 14-15: Opera Omnia, edición cisterciense, 5 (1968), (273-274 · 15 de septiembre Nuestra Señora de los Dolores — Santoral, año impar
- [El nombre de "ángel" designa la función, no el ser](../r/f1cecca40a.md) — San Gregorio Magno · Homilía 34, 8-9: PL 76,1250-1251 · 29 de septiembre SANTOS ARCÁNGELES MIGUEL, GABRIEL Y RAFAEL — Santoral, año impar
- [Estuve enfermo, y me visitasteis](../r/3ee6be000e.md) — San Pablo VI · 25 de enero de 1970: AAS 62, 1970, 82-88 · El mismo día 10 de octubre San Luis Beltrán, presbítero — Santoral, año impar
- [Eficacia pastoral del culto tributado a la Virgen](../r/bfb9dd4e7e.md) — San Pablo VI · AAS 66 [1974),113-168 · 12 de octubre NUESTRA SEÑORA DEL PILAR — Santoral, año impar
- [Dio fe al mensaje divino y concibió por su fe](../r/8710ce6aa9.md) — San Agustín de Hipona · Sermón 25, 7-8: PL 46, 937-938 · 21 de noviembre La Presentación de la Santísima Virgen — Santoral, año impar
