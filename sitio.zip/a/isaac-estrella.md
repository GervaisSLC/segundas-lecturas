# Isaac de Stella

c. 1100–1170 · Isaac of Stella · 3 lecturas

- [María y la Iglesia](../r/2e003688b6.md) — Isaac de Stella · Sermón 51: PL 194, 1862-1863.1865 · Sábado de la semana II de Adviento (semana 2), año par
- [Primogénito de muchos hermanos](../r/aecae9447b.md) — Isaac de Stella · Sermón 42: PL 194, 1831-1832 · Domingo de la semana V de Pascua (semana 5) - Año A: Jn 14, 1-12, año par
- [La preeminencia de la caridad](../r/07b20b4aa7.md) — Isaac de Stella · Sermón 31: PL 194, 1292-1293 · Jueves de la semana IX del Tiempo Ordinario (semana 9), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
