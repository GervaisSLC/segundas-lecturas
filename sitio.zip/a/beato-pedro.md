# Beato Pedro

None · None · 1 lecturas

- [La misericordia y la fidelidad se encuentran en el camino, que es Cristo](../r/1e792e302c.md) — Beato Pedro · 165-167: CCL CM 10, 97. 99. 100 · Semana XXXI DEL TIEMPO ORDINARIO, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
