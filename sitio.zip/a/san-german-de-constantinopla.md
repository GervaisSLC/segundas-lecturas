# San Germán de Constantinopla

None · None · 2 lecturas

- [Sobre la naturaleza de la Iglesia y sobre los sacramentos](../r/0f4d4a3164.md) — San Germán de Constantinopla · PG 98, 383-387 · Martes de la semana XXVI del Tiempo Ordinario (semana 26), año impar
- [Todos nosotros te glorificamos a ti, Dios nuestro, en medio de una profunda tranquilidad](../r/301204af5c.md) — San Germán de Constantinopla · PG 98, 442-443 · Martes de la semana XXV del Tiempo Ordinario (semana 25), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
