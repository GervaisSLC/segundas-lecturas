# San Fulberto de Chartres

None · None · 1 lecturas

- [El misterio de nuestra salvación](../r/7cc7b1e9e5.md) — San Fulberto de Chartres · Carta 5: PL 141, 198-199 · 8 de Enero o Martes después del Domingo de Epifanía — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
