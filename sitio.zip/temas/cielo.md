# Ascensión y patria celestial

15 lecturas (tema asignado automáticamente).

[Todos los temas](index.md) · [Guía para IAs](../llms.txt)

- [Concebirás y darás a luz un hijo](../r/3925679f6d.md) — San Beda el Venerable · Homilía 3 en el Adviento: CCL 122, 14-17 · Viernes de la semana III de Adviento (semana 3), año par
- [Mira, yo envío mi mensajero delante de ti](../r/ad27e05cbb.md) — San Odilón de Cluny · Sermón 10, sobre San Juan Bautista: PL 142, 1019-1020 · Jueves de la semana I de Adviento (semana 1), año impar
- [Angosto y estrecho es el callejón que lleva a la vida](../r/7690c32b46.md) — Orígenes · Homilía 5 sobre el libro del Exodo, 3-4: Ed. Maurist. t. 2, 145-146 · Semana II de Cuaresma — Cuaresma y Pascua, año par
- [La ascensión de Cristo es nuestra propia exaltación](../r/2803c22368.md) — San León Magno · Sermón sobre la Ascensión, 73, 3-5: CCL A 452-454 · Miércoles de la semana VI de Pascua (semana 6), año par
- [La Ascensión del Señor alimenta nuestra fe](../r/3d60196d53.md) — San León Magno · Sermón 2 sobre la Ascensión, 1-4: PL 54, 397-399 · Ascensión - Año A: Mt 28, 16-20 — Cuaresma y Pascua, año par
- [Con él estaré en la tribulación](../r/68f5f8db1b.md) — San Bernardo de Claraval · Sermón 17 sobre el salmo 90: Tú que habitas, 4, 6: Opera omnia, edición cisterciense, 4 [1966), 489-491 · El mismo día 12 de mayo. San Pancracio, Mártir — Santoral, año par
- [Esperamos la eterna felicidad de la ciudad celeste](../r/d3547436b4.md) — San Agustín de Hipona · Carta 137, 16: PL 33, 523-524 · Sábado de la semana III de Pascua (semana 3), año impar
- [Los cristianos en el mundo](../r/56f27a83e1.md) — Carta a Diogneto · Capítulos 5-6: Funck 1, 397-401 · Martes de la semana V de Pascua (semana 5), año impar
- [El amor cubre la multitud de los pecados](../r/cb4d49e820.md) — San Agustín de Hipona · Tratado 1, 5-6: SC 75, 124-126 · Domingo de la semana VI de Pascua (semana 6), año impar
- [Han variado los tiempos, no la fe](../r/cf0ba170ae.md) — San Agustín de Hipona · Tratado 45, 9: CCL 36, 392-393 · Sábado de la semana VI del Tiempo Ordinario (semana 6), año impar
- [Sobre el servicio de la predicación](../r/6167b0216d.md) — San Gregorio Magno · Homilía 17, 5.6.7.8: PL 76, 1140-1142 · Domingo de la semana XV del Tiempo Ordinario (semana 15), año impar
- [Dichosos los que pudieron hospedar al Señor en su casa](../r/92817b23ce.md) — San Agustín de Hipona · Sermón 103,1-2. 6: PL 38, 613. 615 · 29 de julio Santa Marta — Santoral, año impar
- [La Jerusalén celestial está fundada como ciudad](../r/13f817887a.md) — San Gregorio Magno · Lib 2, Hom 1, 5: CCL 142, 210-212 · Lunes de la semana XI del Tiempo Ordinario (semana 11), año par
- [Considerad, hermanos, vuestra vocación](../r/41bb11475e.md) — San Elredo de Rievaulx · Edit C.H. Talbot, SSOC vol 1, 102-103 · Viernes de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [No es duro lo que manda aquel que ayuda a realizar lo que ordena](../r/cc26755d11.md) — San Cesáreo de Arlés · Sermón 159,1.4-6: CCL 104, 652-654 · Domingo de la semana XXIV del Tiempo Ordinario (semana 24), año impar
