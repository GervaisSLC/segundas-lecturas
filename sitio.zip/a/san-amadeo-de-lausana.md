# San Amadeo de Lausana

None · None · 1 lecturas

- [Reina del mundo y de la paz](../r/295d6dd29c.md) — San Amadeo de Lausana · Homilía 7: SC 72, 188. 190.192. 200 · 22 de agosto Santa María Virgen, Reina — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
