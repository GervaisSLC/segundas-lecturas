# Sirvamos a Cristo en los pobres

**San Gregorio Nacianceno** (329–390) · Segunda lectura del Oficio de Lectura

- id: `5ff73fcee1`
- Fuente: De los sermones de san Gregorio de Nacianzo
- Cita patrística: Sermón 14, sobre el amor a los pobres, 38. 40: PG 35, 907-910
- Se lee: Sábado de la semana III de Cuaresma (semana 3), año par
- Escritura: [Ex 40, 16-38](../escritura/ex.md) (primera lectura del día); [Mt 25, 35. 40](../escritura/mt.md) (responsorio); [Jn 15, 12](../escritura/jn.md) (responsorio)
- Temas (automáticos): [Misericordia y pobres](../temas/misericordia.md), [Muerte y difuntos](../temas/muerte.md), [Palabra de Dios y Escritura](../temas/escritura.md), [Caridad y amor fraterno](../temas/caridad.md)
- Cómo citar: San Gregorio Nacianceno, Sermón 14, sobre el amor a los pobres, 38. 40: PG 35, 907-910, «Sirvamos a Cristo en los pobres». Liturgia de las Horas, Oficio de Lectura, segunda lectura, Sábado de la semana III de Cuaresma (semana 3), año par. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-5ff73fcee1](../index.html#r-5ff73fcee1)
- Traducción inglesa antigua (dominio público, no litúrgica): https://www.newadvent.org/fathers/3102.htm
- Autor: [San Gregorio Nacianceno](../a/gregorio-nacianzo.md)

## Texto

Dichosos los misericordiosos —dice la Escritura—, porque ellos alcanzarán misericordia. No es, por cierto, la misericordia una de las últimas bienaventuranzas. Dice el salmo: Dichoso el que cuida del pobre y desvalido. Y de nuevo: Dichoso el que se apiada y presta. Y en otro lugar: El justo a diario se compadece y da prestado. Tratemos de alcanzar la bendición, de merecer que nos llamen dichosos: seamos benignos.

Que ni siquiera la noche interrumpa tus quehaceres de misericordia. No digas: Vuelve, que mañana te ayudaré. Que nada se interponga entre tu propósito y su realización. Porque las obras de caridad son las únicas que no admiten demora.

Parte tu pan con el hambriento, hospeda a los pobres sin techo, y no dejes de hacerlo con jovialidad y presteza. Quien reparte la limosna –dice el Apóstol– que lo haga con agrado; pues todo lo que sea prontitud hace que se te doble la gracia del beneficio que has hecho. Porque lo que se lleva a cabo con una disposición de ánimo triste y forzada no merece gratitud ni tiene nobleza. De manera que, cuando hacemos el bien, hemos de hacerlo, no tristes, sino con alegría.

Si dejas libres a los oprimidos y rompes todos los cepos, dice la Escritura; o sea, si procuras alejar de tu prójimo sus sufrimientos, sus pruebas, la incertidumbre de su futuro, toda murmuración contra él, ¿qué piensas que va a ocurrir? Algo grande y admirable. Un espléndido premio. Escucha: Entonces romperá tu luz como la aurora, te abrirá camino la justicia. ¿Y quién no anhela la luz y la justicia?

Por lo cual, si pensáis escucharme, siervos de Cristo, hermanos y coherederos, visitemos a Cristo mientras nos sea posible, curémoslo, no dejemos de alimentarlo o de vestirlo; acojamos y honremos a Cristo, no en la mesa solamente, como algunos, no con ungüentos, como María, ni con el sepulcro, como José de Arimatea, ni con lo necesario para la sepultura, como aquel mediocre amigo, Nicodemo, ni, en fin, con oro, incienso y mirra, como los Magos, antes que todos los mencionados; sino que, puesto que el Señor de todas las cosas lo que quiere es misericordia y no sacrificio, y la compasión supera en valor a todos los rebaños imaginables, presentémosle ésta mediante la solicitud para con los pobres y humillados, de modo que, cuando nos vayamos de aquí, nos reciban en los eternos tabernáculos, por el mismo Cristo, nuestro Señor, a quien sea dada la gloria por los siglos. Amén.

## Responsorio (Mt 25, 35. 40; Jn 15, 12)

R. Tuve hambre y me disteis de comer, tuve sed y me disteis de beber, fui forastero y me hospedasteis. * Os aseguro que cada vez que lo hicisteis con uno de estos mis humildes hermanos, conmigo lo hicisteis.  
V. Éste es mi mandamiento, que os améis unos a otros como yo os he amado.  
R. Os aseguro que cada vez que lo hicisteis con uno de estos mis humildes hermanos, conmigo lo hicisteis.  

## Oración

Llenos de alegría, al celebrar un año más la Cuaresma, te pedimos, Señor, vivir los sacramentos pascuales, y sentir en nosotros el gozo de su eficacia. Por Jesucristo nuestro Señor.

## Primera lectura del día

**Del libro del Éxodo 40, 16-38** — *Erección del Santuario. La nube del Señor*

En aquellos días, Moisés hizo todo conforme a lo que el Señor le había mandado. El día uno del mes primero del segundo año fue erigida la Morada. Moisés erigió la Morada, colocó las basas, puso los tablones con sus travesaños y plantó las columnas; montó la tienda sobre la Morada y puso la cubierta sobre la tienda; como el Señor se lo había mandado a Moisés. Luego colocó el Testimonio en el Arca, sujetó los varales al Arca y puso el propiciatorio encima del Arca. Después trasladó el Arca a la Morada, puso el velo de separación para cubrir el Arca del Testimonio; como el Señor había mandado a Moisés.

Colocó también la mesa en la Tienda del Encuentro, en la parte norte de la Morada y fuera del velo. Sobre ella dispuso los panes presentados al Señor; como el Señor había mandado a Moisés.

Colocó el candelabro en la Tienda del Encuentro, en la parte sur del Santuario, frente a la mesa, y encendió las lámparas en presencia del Señor; como el Señor había mandado a Moisés.

Puso el altar de oro en la Tienda del Encuentro, frente al velo; y sobre él quemó el incienso perfumado; como el Señor había mandado a Moisés. Después colocó la cortina a la entrada de la Morada.

Puso el altar de los holocaustos a la entrada de la Morada de la Tienda del Encuentro, y sobre él ofreció el holocausto y la ofrenda, como el Señor había mandado a Moisés.

Colocó la pila entre la Tienda del Encuentro y el altar, y le echó agua para las abluciones. Moisés, Aarón y sus hijos se lavaban manos y pies; cuando iban a entrar en la Tienda del Encuentro y al acercarse al altar, se lavaban, como el Señor había mandado a Moisés.

Alrededor de la Morada y del altar levantó el atrio, y colocó el tapiz a la entrada del mismo. Y así acabó la obra Moisés.

Entonces la nube cubrió la Tienda del Encuentro y la gloria del Señor llenó la Morada. Moisés no pudo entrar en la Tienda del Encuentro, porque la nube moraba sobre ella y la gloria del Señor llenaba la Morada. Cuando la nube se alzaba de la Morada, los hijos de Israel levantaban el campamento, en todas las etapas. Pero cuando la nube no se alzaba, ellos esperaban hasta que se alzase. De día la nube del Señor se posaba sobre la Morada, y de noche el fuego, en todas sus etapas, a la vista de toda la casa de Israel.

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
