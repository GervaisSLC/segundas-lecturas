# San Cipriano

None · None · 1 lecturas

- [Es cristiano el que en todo imita a Cristo](../r/d738f99d0e.md) — San Cipriano · PLS 1, 51-52 · Viernes de la semana IX del Tiempo Ordinario (semana 9), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
