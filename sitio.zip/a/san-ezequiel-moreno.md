# San Ezequiel Moreno

None · None · 1 lecturas

- [Tú eres mi fortaleza y refugio](../r/5d89e65ef9.md) — San Ezequiel Moreno · Toribio Minguella, O.A. R., Cartas Pastorales, Circulares y otros Escritos del Ilmo. y Rmo. Sr. D. Fr. Ezequiel Moreno y Díaz, Madrid, 1908, pp. 171.173-4). · El mismo día 19 de agosto San Ezequiel Moreno, obispo — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
