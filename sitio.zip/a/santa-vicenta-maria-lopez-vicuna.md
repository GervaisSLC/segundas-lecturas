# Santa Vicenta María López Vicuña

None · None · 1 lecturas

- [La caridad](../r/a1d0a2e9f3.md) — Santa Vicenta María López Vicuña · Cartas I, Madrid 1976, c. 407 · El mismo día 25 de mayo. Santa Vicenta María López Vicuña, Virgen — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
