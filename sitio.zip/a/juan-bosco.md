# San Juan Bosco

1815–1888 · St. John Bosco · 1 lecturas

- [Trabajé siempre por amor](../r/cfb1e9932c.md) — San Juan Bosco · Epistolario, 4, 201-203: Turín 1959 · 31 de enero San Juan Bosco, Presbítero — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
