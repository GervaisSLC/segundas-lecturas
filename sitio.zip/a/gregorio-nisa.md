# San Gregorio de Nisa

c. 335–395 · St. Gregory of Nyssa · 29 lecturas

- [El niño Jesús que nos ha nacido, es la verdadera luz, la verdadera vida y la justicia verdadera](../r/214a7b77d8.md) — San Gregorio de Nisa · Homilía 3: PG 44, 827-830 · Navidad y su Octava — Adviento y Navidad, año par
- [Dichosos los perseguidos por mi causa](../r/e0034f37e5.md) — San Gregorio de Nisa · Discurso 27, 9: PG 44, 1291-1295. 1299-1302 · 26 de diciembre. San Esteban, protomártir — Santoral, año par
- [Exultemos y alegrémonos en ti](../r/9fec4075d4.md) — San Gregorio de Nisa · Hom 1: PG 44, 765-766.783.786 · 29 de Diciembre. Día V - Octava de Navidad — Santoral, año par
- [Oración al buen pastor](../r/166af8ea5a.md) — San Gregorio de Nisa · Cap. 2: PG 44, 802 · 30 de Diciembre. Día VI - Octava de Navidad — Santoral, año par
- [Dios se ha manifestado en la carne](../r/12af9921bd.md) — San Gregorio de Nisa · Homilía 5: PG 44, 859-862. 863. 874. 875 · 31 de Diciembre. Día VII - Octava de Navidad — Santoral, año par
- [Cristo, primogénito de entre los muertos](../r/3f5cca1ed6.md) — San Gregorio de Nisa · Lib. 4: PG 45, 634-635. 638 · Martes de la semana III de Pascua (semana 3), año par
- [La voluntad de Cristo, norma de nuestra vida](../r/a74cf9f7aa.md) — San Gregorio de Nisa · PG 46, 262-263 · Jueves de la semana III de Pascua (semana 3), año par
- [El cristiano es otro Cristo](../r/25eec95cd9.md) — San Gregorio de Nisa · PG 46, 254-255 · Sábado de la semana III de Pascua (semana 3), año par
- [Yo les he dado la gloria que tú me diste](../r/6b85e551c4.md) — San Gregorio de Nisa · Homilía 15: PG 44, 1115-1118 · Semana VII de Pascua — Cuaresma y Pascua, año par
- [Les di a ellos la gloria que me diste](../r/82d00ca2ca.md) — San Gregorio de Nisa · Homilía 15 : PG 44, 1115-1118 · Semana VII de Pascua — Cuaresma y Pascua, año par
- [Primogénito de la nueva creación](../r/29738f4708.md) — San Gregorio de Nisa · Sermón 1: PG 46, 603-606. 626-627 · Miércoles de la semana V de Pascua (semana 5), año impar
- [Dios es como una roca inaccesible](../r/102aa17cf4.md) — San Gregorio de Nisa · Homilía 6 sobre las bienaventuranzas : PG 44, 1263-1266 · Miércoles de la semana XIV del Tiempo Ordinario (semana 14), año impar
- [La esperanza de ver a Dios](../r/ee579cdb9d.md) — San Gregorio de Nisa · Homilía 6 sobre las bienaventuranzas : PG 44, 1266-1267 · Jueves de la semana XIV del Tiempo Ordinario (semana 14), año impar
- [Dios puede ser hallado en el corazón del hombre](../r/44add5a207.md) — San Gregorio de Nisa · Homilía 6 sobre las bienaventuranzas: PG 44, 1270-1271 · Viernes de la semana XIV del Tiempo Ordinario (semana 14), año impar
- [El rey pacífico gobierna a su pueblo con justicia](../r/9f55629b0e.md) — San Gregorio de Nisa · Homilía 7: PG 44, 907-910 · Viernes de la semana XVI del Tiempo Ordinario (semana 16), año impar
- [Tú que has sido crucificado juntamente con Cristo, ofrécete a Dios como sacerdote sin tacha](../r/8f7e4d66a0.md) — San Gregorio de Nisa · Cap 24: PG 46, 414-416 · Miércoles de la semana XII del Tiempo Ordinario (semana 12), año par
- [Tenemos a Cristo que es nuestra paz y nuestra luz](../r/ff2e247cbc.md) — San Gregorio de Nisa · PG 46, 259-262 · Lunes de la semana XX del Tiempo Ordinario (semana 20), año impar
- [El misterio de la Iglesia](../r/262cc27437.md) — San Gregorio de Nisa · Hom. 8 : PG 44, 947-950 · Jueves de la semana XX del Tiempo Ordinario (semana 20), año impar
- [Se aparta de Dios quien no se une a él en la oración](../r/a984b84447.md) — San Gregorio de Nisa · PG 44,1119. 1123-1126 · Semana XXIX DEL TIEMPO ORDINARIO, año impar
- [Sé benigno con los hermanos desgraciados](../r/d378e3c3a1.md) — San Gregorio de Nisa · Homilía 1 sobre el amor a los pobres: PG 46, 458-459 · Viernes de la semana XXX del Tiempo Ordinario (semana 30), año impar
- [Venid a curaros los que os sentís enfermos](../r/b4098e9edf.md) — San Gregorio de Nisa · Comienza el discurso sobre el bautismo (PG 415-418.419 · Domingo de la semana XVIII del Tiempo Ordinario (semana 18), año par
- [Abre tu alma a una educación esmerada](../r/8f6adc85dc.md) — San Gregorio de Nisa · PG 46, 420-422.426 · Domingo de la semana XVIII del Tiempo Ordinario (semana 18) - Año A: Mt 14, 13-21, año par
- [Amad los trofeos y las coronas que Dios tiene preparados para sus atletas](../r/d4fd282d4b.md) — San Gregorio de Nisa · PG 46, 427-430 · Martes de la semana XVIII del Tiempo Ordinario (semana 18), año par
- [Venid vosotros, benditos de mi Padre; heredad el reino preparado para vosotros desde la creación del mundo](../r/bdc3de38da.md) — San Gregorio de Nisa · PG 46, 430-432 · Miércoles de la semana XVIII del Tiempo Ordinario (semana 18), año par
- [Oración del buen pastor](../r/6083068f4d.md) — San Gregorio de Nisa · Cap 2: PG 44, 802 · Jueves de la semana XIX del Tiempo Ordinario (semana 19), año par
- [El sabio tiene sus ojos puestos en la cabeza](../r/88dcfd0b52.md) — San Gregorio de Nisa · Hom. 5 : PG 44, 683-686 · Domingo de la semana XX del Tiempo Ordinario (semana 20) - Año A: Mt 15, 21-28, año par
- [Tiene su tiempo el nacer y su tiempo el morir](../r/1f2d5b0c97.md) — San Gregorio de Nisa · Homilía 6 : PG 44, 702-703 · Martes de la semana XX del Tiempo Ordinario (semana 20), año par
- [No desprecies a los pobres como si fuesen de ningún valor](../r/6509ff94e2.md) — San Gregorio de Nisa · Hom. 1 sobre el amor a los pobres : PG 46, 459-462 · Miércoles de la semana XXIII del Tiempo Ordinario (semana 23), año par
- [Éste es el grupo que busca al Señor](../r/06878379d0.md) — San Gregorio de Nisa · Sermón sobre la ascensión de Cristo : PG 46, 690-691 · Jueves de la semana XXV del Tiempo Ordinario (semana 25), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
