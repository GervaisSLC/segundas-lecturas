# San Juan Leonardi

None · None · 1 lecturas

- [Te han explicado, hombre, lo que Dios desea de ti](../r/ed41d2c2c8.md) — San Juan Leonardi · Cartas por la reforma universal de toda la Iglesia: en el Archivo de la Orden de Clérigos Regulares de la Madre de Dios · El mismo día 9 de octubre San Juan Leonardi, presbítero — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
