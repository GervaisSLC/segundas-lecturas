# Concilio Vaticano II

1962–1965 · Second Vatican Council · 31 lecturas

- [Índole escatológica de la Iglesia peregrinante](../r/f0daad42ac.md) — Concilio Vaticano II · Núm 48 · Martes de la semana II de Adviento (semana 2), año par
- [Cristo, plenitud de la revelación](../r/80f3938d24.md) — Concilio Vaticano II · Núms 3-4 · Jueves de la semana III de Adviento (semana 3), año par
- [La maternidad de María en la economía de la gracia](../r/190be06986.md) — Concilio Vaticano II · Núms. 61-62 · Común de Santa maría virgen — Comunes, año par
- [María, tipo de la Iglesia](../r/2bac0e17f0.md) — Concilio Vaticano II · Núms. 63-65 · Común de Santa maría virgen — Comunes, año par
- [Vocación de los presbíteros a la perfección](../r/d10851fdfa.md) — Concilio Vaticano II · Núm. 12 · Común de pastores — Comunes, año par
- [Id y haced discípulos de todos los pueblos](../r/f857dc5975.md) — Concilio Vaticano II · Núms. 4-5 · Común de pastores — Comunes, año par
- [Sobre la transmisión de la revelación divina](../r/d3de893d40.md) — Concilio Vaticano II · Núms. 7-8 · Común de doctores de la iglesia — Comunes, año par
- [La Iglesia sigue a su único esposo, Cristo](../r/14c03c5f33.md) — Concilio Vaticano II · Núms. 1. 5. 6.12 · Común de vírgenes — Comunes, año par
- [Los interrogantes más profundos del hombre](../r/adec0c6885.md) — Concilio Vaticano II · Núms. 9-10 · Sábado de la semana I de Cuaresma (semana 1), año par
- [Que toda la actividad del hombre se purifique en el misterio pascual](../r/86849e4b14.md) — Concilio Vaticano II · Núms. 37-38 · Sábado de la semana IV de Cuaresma (semana 4), año par
- [La Iglesia, sacramento visible de la unidad](../r/7602f78e00.md) — Concilio Vaticano II · Núm. 9). · Domingo de la semana V de Cuaresma (semana 5) - Año A: Jn 11, 1-45, año par
- [La economía de la salvación](../r/f248d4d4d4.md) — Concilio Vaticano II · Núms. 5-6 · Sábado de la semana II de Pascua (semana 2), año par
- [Cristo ha hecho partícipes de su consagración y de su misión a los obispos por medio de los apóstoles](../r/1be233be4b.md) — Concilio Vaticano II · Capítulo III, n. 28 · Domingo de la semana IV de Pascua (semana 4) - Año A: Jn 10, 1-10, año par
- [La misión del Espíritu Santo en la Iglesia](../r/28f5fcdbaf.md) — Concilio Vaticano II · Núms. 4. 12 · Miércoles de la semana VII de Pascua (semana 7), año par
- [Disponibles para toda obra buena](../r/83e64cb458.md) — Concilio Vaticano II · Núms. 12-13.16 · 23 de marzo. Santo Toribio de Mogrovejo, Obispo — Santoral, año par
- [Sobre la actividad humana en todo el mundo](../r/a04ff4c74d.md) — Concilio Vaticano II · Núms. 33-34 · 1 de mayo. San José, Obrero — Santoral, año par
- [Yo salvaré a mi pueblo](../r/0acb14e1ad.md) — Concilio Vaticano II · Núms. 2.16 · Domingo de la semana I de Cuaresma (semana 1) - Año A: Mt 4, 1-11, año impar
- [Santidad del matrimonio y de la familia](../r/939a0a6b7a.md) — Concilio Vaticano II · Núm. 48 · Domingo de la semana II de Cuaresma (semana 2) - Año A: Mt 17, 1-9, año impar
- [El misterio de la muerte](../r/fe2805e65e.md) — Concilio Vaticano II · Núms. 18. 22 · Sábado de la semana II de Cuaresma (semana 2), año impar
- [La Iglesia es en Cristo como un sacramento o señal de la íntima unión con Dios](../r/f3dec6e5a8.md) — Concilio Vaticano II · Núms. 1-3 · Domingo de la semana IV de Pascua (semana 4), año impar
- [Somos hijos de Dios y constituimos una familia en Cristo](../r/fff850c4a1.md) — Concilio Vaticano II · Cap. 7, 50-51 · Jueves de la semana V de Pascua (semana 5), año impar
- [Id y haced discípulos de todos los pueblos](../r/94532375d7.md) — Concilio Vaticano II · Núms. 4-5 · Sábado de la semana III del Tiempo Ordinario (semana 3), año impar
- [Hay que anunciar, con toda libertad, el misterio de Cristo](../r/8a41c7d109.md) — Concilio Vaticano II · Núms. 23-24 · El mismo día 3 de febrero San Óscar, Obispo — Santoral, año impar
- [Naturaleza de la paz](../r/376ee1621b.md) — Concilio Vaticano II · n. 78 · 28 de julio Nuestra Señora de la Paz — Santoral, año impar
- [La actividad humana](../r/605dbf61df.md) — Concilio Vaticano II · Núms 33-36 · Sábado de la semana VI del Tiempo Ordinario (semana 6), año par
- [La esperanza de la tierra nueva](../r/c49315d7b3.md) — Concilio Vaticano II · n. 39 · Sábado de la semana XXVII del Tiempo Ordinario (semana 27), año impar
- [Santidad del matrimonio y de la familia](../r/29ededa159.md) — Concilio Vaticano II · Núm. 48 · 16 de noviembre Santa Margarita de Escocia — Santoral, año impar
- [Yo soy el alfa y la omega, el primero y el último](../r/8c0c449131.md) — Concilio Vaticano II · núm. 40.45 · Sábado de la semana XVIII del Tiempo Ordinario (semana 18), año par
- [Naturaleza de la paz](../r/36c5530c4b.md) — Concilio Vaticano II · N. 78 · Domingo de la semana XXXII del Tiempo Ordinario (semana 32), año par
- [Necesidad de inculcar sentimientos que llevan a la paz](../r/c703d5c365.md) — Concilio Vaticano II · Nn. 82-83 · Domingo de la semana XXXII del Tiempo Ordinario (semana 32) - Año A: Mt 25, 1-13, año par
- [Papel de los cristianos en la construcción de la paz](../r/eb6cacbd72.md) — Concilio Vaticano II · Nn. 88-90 · Viernes de la semana XXXII del Tiempo Ordinario (semana 32), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
