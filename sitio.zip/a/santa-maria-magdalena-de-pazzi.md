# Santa María Magdalena de Pazzi

None · None · 1 lecturas

- [Ven, Espíritu Santo](../r/42d74366c9.md) — Santa María Magdalena de Pazzi · Manuscritos III, 186. 264; IV, 716: Opere di santa María Magdalena de' Pazzi, Florencia 1965, 4, pp. 200. 269; 6, p.194 · El mismo día 25 de mayo. Santa María Magdalena de Pazzi, Virgen — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
