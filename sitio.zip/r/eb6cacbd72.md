# Papel de los cristianos en la construcción de la paz

**Concilio Vaticano II** (1962–1965) · Segunda lectura del Oficio de Lectura

- id: `eb6cacbd72`
- Fuente: De la Constitución pastoral Gaudium et spes, sobre la Iglesia en el mundo actual, del Concilio Vaticano II
- Cita patrística: Nn. 88-90
- Se lee: Viernes de la semana XXXII del Tiempo Ordinario (semana 32), año par
- Escritura: [1 M 2, 1. 15-28. 42-50. 65-70](../escritura/1m.md) (primera lectura del día); [Ha 3, 3](../escritura/ha.md) (responsorio); [Lv 26, 1. 6. 9](../escritura/lv.md) (responsorio)
- Temas (automáticos): [Misión y evangelización](../temas/mision.md), [Paz y unidad](../temas/paz.md), [Caridad y amor fraterno](../temas/caridad.md), [Misericordia y pobres](../temas/misericordia.md)
- Cómo citar: Concilio Vaticano II, Nn. 88-90, «Papel de los cristianos en la construcción de la paz». Liturgia de las Horas, Oficio de Lectura, segunda lectura, Viernes de la semana XXXII del Tiempo Ordinario (semana 32), año par. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-eb6cacbd72](../index.html#r-eb6cacbd72)
- Autor: [Concilio Vaticano II](../a/vaticano-ii.md)

## Texto

Los cristianos deben cooperar, con gusto y de corazón, en la edificación de un orden internacional en el que se respeten las legítimas libertades y se fomente una sincera fraternidad entre todos; y eso con tanta mayor razón cuanto más claramente se advierte que la mayor parte de la humanidad sufre todavía una extrema pobreza, hasta tal punto que puede decirse que Cristo mismo, en la persona de los pobres, eleva su voz para solicitar la caridad de sus discípulos.

Que se evite, pues, el escándalo de que, mientras ciertas naciones, cuya población es muchas veces en su mayoría cristiana, abundan en toda clase de bienes, otras, en cambio, se ven privadas de lo más indispensable y sufren a causa del hambre, de las enfermedades y de toda clase de miserias. El espíritu de pobreza y de caridad debe ser la gloria y el testimonio de la Iglesia de Cristo.

Hay que alabar y animar, por tanto, a aquellos cristianos, sobre todo a los jóvenes, que espontáneamente se ofrecen para ayudar a los demás hombres y naciones. Más aún, es deber de todo el pueblo de Dios, animado y guiado por la palabra y el ejemplo de sus obispos, aliviar, según las posibilidades de cada uno, las miserias de nuestro tiempo; y esto hay que hacerlo, como era costumbre en la antigua Iglesia, dando no solamente de los bienes superfluos, sino aun de los necesarios.

El modo de recoger y distribuir lo necesario para las diversas necesidades, sin que haya de ser rígida y uniformemente ordenado, llévese a cabo, sin embargo, con toda solicitud en cada una de las diócesis, naciones e incluso en el plano universal, uniendo siempre que se crea conveniente la colaboración de los católicos con la de los otros hermanos cristianos. En efecto, el espíritu de caridad, lejos de prohibir el ejercicio ordenado y previsor de la acción social y caritativa, más bien lo exige. De aquí que sea necesario que quienes pretenden dedicarse al servicio de las naciones en vía de desarrollo sean oportunamente formados en instituciones especializadas.

Por eso, la Iglesia debe estar siempre presente en la comunidad de las naciones para fomentar o despertar la cooperación entre los hombres; y eso tanto por medio de sus órganos oficiales como por la colaboración sincera y plena de cada uno de los cristianos, colaboración que debe inspirarse en el único deseo de servir a todos.

Este resultado se conseguirá mejor si los mismos fieles, en sus propios ambientes, conscientes de la propia responsabilidad humana y cristiana, se esfuerzan por despertar el deseo de una generosa cooperación con la comunidad internacional. Dése a esto una especial importancia en la formación de los jóvenes, tanto en su formación religiosa como civil.

Finalmente, es muy de desear que los católicos, para cumplir debidamente su deber en el seno de la comunidad internacional, se esfuercen por cooperar activa y positivamente con sus hermanos separados, que como ellos profesan la caridad evangélica, y con todos aquellos otros hombres que están sedientos de verdadera paz.

## Responsorio (Cf. Ha 3, 3; Lv 26, 1. 6. 9)

R. He aquí que vengo, dice el Todopoderoso. * Yo, el Señor vuestro Dios estableceré la paz  
V. Yo me volveré hacia vosotros, os haré fecundos, os multiplicaré y mantendré mi alianza con vosotros.  
R. Yo, el Señor vuestro Dios estableceré la paz.  

## Oración

Dios omnipotente y misericordioso, aparta de nosotros todos los males, para que, bien dispuesto nuestro cuerpo y nuestro espíritu, podamos libremente cumplir tu voluntad. Por nuestro Señor Jesucristo.

## Primera lectura del día

**Del primer libro de los Macabeos 2, 1. 15-28. 42-50. 65-70** — *Rebelión de Matatías*

Por entonces surgió Matatías, hijo de Juan, hijo de Simón sacerdote de la familia de Joarib; aunque oriundo de Jerusalén, se había establecido en Modín.

Los funcionarios reales, encargados de imponer la apostasía, llegaron a Modín para que la gente ofreciese sacrificios, y muchos israelitas acudieron a ellos. Matatías y sus hijos se reunieron aparte. Los funcionarios del rey tomaron la palabra y dijeron a Matatías: «Tú eres una persona ilustre, un hombre importante en esta ciudad, y estás respaldado por tus hijos y parientes. Adelántate el primero, haz lo que manda el rey, como lo han hecho todas las naciones; y los mismos judíos, y los que han quedado en Jerusalén. Tú y tus hijos recibiréis el título de Amigos del rey; os premiarán con oro y plata y muchos regalos».

Pero Matatías respondió en voz alta: «Aunque todos los súbditos del rey le obedezcan apostatando de la religión de sus padres y aunque prefieran cumplir sus órdenes, yo, mis hijos y mis parientes viviremos según la Alianza de nuestros padres. ¡Dios me libre de abandonar la ley y nuestras costumbres! No obedeceremos las órdenes del rey, desviándonos de nuestra religión ni a derecha ni a izquierda».

Nada más decirlo, un judío se adelantó a la vista de todos, dispuesto a sacrificar sobre el ara de Modín, como lo mandaba el rey. Al verlo, Matatías se indignó, tembló de cólera y, en un arrebato de ira santa, corrió a degollar a aquel hombre sobre el ara. Y, acto seguido, mató al funcionario real que obligaba a sacrificar y derribó el ara. Lleno de celo por la ley, hizo lo que Pinjás a Zimrí, hijo de Salu. Luego empezó a decir a voz en grito por la ciudad: «¡Todo el que sienta celo por la ley y quiera mantener la Alianza, que me siga!». Y se echó al monte, con sus hijos, dejando en la ciudad todo cuanto tenía.

Por entonces se les agregó el grupo de «los leales», israelitas valientes, todos entregados de corazón a la ley; se les sumaron también como refuerzos todos los que querían escapar de aquellas desgracias. Organizaron un ejército y descargaron su ira contra los pecadores y su cólera contra los apóstatas. Los que se libraron del ataque fueron a refugiarse entre los gentiles.

Matatías y sus partidarios organizaron una correría, derribaron las aras, circuncidaron por la fuerza a los niños no circuncidados que encontraban en territorio israelita y persiguieron a los insolentes; la campaña fue un éxito, de manera que rescataron la ley de manos de los gentiles y sus reyes, y mantuvieron a raya a los malvados.

Cuando le llegó la hora de morir, Matatías dijo a sus hijos:

«Hoy triunfan la insolencia y el descaro;

son tiempos de subversión y de ira,

Ahora, hijos míos, sed celosos de la ley

y dad la vida por la Alianza de vuestros padres.

Mirad, sé que vuestro hermano Simón es prudente; obedecedlo siempre, que él será vuestro padre. Y Judas Macabeo, aguerrido desde joven, será vuestro caudillo y dirigirá la guerra contra el extranjero. Vosotros ganaos a todos los que guardan la ley y vengad a vuestro pueblo; dad a los gentiles su merecido y cumplid cuidadosamente los preceptos de la ley».

Y, después de bendecirlos, fue a reunirse con sus antepasados. Murió el año ciento cuarenta y seis. Lo enterraron en la sepultura familiar, en Modín, y todo Israel le hizo solemnes funerales.

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
