# San Juan Pablo II

1920–2005 · St. John Paul II · 5 lecturas

- [La Virgen María consoló a Juan Diego](../r/f955545fd0.md) — San Juan Pablo II · México, 31 de julio de 2002). · 9 de diciembre. San Juan Diego de Cuauhtlatoazin — Santoral, año par
- [La vocación, misterio de amor](../r/b77a3e2728.md) — San Juan Pablo II · AAS 76 (1984) 513-546, n. 3 · 10 de enero. Beata Ana de los Ángeles Monteagudo — Santoral, año par
- [La sangre de los mártires da testimonio de la fe cristiana](../r/e30d32dc17.md) — San Juan Pablo II · AAS 92, 2000, 849-850 · 9 de julio San Agustín Zhao Rong, Presbítero, y Compañeros, Mártires — Santoral, año impar
- ["Qué hermosos son sobre los montes los pies del mensajero que trae la Buena Nueva" (Is 52,7).](../r/182d49209e.md) — San Juan Pablo II · Ecclesia, núm. 2346, 21 noviembre 1987, pp. 25 y 27, nn. 5-7. L'Osservatore Romano, edición española, 25 octubre 1987). · El mismo día 28 de septiembre San Lorenzo Ruiz y Compañeros, mártires — Santoral, año impar
- [¡No tengáis miedo! ¡Abrid las puertas a Cristo!](../r/18f57e55ec.md) — San Juan Pablo II · 22 de octubre 1978 · 22 de octubre San Juan Pablo II, papa — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
