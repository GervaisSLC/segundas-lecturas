# San Anselmo de Canterbury

1033–1109 · St. Anselm of Canterbury · 6 lecturas

- [El deseo de contemplar a Dios](../r/690b901ab2.md) — San Anselmo de Canterbury · Libro 1: Opera omnia, ed. Schmitt, Seckau [Austria] 1938, 1, 97-100 · Viernes de la semana I de Adviento (semana 1), año par
- [¡Oh Virgen, por tu bendición queda bendita toda criatura!](../r/5db8eda892.md) — San Anselmo de Canterbury · Sermón 52: PL 158, 955-956 · 8 de diciembre. LA INMACULADA CONCEPCIÓN DE SANTA MARÍA VIRGEN — Santoral, año par
- [Que te conozca y te ame para que encuentre en ti mi alegría](../r/f1557cda4b.md) — San Anselmo de Canterbury · Caps. 14. 16. 26: Opera omnia, edición Schmitt, Seckau [Austria] 1938,1,111-113.121-122 · 21 de abril. San Anselmo, Obispo y Doctor de la Iglesia — Santoral, año par
- [Da amor y recibe el reino; ama y toma](../r/35f4c22795.md) — San Anselmo de Canterbury · Carta 112 : Opera omnia, t. 3, 1946, 244-246 · Domingo de la semana XXI del Tiempo Ordinario (semana 21), año impar
- [La nueva Iglesia de los fieles fue reunida por la gracia del Espíritu Santo](../r/d335a9a570.md) — San Anselmo de Canterbury · Lib. 1, 6: SC 118, 64-66 · Miércoles de la semana XXVI del Tiempo Ordinario (semana 26), año impar
- [No temas, que te he redimido: he dado mi vida por ti](../r/01c8d07af0.md) — San Anselmo de Canterbury · Meditación 3 : Opera omnia, 1946, 88-90 · Lunes de la semana XXXI del Tiempo Ordinario (semana 31), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
