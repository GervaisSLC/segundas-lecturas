# San Juan Bautista de la Salle

None · None · 1 lecturas

- [El amor de Cristo nos apremia](../r/ef363b5269.md) — San Juan Bautista de la Salle · Meditación 201 · 7 de abril. San Juan Bautista de la Salle, Presbítero — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
