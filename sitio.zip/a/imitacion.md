# Tomás de Kempis (Imitación de Cristo)

c. 1380–1471 · Thomas à Kempis (Imitation of Christ) · 3 lecturas

- [Sobre la humildad y la paz](../r/cc03e08036.md) — Tomás de Kempis (Imitación de Cristo) · Lib. 2, cap. 2-3 · Martes de la semana III de Adviento (semana 3), año par
- [La fidelidad del Señor dura por siempre](../r/110fa39002.md) — Tomás de Kempis (Imitación de Cristo) · Lib. 3, cap. 14 · Miércoles de la semana VII del Tiempo Ordinario (semana 7), año impar
- [Yo instruiré a mis profetas](../r/3a6b6d9e42.md) — Tomás de Kempis (Imitación de Cristo) · Lib. 3, cap. 3 · Sábado de la semana XXIX del Tiempo Ordinario (semana 29), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
