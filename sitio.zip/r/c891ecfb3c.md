# En medio de vosotros hay uno que no conocéis

**Ruperto de Deutz** (c. 1075–1129) · Tercera lectura del Oficio de Lectura

- id: `c891ecfb3c`
- Fuente: Del Tratado sobre las obras del Espíritu de Santo Ruperto de Deutz, abad
- Cita patrística: Lib. III, cap 3: SC 165, 26-28
- Ciclo dominical: B · Evangelio Jn 1, 6-8; 19-28
- Se lee: Domingo de la semana III de Adviento (semana 3), año par; Domingo de la semana III de Adviento (semana 3), año impar
- Escritura: [Jn 1, 6-8](../escritura/jn.md) (evangelio del domingo); [Jn 1, 29-30. 27](../escritura/jn.md) (responsorio); [Mt 3, 11](../escritura/mt.md) (responsorio)
- Temas (automáticos): [Bautismo](../temas/bautismo.md), [Espíritu Santo](../temas/espiritu.md), [Cruz y Pasión](../temas/cruz.md), [Penitencia y conversión](../temas/conversion.md)
- Cómo citar: Ruperto de Deutz, Lib. III, cap 3: SC 165, 26-28, «En medio de vosotros hay uno que no conocéis». Liturgia de las Horas, Oficio de Lectura, tercera lectura, Domingo de la semana III de Adviento (semana 3), año par. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-c891ecfb3c](../index.html#r-c891ecfb3c)
- Autor: [Ruperto de Deutz](../a/ruperto-deutz.md)

## Texto

El bautismo de Juan es el bautismo del siervo; el bautismo de Cristo es el bautismo del Señor. El bautismo de Juan es un bautismo de conversión; el bautismo de Cristo es un bautismo para el perdón de los pecados. Mediante el bautismo de Juan, Cristo fue manifestado; mediante su propio bautismo, es decir, mediante su pasión, Cristo fue glorificado. Juan habla así de su bautismo: Yo no lo conocía, pero he salido a bautizar con agua, para que sea manifestado a Israel. Por lo que a Cristo se refiere, una vez recibido el bautismo de Juan, habla así de su bautismo: Tengo que pasar por un bautismo, ¡y qué angustia hasta que se cumpla! Finalmente, mediante el bautismo de Juan el pueblo se preparaba para el bautismo de Cristo; mediante el bautismo de Cristo el pueblo se capacita para el reino de Dios.

No cabe duda de que los que fueron bautizados con el bautismo de Juan –de Juan que decía al pueblo que creyesen en el que iba a venir después–, y salieron de esta vida antes de la pasión de Cristo, una vez que Cristo fue bautizado en su pasión, fueron absueltos de sus pecados por graves que fueran, entraron con él en el paraíso y con él vieron el reino de Dios. En cambio, los que despreciaron el plan de Dios para con ellos y, sin haber recibido el bautismo de Juan, abandonaron la luz de esta vida antes del susodicho bautismo de la pasión de Cristo, de nada les sirvió el antiguo remedio de la circuncisión; como tampoco les aprovechó la pasión de Cristo ni fueron sacados del infierno, porque no pertenecían al número de aquellos de quienes decía Cristo: Y por ellos me consagro yo.

Por otra parte, tampoco conviene olvidar que quienes recibieron el bautismo de Juan y sobrevivieron al momento en que, glorificado Jesús, fue predicado el evangelio de su bautismo, si no lo recibieron, si no juzgaron necesario ser bautizados con su bautismo, de nada les valió el haber recibido el bautismo de Juan. Consciente de ello el apóstol Pablo, habiendo encontrado unos discípulos, les preguntó: ¿Recibisteis el Espíritu Santo al aceptar la fe? Y de nuevo: Entonces, ¿qué bautismo habéis recibido? –se sobreentiende: si ni siquiera habéis oído hablar de un Espíritu Santo—, respondiendo ellos: El bautismo de Juan, les dijo: El bautismo de Juan era signo de conversión, y él decía al pueblo que creyesen en el que iba a venir después, es decir, en Jesús. Al oír esto, se bautizaron en el nombre del Señor Jesús; cuando Pablo les impuso las manos, bajó sobre ellos el Espíritu Santo.

¡Qué enorme diferencia entre el bautismo del siervo, en el que ni mención se hacía del Espíritu Santo, y el bautismo del Señor que no se confiere sino en el nombre del Espíritu Santo, a la vez que en el nombre del Padre y del Hijo, y en el que se otorga el Espíritu Santo para el perdón de los pecados! Luego bajo un nombre común, ambas realidades son denominadas bautismo; mas a pesar de la identidad de nombre el sentido profundo es muy diferente.

## Nota

> 1. Si este domingo coincide con el día 17 de diciembre, las lecturas y los responsorios del oficio de lectura se toman del formulario asignado a ese día (ir desde aquí).

> 2. Si no coincide con el 17 de diciembre se hacen las lecturas que siguen a continuación.

> 3. En ambos casos, las antífonas propias y los salmos se toman del domingo III del Salterio.

## Responsorio (Jn 1, 29-30. 27; Mt 3, 11)

R. Éste es el cordero de Dios, que quita el pecado del mundo. Éste es de quien yo dije: Después de mí viene un hombre superior a mí porque era antes que yo, * al que no soy digno de desatar la correa de su sandalia.  
V. Yo bautizo con agua: él os bautizará en Espíritu Santo.  
R. Al que no soy digno de desatar la correa de su sandalia.  

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
