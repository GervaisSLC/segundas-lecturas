# San Bruno de Segni

None · None · 1 lecturas

- [Grande es el poder de la fe](../r/bb7c688e40.md) — San Bruno de Segni · Parte 2, 40: PL 165, 426-428 · Domingo de la semana XXVIII del Tiempo Ordinario (semana 28), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
