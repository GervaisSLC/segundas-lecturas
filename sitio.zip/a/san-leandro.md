# San Leandro

None · None · 1 lecturas

- [Gozo de la unidad de la Iglesia](../r/a37f865ee6.md) — San Leandro · PL 72, 894-895 · 13 de noviembre San Leandro, obispo — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
