# San Paulino de Nola

c. 354–431 · St. Paulinus of Nola · 4 lecturas

- [Dios infunde su amor en los suyos por toda la tierra, por obra del Espíritu Santo](../r/58f9d7b911.md) — San Paulino de Nola · Carta 3, a Alipio,1. 5. 6: CSEL 29,13-14.17-18 · 22 de junio San Paulino de Nola, Obispo — Santoral, año impar
- [Purificados nuestros sentidos de toda levadura de maldad, con mucho gusto habitará en nosotros nuestro Señor Jesucristo](../r/7ab2ace5dc.md) — San Paulino de Nola · Carta 32, 23-24. 25: CSEL 29, 297-300 · Martes de la semana XIX del Tiempo Ordinario (semana 19), año impar
- [Nuestra gloria, posesión y reino es Cristo](../r/b3a3bc94e1.md) — San Paulino de Nola · Carta 38, 3-4. 6: CSEL 29, 326-327. 329 · Martes de la semana XXXI del Tiempo Ordinario (semana 31), año impar
- [Demos al Señor, que recibe en la persona de cada pobre](../r/bcdcdd3aa2.md) — San Paulino de Nola · Carta 34,2-4: CSEL 29, 305-306 · Semana XXXII DEL TIEMPO ORDINARIO, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
