# En toda esta lucha me siento rebosando de alegría

**San Juan Crisóstomo** (c. 349–407) · Segunda lectura del Oficio de Lectura

- id: `d04fcccd5f`
- Fuente: De las homilías sobre la segunda carta a los Corintios de San Juan Crisóstomo, obispo
- Cita patrística: 14, 1-2: PG 61, 497-499
- Se lee: Domingo de la semana VIII del Tiempo Ordinario (semana 8), año par
- Escritura: [2 Co 7, 2-16](../escritura/2co.md) (primera lectura del día); [Sal 102, 2.4](../escritura/sal.md) (responsorio); [Ga 2, 20](../escritura/ga.md) (responsorio)
- Temas (automáticos): [Virtudes y lucha espiritual](../temas/virtudes.md), [Muerte y difuntos](../temas/muerte.md)
- Cómo citar: San Juan Crisóstomo, 14, 1-2: PG 61, 497-499, «En toda esta lucha me siento rebosando de alegría». Liturgia de las Horas, Oficio de Lectura, segunda lectura, Domingo de la semana VIII del Tiempo Ordinario (semana 8), año par. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-d04fcccd5f](../index.html#r-d04fcccd5f)
- Traducción inglesa antigua (dominio público, no litúrgica): https://www.newadvent.org/fathers/2202.htm
- Autor: [San Juan Crisóstomo](../a/juan-crisostomo.md)

## Texto

Nuevamente vuelve Pablo a hablar de la caridad, para atemperar la aspereza de su reprensión. Pues, después que los ha reprendido y les ha echado en cara que no lo aman como él los ama, sino que, separándose de su amor, se han juntado a otros hombres perniciosos, por segunda vez, suaviza la dureza de su reprensión, diciendo: Dadnos amplio lugar en vuestro corazón, esto es: «Amadnos». El favor que pide no es en manera alguna gravoso, y es un favor de más provecho para el que lo da que para el que lo recibe. Y no dice: «Amadnos», sino: Dadnos amplio lugar en vuestro corazón, expresión que incluye un matiz de compasión.

«¿Quién –dice– nos ha echado fuera de vuestra mente? ¿Quién nos ha arrojado de ella? ¿Cuál es la causa de que nos sintamos al estrecho entre vosotros?» Antes había dicho: Vosotros estáis encogidos por dentro, y ahora aclara el sentido de esta expresión, diciendo: Dadnos amplio lugar en vuestro corazón, añadiendo este nuevo motivo para atraérselos. Nada hay, en efecto, que mueva tanto a amar como el pensamiento, por parte de la persona amada, de que aquel que la ama desea en gran manera verse correspondido.

Ya os tengo dicho —añade— que os llevo tan en el corazón, que estamos unidos para vida y para muerte. Muy grande es la fuerza de este amor, pues que, a pesar de sus desprecios, desea morir y vivir con ellos. «Porque os llevamos en el corazón, mas no de cualquier modo, sino del modo dicho». Porque puede darse el caso de uno que ame pero rehuya el peligro; no es éste nuestro caso.

Me siento lleno de ánimos. ¿De qué ánimos? «De los que vosotros me proporcionáis: porque os habéis enmendado y me habéis consolado así con vuestras obras». Esto es propio del que ama, reprochar la falta de correspondencia a su amor, pero con el temor de excederse en sus reproches y causar tristeza. Por esto, dice: Me siento lleno de ánimos y rebosando de alegría.

Es como si dijera: «Me habéis proporcionado una gran tristeza, pero me habéis proporcionado también una gran satisfacción y consuelo, ya que no sólo habéis quitado la causa de mi tristeza, sino que además me habéis llenado de una alegría mayor aún».

Y, a continuación, explica cuán grande sea esta alegría, cuando, después que ha dicho: Me siento rebosando de alegría, añade también: En toda esta lucha. «Tan grande –dice– es el placer que me habéis dado, que ni estas tan graves tribulaciones han podido oscurecerlo, sino que su grandeza exuberante ha superado todos los pesares que nos invadían y ha hecho que ni los sintiéramos».

## Responsorio (Sal 102, 2.4; Ga 2, 20)

R. Bendice, alma mía, al Señor, * no olvides sus amores. Él saca tu vida de la muerte, te colma de gracia y de amor.  
V. Me ha amado y se ha entregado por mí.  
R. No olvides sus amores. Él saca tu vida de la muerte, te colma de gracia y de amor.  

## Primera lectura del día

**De la segunda carta a los Corintios 7, 2-16** — *El arrepentimiento de los corintios: consuelo del apóstol*

Hermanos: Dadnos cabida en vuestros corazones. A nadie ofendimos, a nadie arruinamos, a nadie explotamos. No os digo esto para condenaros, pues ya os he dicho que os tengo en el corazón hasta el punto de que compartimos muerte y vida. Puedo hablaros con toda franqueza, estoy orgulloso de vosotros, estoy lleno de consuelo, desbordo de gozo en todas nuestras tribulaciones.

En efecto, cuando llegamos a Macedonia no tuvimos ningún sosiego, sino tribulaciones de toda clase: luchas por fuera, temores por dentro. Pero el Dios que consuela a los afligidos, nos consoló con la llegada de Tito; y no sólo con su llegada, sino además con el consuelo que él había encontrado entre vosotros; nos comunicó vuestra añoranza, vuestro llanto, vuestro afán por mí, lo cual me alegró todavía más. Porque, si os contristé con mi carta, no me arrepiento; y si entonces lo sentí —pues veo que aquella carta os entristeció, aunque por poco tiempo—, ahora me alegro, no porque os hubierais entristecido, sino porque vuestra tristeza os llevó al arrepentimiento; pues os entristecisteis como Dios quiere, de modo que de parte nuestra no habéis sufrido ningún perjuicio. Efectivamente, la tristeza vivida como Dios quiere produce arrepentimiento decisivo y saludable; en cambio, la tristeza de este mundo lleva a la muerte. Pues mirad cuántas cosas ha producido entre vosotros el haberos entristecido según Dios: ¡qué interés y qué excusas, qué indignación y qué respeto, qué añoranza, qué afecto y qué escarmiento! Habéis mostrado en todo que sois inocentes en este asunto. De hecho, si os escribí no fue pensando en el ofensor ni en el ofendido, sino para que se pusiera de manifiesto entre vosotros ante Dios vuestro interés por nosotros. Esto es lo que nos ha consolado.

Además de este consuelo, nos alegró enormemente la alegría de Tito, cuyo espíritu se tranquilizó gracias a todos vosotros. Porque, si en algo me he gloriado de vosotros ante él, no he quedado avergonzado. Todo lo contrario, así como os he hablado siempre con verdad, de igual modo nuestro orgullo con Tito se ha mostrado también verdadero. Además, su cariño por vosotros ha aumentado al recordar la obediencia que manifestasteis todos vosotros y la piadosa reverencia con que lo recibisteis. Me alegra porque cuento con vosotros en todo.

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
