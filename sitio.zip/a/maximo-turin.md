# San Máximo de Turín

d. c. 420 · St. Maximus of Turin · 9 lecturas

- [La navidad y el bautismo de Cristo son mi misterio y mi salvación](../r/daf22ae4b0.md) — San Máximo de Turín · Sermón 45, 1-3 CCL 23, 182-183 · 12 de Enero oSábado después del Domingo de Epifanía — Santoral, año par
- [Todavía hoy la voz de Juan nos interpela](../r/ee9adb7ce7.md) — San Máximo de Turín · Sermón 88, 1-3: CCL 23, 359-360 · Sábado de la semana I de Adviento (semana 1), año impar
- [La Navidad del Señor está cerca](../r/e279750692.md) — San Máximo de Turín · Sermón 61a, 1-3: CCL 23, 249. 250-251 · 19 de Diciembre — Santoral, año impar
- [Cristo es el día](../r/e220f9d839.md) — San Máximo de Turín · Sermón 53, 1-2. 4: CCL 23, 214-216 · Domingo de la semana V de Pascua (semana 5), año par
- [Cristo, día sin ocaso](../r/7dd62bc313.md) — San Máximo de Turín · Sermón 53, 1-2. 4: CCL 23, 214-216 · Sábado de la semana IV de Pascua (semana 4), año impar
- [Hemos de bañarnos en la misma fuente en que Cristo se bañó para llegar a ser lo que Cristo es](../r/1659ce947a.md) — San Máximo de Turín · Sermón 13, 1-4: CCL 23, 51-52 · Lunes de la semana XIX del Tiempo Ordinario (semana 19), año impar
- [El bautismo del Señor es nuestra sepultura](../r/e26191fd7e.md) — San Máximo de Turín · Sermón 59, 2-4: CCL 23, 236-238 · Domingo de la semana XXI del Tiempo Ordinario (semana 21), año impar
- [Por la humildad se llega al reino; por la sencillez se entra en el cielo](../r/48b8e98e34.md) — San Máximo de Turín · Sermón 48, 1-2: CCL 23, 187-188 · Domingo de la semana XXV del Tiempo Ordinario (semana 25), año impar
- [Todo para gloria de Dios](../r/b128a96f35.md) — San Máximo de Turín · Sermón 73, 1-4: CCL 23, 305-307 · Domingo de la semana XXV del Tiempo Ordinario (semana 25), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
