# Comunes — año impar

[Volver al calendario](index.md) · [Guía para IAs](../llms.txt)

## Común de la dedicación de una iglesia

- [Somos edificados a manera de piedras vivas como casa de Dios](../r/12127aa4a0.md) — Orígenes · Homilía 9, 1-2: SC 71, 244-246
- [Edificación y consagración de la casa de Dios en nosotros](../r/07fa52d6fc.md) — San Agustín de Hipona · Sermón 336, 1. 6: PL 38 [ed. 1861], 1471-1472. 1475

## Común de Santa maría virgen

- [La bendición del Padre ha brillado para los hombres por medio de María](../r/d7928279c6.md) — San Sofronio de Jerusalén · Sermón 2, en la Anunciación de la Santísima Virgen, 21-22. 26: PG 87, 3, 3242. 3250
- **La oración como en las Laudes.** — [La bendición del Padre ha brillado para los hombres por medio de María](../r/d7928279c6.md) — San Sofronio de Jerusalén · Sermón 2, en la Anunciación de la Santísima Virgen, 21-22. 26: PG 87, 3, 3242. 3250
- [María, Madre nuestra](../r/7e3b7cf0fd.md) — San Elredo de Rievaulx · Sermón 20, en la Natividad de santa María: PL 195, 322-324
- [La maternidad de María en la economía de la gracia](../r/190be06986.md) — Concilio Vaticano II · Núms. 61-62
- [María, antes de concebir corporalmente, concibió en su espíritu](../r/19a318fd82.md) — San León Magno · Sermón 1 en la Natividad del Señor, 2. 3: PL 54,191-192
- [Alabanzas de la Madre de Dios](../r/09a87d2250.md) — San Cirilo de Alejandría · Homilía 4: PG 77, 991. 995-996
- [El amigo de los hombres se ha hecho hombre, naciendo de la Virgen](../r/c519c14650.md) — San Proclo de Constantinopla · Sobre la Natividad del Señor, 1-2: PG 65, 843-846
- [María, Madre de Cristo y Madre de los cristianos](../r/8c0548eac7.md) — Beato Guerrico de Igny · Sermón 1 en la Asunción de santa María: PL 185,187-189
- [Adán y Cristo, Eva y María](../r/60cfbfae09.md) — San Juan Crisóstomo · Sobre el cementerio y la cruz, 2: PG 49, 396
- [María, tipo de la Iglesia](../r/2bac0e17f0.md) — Concilio Vaticano II · Núms. 63-65

## Para varios mártires

- [Los que deseamos alcanzar las promesas del Señor debemos imitarle en todo](../r/4a6dcb0d37.md) — San Cipriano de Cartago · Carta 6,1-2: CSEL 3, 480-482

## Para un mártir

- [Preciosa es la muerte de los mártires, comprada con el precio de la muerte de Cristo](../r/737c0b2c30.md) — San Agustín de Hipona · Sermón 329, en el natalicio de los mártires, 1-2: PL 38,1454-1456

## Común de pastores

- [En Pedro permanece lo que Cristo instituyó](../r/9066b6bf8b.md) — San León Magno · Sermón 3 en el aniversario de su consagración episcopal, 2-3: PL 54,145-146
- [Dios edifica y guarda su ciudad](../r/288c413097.md) — San Hilario de Poitiers · Núms. 7-10: PL 9, 696-697
- [Criado fiel y solícito](../r/c754ee4157.md) — San Fulgencio de Ruspe · Sermón 1, 2-3: CCL 91 A, 889-890
- [Vocación de los presbíteros a la perfección](../r/d10851fdfa.md) — Concilio Vaticano II · Núm. 12
- [Id y haced discípulos de todos los pueblos](../r/f857dc5975.md) — Concilio Vaticano II · Núms. 4-5

## Común de doctores de la iglesia

- [Debemos buscar la inteligencia de la fe en el Espíritu Santo](../r/b70aa2a23c.md) — San Asterio de Amasea · PL 180, 384
- [Sobre la transmisión de la revelación divina](../r/d3de893d40.md) — Concilio Vaticano II · Núms. 7-8

## Común de vírgenes

- [El coro numeroso de las vírgenes acrecienta el gozo de la madre Iglesia](../r/c4251428aa.md) — San Cipriano de Cartago · Núms. 3-4. 22. 23: CSEL 3,189-190. 202-204
- [La Iglesia sigue a su único esposo, Cristo](../r/14c03c5f33.md) — Concilio Vaticano II · Núms. 1. 5. 6.12

## Común de santos varones

- [No puede ocultarse la luz de los cristianos](../r/fdd1c7e7d5.md) — San Juan Crisóstomo · Homilía 20, 4: PG 60,162-164
- [Sobre la vocación universal a la santidad](../r/a7d31d4110.md) — San Agustín de Hipona · Sermón 96,1. 4. 9: PL 38, 584. 586. 588

## Común de santas mujeres

- [No puede ocultarse la luz de los cristianos](../r/fdd1c7e7d5.md) — San Juan Crisóstomo · Homilía 20, 4: PG 60,162-164
- [Sobre la vocación universal a la santidad](../r/a7d31d4110.md) — San Agustín de Hipona · Sermón 96,1. 4. 9: PL 38, 584. 586. 588
- [La esposa es el sol de la familia](../r/b6123f0872.md) — Papa Pío XII · Discorsi e radiomessaggi, 11 de marzo de 1942:3,385-390

## Para los santos religiosos

- [En el mundo, pero no del mundo](../r/8682879c02.md) — San Gregorio Magno · Libro 2, homilía 36,11-13: PL 76,1272-1274

## Para los que se han consagrado a una actividad caritativa

- [Cristo nos recomienda la misericordia](../r/4f560b8b83.md) — San Juan Crisóstomo · Homilía 15, 6: PG 60, 547-548

## Para los santos educadores

- [Tenemos que preocuparnos del bien de los niños](../r/529ac855f4.md) — San Juan Crisóstomo · Homilía 59: PG 58, 580. 584
