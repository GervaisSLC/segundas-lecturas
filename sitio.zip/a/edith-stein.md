# Santa Teresa Benedicta de la Cruz

1891–1942 · St. Teresa Benedicta of the Cross (Edith Stein) · 1 lecturas

- [La puerta de la vida se abre a los que creen en el Crucificado](../r/14dfaee560.md) — Santa Teresa Benedicta de la Cruz · Propio de los santos — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
