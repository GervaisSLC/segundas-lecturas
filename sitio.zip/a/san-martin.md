# San Martín

None · None · 1 lecturas

- [El Señor está cerca, ¿por qué me voy a preocupar?](../r/1db0476b40.md) — San Martín · Carta 17: PL 87, 203-204 · 13 de abril. San Martín I, Papa y Mártir — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
