# San Hipólito

None · None · 1 lecturas

- [¡Oh mística largueza! ¡Oh Pascua divina!](../r/1078775c5c.md) — San Hipólito · Homilía 6, 1. 5 en la Pascua: PG 59, 735. 743-746 · Lunes de la Octava de Pascua — Cuaresma y Pascua, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
