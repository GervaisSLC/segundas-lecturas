# Santa Rosa de Lima

None · None · 1 lecturas

- [Conozcamos el amor de Cristo, que excede todo conocimiento](../r/2647f393eb.md) — Santa Rosa de Lima · Al médico Castillo: edición L. Getino, La patrona de América, Madrid 1928, pp. 54-55 · 23 de agosto Santa Rosa de Lima, virgenPatrona de América Latina — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
