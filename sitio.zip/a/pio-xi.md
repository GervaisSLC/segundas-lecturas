# Papa Pío XI

1857–1939 · Pope Pius XI · 1 lecturas

- [Derramó su sangre por la unidad de la Iglesia](../r/57601a8dee.md) — Papa Pío XI · AAS 15 [1923], 573-582 · 12 de noviembre San Josafat, obispo y mártir — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
