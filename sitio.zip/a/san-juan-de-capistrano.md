# San Juan de Capistrano

None · None · 1 lecturas

- [La vida de los clérigos virtuosos ilumina y serena](../r/b6b2d876b3.md) — San Juan de Capistrano · Parte 1, Venecia 1580, 2 · 23 de octubre San Juan de Capistrano, presbítero — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
