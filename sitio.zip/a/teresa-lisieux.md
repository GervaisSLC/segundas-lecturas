# Santa Teresa del Niño Jesús

1873–1897 · St. Thérèse of Lisieux · 1 lecturas

- [En el corazón de la Iglesia, yo seré el amor](../r/199a075336.md) — Santa Teresa del Niño Jesús · Manuscrits autobiographiques, Lisieux 1957, 227-229 · 1 de octubre Santa Teresa del Niño Jesús, virgen y doctora de la Iglesia — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
