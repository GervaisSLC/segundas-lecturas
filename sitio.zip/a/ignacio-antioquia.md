# San Ignacio de Antioquía

c. 35–107 · St. Ignatius of Antioch · 19 lecturas

- [No quiero agradar a los hombres, sino a Dios](../r/aac0d1bb9b.md) — San Ignacio de Antioquía · 1, 1-2, 2: Funck 1, 213-215 · Martes de la semana IV del Tiempo Ordinario (semana 4), año impar
- [Ser cristiano no sólo de nombre, sino también de hecho](../r/0e47fbe144.md) — San Ignacio de Antioquía · 3-4: Funck 1, 215-219 · Miércoles de la semana IV del Tiempo Ordinario (semana 4), año impar
- [Permitid que imite la pasión de mi Dios](../r/6375a11b8c.md) — San Ignacio de Antioquía · 5-6: Funck 1, 219-221 · Jueves de la semana IV del Tiempo Ordinario (semana 4), año impar
- [Os escribo en vida, pero deseando morir](../r/b460a51b8d.md) — San Ignacio de Antioquía · 7-8: Funck 1, 121-123 · Viernes de la semana IV del Tiempo Ordinario (semana 4), año impar
- [Os saluda mi espíritu y la caridad de las Iglesias](../r/ffed9a4f26.md) — San Ignacio de Antioquía · 9-10: Funck 1, 223 · Sábado de la semana IV del Tiempo Ordinario (semana 4), año impar
- [Me ofrezco como víctima de expiación](../r/986002afe9.md) — San Ignacio de Antioquía · Carta 6-8: Funck 1, 251 · Domingo de la semana IX del Tiempo Ordinario (semana 9), año impar
- [Es necesario no sólo llamarse cristianos, sino serlo en realidad](../r/9bec4bf3f9.md) — San Ignacio de Antioquía · Caps 1, 1-5,2: Funk 1, 191-195 · Viernes de la semana X del Tiempo Ordinario (semana 10), año par
- [Una sola oración y una sola esperanza en la caridad y en la santa alegría](../r/93fc0da3b2.md) — San Ignacio de Antioquía · Caps 6 1-9, 2: Funk 1,195-199 · Sábado de la semana X del Tiempo Ordinario (semana 10), año par
- [Tenéis a Cristo en vosotros](../r/130f9e8ff3.md) — San Ignacio de Antioquía · Caps 10, 1—15: Funk 1, 199-203 · Domingo de la semana XI del Tiempo Ordinario (semana 11), año par
- [Soy trigo de Dios, y he de ser molido por los dientes de las fieras](../r/12228c3735.md) — San Ignacio de Antioquía · Caps. 4, 1-2; 6, 1-8, 3: Funk 1, 217-223 · 17 de octubre San Ignacio de Antioquía, obispo y mártir — Santoral, año impar
- [Os quiero prevenir como a hijos míos amadísimos](../r/2c1505fe25.md) — San Ignacio de Antioquía · Caps 1, 1-3; 2; 4,1-2; 6,1; 7, 1-8, 1: Funk 1, 203-209 · Viernes de la semana XXI del Tiempo Ordinario (semana 21), año par
- [Convertíos en criaturas nuevas por medio de la fe, que es como la carne del Señor, y por medio de la caridad, que es como su sangre](../r/f31dedede1.md) — San Ignacio de Antioquía · Caps 8, 1-9, 2; 11, 1—13 3: Funk 1, 209-211 · Sábado de la semana XXI del Tiempo Ordinario (semana 21), año par
- [No os hablo con autoridad, como si fuera alguien](../r/fc21868788.md) — San Ignacio de Antioquía · 1-3: Funk 2, 183-185 · Domingo de la semana XXII del Tiempo Ordinario (semana 22), año par
- [En la concordia de la unidad](../r/6c2424659b.md) — San Ignacio de Antioquía · n. 4-6: Funk 2, 183-185 · Domingo de la semana XXII del Tiempo Ordinario (semana 22) - Año A: Mt 12, 21-27, año par
- [Todo lo hacéis en Cristo Jesús](../r/a284268d38.md) — San Ignacio de Antioquía · 7-9: Funk 2, 189-193 · Martes de la semana XXII del Tiempo Ordinario (semana 22), año par
- [Las cadenas, perlas espirituales](../r/2e388de472.md) — San Ignacio de Antioquía · 10-12: Funk 2, 195-197 · Miércoles de la semana XXII del Tiempo Ordinario (semana 22), año par
- [Nada mejor que la paz en Cristo](../r/83a5ee7288.md) — San Ignacio de Antioquía · 13-15: Funk 2, 197-201 · Jueves de la semana XXII del Tiempo Ordinario (semana 22), año par
- [La cruz es para nosotros salvación y vida eterna](../r/f0f069b8a1.md) — San Ignacio de Antioquía · 16-19: Funk 2,201-203 · Viernes de la semana XXII del Tiempo Ordinario (semana 22), año par
- [Doy mi vida por vosotros](../r/c2af025683.md) — San Ignacio de Antioquía · 20-21: Funk 2, 203-205 · Sábado de la semana XXII del Tiempo Ordinario (semana 22), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
