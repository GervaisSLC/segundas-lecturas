# San Quodvultdeus

d. c. 450 · St. Quodvultdeus · 1 lecturas

- [Todavía no hablan, y ya confiesan a Cristo](../r/d7169f3b32.md) — San Quodvultdeus · Sermón 2 sobre el Símbolo: PL 40, 655 · 28 de Diciembre. Santos Inocentes — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
