# La gracia del perdón es una e idéntica para todos

**Ruperto de Deutz** (c. 1075–1129) · Segunda lectura del Oficio de Lectura

- id: `d3eeb474de`
- Fuente: Del comentario de Ruperto de Deutz sobre el evangelio de san Juan
- Cita patrística: Lib 2: CCL CM 9, 60-62
- Se lee: Martes de la semana XX del Tiempo Ordinario (semana 20), año impar
- Escritura: [Ef 2, 1-10](../escritura/ef.md) (primera lectura del día); [Hb 10, 22-23](../escritura/hb.md) (responsorio); [Mc 16, 16](../escritura/mc.md) (responsorio)
- Temas (automáticos): [Bautismo](../temas/bautismo.md), [Penitencia y conversión](../temas/conversion.md), [Pecado y redención](../temas/salvacion.md), [Espíritu Santo](../temas/espiritu.md)
- Cómo citar: Ruperto de Deutz, Lib 2: CCL CM 9, 60-62, «La gracia del perdón es una e idéntica para todos». Liturgia de las Horas, Oficio de Lectura, segunda lectura, Martes de la semana XX del Tiempo Ordinario (semana 20), año impar. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-d3eeb474de](../index.html#r-d3eeb474de)
- Autor: [Ruperto de Deutz](../a/ruperto-deutz.md)

## Texto

El bautismo de Cristo es una unción real y sacerdotal, por la que el mismo ungido, con preferencia a sus compañeros, es llamado Cristo, nombre que en hebreo se traduce por Mesías, en griego es Cristo, en latín se dice Ungido. Unción con la que él es el único en ser ungido tan cumplidamente, que es capaz de ungir individualmente a los demás y hacer hijos de adopción ungidos por él, que es el Ungido por excelencia, es decir, hace que se les llame con un nombre derivado de Cristo. Es lo que indica esta expresión: Ese es el que ha de bautizar con el Espíritu Santo.

Y este bautismo no posee solamente una virtualidad, sino una doble operación. Pues Cristo bautiza con Espíritu Santo, otorgando en primer lugar el perdón de los pecados; pero bautiza confiriendo, en un segundo momento, el ornato de las diversas gracias. Del perdón de los pecados dice, efectivamente, el mismo día de la resurrección, exhalando su aliento sobre los discípulos, a quienes ciertamente ya había lavado de sus pecados en su propia sangre: Recibid el Espíritu Santo. Que iba a enviarles el Espíritu para el perdón de los pecados, lo atestigua él mismo al añadir inmediatamente: A quienes les perdonéis los pecados, les quedan perdonados; a quienes se los retengáis, les quedan retenidos.

De aquella profusión de dones, mediante la cual reparte el ornato de las diversas gracias, dice el mismo Lucas al escribir en los Hechos de los apóstoles: Juan bautizó con agua, dentro de pocos días seréis bautizados con Espíritu Santo. Así pues, nos bautiza con Espíritu Santo cuando, al bajar a la fuente bautismal y descender de una manera invisible la gracia del mismo Espíritu Santo, perdona todos los pecados de los que se bautizan. En la remisión de los pecados no existe naturalmente diferencia alguna,sino que, de modo uniforme e igualitario, la gracia del perdón es una e idéntica para todos, extinguiendo todas nuestras culpas y arrojando a lo hondo del mar todos nuestros delitos.

En cambio, en lo tocante a los dones de la gracia, no a todos se les da en la misma medida, pues a uno se le da el don de la fe, a otro hablar con inteligencia o sabiduría, a otro el don de lenguas, a otro el don de interpretarlas. El mismo y único Espíritu obra todo esto, repartiendo a cada uno en particular como a él le parece.

En los santos del nuevo Testamento vemos estos dones del que bautiza, estas insignes muestras del glorioso bautismo, dones que —según se lee— nadie de ellos recibió antes de aceptar el bautismo para el perdón de los pecados, excepto Cornelio y los que con él estaban, sobre los cuales, mientras Pedro estaba todavía hablando, cayó el Espíritu Santo, y hablaban lenguas extrañas y proclamaban la grandeza de Dios.

Por lo que a los padres del antiguo Testamento se refiere, algunos de ellos recibieron el don de curar, y, muchos, el don de profecía, aunque no habían recibido el bautismo que conlleva el perdón de los pecados. Pues es cosa averiguada que todos fueron bautizados cuando Cristo murió en la cruz, y de su costado, atravesado por la lanza, brotó un río de sangre y agua para la purificación de toda la Iglesia: de aquella que había comenzado a existir desde el principio del mundo hasta el momento mismo de su muerte; desde el primer justo, es decir, desde Abel hasta el ladrón, que, en la cruz, cuando aún no había brotado del costado de Cristo el río que provocó aquella tan enorme y tan salutífera inundación, confesó al Señor y, mediante la fe, compró su reino futuro con aquella repentina confesión.

## Responsorio (Hb 10, 22-23; Mc 16, 16)

R. Purificados los corazones de toda mala conciencia y lavado el cuerpo con agua pura, mantengamos firme la confesión de la esperanza, * pues fiel es el autor de la promesa.  
V. Quien crea y sea bautizado, será salvo.  
R. Pues fiel es el autor de la promesa.  

## Oración

Oh Dios, que has preparado bienes inefables para los que te aman, infunde tu amor en nuestros corazones, para que, amándote en todo y sobre todas las cosas consigamos alcanzar tus promesas, que superan todo deseo. Por nuestro Señor Jesucristo.

## Primera lectura del día

**De la carta a los Efesios 2, 1-10** — *Los pecadores han sido salvados en Cristo Jesús*

Hermanos:

También vosotros un tiempo estabais muertos por vuestras culpas y pecados, cuando seguíais el proceder de este mundo, según el príncipe de la potestad del aire, el espíritu que ahora actúa en los rebeldes contra Dios. Como ellos, también nosotros vivíamos en el pasado siguiendo las tendencias de la carne, obedeciendo los impulsos del instinto y de la imaginación; y, por naturaleza, estábamos destinados a la ira, como los demás. Pero Dios, rico en misericordia, por el gran amor con que nos amó, estando nosotros muertos por los pecados, nos ha hecho revivir con Cristo —estáis salvados por pura gracia—; nos ha resucitado con Cristo Jesús, nos ha sentado en el cielo con él, para revelar en los tiempos venideros la inmensa riqueza de su gracia, mediante su bondad para con nosotros en Cristo Jesús.

En efecto, por gracia estáis salvados, mediante la fe. Y esto no viene de vosotros: es don de Dios. Tampoco viene de las obras, para que nadie pueda presumir. Somos, pues, obra suya. Dios nos ha creado en Cristo Jesús, para que nos dediquemos a las buenas obras, que de antemano dispuso él que practicásemos.

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
