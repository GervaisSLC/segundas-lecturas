# Adviento y Navidad — año par

[Volver al calendario](index.md) · [Guía para IAs](../llms.txt)

## Semana I de Adviento

- **Domingo de la semana I de Adviento (semana 1)** — [Las dos venidas de Cristo](../r/74b4e0fdd3.md) — San Cirilo de Jerusalén · Catequesis 15,1-3: PG 33, 870-874
- **Domingo de la semana I de Adviento (semana 1)** — [Velad, para estar preparados](../r/560f5ec606.md) — San Pascasio Radberto · Lib. 11, cap 24: PL 120, 799-800
- **Domingo de la semana I de Adviento (semana 1)** — [A Dios no le gusta condenar, sino salvar](../r/7509359350.md) — San Agustín de Hipona · Sermón 18, 1-2: CCL 61, 245-246
- **Domingo de la semana I de Adviento (semana 1)** — [Aguardamos al Salvador](../r/8f5f226f2b.md) — San Bernardo de Claraval · Sermón 4 de Adviento 1, 3-4: Opera omnia, edit. cister. 4, 1966, 182-185
- **Lunes de la semana I de Adviento (semana 1)** — [Sobre el tiempo de Adviento](../r/eec858d849.md) — San Carlos Borromeo · Acta Ecclesiae Mediolanensis, t. 2, Lyon 1683, 916-917
- **Martes de la semana I de Adviento (semana 1)** — [¡Qué admirable intercambio!](../r/a7d27195ee.md) — San Gregorio Nacianceno · Disertación 45, 9.22.26.28: PG 36, 634-635.654.658-659.662
- **Miércoles de la semana I de Adviento (semana 1)** — [Vendrá a nosotros la Palabra del Señor](../r/17144cafbe.md) — San Bernardo de Claraval · Sermón 5 en el Adviento del Señor, 1-3: Opera omnia, Edit. cister. 4, 1966, 188-190
- **Jueves de la semana I de Adviento (semana 1)** — [Vigilad, pues vendrá de nuevo](../r/3664f76eff.md) — San Efrén · Cap. 18, 15-17: SC 121, 325-328
- **Viernes de la semana I de Adviento (semana 1)** — [El deseo de contemplar a Dios](../r/690b901ab2.md) — San Anselmo de Canterbury · Libro 1: Opera omnia, ed. Schmitt, Seckau [Austria] 1938, 1, 97-100
- **Sábado de la semana I de Adviento (semana 1)** — [La esperanza nos sostiene](../r/05c8e6f390.md) — San Cipriano de Cartago · Tratado 13.15: CSEL 3, 406-408

## Semana II de Adviento

- **Domingo de la semana II de Adviento (semana 2)** — [Una voz grita en el desierto](../r/4cf2a921bf.md) — Eusebio de Cesarea · Cap 40: PG 24, 366-367
- **Domingo de la semana II de Adviento (semana 2)** — [Convertíos, porque está cerca el Reino de los cielos](../r/6aaa580a0d.md) — San Agustín de Hipona · Serm. 109 1 : PL 38,636
- **Domingo de la semana II de Adviento (semana 2)** — [Allanad los senderos del Señor](../r/ab8b4447c4.md) — Orígenes · Hom. 22, 1-2: SC 87, 301-302
- **Domingo de la semana II de Adviento (semana 2)** — [Todos verán la salvación de Dios](../r/d22adc551d.md) — San Bernardo de Claraval · Sermón 1 en el Adviento, 9-10: Opera omnia, edit. Cist. 4, 1966, 167-169
- **Lunes de la semana II de Adviento (semana 2)** — [Dios nos habló por medio de su Hijo](../r/252dff280e.md) — San Juan de la Cruz · Libro 2, cap 22, núms. 3-4
- **Martes de la semana II de Adviento (semana 2)** — [Índole escatológica de la Iglesia peregrinante](../r/f0daad42ac.md) — Concilio Vaticano II · Núm 48
- **Miércoles de la semana II de Adviento (semana 2)** — [Las promesas de Dios se nos conceden por su Hijo](../r/146fff1983.md) — San Agustín de Hipona · Sal 109 1-3: CCL 40, 1061-1063
- **Jueves de la semana II de Adviento (semana 2)** — [El amor desea ver a Dios](../r/f2165f25b8.md) — San Pedro Crisólogo · Sermón 147 : PL 52, 594-595
- **Viernes de la semana II de Adviento (semana 2)** — [Israel echará brotes y flores](../r/780fd15fb1.md) — San Cirilo de Alejandría · Lib 3, t 1: PG 70, 593-594
- **Sábado de la semana II de Adviento (semana 2)** — [María y la Iglesia](../r/2e003688b6.md) — Isaac de Stella · Sermón 51: PL 194, 1862-1863.1865

## Semana III de Adviento

- **Domingo de la semana III de Adviento (semana 3)** — [Juan era la voz, Cristo es la Palabra](../r/c0b46ce61f.md) — San Agustín de Hipona · Sermón 293 3: PL 38, 1328-1329
- **Domingo de la semana III de Adviento (semana 3)** — [¿Eres tú el que ha de venir o tenemos que esperar a otro?](../r/e89752cee2.md) — San Ambrosio de Milán · Lib. 5, 93-95.99-102.109: CCL 14, 165-166.167-168.171-177
- **Domingo de la semana III de Adviento (semana 3)** — [En medio de vosotros hay uno que no conocéis](../r/c891ecfb3c.md) — Ruperto de Deutz · Lib. III, cap 3: SC 165, 26-28
- **Domingo de la semana III de Adviento (semana 3)** — [Seamos un edificio sólido, que ninguna tormenta consiga derribar](../r/1851822d39.md) — Orígenes · Hom. 26, 3-5: SC 87, 341-343
- [Él nos amó primero](../r/cfe704d151.md) — San Asterio de Amasea · Núms. 9-11: SC 61, 90-96
- **Martes de la semana III de Adviento (semana 3)** — [Sobre la humildad y la paz](../r/cc03e08036.md) — Tomás de Kempis (Imitación de Cristo) · Lib. 2, cap. 2-3
- **Miércoles de la semana III de Adviento (semana 3)** — [Cuando venga Cristo, Dios será visto por todos los hombres](../r/354f766de9.md) — San Ireneo de Lyon · Lib 4, 20, 4-5: SC 100, 634-640
- **Jueves de la semana III de Adviento (semana 3)** — [Cristo, plenitud de la revelación](../r/80f3938d24.md) — Concilio Vaticano II · Núms 3-4
- **Viernes de la semana III de Adviento (semana 3)** — [Tu deseo es tu oración](../r/78252551b4.md) — San Agustín de Hipona · Salmo 37, 13-14: CCL 38, 391-392

## Semana IV de Adviento

- **Viernes de la semana III de Adviento (semana 3)** — [¡Oh grande e insondable misterio!](../r/39b44efbb1.md) — San Beda el Venerable · Homilía 5 en la vigilia de Navidad: CCL 122, 32-36
- **Viernes de la semana III de Adviento (semana 3)** — [Concebirás y darás a luz un hijo](../r/3925679f6d.md) — San Beda el Venerable · Homilía 3 en el Adviento: CCL 122, 14-17
- **Viernes de la semana III de Adviento (semana 3)** — [¡Mira que viene el Rey!](../r/275b04c469.md) — Beato Guerrico de Igny · Sermón 2 en el Adviento del Señor, 1-4: SC 166, 104-116

## Navidad y su Octava

- [El niño Jesús que nos ha nacido, es la verdadera luz, la verdadera vida y la justicia verdadera](../r/214a7b77d8.md) — San Gregorio de Nisa · Homilía 3: PG 44, 827-830
- [Junto al Niño Jesús están María y José](../r/6ac6ae87ce.md) — San Juan Crisóstomo · Homilía sobre el día de Navidad: PG 56, 392
- [Al asumir la condición de esclavo, Cristo, en cierto modo, fue contado entre los siervos](../r/667d1c59bd.md) — San Cirilo de Alejandría · Homilía 12: PG 77, 1042. 1047. 1050
- [Angustiados buscamos a Jesús](../r/fcd955ab28.md) — Orígenes · Homilía 18, 2-5: Edit GCS 9, 112-113

## Ferias anteriores a la Epifanía

- [¡Levántate, brilla, que llega tu luz!](../r/b139d84e0d.md) — San Elredo de Rievaulx · Sermón 3 en la manifestación del Señor : PL 195, 228-229

## Ferias posteriores a la Epifanía

- **Domingo después del 6 de Enero. EL BAUTISMO DEL SEÑOR** — [Del seno de la Virgen nació el que es Siervo y Señor a la vez](../r/eee161dda5.md) — San Ambrosio de Milán · 4-5 : CCL 64, 52-53
- **Domingo después del 6 de Enero. EL BAUTISMO DEL SEÑOR** — [Vino a nosotros el que es el esplendor de la gloria del Padre](../r/7316e75b00.md) — San Gregorio de Neocesarea · Homilía 4 en la santa Teofanía: PG 10, 1182-1183
- **Domingo después del 6 de Enero. EL BAUTISMO DEL SEÑOR** — [Éste es mi Hijo, el amado, mi predilecto](../r/df1cf7e154.md) — San Gregorio de Antioquía · Homilía 2, 5. 6. 9. 10 en el Bautismo de Cristo: PG 88, 1875-1879. 1882-1883
- **Domingo después del 6 de Enero. EL BAUTISMO DEL SEÑOR** — [¡Venid al bautismo de la inmortalidad!](../r/bd9d6ef23f.md) — San Hipólito de Roma · En la santa Teofanía : PG 10, 858-859
