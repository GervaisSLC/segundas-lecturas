# Ley y alianza

25 lecturas (tema asignado automáticamente).

[Todos los temas](index.md) · [Guía para IAs](../llms.txt)

- [Vendrá el Señor y su doctrina superará a la ley](../r/75064d122e.md) — San Cirilo de Alejandría · Núm. 3, 32: PG 72, 330-331 · Martes de la semana III de Adviento (semana 3), año impar
- [La pasión de Cristo como premio de la piedad](../r/15aaa03b4f.md) — San Agustín de Hipona · Carta 140, 13-15, Libro sobre la gracia del nuevo Testamento: CSEL 44, 164-166 · Semana I de Cuaresma — Cuaresma y Pascua, año par
- [La circuncisión del corazón](../r/d7258f781c.md) — Afraates · Demostración 11, Sobre la circuncisión, 11-12: PS 1, 498-503 · Miércoles de la semana I de Cuaresma (semana 1), año par
- [La alianza del Señor](../r/c65064c94e.md) — San Ireneo de Lyon · Lib. 4,16, 1-5: SC 100, 564-572 · Viernes de la semana II de Cuaresma (semana 2), año par
- [Cristo es nuestro sumo sacerdote, nuestra propiciación](../r/72b0cb876b.md) — Orígenes · Homilía 9, 5. 10: PG 12, 515. 523 · Domingo de la semana IV de Cuaresma (semana 4) - Año A: Jn 9, 1-41, año par
- [La Iglesia, sacramento visible de la unidad](../r/7602f78e00.md) — Concilio Vaticano II · Núm. 9). · Domingo de la semana V de Cuaresma (semana 5) - Año A: Jn 11, 1-45, año par
- [Constantemente somos saciados con el cuerpo del Salvador y constantemente participamos de la sangre del Cordero](../r/50961e1f2f.md) — Eusebio de Cesarea · Tratado 7. 9. 10-12: PG 24, 702-706 · Jueves de la Octava de Pascua — Cuaresma y Pascua, año par
- [Cantemos al Señor el cántico del amor](../r/6da14eecd8.md) — San Agustín de Hipona · Sermón 34, 13. 56: CCL 41, 424. 426 · Domingo de la semana III de Pascua (semana 3), año par
- [Cristo ha hecho partícipes de su consagración y de su misión a los obispos por medio de los apóstoles](../r/1be233be4b.md) — Concilio Vaticano II · Capítulo III, n. 28 · Domingo de la semana IV de Pascua (semana 4) - Año A: Jn 10, 1-10, año par
- [El mandamiento nuevo](../r/90887759f2.md) — San Agustín de Hipona · Tratado 65, 1-3: CCL 36, 490-492 · Domingo de la semana V de Pascua (semana 5), año par
- [Rasgad los corazones, no las vestiduras](../r/889c5a098c.md) — San Pablo VI · AAS t. 58. 1966, 178-179 · Sábado después de Ceniza — Cuaresma y Pascua, año impar
- [Después de Moisés y la ley, Cristo se ha hecho nuestro guía](../r/6ed72fabc2.md) — San Cirilo de Alejandría · Lib. 8: PG 68, 574- 575 · Martes de la semana II de Cuaresma (semana 2), año impar
- [El pan celestial y la bebida de salvación](../r/dd269a4df0.md) — Sin identificar · Catequesis 22 [Mistagógica 4], 1. 3-6. 9: PG 33, 1098-1106 · Sábado de la Octava de Pascua — Cuaresma y Pascua, año impar
- [La rica herencia del nuevo Testamento](../r/3194ec0b23.md) — San Gaudencio de Brescia · Tratado 2, CSEL 68, 30-32 · Jueves de la semana II de Pascua (semana 2), año impar
- [Estudiad las Escrituras, pues ellas están dando testimonio de mí](../r/0360ee18db.md) — San Ambrosio de Milán · Comentario sobre el Salmo 1, 33: CSEL 64, 28-30 · Sábado de la semana X del Tiempo Ordinario (semana 10), año impar
- [Imitemos al Señor](../r/b1a26e4086.md) — San Juan Crisóstomo · Homilía 1,5 sobre la cruz y el ladrón : PG 49, 405-408 · Domingo de la semana XIV del Tiempo Ordinario (semana 14), año impar
- [Tanto en la ley como en el evangelio, el primero y principal mandamiento es amar a Dios](../r/23eb3ac28c.md) — San Ireneo de Lyon · Lib 4, 12,1—13,3: SC 100, 508-516 · Domingo de la semana XXII del Tiempo Ordinario (semana 22), año impar
- [Quiero misericordia y no sacrificios](../r/5b23edcf95.md) — San Ireneo de Lyon · Lib. 4, 17, 4-6: SC 100, 590-594 · Tiempo Ordinario, año impar
- [Muy a gusto hemos de presumir de nuestras debilidades, para que así resida en nosotros la fuerza de Dios](../r/50970e6693.md) — San Hilario de Poitiers · Tratado 3. 7. 11 sobre el Salmo 15: PL 9, 892. 894. 896. 897 · Jueves de la semana XXX del Tiempo Ordinario (semana 30), año impar
- [Al crecer el amor, el alma se siente segura](../r/2833bd0914.md) — San Agustín de Hipona · Sermón Mai 14,1-2: PLS 2, 449-450 · Semana XXXI DEL TIEMPO ORDINARIO, año impar
- [Cristo, en cuanto Hijo y Señor, se ha convertido en administrador del nuevo Testamento](../r/3c773fdfda.md) — San Cirilo de Alejandría · Lib. 4, Sermón 1: PG 70, 858-859 · Jueves de la semana XXXI del Tiempo Ordinario (semana 31), año impar
- [Meteré mi ley en su pecho](../r/ce0979b035.md) — San León Magno · Sermón 95, 1-2: CCL 138A, 582-584 · Lunes de la semana XXXIV del Tiempo Ordinario (semana 34), año impar
- [La voz de la Iglesia que resuena dulcemente](../r/c0afaadb69.md) — San Pío X · AAS 3 [1911), 633-635 · 21 de agosto San Pío X, papa — Santoral, año impar
- [Cantad a Dios con maestría y con júbilo](../r/134d9d8640.md) — San Agustín de Hipona · Salmo 32, sermón 1, 7-8: CCL 38, 253-254 · 22 de noviembre Santa Cecilia, virgen y mártir — Santoral, año impar
- [Cristo por nosotros se hizo pan](../r/716852074c.md) — Pedro de Blois · Sermón 54, sobre el sacrificio del altar : PL 207, 720-721 · Miércoles de la semana XXVIII del Tiempo Ordinario (semana 28), año par
