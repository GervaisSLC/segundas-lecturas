# San Beda el Venerable

c. 673–735 · St. Bede the Venerable · 13 lecturas

- [¡Oh grande e insondable misterio!](../r/39b44efbb1.md) — San Beda el Venerable · Homilía 5 en la vigilia de Navidad: CCL 122, 32-36 · Viernes de la semana III de Adviento (semana 3), año par
- [Concebirás y darás a luz un hijo](../r/3925679f6d.md) — San Beda el Venerable · Homilía 3 en el Adviento: CCL 122, 14-17 · Viernes de la semana III de Adviento (semana 3), año par
- [Cántico de María](../r/5cfdcbf569.md) — San Beda el Venerable · Lib. 1, 46-55: CCL 120, 37-39 · 22 de Diciembre — Santoral, año par
- [Están de pie delante del Cordero contemplando su gloria](../r/f89423ada3.md) — San Beda el Venerable · Homilía 1, 10: CCL 122, 68. 71-72 · 28 de Diciembre. Santos Inocentes — Santoral, año par
- [Jesús crecía en sabiduría, edad y gracia](../r/1ff7c8bb58.md) — San Beda el Venerable · Hom. 1, 19: CCL. 122. 134-135. 138-139 · Domingo dentro de la Octava de Navidad. LA SAGRADA FAMILIA DE JESÚS, MARÍA Y JOSÉ — Adviento y Navidad, año impar
- [María proclama la grandeza del Señor por las obras que ha hecho en ella](../r/28e9c7e8f9.md) — San Beda el Venerable · Libro 1, 4: CCL 122, 25-26. 30 · 31 de mayo. LA VISITACIÓN DE LA VIRGEN MARÍA — Santoral, año par
- [Raza elegida, sacerdocio real](../r/f079f8544b.md) — San Beda el Venerable · Capítulo 2: PL 93, 50-51 · Domingo de la semana III de Pascua (semana 3) - Año A: Lc 24, 13-35, año impar
- [Éstos son los bienes que principalmente hemos de pedir](../r/f06c6b1ae4.md) — San Beda el Venerable · Homilía 14 (CCL 122, 272-273.277-279 · Domingo de la semana XVII del Tiempo Ordinario (semana 17), año impar
- [Somos el pueblo de Dios](../r/9c470a3e48.md) — San Beda el Venerable · Homilía 1, 16: CCL 122, 117-118 · Martes de la semana XXIII del Tiempo Ordinario (semana 23), año impar
- [Precursor del nacimiento y de la muerte de Cristo](../r/1b3c5bc863.md) — San Beda el Venerable · Homilía 23: CCL 122, 354. 356-357 · 29 de agosto El Martirio de San Juan Bautista — Santoral, año impar
- [Jesús lo vio y, porque lo amó, lo eligió](../r/3e1e13b480.md) — San Beda el Venerable · Homilía 21: CCL 122,149-151 · 21 de septiembre SAN MATEO, apóstol y evangelista — Santoral, año impar
- [El Hijo del hombre vendrá con la gloria de su Padre](../r/45947dda33.md) — San Beda el Venerable · Hom. 1, 24: CCL 122, 170-171 · Viernes de la semana XXIII del Tiempo Ordinario (semana 23), año par
- [El tiempo de las bodas es aquel en que, por el misterio de la encarnación, el Señor se unió a la Iglesia](../r/1db5456fa0.md) — San Beda el Venerable · Hom. 14 : CCL 122, 95-96 · Viernes de la semana XXV del Tiempo Ordinario (semana 25), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
