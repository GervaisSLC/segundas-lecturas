# San Columbano

543–615 · St. Columban · 5 lecturas

- [Luz perenne en el templo del Pontífice eterno](../r/dfba97fbd7.md) — San Columbano · 12, 2-3 Opera, Dublín 1957, pp. 112-114 · Viernes de la semana XI del Tiempo Ordinario (semana 11), año par
- [El que tenga sed que venga a mí y que beba](../r/34e88ee304.md) — San Columbano · Instrucción sobre Cristo, fuente de vida 13, 1-2: Opera, Dublín 1957, pp. 116-118 · Martes de la semana XXVIII del Tiempo Ordinario (semana 28), año impar
- [Tú, Señor, eres todo lo nuestro](../r/5ad1b14266.md) — San Columbano · Instrucción sobre Cristo, fuente de vida 13, 2-3: Opera, Dublín 1957, pp. 118-120 · Miércoles de la semana XXVIII del Tiempo Ordinario (semana 28), año impar
- [La grandeza del hombre consiste en su semejanza con Dios, con tal de que la conserve](../r/1309b291b5.md) — San Columbano · Instrucción 11, Sobre el amor, 1-2: Opera, Dublín 1957, pp, 106-107 · El mismo día 23 de noviembre San Columbano, abad — Santoral, año impar
- [La insondable profundidad de Dios](../r/a01fe6e6fa.md) — San Columbano · Instrucción 1, 3-5 sobre la fe: Opera omnia, Dublín 1957, pp. 62-66 · Jueves de la semana XX del Tiempo Ordinario (semana 20), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
