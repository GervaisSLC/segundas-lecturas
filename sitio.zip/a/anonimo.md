# Actas y escritos anónimos

 · Anonymous acts & writings · 47 lecturas

- [La voz de la tórtola se ha escuchado en nuestra tierra](../r/381f17998a.md) — Actas y escritos anónimos · «Nicán Mupohua», 12ª edición, Buena Prensa, México, D. F., 1971, pp. 3-19. 21 · MES DE DiCIEMBRE — Santoral, año par
- [Nos fue enviado el Señor como redentor, vida y salvación](../r/6400a7b0f1.md) — Actas y escritos anónimos · Sermón 12: PLS 4, 770-771 · 22 de Diciembre — Santoral, año impar
- [El descenso del Señor al abismo](../r/7f9072e0fa.md) — Actas y escritos anónimos · PG 43, 439. 451. 462-463 · Sábado Santo — Cuaresma y Pascua, año par
- [La Pascua espiritual](../r/c9ce7e6e34.md) — Actas y escritos anónimos · PG 59, 723-724 · Domingo de la Octava de Pascua — Cuaresma y Pascua, año par
- [El bautismo, un injerto para la inmortalidad](../r/571941439e.md) — Actas y escritos anónimos · PG 28, 1080-1082 · Martes de la semana II de Pascua (semana 2), año par
- [La unidad de la Iglesia se manifiesta en la pluralidad de lenguas](../r/9295660c2b.md) — Actas y escritos anónimos · Sermón 8, 1-3: PL 65, 743-744 · Sábado de la semana VII de Pascua (semana 7), año par
- [Seréis mis testigos](../r/896dfc62cf.md) — Actas y escritos anónimos · Cap. 14,109-110: Acta Sanctorum Februarii,1, 769 · 6 de febrero. San Pablo Miki y Compañeros, Mártires — Santoral, año par
- [Acrecienta tu Iglesia y reúne a todos sus miembros en la unidad](../r/22f1964afd.md) — Actas y escritos anónimos · Cap. 18: Denkschriften der kaiserl. Akademie der Wissei schaften 19, Viena 1870, p. 246 · 14 de febrero. San Cirilo, Monje, y San Metodio, Obispo, Patronos de Europa — Santoral, año par
- [Hagamos el elogio de los hombres ilustres](../r/7ae9f1b7dd.md) — Actas y escritos anónimos · Monumenta Ordinis Servorum Beatae Maríae Virginis, 1, 3. 5. 6. 9.11: pp. 71 ss. · Mes de febrero — Santoral, año par
- [Como un sacrificio enjundioso y agradable](../r/4d7cf6151b.md) — Actas y escritos anónimos · Caps. 13, 2-5, 2: Funk 1, 297-299 · 23 de febrero. San Policarpo, Obispo y Mártir — Santoral, año par
- [Invirtió su tesoro según el mandato del Altísimo](../r/5dc0bc6209.md) — Actas y escritos anónimos · Caps. 2-3: Acta Sanctorum Martii 1, 347-348 · 4 de marzo. San Casimiro — Santoral, año par
- [Llamados y elegidos para gloria del Señor](../r/c29a94cdbf.md) — Actas y escritos anónimos · Caps. 18. 20-21: edición van Beek, Nimega 1936, pp. 42. 46-52 · 7 de marzo. Santas Perpetua y Felicidad, Mártires — Santoral, año par
- [La paciencia y caridad de Santa Francisca](../r/cf156644ef.md) — Actas y escritos anónimos · Caps. 6-7: Acta Sanctorum Martii 2, *188—*189 · 9 de marzo. Santa Francisca Romana, Religiosa — Santoral, año par
- [Se abrazó a la cruz con todo su cuerpo](../r/6888b00d7f.md) — Actas y escritos anónimos · Acta Sanctorum, Aprilis, III, pp. 186-187). · El mismo día 23 de abril. San Adalberto, Obispo y Mártir — Santoral, año par
- [Hombre fiel por su nombre y por su vida](../r/6742f68988.md) — Actas y escritos anónimos · 24 de abril. San Fidel de Sigmaringa, Presbítero y Mártir — Santoral, año par
- [Fue un prelado de grandísima caridad y amor de Dios](../r/45f4053157.md) — Actas y escritos anónimos · Archivo Secreto Vaticano, Riti-Proces., vol. 1581). · Mes de abril — Santoral, año par
- [La sangre de los mártires es semilla de cristianos](../r/d09503e9f3.md) — Actas y escritos anónimos · 28 de abril. San Pedro Chanel, Presbítero y Mártir — Santoral, año par
- [El amor lo puede todo](../r/f00fa1090a.md) — Actas y escritos anónimos · 22 de mayo. Santa Joaquina Vedruna, Religiosa — Santoral, año par
- [El poder temporal puesto al servicio de Dios y de la Iglesia](../r/a21903eec0.md) — Actas y escritos anónimos · 30 de mayo. San Fernando — Santoral, año par
- [](../r/f9f3790f54.md) — Actas y escritos anónimos · 6 de junio. San Norberto, Obispo — Santoral, año par
- [Cristo, autor de la resurrección y de la vida](../r/7a644be5b5.md) — Actas y escritos anónimos · Sermón 35, 6-9: PL 17 [ed. 1879], 696-697 · Miércoles de la Octava de Pascua — Cuaresma y Pascua, año impar
- [Por la unción recibida, los cristianos están consagrados de por vida a la cruz de Cristo](../r/49deef3d29.md) — Actas y escritos anónimos · Homilía 17, 1-4: PG 34, 623-626 · Semana XVI del Tiempo Ordinario, año impar
- [Alegría en el martirio](../r/1a55b69402.md) — Actas y escritos anónimos · Caps. 3-4 · 20 de enero San Fructuoso, Obispo y Mártir y sus Diáconos, Santos Augurio y Eulogio — Santoral, año impar
- [Proveía a la paz y tranquilidad de la Iglesia](../r/48d1a10586.md) — Actas y escritos anónimos · MGH, Scriptores 4, 792-799 · Tiempo Ordinario, año impar
- [Servidor de Cristo en la persona de los hermanos](../r/511d93b32e.md) — Actas y escritos anónimos · S. Cicatelli, Vita del P. Camillo de Lellis, Viterbo 1615 · 14 de julio San Camilo de Lelis, Presbítero — Santoral, año impar
- [¡Dios, vida mía, qué suave eres: seas siempre bendito!](../r/b3b0350d74.md) — Actas y escritos anónimos · Acta Sanctorum julii V, París 1868, pp. 884-886). · El mismo día 14 de julio San Francisco Solano, Presbítero — Tiempo Ordinario, año impar
- [Llegaréis a vuestra plenitud, según la plenitud total de Cristo](../r/f9b2209e6f.md) — Actas y escritos anónimos · 18, 7-11: PG 34, 639-642 · Viernes de la semana VI del Tiempo Ordinario (semana 6), año par
- [Sobre el fundamento de la oración](../r/ed22e2548f.md) — Actas y escritos anónimos · Hom 6, 1-3: PG 34, 518-519 · Jueves de la semana XII del Tiempo Ordinario (semana 12), año par
- [Conviene orar y hacer votos a Dios continua y atentamente](../r/eaaa797aeb.md) — Actas y escritos anónimos · Hom 33: PG 34, 741-743 · Lunes de la semana XIII del Tiempo Ordinario (semana 13), año par
- [Haz penitencia y vuelve al Señor](../r/df54d31b6c.md) — Actas y escritos anónimos · Patericon 196: CSCO, Scriptores Aethiopici, t. 54, 118-121 · Sábado de la semana XIII del Tiempo Ordinario (semana 13), año par
- [Considérate pecador si quieres llegar a ser justo](../r/087e405f59.md) — Actas y escritos anónimos · Patericon 142b: CSCO, Scriptores Aethiopici, t. 54, 62-64 · Viernes de la semana XIV del Tiempo Ordinario (semana 14), año par
- [Sobre la perfecta fe en Dios](../r/a92602f258.md) — Actas y escritos anónimos · Homilía 48,1-6: PG 34, 807-811 · Domingo de la semana XXV del Tiempo Ordinario (semana 25), año impar
- [Éste es el camino que recorrió Cristo](../r/545404835a.md) — Actas y escritos anónimos · PL 3, 312-313 · Semana XXX DEL TIEMPO ORDINARIO, año impar
- [Hablaba con Dios o de Dios](../r/64341a1ba6.md) — Actas y escritos anónimos · Libellus de principiis Ordinis Praedicatorum; Acta canonizationis sancti Dominici: Monumenta Ordinis Praedicatorum historica 16, Roma 1935, pp: 30ss.146-147 · 8 de agosto Santo Domingo de Guzmán, presbítero — Santoral, año impar
- [Es fuerte el amor como la muerte](../r/49ed6516bb.md) — Actas y escritos anónimos · Françoise-Madeleine de Chaugy, Mémoires sur la vie et les vertus de sainte Jeanne- Françoise de Chantal, III, 3: 3.a edición, París 1853, pp. 306-307 · 12 de agosto Santa Juana Francisca de Chantal, religiosa — Santoral, año impar
- [Cuando un rey juzga lealmente a los desvalidos, su trono está siempre firme](../r/811539dbd2.md) — Actas y escritos anónimos · Edición M. Weingart, Praga 1934, 974-983 · 28 de septiembre San Wenceslao, mártir — Santoral, año impar
- [El Pilar, lugar privilegiado de oración t de gracia](../r/12e42598a5.md) — Actas y escritos anónimos · 12 de octubre NUESTRA SEÑORA DEL PILAR — Santoral, año impar
- [Tendía siempre hacia Dios](../r/3d4c2ac009.md) — Actas y escritos anónimos · Acta Sanctorum Octobris 8, 1853, 201-202 · 16 de octubre Santa Eduvigis, religiosa — Santoral, año impar
- [Isabel reconoció y amó a Cristo en la persona de los pobres](../r/1096e82e1a.md) — Actas y escritos anónimos · Al Sumo pontífice, año 1232: A. Wyss, Hessisches Urkundenbuch 1, Leipzig 1879, 31-35 · 17 de noviembre Santa Isabel de Hungría — Santoral, año impar
- [Que nadie desespere por la gravedad de sus pecados](../r/2e16f6e3c8.md) — Actas y escritos anónimos · Sermón 4, 2-7: SC 161, 170-175 · Martes de la semana XXI del Tiempo Ordinario (semana 21), año par
- [Cristo quiso salvar a los que estaban a punto de perecer](../r/9044b9826e.md) — Actas y escritos anónimos · Caps 1, 1-2,7: Funk 1, 145-149 · Jueves de la semana XXXIII del Tiempo Ordinario (semana 33), año par
- [Confesemos a Dios con nuestras obras](../r/342902a7bd.md) — Actas y escritos anónimos · Caps 3-4, 5; 7, 1-6: Funk 1, 149-152 · Viernes de la semana XXXIII del Tiempo Ordinario (semana 33), año par
- [El arrepentimiento de un corazón sincero](../r/d20a4e07ea.md) — Actas y escritos anónimos · Caps 8, 1-9,11: Funk 1, 152-156 · Sábado de la semana XXXIII del Tiempo Ordinario (semana 33), año par
- [Perseveremos en la esperanza](../r/488932356d.md) — Actas y escritos anónimos · 10, 1-12,1; 13, 1: Funk 1, 157-159 · Domingo de la semana XXXIV del Tiempo Ordinario (semana 34) - Año A: Mt 25, 31-46, año par
- [La Iglesia viva es el cuerpo de Cristo](../r/b6823698de.md) — Actas y escritos anónimos · Caps 13, 2-14, 5: Funk 1, 159-161 · Martes de la semana XXXIV del Tiempo Ordinario (semana 34), año par
- [Convirtámonos a Dios, que nos llama](../r/fcca96fd11.md) — Actas y escritos anónimos · Caps 15, 1-17, 2: Funk 1, 161-167 · Miércoles de la semana XXXIV del Tiempo Ordinario (semana 34), año par
- [Practiquemos el bien, para que al fin nos salvemos](../r/71016dbe6c.md) — Actas y escritos anónimos · Caps 18,1—20,5 Funk 1, 167-171 · Jueves de la semana XXXIV del Tiempo Ordinario (semana 34), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
