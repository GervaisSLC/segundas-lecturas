# Tenemos a Cristo que es nuestra paz y nuestra luz

**San Gregorio de Nisa** (c. 335–395) · Segunda lectura del Oficio de Lectura

- id: `ff2e247cbc`
- Fuente: Del tratado de san Gregorio de Nisa, sobre el perfecto modelo del cristiano
- Cita patrística: PG 46, 259-262
- Se lee: Lunes de la semana XX del Tiempo Ordinario (semana 20), año impar
- Escritura: [Ef 1, 15-23](../escritura/ef.md) (primera lectura del día); [Lc 1, 78. 79](../escritura/lc.md) (responsorio)
- Temas (automáticos): [Paz y unidad](../temas/paz.md), [Santidad y perfección](../temas/santidad.md), [Muerte y difuntos](../temas/muerte.md)
- Cómo citar: San Gregorio de Nisa, PG 46, 259-262, «Tenemos a Cristo que es nuestra paz y nuestra luz». Liturgia de las Horas, Oficio de Lectura, segunda lectura, Lunes de la semana XX del Tiempo Ordinario (semana 20), año impar. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-ff2e247cbc](../index.html#r-ff2e247cbc)
- Autor: [San Gregorio de Nisa](../a/gregorio-nisa.md)

## Texto

El es nuestra paz, él ha hecho de los dos pueblos una sola cosa. Teniendo en cuenta que Cristo es la paz, mostraremos la autenticidad de nuestro nombre de cristianos si, con nuestra manera de vivir, ponemos de manifiesto la paz que reside en nosotros y que es el mismo Cristo. Él ha dado muerte al odio, como dice el Apóstol. No permitamos, pues, de ningún modo que este odio reviva en nosotros, antes demostremos que está del todo muerto. Dios, por nuestra salvación, le dio muerte de una manera admirable; ahora, que yace bien muerto, no seamos nosotros quienes lo resucitemos en perjuicio de nuestras almas, con nuestras iras y deseos de venganza.

Ya que tenemos a Cristo, que es la paz, nosotros también matemos el odio, de manera que nuestra vida sea una prolongación de la de Cristo, tal como lo conocemos por la fe. Del mismo modo que él, derribando la barrera de separación, de los dos pueblos creó en su persona un solo hombre, estableciendo la paz, así también nosotros atraigámonos la voluntad no sólo de los que nos atacan desde fuera, sino también de los que entre nosotros promueven sediciones, de modo que cese ya en nosotros esta oposición entre las tendencias de la carne y del Espíritu, contrarias entre sí; procuremos, por el contrario, someter a la ley divina la prudencia de nuestra carne, y así, superada esta dualidad que hay en cada uno de nosotros, esforcémonos en reedificarnos a nosotros mismos, de manera que formemos un solo hombre, y tengamos paz en nosotros mismos.

La paz se define como la concordia entre las partes disidentes. Por esto, cuando cesa en nosotros esta guerra interna, propia de nuestra naturaleza, y conseguimos la paz, nos convertimos nosotros mismos en paz, y así demostramos en nuestra persona la veracidad y propiedad de este apelativo de Cristo.

Además, considerando que Cristo es la luz verdadera sin mezcla posible de error alguno, nos damos cuenta de que también nuestra vida ha de estar iluminada con los rayos de la luz verdadera. Los rayos del sol de justicia son las virtudes que de él emanan para iluminarnos, para que dejemos las actividades de las tinieblas y nos conduzcamos como en pleno día, con dignidad, y, apartando de nosotros las ignominias que se cometen a escondidas y obrando en todo a plena luz, nos convirtamos también nosotros en luz, y, según es propio de la luz, iluminemos a los demás con nuestras obras.

Y si tenemos en cuenta que Cristo es nuestra santificación, nos abstendremos de toda obra y pensamiento malo e impuro, con lo cual demostraremos que llevamos con sinceridad su mismo nombre, mostrando la eficacia de esta santificación no con palabras, sino con los actos de nuestra vida.

## Responsorio (Cf. Lc 1, 78. 79)

R. Vendrá a visitarnos de lo alto un sol que surge: * Guiará nuestros pasos por el camino de la paz.  
V. Iluminará a los que viven en tiniebla y en sombra de muerte.  
R. Guiará nuestros pasos por el camino de la paz.  

## Oración

Oh Dios, que has preparado bienes inefables para los que te aman, infunde tu amor en nuestros corazones, para que, amándote en todo y sobre todas las cosas consigamos alcanzar tus promesas, que superan todo deseo. Por nuestro Señor Jesucristo.

## Primera lectura del día

**De la carta a los Efesios 1, 15-23** — *Oración de Pablo para que los fieles sean iluminados*

Hermanos:

Habiendo oído hablar de vuestra fe en Cristo y de vuestro amor a todos los santos, no ceso de dar gracias por vosotros, recordándoos en mis oraciones, a fin de que el Dios de nuestro Señor Jesucristo, el Padre de la gloria, os dé espíritu de sabiduría y revelación para conocerlo, e ilumine los ojos de vuestro corazón para que comprendáis cuál es la esperanza a la que os llama, cuál la riqueza de gloria que da en herencia a los santos, y cuál la extraordinaria grandeza de su poder en favor de nosotros, los creyentes, según la eficacia de su fuerza poderosa, que desplegó en Cristo, resucitándolo de entre los muertos y sentándolo a su derecha en el cielo, por encima de todo principado, poder, fuerza y dominación, y por encima de todo nombre conocido, no solo en este mundo, sino en el futuro.

Y todo lo puso bajo sus pies, y lo dio a la Iglesia, como Cabeza, sobre todo. Ella es su cuerpo, plenitud del que llena todo en todos.

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
