# San Pedro Claver

None · None · 1 lecturas

- [Enviado para dar la Buena Noticia a los que sufren, para vendar los corazones desgarrados, para proclamar la amnistía a los cautivos.](../r/1d47679640.md) — San Pedro Claver · Epist. diei 31 maii 1627 ad Superiorem suum data; Edit (in lingua hispanica) A. Valtierra, S.L., San Pedro Claver, Cartagena, 1964, pp. 140-141 · 9 de septiembre San Pedro Claver, presbítero — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
