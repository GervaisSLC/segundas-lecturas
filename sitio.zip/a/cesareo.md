# San Cesáreo de Arlés

c. 470–542 · St. Caesarius of Arles · 9 lecturas

- [El que dé testimonio de la verdad será mártir de Cristo](../r/3f9a1fd8c0.md) — San Cesáreo de Arlés · Sermón 225, 1-2: CCL 104, 888-889 · 21 de mayo. San Cristóbal Magallanes, Presbítero, y Compañeros, Mártires — Santoral, año par
- [Inclinaos bajo la poderosísima mano de Dios](../r/fe8a505dfd.md) — San Cesáreo de Arlés · Sermón 114, 1.4: CCL 104, 593-595 · Domingo de la semana III del Tiempo Ordinario (semana 3), año impar
- [La sabiduría de Dios en la obra de la redención](../r/33ace1b87f.md) — San Cesáreo de Arlés · Sermón 11, 1. 4. 6: CCL 103, 54. 56-57 · Domingo de la semana IV del Tiempo Ordinario (semana 4), año impar
- [Alegrémonos, pues hemos merecido ser templo de Dios](../r/36229c5e51.md) — San Cesáreo de Arlés · Sermón 229, 2: CCL 104, 905-907 · Sábado de la semana XVI del Tiempo Ordinario (semana 16), año impar
- [El pueblo cristiano, apoyándose en la humildad, se eleva a la cumbre de la virtud](../r/82f5d5d1e4.md) — San Cesáreo de Arlés · Sermón 90, 4.6: CCL 103, 372.373. 374 · Miércoles de la semana V del Tiempo Ordinario (semana 5), año par
- [La misericordia divina y la misericordia humana](../r/7313f6cdba.md) — San Cesáreo de Arlés · Sermón 25, 1: CCL 103, 111-112 · Lunes de la semana VIII del Tiempo Ordinario (semana 8), año par
- [No es duro lo que manda aquel que ayuda a realizar lo que ordena](../r/cc26755d11.md) — San Cesáreo de Arlés · Sermón 159,1.4-6: CCL 104, 652-654 · Domingo de la semana XXIV del Tiempo Ordinario (semana 24), año impar
- [Todos, por el bautismo, hemos sido hechos templos de Dios](../r/eace2796dd.md) — San Cesáreo de Arlés · Sermón 229,1-3: CCL 104, 905-908 · 6 de noviembre Mártires de España del Siglo XX — Santoral, año impar
- [¿Cómo seguir a Cristo?](../r/4059fdf75c.md) — San Cesáreo de Arlés · Sermón 159, 1. 3-6: CCL 104, 650. 652-654 · 25 de noviembre Santa Catalina de Alejandría, virgen y mártir — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
