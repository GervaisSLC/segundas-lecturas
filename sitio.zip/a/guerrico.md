# Beato Guerrico de Igny

c. 1070–1157 · Bl. Guerric of Igny · 5 lecturas

- [¡Mira que viene el Rey!](../r/275b04c469.md) — Beato Guerrico de Igny · Sermón 2 en el Adviento del Señor, 1-4: SC 166, 104-116 · Viernes de la semana III de Adviento (semana 3), año par
- [María, Madre de Cristo y Madre de los cristianos](../r/8c0548eac7.md) — Beato Guerrico de Igny · Sermón 1 en la Asunción de santa María: PL 185,187-189 · Común de Santa maría virgen — Comunes, año par
- [Dios me libre de gloriarme si no es en la cruz de nuestro Señor Jesucristo](../r/ec509944c5.md) — Beato Guerrico de Igny · Sermón 2, 1 en el Domingo de Ramos: PL 185, 130-131 · Miércoles Santo — Cuaresma y Pascua, año impar
- [Velad, para que os ilumine la luz de la mañana](../r/d34dcc30b7.md) — Beato Guerrico de Igny · Sermón 3 sobre la Resurrección del Señor (3.5: SC 202,250-252.256-258 · Domingo de la semana XIII del Tiempo Ordinario (semana 13), año par
- [¡Oh preclara herencia de los pobres!](../r/8f246de85c.md) — Beato Guerrico de Igny · Sermón 5.6.7 en la solemnidad de Todos los Santos: SC 202, 508.510.512.514 · Martes de la semana XXIX del Tiempo Ordinario (semana 29), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
