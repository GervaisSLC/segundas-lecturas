# San Pedro Canisio

1521–1597 · St. Peter Canisius · 1 lecturas

- [Una plegaria de San Pedro Canisio](../r/e2930f2779.md) — San Pedro Canisio · Edición O. Braunsberger, Petri Canisii Epistulae et Acta, I, Friburgo de Brisgovia 1896, pp. 53-55 · 21 de diciembre. San Pedro Canisio Presbítero y Doctor de la Iglesia — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
