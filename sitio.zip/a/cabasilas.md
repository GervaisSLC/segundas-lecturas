# San Nicolás Cabasilas

c. 1322–1392 · St. Nicholas Cabasilas · 12 lecturas

- [Cristo nos ha abierto las puertas de la eternidad](../r/d4939584b9.md) — San Nicolás Cabasilas · Lib. 1: PG 150, 510-511 · Miércoles de la semana II de Pascua (semana 2), año par
- [Los sagrados misterios nos unen a Cristo](../r/0bb696bafd.md) — San Nicolás Cabasilas · Lib. 2: PG 150, 522-523 · Miércoles de la semana III de Pascua (semana 3), año par
- [Cristo es al mismo tiempo sacerdote y altar, ofrenda y oferente, sujeto y objeto de la ofrenda](../r/9f9c046a35.md) — San Nicolás Cabasilas · Lib. 3: PG 150, 578-579 · Martes de la semana V de Pascua (semana 5), año par
- [Si moramos en Cristo, ¿qué más podemos desear?](../r/d18f6b0c49.md) — San Nicolás Cabasilas · Lib. 4: PG 150, 582-583 · Miércoles de la semana V de Pascua (semana 5), año par
- [La unción del Espíritu Santo](../r/8f4e53a22c.md) — San Nicolás Cabasilas · Lib. 6: PG 150, 574-575 · Jueves de la semana V de Pascua (semana 5), año par
- [Jesús mismo es el premio y la corona de los combatientes](../r/2f3da720ed.md) — San Nicolás Cabasilas · Tratado 6: PG 150, 678-679 · Miércoles de la semana VI del Tiempo Ordinario (semana 6), año impar
- [He venido para que tengan vida](../r/a3d804ce2b.md) — San Nicolás Cabasilas · Lib. 1: PG 150, 510-511 · Viernes de la semana XIX del Tiempo Ordinario (semana 19), año impar
- [Siento en mi interior la voz de un agua viva que me habla y me dice: «Ven al Padre»](../r/8f48d496e5.md) — San Nicolás Cabasilas · Lib 1: PG 150, 494-495 · Domingo de la semana XXVIII del Tiempo Ordinario (semana 28) - Año A: Mt 22, 1-14, año par
- [A través de los sacramentos, el sol de justicia penetra en este mundo tenebroso](../r/fcfac63708.md) — San Nicolás Cabasilas · Lib 1: PG 150, 502-503 · Martes de la semana XXVIII del Tiempo Ordinario (semana 28), año par
- [La bondad de Dios es inexplicable](../r/ade73bb72c.md) — San Nicolás Cabasilas · Lib 1 PG 150, 498-499 · Jueves de la semana XXVIII del Tiempo Ordinario (semana 28), año par
- [Sobre la victoria de Cristo](../r/b4f7430136.md) — San Nicolás Cabasilas · Lib 1: PG 150, 515-518 · Domingo de la semana XXIX del Tiempo Ordinario (semana 29) - Año A: Mt 22, 15-21, año par
- [Cristo en persona es nuestro arquetipo](../r/cbb9bcbdc9.md) — San Nicolás Cabasilas · Lib 6: PG 150, 678-679 · Jueves de la semana XXX del Tiempo Ordinario (semana 30), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
