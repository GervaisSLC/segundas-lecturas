# San Antonio María Claret

None · None · 1 lecturas

- [Nos apremia el amor de Cristo](../r/dd13e3753f.md) — San Antonio María Claret · L'egoismo vinto, Roma 1869, 60; Autobiografía, cap. 34 · 24 de octubre San Antonio María Claret, obispo — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
