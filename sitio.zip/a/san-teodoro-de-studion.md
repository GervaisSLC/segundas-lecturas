# San Teodoro de Studion

None · None · 1 lecturas

- [Preciosa y vivificante es la cruz de Cristo](../r/cfe15187f0.md) — San Teodoro de Studion · PG 99, 691-694. 695 · Viernes de la semana II de Pascua (semana 2), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
