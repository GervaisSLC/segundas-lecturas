# San Lorenzo Justiniano

1381–1456 · St. Lawrence Justinian · 1 lecturas

- [María conservaba todas estas cosas en su corazón](../r/37ad439682.md) — San Lorenzo Justiniano · Sermón X, en la fiesta de la Purificación de la Santísima Virgen María: Opera 2, Venecia 1751, 38-39 · Mes de mayo — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
