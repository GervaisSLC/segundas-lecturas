# San Ildefonso de Toledo

607–667 · St. Ildephonsus of Toledo · 1 lecturas

- [En el Bautismo, Cristo es quien bautiza](../r/f0cdccf1a9.md) — San Ildefonso de Toledo · Caps. 15-16: PL 96,117-118 · 23 de enero San Ildefonso, Obispo — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
