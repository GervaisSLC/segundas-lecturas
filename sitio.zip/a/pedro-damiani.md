# San Pedro Damiani

1007–1072 · St. Peter Damian · 4 lecturas

- [Tras la tristeza, espera con alegría el gozo](../r/a4e4ddf3a0.md) — San Pedro Damiani · Libro 8, 6: PL 144, 473-476 · 21 de febrero. San Pedro Damiani, Obispo y Doctor de la Iglesia — Santoral, año par
- [Protegido inexpugnablemente con el estandarte de la cruz](../r/be481cb2ad.md) — San Pedro Damiani · Sermón 3, Sobre san Jorge: PL 144, 567-571 · 23 de abril. San Jorge, Mártir — Santoral, año par
- [Se negó a sí mismo para seguir a Cristo](../r/b8e63fc831.md) — San Pedro Damiani · Caps. 31 y 69: PL 144, 982-983.1005-1006 · 19 de junio San Romualdo, Abad — Santoral, año impar
- [La comunión de los santos en la unidad de la fe](../r/2926f32127.md) — San Pedro Damiani · Opúsculo 11, 56.10: PL 145, 235-236. 239 · Miércoles de la semana XXX del Tiempo Ordinario (semana 30), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
