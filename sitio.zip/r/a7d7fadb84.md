# El que por nosotros se hizo mortal, es confesado Rey y Señor

**San Odilón de Cluny** (c. 962–1049) · Segunda lectura del Oficio de Lectura

- id: `a7d7fadb84`
- Fuente: De los sermones de San Odilón de Cluny
- Cita patrística: Sermón 9 en el día de Pentecostés : PL 142, 1015-1016
- Se lee: 10 de Enero o Jueves después del Domingo de Epifanía — Santoral, año par; 10 de Enero o Jueves después del Domingo de Epifanía — Santoral, año impar
- Escritura: [Is 59, 15-21](../escritura/is.md) (primera lectura del día); [Sal 129, 7-8](../escritura/sal.md) (responsorio); [Tt 2, 13-14](../escritura/tt.md) (responsorio)
- Temas (automáticos): [Bautismo](../temas/bautismo.md), [Santidad y perfección](../temas/santidad.md), [Fe](../temas/fe.md), [Pastores y ministerio](../temas/pastores.md)
- Cómo citar: San Odilón de Cluny, Sermón 9 en el día de Pentecostés : PL 142, 1015-1016, «El que por nosotros se hizo mortal, es confesado Rey y Señor». Liturgia de las Horas, Oficio de Lectura, segunda lectura, 10 de Enero o Jueves después del Domingo de Epifanía — Santoral, año par. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-a7d7fadb84](../index.html#r-a7d7fadb84)
- Autor: [San Odilón de Cluny](../a/odilon.md)

## Texto

Nace Cristo de una Virgen inmaculada, para que el maculado nacimiento humano se remontara a su origen espiritual. Quiso ser circuncidado según la ley para demostrar que él es el autor de la ley, y para que nosotros, circuncidados a ejemplo suyo en el gozo del Espíritu, es decir, instruidos en las cosas celestiales, fuéramos capaces de entrar en la construcción de la celeste edificación.

Luego, adorado por los magos, recibe la significativa ofrenda de los tres dones, para que quien por nosotros se había hecho mortal, fuera reconocido como Rey y Señor de los siglos. Quiso también ser presentado en el templo y aceptó que se ofrecieran por él una tórtola y una paloma, dándonos ejemplo, para que cuando nos acerquemos al altar, inmolemos víctimas de castidad, de inocencia y de las demás virtudes.

A los doce años se queda en el templo sin saberlo la Virgen Madre. Se le busca inmediatamente con rapidez y solicitud amorosa, y se le encuentra sentado en medio de los maestros, no enseñando, sino aprendiendo y escuchando. Y al preguntarle su madre por qué se quedó sin decírselo, le responde que está en la casa de su Padre. Estos episodios de la infancia de Jesús tienen el refrendo de la autoridad de la fe católica. Indudablemente, cuando Jesús es buscado por su madre, se le reconoce como verdadero hombre; y cuando asegura que es conveniente que él esté en la casa de su Padre, todo creyente le reconoce como verdadero y único Hijo de Dios. Sentado en medio de los maestros, escuchándolos y haciéndoles preguntas, nos indica que nadie debe arrogarse el ministerio de la predicación antes de llegar a la edad adulta.

Conviene también saber que el magisterio de la Iglesia no aprueba de la infancia de Jesús más que datos de los que el evangelio nos ha conservado. Sin embargo —y ahí está la fe de los creyentes para corroborarlo—, Jesús recorrió todo el abanico de las debilidades inherentes a la humanidad asumida, a excepción del pecado, si bien el Dios oculto en el hombre permaneció siempre impasible. Y aun cuando el Hijo de Dios no tenía ninguna necesidad de ser limpiado o purificado, sin embargo en un día concreto de su vida y en un determinado momento, esto es, a los treinta años de edad, recibió aquel singular y singularmente saludable misterio del bautismo. Y al recibirlo, lo santificó; y al santificarlo lo legó, como don celeste, a todos los fieles para que por su medio fueran santificados.

Pero si es cierto que concedió la posibilidad de bautizar a los ministros de la Iglesia, se reservó para sí —reivindicándola como prerrogativa singular— la potestad de bautizar. Tenemos la prueba en la voz divina que habló a san Juan, varón de gran mérito, cuando Jesús no dudó dirigirse a él para ser bautizado: Aquel sobre quien veas —dijo— bajar el Espíritu y posarse sobre él, ése es el que ha de bautizar con Espíritu Santo. Pues bien, el amigo del Esposo, es fiel y humilde Precursor, aquel de quien afirmó la Verdad no haber nacido de mujer otro más grande que él, aquel a quien la sagrada palabra del evangelio nos presenta bautizando y predicando el bautismo, dice: Yo os bautizo con agua, pero el que viene detrás, él os bautizará con Espíritu Santo y fuego.

## Responsorio (Sal 129, 7-8; Tt 2, 13-14)

R. Sólo en el Señor está el amor, la redención copiosa. * Él redimirá a Israel de todos sus pecados.  
V. El Salvador nuestro Jesucristo se entregó por nosotros a fin de rescatarnos de toda iniquidad.  
R. Él redimirá a Israel de todos sus pecados.  

## Oración

Oh Dios, que por medio de tu Hijo has hecho clarear para todos los pueblos la aurora de tu eternidad, concede a tu pueblo reconocer la gloria de su Redentor y llegar un día a la luz eterna. Por nuestro Señor Jesucristo.

## Primera lectura del día

**Del libro del profeta Isaías 59, 15-21** — *El Señor viene*

Falta la honestidad: quien se aparta del mal queda arruinado.

Todo esto ha visto el Señor y no soporta que ya no haya justicia.

El Señor ha visto consternado que nadie interviene. Su poder lo socorre, su justicia lo apoya.

Se pone la justicia como armadura, la salvación como yelmo, se viste la túnica de la venganza, y se cubre con el manto de la indignación.

A cada uno pagará su merecido: furor para sus adversarios, represalia para sus enemigos. A las islas dará su merecido.

Temerán los de Occidente el nombre del Señor, los de Oriente su gloria, porque viene como un torrente el enemigo, empujado por el soplo del Señor.

Pero el Señor llega como libertador para Sión y para quienes abandonan su rebelión en Jacob —oráculo del Señor—.

Este es mi pacto con ellos —dice el Señor—: Mi espíritu, que está sobre ti, mis palabras que puse en tu boca, no se apartarán de tu boca, de la boca de tu descendencia, ni de la boca de la progenie de tu descendencia —dice el Señor—, desde ahora y para siempre.

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
