# San Cirilo

None · None · 1 lecturas

- [Su gloria llenará la tierra](../r/c13c788e3c.md) — San Cirilo · Lib. 4, or. 1: PG 70, 859-861 · Miércoles de la semana II de Adviento (semana 2), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
