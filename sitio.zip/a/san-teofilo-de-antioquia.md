# San Teófilo de Antioquía

None · None · 1 lecturas

- [Dichosos los limpios de corazón, porque ellos verán a Dios](../r/f9227e0c2e.md) — San Teófilo de Antioquía · Lib. 1, 2. 7: PG 6, 1026-1027. 1035 · Miércoles de la semana III de Cuaresma (semana 3), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
