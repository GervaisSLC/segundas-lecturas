# San Bernardino de Siena

1380–1444 · St. Bernardine of Siena · 3 lecturas

- [El Nombre de Jesús, el gran fundamento de la fe](../r/9ba66f290c.md) — San Bernardino de Siena · Sermón 49, art. 1: Opera omnia 4, 495ss. · 3 de enero. SANTO NOMBRE DE JESÚS — Santoral, año par
- [Protector y custodio fiel](../r/4cce2cca16.md) — San Bernardino de Siena · Sermón 2, Sobre san José: Opera omnia 7,16. 27-30 · 19 de marzo. SAN JOSÉ, Esposo de la Virgen María — Santoral, año par
- [El Nombre de Jesús, luz de los predicadores](../r/e8c6cdba6c.md) — San Bernardino de Siena · Sermón 49, sobre el glorioso nombre de Jesucristo, cap. 2: Opera omnia 4, 505-506 · 20 de mayo. San Bernardino de Siena, Presbítero — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
