# En Cristo fuimos tentados, en él vencimos al diablo

**San Agustín de Hipona** (354–430) · Segunda lectura del Oficio de Lectura

- id: `de2cf91fb5`
- Fuente: De los comentarios de san Agustín, obispo, sobre los salmos
- Cita patrística: Comentario sobre el salmo 60, 2-3: CCL 39, 766
- Se lee: Semana I de Cuaresma — Cuaresma y Pascua, año par; Semana I de Cuaresma — Cuaresma y Pascua, año impar
- Escritura: [Ex 6, 1](../escritura/ex.md) (primera lectura del día); [Jr 1, 19](../escritura/jr.md) (responsorio); [Jr 39, 18](../escritura/jr.md) (responsorio)
- Temas (automáticos): [Paciencia en la prueba](../temas/tribulacion.md), [Oración](../temas/oracion.md)
- Cómo citar: San Agustín de Hipona, Comentario sobre el salmo 60, 2-3: CCL 39, 766, «En Cristo fuimos tentados, en él vencimos al diablo». Liturgia de las Horas, Oficio de Lectura, segunda lectura, Semana I de Cuaresma — Cuaresma y Pascua, año par. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-de2cf91fb5](../index.html#r-de2cf91fb5)
- Traducción inglesa antigua (dominio público, no litúrgica): https://www.newadvent.org/fathers/1801060.htm
- Autor: [San Agustín de Hipona](../a/agustin.md)

## Texto

Dios mío, escucha mi clamor, atiende a mi súplica. ¿Quién es el que habla? Parece que sea uno solo. Pero veamos si es uno solo: Te invoco desde los confines de la tierra con el corazón abatido. Por lo tanto, si invoca desde los confines de la tierra, no es uno solo; y, sin embargo, es uno solo, porque Cristo es uno solo, y todos nosotros somos sus miembros. ¿Y quién es ese único hombre que clama desde los confines de la tierra? Los que invocan desde los confines de la tierra son los llamados a aquella herencia, a propósito de la cual se dijo al mismo Hijo: Pídemelo: te daré en herencia las naciones, en posesión, los confines de la tierra. De manera que quien clama desde los confines de la tierra es el cuerpo de Cristo, la heredad de Cristo, la única Iglesia de Cristo, esta unidad que formamos todos nosotros.

Y ¿qué es lo que pide? Lo que he dicho antes: Dios mío, escucha mi clamor, atiende a mi súplica; te invoco desde los confines de la tierra. O sea: «Esto que pido, lo pido desde los confines de la tierra», es decir, desde todas partes.

Pero, ¿por qué ha invocado así? Porque tenía el corazón abatido. Con ello da a entender que el Señor se halla presente en todos los pueblos y en los hombres del orbe entero no con gran gloria, sino con graves tentaciones.

Pues nuestra vida en medio de esta peregrinación no puede estar sin tentaciones, ya que nuestro progreso se realiza precisamente a través de la tentación, y nadie se conoce a sí mismo si no es tentado, ni puede ser coronado si no ha vencido, ni vencer si no ha combatido, ni combatir si carece de enemigo y de tentaciones.

Este que invoca desde los confines de la tierra está angustiado, pero no se encuentra abandonado. Porque a nosotros mismos, esto es, a su cuerpo, quiso prefigurarnos también en aquel cuerpo suyo en el que ya murió, resucitó y ascendió al cielo, a fin de que sus miembros no desesperen de llegar adonde su cabeza los precedió.

De forma que nos incluyó en sí mismo cuando quiso verse tentado por Satanás. Nos acaban de leer que Jesucristo, nuestro Señor, se dejó tentar por el diablo. ¡Nada menos que Cristo tentado por el diablo! Pero en Cristo estabas siendo tentado tú, porque Cristo tenía de ti la carne, y de él procedía para ti la salvación; de ti procedía la muerte para él, y de él para ti la vida; de ti para él los ultrajes, y de él para ti los honores; en definitiva, de ti para él la tentación, y de él para ti la victoria.

Si hemos sido tentados en él, también en él vencemos al diablo. ¿Te fijas en que Cristo fue tentado, y no te fijas en que venció? Reconócete a ti mismo tentado en él, y reconócete también vencedor en él. Podía haber evitado al diablo; pero, si no hubiese sido tentado, no te habría aleccionado para la victoria cuando tú fueras tentado.

## Nota

> El camino de la cuaresma es paralelo al de la historia de salvación que hoy comienza a narrarse en las primeras lecturas de la misa del primer Domingo a partir del pecado de los primeros padres (ciclo A), del pacto sellado por Dios con Noé tras el diluvio (ciclo B) y de la llamada "profesión de fe Israelita" (ciclo C) que nos lleva hasta Abrahán.

> Los apóstoles se sirvieron de estos mismos misterios para hablarnos de la gracia que sobreabunda por encima del pecado, del bautismo que tuvo una imagen profética en el diluvio y de la fe cristiana que no anula, sino que perfecciona la del pueblo elegido.

> Jesús, después de ser bautizado, mantuvo en el desierto un combate singular con Satanás que representa las tentaciones que hubo de superar toda su vida para ser fiel al Padre; de este modo el Señor es modelo para el cristiano que desea superar el pecado y hace penitencia. Jesús imita también en su retiro de cuarenta días a los antiguos profetas Moisés y Elías, como lo hace ahora la Iglesia siguiendo su ejemplo.

## Responsorio (Jr 1, 19; 39, 18)

R. Lucharán contra ti, pero no podrán contigo; * porque yo estoy contigo para librarte —oráculo del Señor—.  
V. No caerás a espada, salvarás tu vida porque confiaste en mí.  
R. Porque yo estoy contigo para librarte —oráculo del Señor—.  

## Primera lectura del día

**Del libro del Éxodo 5, 1—6, 1** — *Opresión del pueblo de Dios*

En aquellos días Moisés y Aarón se presentaron al faraón y le dijeron:

«Así dice el Señor, el Dios de Israel: “Deja salir a mi pueblo, para que celebre una fiesta en mi honor en el desierto”».

Respondió el faraón:

«¿Quién es el Señor para que tenga que obedecerle dejando marchar a Israel? No conozco al Señor ni dejaré marchar a Israel».

Replicaron ellos:

«El Dios de los hebreos se nos ha aparecido: tenemos que hacer un viaje de tres jornadas por el desierto, para ofrecer sacrificios al Señor, nuestro Dios, de lo contrario nos herirá con peste o espada».

El rey de Egipto les dijo:

«¿Por qué, Moisés y Aarón, soliviantáis al pueblo en su trabajo? Volved a vuestras tareas».

Y añadió el faraón:

«Ahora que son más numerosos que los naturales de la tierra, ¿queréis que dejen sus tareas?».

Aquel día el faraón ordenó a los capataces y a los inspectores:

«No volváis a proveer de paja al pueblo para fabricar adobes, como hacíais antes; que ellos vayan y se busquen la paja. Pero les exigiréis la misma cantidad de adobes que hacían antes, sin disminuir nada. Son unos holgazanes y por eso andan gritando: “Vamos a ofrecer sacrificios a nuestro Dios”. Imponedles un trabajo pesado y que lo cumplan; y no hagáis caso de palabras engañosas».

Los capataces y los inspectores salieron y dijeron al pueblo:

«Así dice el faraón: “No os proveeré de paja. Id vosotros a recogerla donde la encontréis. Pero vuestra tarea no disminuirá en nada”».

El pueblo se dispersó por toda la tierra de Egipto para recoger paja. Los capataces les apremiaban, diciendo:

«Completad vuestro trabajo, la tarea de cada día, como cuando se os daba paja».

Y golpeaban a los inspectores israelitas, que habían sido nombrados por los capataces del faraón, diciendo:

«¿Por qué ni ayer ni hoy habéis completado vuestra cantidad de adobes, como antes?».

Entonces, los inspectores israelitas fueron a reclamar al faraón y le dijeron:

«¿Por qué tratas así a tus siervos? No se provee de paja a tus siervos y encima nos exigen que hagamos adobes; golpean a tus siervos y tu pueblo tiene la culpa».

Contestó el faraón:

«¡Holgazanes! Eso es lo que sois, unos holgazanes. Por eso andáis diciendo: “Vamos a ofrecer sacrificios al Señor”. Y ahora, id a trabajar; no se os proveerá de paja, pero produciréis la misma cantidad de adobes».

Los inspectores israelitas se vieron en un aprieto cuando les dijeron:

«No disminuirá vuestra cantidad diaria de adobes»; y, encontrando a Moisés y a Aarón, que los esperaban a la salida del palacio del faraón, les dijeron:

«El Señor os examine y os juzgue; nos habéis hecho odiosos al faraón y a su corte; le habéis puesto en la mano una espada para que nos mate».

Entonces Moisés volvió al Señor y le dijo:

«Señor, ¿por qué maltratas a este pueblo? ¿Por qué me has enviado? Desde que me presenté al faraón para hablar en tu nombre, él maltrata a este pueblo y tú no haces nada para librar a tu pueblo».

El Señor respondió a Moisés:

«Ahora verás lo que voy a hacer al faraón, pues en virtud de una mano fuerte los dejará marchar; más aún, debido a una mano fuerte los expulsará de su tierra».

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
