# Ricardo de San Víctor

d. 1173 · Richard of Saint Victor · 1 lecturas

- [Sed imitadores de Dios, como hijos queridos](../r/2eb63dac29.md) — Ricardo de San Víctor · 42-45: Ed. G. Dumeige, Paris 1955, 171-175 · Domingo de la semana XXVI del Tiempo Ordinario (semana 26), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
