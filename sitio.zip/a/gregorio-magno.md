# San Gregorio Magno

c. 540–604 · St. Gregory the Great · 25 lecturas

- [En el mundo, pero no del mundo](../r/8682879c02.md) — San Gregorio Magno · Libro 2, homilía 36,11-13: PL 76,1272-1274 · Para los santos religiosos — Comunes, año par
- [El Señor ama a sus discípulos, y, sin embargo, los envía al mundo a padecer](../r/2bbaebe809.md) — San Gregorio Magno · Homilía 26, 1-2: PL 76, 1197-1198 · Domingo de la Octava de Pascua — Cuaresma y Pascua, año par
- [Cristo, el buen Pastor](../r/aa65a3247f.md) — San Gregorio Magno · Homilía 14 sobre los evangelios, 3-6: PL 76, 1129-1130 · Domingo de la semana IV de Pascua (semana 4), año par
- [Pudo más porque amó más](../r/a6a4457c58.md) — San Gregorio Magno · Libro 2, 33: PL 66,194-196 · 10 de febrero. Santa Escolástica, Virgen — Santoral, año par
- [Los ingleses han sido revestidos por la luz de la santa fe](../r/fedb6ce324.md) — San Gregorio Magno · Libro 9, 36: MGH, Epistolae 2, 305-306 · 27 de mayo. San Agustín de Cantorbery, Obispo — Santoral, año par
- [La voz de las almas es su amoroso deseo](../r/3f8aa0ddbf.md) — San Gregorio Magno · Lib. 2, 11: SC 32, 188-190 · Domingo de la semana III de Pascua (semana 3), año impar
- [La carga del gobierno](../r/68bafd79a7.md) — San Gregorio Magno · Parte 1, cap. 3: PL 177, 16-17 · Jueves de la semana XIII del Tiempo Ordinario (semana 13), año impar
- [Aplicaos, hermanos, a meditar las palabras de Dios](../r/f462a86078.md) — San Gregorio Magno · Lib. 2, homilía 3, 18. 19. 21: CCL 142, 250. 252. 253. 254 · Sábado de la semana XIV del Tiempo Ordinario (semana 14), año impar
- [Sobre el servicio de la predicación](../r/6167b0216d.md) — San Gregorio Magno · Homilía 17, 5.6.7.8: PL 76, 1140-1142 · Domingo de la semana XV del Tiempo Ordinario (semana 15), año impar
- [Sobre la vida activa y la vida contemplativa](../r/58095cee69.md) — San Gregorio Magno · Lib 2, Hom 2, 8-9: CCL 142, 230-231 · Domingo de la semana XVI del Tiempo Ordinario (semana 16), año impar
- [¡Señor mío y Dios mío!](../r/18d5ad7e62.md) — San Gregorio Magno · Homilía 26, 7-9: PL 76, 1201-1202 · 3 de julio SANTO TOMÁS, Apóstol — Santoral, año impar
- [Ardía en deseos de Cristo, a quien pensaba que se lo habían llevado](../r/ae5efbefb4.md) — San Gregorio Magno · Homilía 25,1-2. 4-5: PL 76,1189-1193 · 22 de julio Santa María Magdalena — Santoral, año impar
- [La Jerusalén celestial está fundada como ciudad](../r/13f817887a.md) — San Gregorio Magno · Lib 2, Hom 1, 5: CCL 142, 210-212 · Lunes de la semana XI del Tiempo Ordinario (semana 11), año par
- [Si aceptamos de Dios los bienes, ¿no vamos a aceptar los males?](../r/12210ea6cb.md) — San Gregorio Magno · Lib 3, 15-16: PL 75, 606-608 · Lunes de la semana XV del Tiempo Ordinario (semana 15), año par
- [La ley del Señor abarca muchos aspectos](../r/84ba8dfe58.md) — San Gregorio Magno · Lib 10, 7-8.10: PL 75. 922.925-926 · Domingo de la semana XVI del Tiempo Ordinario (semana 16), año par
- [El testigo interior](../r/f9e6b6ff9e.md) — San Gregorio Magno · Lib 10, 47-48: PL 75, 946-947 · Ciclo B Mc 6, 30-34 — Tiempo Ordinario, año par
- [La verdadera enseñanza evita la arrogancia](../r/06b4fcbe1f.md) — San Gregorio Magno · Lib 23, 23-24: PL 76, 265-266 · Miércoles de la semana XVII del Tiempo Ordinario (semana 17), año par
- [La Iglesia se asoma como el alba](../r/48866c8da6.md) — San Gregorio Magno · Lib 29, 2-4: PL 76, 478-480 · Jueves de la semana XVII del Tiempo Ordinario (semana 17), año par
- [La esperanza de los premios celestiales](../r/926ac40229.md) — San Gregorio Magno · Lib. 2, Homilía 1, 7: CCL 142, 213- 214 · Jueves de la semana XXI del Tiempo Ordinario (semana 21), año impar
- [Ataques por fuera y temores por dentro](../r/7e1909eaad.md) — San Gregorio Magno · Lib. 3, 39-40: PL 75, 619-620 · Lunes de la semana XXV del Tiempo Ordinario (semana 25), año impar
- [Cristo se hizo carne para hacernos a nosotros espirituales](../r/31e9531468.md) — San Gregorio Magno · Lib. 2, Hom. 4, 19-20: CCL 142, 271-273 · Sábado de la semana XXXIII del Tiempo Ordinario (semana 33), año impar
- [Por amor a Cristo, cuando hablo de Él, ni a mí mismo me perdono](../r/c02be0247c.md) — San Gregorio Magno · Libro 1,11, 4-6: CCL 142,170-172 · Mes de septiembre — Santoral, año impar
- [El nombre de "ángel" designa la función, no el ser](../r/f1cecca40a.md) — San Gregorio Magno · Homilía 34, 8-9: PL 76,1250-1251 · 29 de septiembre SANTOS ARCÁNGELES MIGUEL, GABRIEL Y RAFAEL — Santoral, año impar
- [El Señor viene detrás de sus predicadores](../r/1a23f13cd3.md) — San Gregorio Magno · Homilía 17,1-3: PL 76,1139 · 18 de octubre SAN LUCAS, evangelista — Santoral, año impar
- [El pastor debe saber guardar silencio con discreción y hablar cuando es útil](../r/1a4a086f98.md) — San Gregorio Magno · Lib 2, 4: PL 77, 30-31 · Domingo de la semana XXI del Tiempo Ordinario (semana 21), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
