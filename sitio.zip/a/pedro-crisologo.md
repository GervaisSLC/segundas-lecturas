# San Pedro Crisólogo

c. 380–450 · St. Peter Chrysologus · 16 lecturas

- [El amor desea ver a Dios](../r/f2165f25b8.md) — San Pedro Crisólogo · Sermón 147 : PL 52, 594-595 · Jueves de la semana II de Adviento (semana 2), año par
- [Mirad: la virgen concebirá y dará a luz un hijo, y le pondrá por nombre Emmanuel](../r/d752733d49.md) — San Pedro Crisólogo · Sermón 145: PL 52, 588 · 25 de Diciembre. LA NATIVIDAD DEL SEÑOR — Santoral, año par
- [Paz es el nombre personal de Cristo](../r/a0b35f89fd.md) — San Pedro Crisólogo · Sermón 149: PL 52, 598-599 · 25 de Diciembre. LA NATIVIDAD DEL SEÑOR — Santoral, año impar
- [El que por nosotros quiso nacer no quiso ser ignorado por nosotros](../r/819e4b9081.md) — San Pedro Crisólogo · Sermón 160: PL 52, 620-622 · 7 de Enero — Santoral, año impar
- [La oración llama, el ayuno intercede, la misericordia recibe](../r/715216298e.md) — San Pedro Crisólogo · Sermón 43: PL 52, 320. 322 · Martes de la semana III de Cuaresma (semana 3), año par
- [Era necesaria la muerte de Lázaro para que, con Lázaro ya en el sepulcro, resucitase la fe de los discípulos](../r/aff6915957.md) — San Pedro Crisólogo · Sermón 6 : PL 52, 375-377 · Semana V de Cuaresma — Cuaresma y Pascua, año par
- [Del cielo vino el Pastor para reconducir las ovejas descarriadas a los pastos de la vida](../r/8d7fa4584f.md) — San Pedro Crisólogo · Sermón 6 (CCL 24, 44-47 · Domingo de la semana IV de Pascua (semana 4), año par
- [Sé tú mismo el sacrificio y el sacerdote de Dios](../r/b5c37bd1d9.md) — San Pedro Crisólogo · Sermón 108 :PL 52, 499-500 · Martes de la semana IV de Pascua (semana 4), año impar
- [Dios busca a los hombres, no las cosas de los hombres](../r/997afad38a.md) — San Pedro Crisólogo · Sermón 18 : PL 52, 246-249 · Domingo de la semana V del Tiempo Ordinario (semana 5), año impar
- [Realmente, para Dios la muerte es un sueño](../r/be5df8c8d9.md) — San Pedro Crisólogo · Sermón 34, 1.5: CCL 34,193.197-199 · Domingo de la semana XIII del Tiempo Ordinario (semana 13), año impar
- [Convertíos, porque está cerca el reino de los cielos](../r/a1796f64d3.md) — San Pedro Crisólogo · Sermón 167: PL 52, 637-638 · Martes de la semana XVII del Tiempo Ordinario (semana 17), año impar
- [Dichosos los que trabajan por la paz](../r/e108731d63.md) — San Pedro Crisólogo · Sobre la paz: PL 52,347-348 · 4 de julio Santa Isabel de Portugal — Santoral, año impar
- [El mártir reina y vive](../r/f44ec989d7.md) — San Pedro Crisólogo · Sermón 128, 1-3: CCL 24A, 789-791 · 20 de julio San Apolinar, Obispo y Mártir — Santoral, año impar
- [El misterio de la Encarnación](../r/1b5c4949b3.md) — San Pedro Crisólogo · Sermón 148: PL 52, 596-598 · 30 de julio San Pedro Crisólogo, Obispo y Doctor de la Iglesia — Santoral, año impar
- [El número prescrito no limita, sino que dilata el perdón](../r/886620014a.md) — San Pedro Crisólogo · Sermón 139 : PL 52, 573-575 · Domingo de la semana XXIII del Tiempo Ordinario (semana 23), año impar
- [Cristo nos buscó en la tierra: busquémosle nosotros en el cielo](../r/b5869e43f5.md) — San Pedro Crisólogo · Sermón 168 :PL 52, 639-641 · Domingo de la semana XXIV del Tiempo Ordinario (semana 24), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
