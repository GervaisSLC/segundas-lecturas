# Santa Teresa de Jesús

1515–1582 · St. Teresa of Ávila · 2 lecturas

- [Venga a nosotros tu reino](../r/986f957467.md) — Santa Teresa de Jesús · Cap 51: BAC 120, 221-224 · Martes de la semana XV del Tiempo Ordinario (semana 15), año impar
- [Hemos de imitar la pobreza de Jesús](../r/7b8d5e9f9b.md) — Santa Teresa de Jesús · Carta 201: Cartas. Copias auténticas, t. 1. Archivo general de la Congregación, Valencia: Causa de beatificación y canonización de la sierva de Dios Teresa de Jesús Jornet e lbars). · 26 de agosto Santa Teresa de Jesús Jornet e Ibars, virgen, Patrona de la Ancianidad — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
