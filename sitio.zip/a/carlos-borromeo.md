# San Carlos Borromeo

1538–1584 · St. Charles Borromeo · 1 lecturas

- [Sobre el tiempo de Adviento](../r/eec858d849.md) — San Carlos Borromeo · Acta Ecclesiae Mediolanensis, t. 2, Lyon 1683, 916-917 · Lunes de la semana I de Adviento (semana 1), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
