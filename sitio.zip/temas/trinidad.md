# Trinidad

13 lecturas (tema asignado automáticamente).

[Todos los temas](index.md) · [Guía para IAs](../llms.txt)

- [La Palabra tomó de María nuestra condición](../r/8f640cd3d0.md) — San Atanasio de Alejandría · Carta a Epicteto, 5-9: PG 26,1058.1062-1066 · 1 de Enero. SANTA MARÍA, MADRE DE DIOS — Santoral, año par
- [Alabanzas de la Madre de Dios](../r/09a87d2250.md) — San Cirilo de Alejandría · Homilía 4: PG 77, 991. 995-996 · Común de Santa maría virgen — Comunes, año par
- [El misterio del agua](../r/901aba4fc6.md) — Dídimo de Alejandría · Lib. 2, 13-14: PG 39, 691-698 · Jueves de la semana V de Cuaresma (semana 5), año par
- [El bautismo nos hace inmortales y nos deifica](../r/f7c9c0463f.md) — Dídimo de Alejandría · Lib. 2, 14: PG 39, 710-718 · Viernes de la Octava de Pascua — Cuaresma y Pascua, año par
- [Me he hecho Hijo del hombre, para que vosotros podáis ser hijos de Dios](../r/4834ea815e.md) — San León Magno · Tratado 77, 4-6: CCL 138A, 490-493 · Domingo de Pentecostés — Cuaresma y Pascua, año par
- [El Espíritu de la verdad os guiará hasta la verdad plena](../r/3007a374ff.md) — San León Magno · Tratado 75, 1-3: CCL 138A, 465-468 · Domingo de Pentecostés — Cuaresma y Pascua, año par
- [Gusté y vi](../r/54eb3be049.md) — Santa Catalina de Siena · Cap. 167, Acción de gracias a la Santísima Trinidad: edición latina, Ingolstadt 1583, ff. 290v-291 · 29 de abril. Santa Catalina de Siena, Virgen y Doctora de la IglesiaPatrona de Europa — Santoral, año par
- [Pasaré al lugar del tabernáculo admirable](../r/436f6e04e0.md) — San Jerónimo · Homilía a los recién bautizados, sobre el salmo 41: CCL 78, 542-544 · Miércoles de la semana XV del Tiempo Ordinario (semana 15), año impar
- [Luz, resplandor y gracia en la Trinidad y por la Trinidad](../r/eb232b122f.md) — San Atanasio de Alejandría · Carta a Serapión 1, 28-30: PG 26, 594-595. 599 · Domingo después de Pentecostés LA SANTÍSIMA TRINIDAD — Solemnidades del Señor, año impar
- [Tu palabra, oh Dios, es fuente de vida eterna](../r/cd790af346.md) — San Agustín de Hipona · Lib 13, 21, 31—22, 32: CSEL 33, 369-371 · Viernes de la semana XVI del Tiempo Ordinario (semana 16), año par
- [Me casaré contigo en matrimonio perpetuo](../r/d2a792832d.md) — San Juan de la Cruz · Canción 39, 4-7 · Jueves de la semana XXIII del Tiempo Ordinario (semana 23), año impar
- [Enviado para dar la Buena Noticia a los que sufren, para vendar los corazones desgarrados, para proclamar la amnistía a los cautivos.](../r/1d47679640.md) — San Pedro Claver · Epist. diei 31 maii 1627 ad Superiorem suum data; Edit (in lingua hispanica) A. Valtierra, S.L., San Pedro Claver, Cartagena, 1964, pp. 140-141 · 9 de septiembre San Pedro Claver, presbítero — Santoral, año impar
- [La insondable profundidad de Dios](../r/a01fe6e6fa.md) — San Columbano · Instrucción 1, 3-5 sobre la fe: Opera omnia, Dublín 1957, pp. 62-66 · Jueves de la semana XX del Tiempo Ordinario (semana 20), año par
