# San Juan XXIII

1881–1963 · St. John XXIII · 1 lecturas

- [Martín de la caridad](../r/5be67790ca.md) — San Juan XXIII · Día 6 de mayo de 1962: AAS 54 [1962], 306-309 · 3 de noviembre San Martín de Porres, religioso — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
