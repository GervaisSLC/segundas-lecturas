# San Elredo de Rievaulx

1110–1167 · St. Aelred of Rievaulx · 14 lecturas

- [Hoy nos ha nacido un Salvador](../r/59135e1d09.md) — San Elredo de Rievaulx · Sermón 1 de la Natividad del Señor : PL 195, 226-227 · 25 de Diciembre. LA NATIVIDAD DEL SEÑOR — Santoral, año par
- [¡Levántate, brilla, que llega tu luz!](../r/b139d84e0d.md) — San Elredo de Rievaulx · Sermón 3 en la manifestación del Señor : PL 195, 228-229 · Ferias anteriores a la Epifanía — Adviento y Navidad, año par
- [María, Madre nuestra](../r/7e3b7cf0fd.md) — San Elredo de Rievaulx · Sermón 20, en la Natividad de santa María: PL 195, 322-324 · Común de Santa maría virgen — Comunes, año par
- [Este tiempo nos recuerda las dos venidas del Señor](../r/753cda82c5.md) — San Elredo de Rievaulx · Sermón 1 sobre la venida del Señor: PL 195, 209-210 · Domingo de la semana I de Adviento (semana 1), año impar
- [Debemos practicar la caridad fraterna según el ejemplo de Cristo](../r/68613b723f.md) — San Elredo de Rievaulx · Lib. 3, 5: PL 195, 582 · Viernes de la semana I de Cuaresma (semana 1), año par
- [La amistad verdadera es perfecta y constante](../r/014f6734cf.md) — San Elredo de Rievaulx · Lib. 3, 92. 93. 94. 96: CCL CM 1, 337-338 · Martes de la semana XIV del Tiempo Ordinario (semana 14), año impar
- [Sobre el pueblo bien dispuesto que se prepara para el Señor](../r/f502198632.md) — San Elredo de Rievaulx · Edit C.H. Talbot, SSOC, I, 1952, 40-41 · Sábado de la semana XIV del Tiempo Ordinario (semana 14), año par
- [Considerad, hermanos, vuestra vocación](../r/41bb11475e.md) — San Elredo de Rievaulx · Edit C.H. Talbot, SSOC vol 1, 102-103 · Viernes de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [Irá delante del Señor con el espíritu y poder de Elías](../r/fa78490b30.md) — San Elredo de Rievaulx · Sermón «Quomodo referatur», Edit C.H. Talbot, SSOC vol 1, 120-121 · Sábado de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [Surgió un hombre enviado por Dios](../r/3fed855ce6.md) — San Elredo de Rievaulx · Sermón sobre la interrelación Elías y Juan Bautista, Edit. C.H. Talbot, SSOC vol 1, p. 118 · Sábado de la semana XIX del Tiempo Ordinario (semana 19), año impar
- [Sobre la verdadera humildad](../r/bd20d73331.md) — San Elredo de Rievaulx · Edit C.H. Talbot, SSOC vol 1, 78-80 · Domingo de la semana XXII del Tiempo Ordinario (semana 22), año impar
- [La tierra estaba llena de la gloria del Señor](../r/d0b24ad571.md) — San Elredo de Rievaulx · Sermón sobre la venida del Señor, Edit. C.H. Talbot, SSOC, vol 1, Roma 1952, 32-33 · Sábado de la semana XXIV del Tiempo Ordinario (semana 24), año impar
- [En nuestra Pascua, Cristo es inmolado no en figura, sino en realidad](../r/bd2259cb6c.md) — San Elredo de Rievaulx · Sermón en el día de Pascua, Edit. C.H. Talbot, SSOC, vol 1, 94-95 · Jueves de la semana XXVI del Tiempo Ordinario (semana 26), año impar
- [Un amigo fiel es un talismán](../r/c2a57cb06a.md) — San Elredo de Rievaulx · Lib 2: Edit J. Dubois, 53-57 · Viernes de la semana XXVII del Tiempo Ordinario (semana 27), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
