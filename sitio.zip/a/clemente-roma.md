# San Clemente I, papa

d. c. 99 · St. Clement of Rome · 28 lecturas

- [Convertíos](../r/f1ef327991.md) — San Clemente I, papa · Caps. 7, 4-8, 5-9. 1; 13, 1-4; 19, 2: Funck 1, 71-73.77-78.87 · Miércoles de Ceniza — Cuaresma y Pascua, año par
- [Muchos son los senderos, pero uno solo es el camino](../r/219f8f89fc.md) — San Clemente I, papa · Cap. 36, 1-2; 37-38: Funk 1, 145-149 · Viernes de la semana IV de Pascua (semana 4), año par
- [¿Quién será capaz de explicar el vínculo del amor divino?](../r/ce13c14964.md) — San Clemente I, papa · 49-50: Funck 1, 123-125 · Semana I de Cuaresma — Cuaresma y Pascua, año impar
- [Habiendo sufrido por envidia, se han convertido en un magnífico ejemplo](../r/25c228b1bc.md) — San Clemente I, papa · Caps. 5,1-7, 4: Funk 1, 67-71 · Mes de junio — Santoral, año impar
- [Gracia y paz a vosotros de parte del Dios omnipotente](../r/f3d4f33212.md) — San Clemente I, papa · 1: Funk 1,61-62 · Domingo de la semana II del Tiempo Ordinario (semana 2), año par
- [Sed solícitos día y noche por la fraternidad universal](../r/57ba417109.md) — San Clemente I, papa · 2-3: Funk 1, 63-65 · Del comentario de san Cirilo de Alejandría, obispo, sobre el evangelio de san Juan — Tiempo Ordinario, año par
- [Pongamos ante nuestros ojos a los santos apóstoles](../r/fbde44fddc.md) — San Clemente I, papa · 4-5: Funk 1, 65-69 · Martes de la semana II del Tiempo Ordinario (semana 2), año par
- [De generación en generación, el Señor concedió un tiempo de penitencia a los que deseaban convertirse a él](../r/81d6c4e5f2.md) — San Clemente I, papa · 6-8: Funk 1,69-73 · Miércoles de la semana II del Tiempo Ordinario (semana 2), año par
- [Abrahán, llamado amigo, fue hallado fiel](../r/7b98ac4792.md) — San Clemente I, papa · 9-11: Funk 1, 73-75 · Jueves de la semana II del Tiempo Ordinario (semana 2), año par
- [Seamos humildes de corazón](../r/0aff14047c.md) — San Clemente I, papa · 12-13: Funk 1, 75-79 · Viernes de la semana II del Tiempo Ordinario (semana 2), año par
- [Ved qué dechado se nos propone](../r/6f6658c7d6.md) — San Clemente I, papa · 14-17: Funk 1, 79-85 · Sábado de la semana II del Tiempo Ordinario (semana 2), año par
- [El Señor del universo ha querido que reinara la paz y la concordia](../r/c78db01ded.md) — San Clemente I, papa · 18-20: Funk 1, 85-89 · Domingo de la semana III del Tiempo Ordinario (semana 3), año par
- [No nos apartamos nunca de la voluntad de Dios](../r/182965a898.md) — San Clemente I, papa · 21, 1—22, 5; 23, 1-2: Funk 1, 89-93 · Lunes de la semana III del Tiempo Ordinario (semana 3), año par
- [Dios es fiel en sus promesas](../r/8498354e55.md) — San Clemente I, papa · 24, 1-5; 27, 1—29, 1 · Martes de la semana III del Tiempo Ordinario (semana 3), año par
- [Busquemos en Dios nuestra alabanza, no en nosotros mismos](../r/8a27d297eb.md) — San Clemente I, papa · 30.31.32: Funk 1, 97-101 · Miércoles de la semana III del Tiempo Ordinario (semana 3), año par
- [Nuestra gloria y nuestra confianza estén siempre en Dios](../r/3fe4e895e8.md) — San Clemente I, papa · 33-34: Funk 1, 101-103 · Jueves de la semana III del Tiempo Ordinario (semana 3), año par
- [¡Qué grandes y maravillosos son los dones de Dios!](../r/fd3d8ee34f.md) — San Clemente I, papa · 35-36: Funk 1, 105-107 · Viernes de la semana III del Tiempo Ordinario (semana 3), año par
- [Tomemos como ejemplo a nuestro cuerpo](../r/a75a5ecd6c.md) — San Clemente I, papa · 37-38: Funk 1, 107-109 · Sábado de la semana III del Tiempo Ordinario (semana 3), año par
- [Los apóstoles salieron a anunciar la llegada del reino de Dios](../r/1b11eaab85.md) — San Clemente I, papa · 40-43: Funk 1, 109-115 · Domingo de la semana IV del Tiempo Ordinario (semana 4), año par
- [Los justos sufrieron persecución](../r/4fa2e87fc4.md) — San Clemente I, papa · 44-45: Funk 1,115-119 · Lunes de la semana IV del Tiempo Ordinario (semana 4), año par
- [Busque cada uno no sólo su propio interés, sino también el de la comunidad](../r/05272e8936.md) — San Clemente I, papa · 46, 2-47, 4; 48, 1-6: Funk 1,119-123 · Semana IV del Tiempo Ordinario, año par
- [Más le vale al hombre confesar sus caídas que endurecer su corazón](../r/58742b75c4.md) — San Clemente I, papa · 51-52.54: Funk 1, 129.130 · Jueves de la semana IV del Tiempo Ordinario (semana 4), año par
- [Obedezcamos a su nombre santísimo y glorioso](../r/2b24452bb1.md) — San Clemente I, papa · 56, 1-2.16; 57, 1-2; 58,1-2: Funk 1, 131-135 · Viernes de la semana IV del Tiempo Ordinario (semana 4), año par
- [La oración de los fieles](../r/2b20a7925d.md) — San Clemente I, papa · 59, 1–60,4; 61, 3: Funk 1, 135-137 · Sábado de la semana IV del Tiempo Ordinario (semana 4), año par
- [Mantened la concordia en la caridad y en la paz](../r/b47e1080e5.md) — San Clemente I, papa · 62-63: Funk 1, 141-143 · Domingo de la semana V del Tiempo Ordinario (semana 5), año par
- [La gracia de nuestro Señor Jesucristo esté con vosotros y con todos los llamados](../r/1a3d34e7da.md) — San Clemente I, papa · 64-65: Funk 1, 143-145 · Lunes de la semana V del Tiempo Ordinario (semana 5), año par
- [Acción de gracias y petición del pueblo cristiano](../r/c2ee26b2e1.md) — San Clemente I, papa · Caps. 59, 2-60, 4: Funk 1,135-141 · Mes de octubre — Santoral, año impar
- [Maravillosos son los dones de Dios](../r/37a5d3ed03.md) — San Clemente I, papa · Caps. 35,1-5; 36,1-2; 37,1. 4-5; 38,1-2. 4: Funk 1,105-109 · 23 de noviembre San Clemente I, papa y mártir — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
