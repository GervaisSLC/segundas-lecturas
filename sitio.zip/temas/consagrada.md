# Vida monástica y virginidad

32 lecturas (tema asignado automáticamente).

[Todos los temas](index.md) · [Guía para IAs](../llms.txt)

- [Mirad: la virgen concebirá y dará a luz un hijo, y le pondrá por nombre Emmanuel](../r/d752733d49.md) — San Pedro Crisólogo · Sermón 145: PL 52, 588 · 25 de Diciembre. LA NATIVIDAD DEL SEÑOR — Santoral, año par
- [Vino a nosotros el que es el esplendor de la gloria del Padre](../r/7316e75b00.md) — San Gregorio de Neocesarea · Homilía 4 en la santa Teofanía: PG 10, 1182-1183 · Domingo después del 6 de Enero. EL BAUTISMO DEL SEÑOR — Adviento y Navidad, año par
- [Que el Dios del amor y de la paz purifique vuestros corazones](../r/2e76c8c221.md) — San Raimundo de Peñafort · Monumenta Ordinis Praedicatorum Historica 6, 2, Roma 1901, pp. 84-85 · 7 de enero. San Raimundo de Peñafort, Presbítero — Santoral, año par
- [La vocación, misterio de amor](../r/b77a3e2728.md) — San Juan Pablo II · AAS 76 (1984) 513-546, n. 3 · 10 de enero. Beata Ana de los Ángeles Monteagudo — Santoral, año par
- [María, antes de concebir corporalmente, concibió en su espíritu](../r/19a318fd82.md) — San León Magno · Sermón 1 en la Natividad del Señor, 2. 3: PL 54,191-192 · Común de Santa maría virgen — Comunes, año par
- [El coro numeroso de las vírgenes acrecienta el gozo de la madre Iglesia](../r/c4251428aa.md) — San Cipriano de Cartago · Núms. 3-4. 22. 23: CSEL 3,189-190. 202-204 · Común de vírgenes — Comunes, año par
- [La Iglesia sigue a su único esposo, Cristo](../r/14c03c5f33.md) — Concilio Vaticano II · Núms. 1. 5. 6.12 · Común de vírgenes — Comunes, año par
- [No es lícito mentir a Dios](../r/b79c98b140.md) — San Agustín de Hipona · Sermón 148: PL 38, 799-800 · Domingo de la semana II de Pascua (semana 2) - Año A: Jn 20, 19-31, año par
- [La unción del Espíritu Santo](../r/8f4e53a22c.md) — San Nicolás Cabasilas · Lib. 6: PG 150, 574-575 · Jueves de la semana V de Pascua (semana 5), año par
- [Pudo más porque amó más](../r/a6a4457c58.md) — San Gregorio Magno · Libro 2, 33: PL 66,194-196 · 10 de febrero. Santa Escolástica, Virgen — Santoral, año par
- [Hagamos el elogio de los hombres ilustres](../r/7ae9f1b7dd.md) — Actas y escritos anónimos · Monumenta Ordinis Servorum Beatae Maríae Virginis, 1, 3. 5. 6. 9.11: pp. 71 ss. · Mes de febrero — Santoral, año par
- [Se abrazó a la cruz con todo su cuerpo](../r/6888b00d7f.md) — Actas y escritos anónimos · Acta Sanctorum, Aprilis, III, pp. 186-187). · El mismo día 23 de abril. San Adalberto, Obispo y Mártir — Santoral, año par
- [Todo tuyo](../r/ae951caf61.md) — San Luis María Grignion de Montfort · nn. 120-121.125-126: oeuvres completes, Seuil, Paris 1966, 562-563.566-567). (cf. Obras completas, BAC, n. 451). · El mismo día 28 de abril. San Luis María Griñón de Montfort, Presbítero — Santoral, año par
- [El amor lo puede todo](../r/f00fa1090a.md) — Actas y escritos anónimos · 22 de mayo. Santa Joaquina Vedruna, Religiosa — Santoral, año par
- [Rasgad los corazones, no las vestiduras](../r/889c5a098c.md) — San Pablo VI · AAS t. 58. 1966, 178-179 · Sábado después de Ceniza — Cuaresma y Pascua, año impar
- [La eucaristía, Pascua del Señor](../r/f73693864a.md) — San Gaudencio de Brescia · Tratado 2: CSEL 68, 26. 29-30 · Sábado de la semana V de Pascua (semana 5), año impar
- [El progreso del dogma cristiano](../r/49144faee1.md) — San Vicente de Lerins · Capítulo 23: PL 50, 667-668 · Viernes de la semana V del Tiempo Ordinario (semana 5), año impar
- [Todas estas cosas las realizan las manos consagradas de los sacerdotes](../r/bf3186e110.md) — San Juan Crisóstomo · Lib 3, 3-6: PG 48, 643-644 · Domingo de la semana VII del Tiempo Ordinario (semana 7), año impar
- [Los discípulos llamados a ser los iniciadores y maestros del mundo entero](../r/c14c90a2fa.md) — San Cirilo de Alejandría · Cap 6: PG 72, 602-603 · Domingo de la semana VIII del Tiempo Ordinario (semana 8), año impar
- [Por la unción recibida, los cristianos están consagrados de por vida a la cruz de Cristo](../r/49deef3d29.md) — Actas y escritos anónimos · Homilía 17, 1-4: PG 34, 623-626 · Semana XVI del Tiempo Ordinario, año impar
- [La devoción se ha de ejercitar de diversas maneras](../r/2cd76a804d.md) — San Francisco de Sales · Parte 1, cap. 3 · 24 de enero San Francisco de Sales, Obispo y Doctor de la Iglesia — Santoral, año impar
- [Se negó a sí mismo para seguir a Cristo](../r/b8e63fc831.md) — San Pedro Damiani · Caps. 31 y 69: PL 144, 982-983.1005-1006 · 19 de junio San Romualdo, Abad — Santoral, año impar
- [La castidad sin la caridad no tiene valor](../r/ad7c8157ac.md) — San Bernardo de Claraval · Carta 42, a Enrique, arzobispo de Sens [Tratado sobre las costumbres y el ministerio de los obispos]), 3, 8: PL 182, 816-817 · 26 de junio San Pelayo, Mártir — Santoral, año impar
- [Por sus frutos los conoceréis](../r/acd120a7f7.md) — San Juan Damasceno · Sermón 6, Sobre la Natividad de la Virgen María, 2. 4. 5. 6: PG 96, 663. 667. 670 · 26 de julio Santos Joaquín y Ana, Padres de la Virgen María — Santoral, año impar
- [Preparada por el Altísimo, designada anticipadamente por los padres antiguos](../r/625e179c36.md) — San Bernardo de Claraval · Homilía 2, 1-2.4: Opera omnia ed. Cister, 4, 1966, 21-23 · Miércoles de la semana XXV del Tiempo Ordinario (semana 25), año impar
- [Por amor a Cristo, cuando hablo de Él, ni a mí mismo me perdono](../r/c02be0247c.md) — San Gregorio Magno · Libro 1,11, 4-6: CCL 142,170-172 · Mes de septiembre — Santoral, año impar
- [Estuve enfermo, y me visitasteis](../r/3ee6be000e.md) — San Pablo VI · 25 de enero de 1970: AAS 62, 1970, 82-88 · El mismo día 10 de octubre San Luis Beltrán, presbítero — Santoral, año impar
- [Tendía siempre hacia Dios](../r/3d4c2ac009.md) — Actas y escritos anónimos · Acta Sanctorum Octobris 8, 1853, 201-202 · 16 de octubre Santa Eduvigis, religiosa — Santoral, año impar
- [Defensor y restaurador de la fe](../r/8d0e6ef591.md) — San Isidoro de Sevilla · Cap. 41: PL 83, 1103-1104 · Mes de octubre — Santoral, año impar
- [Isabel reconoció y amó a Cristo en la persona de los pobres](../r/1096e82e1a.md) — Actas y escritos anónimos · Al Sumo pontífice, año 1232: A. Wyss, Hessisches Urkundenbuch 1, Leipzig 1879, 31-35 · 17 de noviembre Santa Isabel de Hungría — Santoral, año impar
- [Llevemos desde ahora una vida sobria, honrada y religiosa aguardando la aparición gloriosa del gran Dios](../r/b42ff5f42f.md) — Clemente de Alejandría · Cap 1: PG 8, 59-63 · Jueves de la semana XXIII del Tiempo Ordinario (semana 23), año par
- [El tiempo de las bodas es aquel en que, por el misterio de la encarnación, el Señor se unió a la Iglesia](../r/1db5456fa0.md) — San Beda el Venerable · Hom. 14 : CCL 122, 95-96 · Viernes de la semana XXV del Tiempo Ordinario (semana 25), año par
