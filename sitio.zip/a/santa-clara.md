# Santa Clara

None · None · 1 lecturas

- [Atiende a la pobreza, la humildad y la caridad de Cristo](../r/c0c0f979b4.md) — Santa Clara · Escritos de santa Clara, edición Ignacio Omaechevarría, Madrid 1970, pp. 339-341 · 11 de agosto Santa Clara, virgen — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
