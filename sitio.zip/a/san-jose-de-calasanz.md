# San José de Calasanz

None · None · 1 lecturas

- [Procuremos vivir unidos a Cristo y agradarle sólo a Él](../r/c4ff714cf0.md) — San José de Calasanz · Memorial al cardenal M. A. Tonti, 1621: Ephemerides Calasantiae 36, 9-10, Roma 1967, pp. 473-474; L. Picanyol, Epistolario di S. Giuseppe Calasanzio, 9 volúmenes, edición calasancia, Roma 1951-1956, passim · El mismo día 25 de agosto San José Calasanz, presbítero — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
