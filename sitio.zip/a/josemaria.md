# San Josemaría Escrivá

1902–1975 · St. Josemaría Escrivá · 1 lecturas

- [Conducir en medio del mundo una vida verdaderamente contemplativa](../r/d49c4ea199.md) — San Josemaría Escrivá · Hacia la santidad, ed. Palabra, Madrid 1973, pp. 7-9, 12-13, 20-21, 23-24, 32-33, 40-41, 52 · 26 de junio San Josémaría Escrivá de Balaguer, Presbítero — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
