# Santa Margarita María de Alacoque

None · None · 1 lecturas

- [Debemos conocer el amor de Cristo, que excede todo conocimiento](../r/6368dac48a.md) — Santa Margarita María de Alacoque · Vie et oeuvres 2, París 1915, 321. 336. 493. 554 · El mismo día 16 de octubre Santa Margarita María de Alacoque, virgen — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
