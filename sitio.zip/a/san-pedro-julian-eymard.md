# San Pedro Julián Eymard

None · None · 1 lecturas

- [Eucaristía: Sacramento de vida](../r/93f52ebe30.md) — San Pedro Julián Eymard · La Présence réelle, vol. 1, París, 1950, pp. 270-271 et 307-308). · El mismo día 2 de agosto San Pedro Julián Eymard, presbítero — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
