# San Francisco Javier

None · None · 1 lecturas

- [¡Ay de mí si no anuncio el Evangelio!](../r/33106bab51.md) — San Francisco Javier · Cartas 4 [1542]... y 5 [1544]: BAC 101, Cartas y escritos de san Francisco Javier, pp. 107-108. 115-116 · 3 de diciembre. San Francisco Javier, Presbítero — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
