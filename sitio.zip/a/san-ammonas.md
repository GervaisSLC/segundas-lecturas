# San Ammonas

None · None · 1 lecturas

- [Los que están cerca de Dios han sido constituidos médicos de almas](../r/fc78f96a57.md) — San Ammonas · Ep 12: PO 10/6, 1973, 603-607 · 24 de julio San Sarbelio (Charbel) Makllüf, Presbítero — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
