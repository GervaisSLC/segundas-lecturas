# La navidad y el bautismo de Cristo son mi misterio y mi salvación

**San Máximo de Turín** (d. c. 420) · Segunda lectura del Oficio de Lectura

- id: `daf22ae4b0`
- Fuente: De los sermones de San Máximo de Turín
- Cita patrística: Sermón 45, 1-3 CCL 23, 182-183
- Se lee: 12 de Enero oSábado después del Domingo de Epifanía — Santoral, año par; 12 de Enero oSábado después del Domingo de Epifanía — Santoral, año impar
- Escritura: [Ba 5, 9](../escritura/ba.md) (primera lectura del día); [Jn 1, 14](../escritura/jn.md) (responsorio); [Sb 18, 14-15](../escritura/sb.md) (responsorio)
- Temas (automáticos): [Bautismo](../temas/bautismo.md), [Pecado y redención](../temas/salvacion.md), [Cruz y Pasión](../temas/cruz.md), [Penitencia y conversión](../temas/conversion.md)
- Cómo citar: San Máximo de Turín, Sermón 45, 1-3 CCL 23, 182-183, «La navidad y el bautismo de Cristo son mi misterio y mi salvación». Liturgia de las Horas, Oficio de Lectura, segunda lectura, 12 de Enero oSábado después del Domingo de Epifanía — Santoral, año par. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-daf22ae4b0](../index.html#r-daf22ae4b0)
- Autor: [San Máximo de Turín](../a/maximo-turin.md)

## Texto

Hoy ha salido para el mundo el verdadero sol, hoy en las tinieblas del siglo ha surgido la luz. Dios se ha hecho hombre para que el hombre llegue a ser Dios; el Señor asumió la forma de esclavo para que el siervo se convierta en Señor; el morador y creador de los cielos habitó en la tierra para que el hombre, colono de la tierra, pueda emigrar a los cielos.

¡Oh día más lúcido que cualquier sol! ¡Oh momento más esperado de todos los siglos! Lo que anhelaban los ángeles, lo que ni serafines ni querubines ni coros celestiales conocieron, esto es lo que se ha revelado en nuestros días; lo que ellos veían como en un espejo y a través de imágenes, nosotros lo contemplamos en su misma realidad. El que habló al pueblo de Israel por boca de Isaías, Jeremías y demás profetas, ahora nos habla por su Hijo. ¡Qué diferencia entre el antiguo y nuevo Testamento! En aquél, Dios hablaba a través de la nube; a nosotros nos habla a cielo despejado; allí Dios se mostraba en la zarza, aquí Dios nace de la Virgen; allí era el fuego el que consumía los pecados del pueblo, aquí es un hombre el que perdona los pecados del pueblo, mejor dicho, es el Señor que perdona a sus siervos, pues nadie, fuera de Dios, puede perdonar pecados.

Tanto si el Señor Jesús nació hoy como si hoy es el día de su bautismo –existen al respecto opiniones diversas y podemos adherirnos a la que mejor nos parezca—, una cosa es clara: que tanto si hoy es el día en que nació de la Virgen como si es el día en que renació en el bautismo, su nacimiento –en la carne y en el espíritu– es en provecho nuestro: ambos misterios son míos, mía es la utilidad que redunda de ellos. El Hijo de Dios no tenía necesidad ni de nacer ni de ser bautizado, pues no había cometido pecado para que se le perdonase en el bautismo. Pero su humildad es nuestra sublimidad, su cruz es nuestra victoria, su patíbulo es nuestro triunfo.

Coloquemos alegres esta señal sobre nuestros hombros, enarbolemos el estandarte de la victoria, más aún, grabemos ese lábaro en nuestras frentes. Cuando el diablo vea esta señal en el dintel de nuestras puertas, se estremecerá, y los que no temen los dorados capitolios, temen la cruz; los que no se arredran ante los cetros reales, la púrpura y el fasto de los césares, se echan a temblar ante las maceraciones y los ayunos de los cristianos.

Alegrémonos, pues, carísimos hermanos, y levantemos al cielo en forma de cruz la manos puras. Mientras Moisés tenía las manos en alto, vencía Israel; mientras las tenía bajadas, vencía Amalec. Las mismas aves cuando se elevan a las alturas y planean en el aire, con las alas extendidas imitan la cruz. Y las mismas cruces artísticas son verdaderos trofeos y botín de guerra, cruces que debemos llevar no sólo en la frente, sino también en nuestras almas, para que, armados de esta guisa, caminemos sobre áspides y víboras en Cristo Jesús, a quien se debe la gloria por los siglos de los siglos.

## Responsorio (Jn 1, 14; Sb 18, 14-15)

R. La Palabra se hizo carne y puso su morada entre nosotros. * Y hemos contemplado su gloria, como Hijo único, lleno de gracia y de verdad.  
V. Cuando un sosegado silencio todo lo envolvía, tu Palabra omnipotente saltó del cielo, desde el trono real.  
R. Y hemos contemplado su gloria, como Hijo único, lleno de gracia y de verdad.  

## Oración

Dios todopoderoso y eterno, tú que nos has hecho renacer a una vida nueva por medio de tu Hijo, concédenos que la gracia nos modele a imagen de Cristo, en quien nuestra naturaleza mortal se une a tu naturaleza divina. Por nuestro Señor Jesucristo.

## Primera lectura del día

**Del libro del profeta Baruc 4, 30—5, 9** — *Alegría de la nueva Jerusalén*

¡Ánimo, Jerusalén! El Señor que te dio su nombre te consolará.

¡Malditos los que te han hecho daño, los que se han alegrado de tu caída! ¡Malditas las ciudades que esclavizaron a tus hijos! ¡Maldita la ciudad donde fueron a parar! Si se alegró al verte caer, si contempló regocijada tu catástrofe, se lamentará cuando sea devastada. Le arrancaré el orgullo de ciudad populosa, su altivez quedará reducida a duelo. El fuego inextinguible del Eterno la devorará, durante años será habitada por demonios.

Vuelve la mirada hacia oriente, Jerusalén; contempla la alegría que Dios te envía. Ahí llegan los hijos que viste marchar, la palabra del Santo los ha convocado; ya van viniendo de oriente a occidente, llegan celebrando la gloria de Dios.

Jerusalén, despójate del vestido de luto y aflicción que llevas, y vístete las galas perpetuas de la gloria que Dios te concede.

Envuélvete ahora en el manto de la justicia de Dios, y ponte en la cabeza la diadema de la gloria del Eterno, porque Dios mostrará tu esplendor a cuantos habitan bajo el cielo. Dios te dará un nombre para siempre: «Paz en la justicia» y «Gloria en la piedad».

En pie, Jerusalén, sube a la altura, mira hacia oriente y contempla a tus hijos: el Santo los reúne de oriente a occidente y llegan gozosos invocando a su Dios. A pie tuvieron que partir, conducidos por el enemigo, pero Dios te los traerá con gloria, como llevados en carroza real.

Dios ha mandado rebajarse a todos los montes elevados y a todas las colinas encumbradas; ha mandado rellenarse a los barrancos hasta hacer que el suelo se nivele, para que Israel camine seguro, guiado por la gloria de Dios.

Ha mandado a los bosques y a los árboles aromáticos que den sombra a Israel.

Porque Dios guiará a Israel con alegría, a la luz de su gloria, con su justicia y su misericordia.

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
