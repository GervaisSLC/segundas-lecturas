# Tiempo Ordinario — año par

[Volver al calendario](index.md) · [Guía para IAs](../llms.txt)

## Semana 1 del Tiempo Ordinario

- **Martes de la semana I del Tiempo Ordinario (semana 1)** — [El Señor colocó al hombre en el paraíso como el sol en el cielo, a la espera del reino de los cielos](../r/f9daed8a78.md) — San Ambrosio de Milán · cap.1, 2-2, 6: CSEL 32, 266-267
- **Miércoles de la semana I del Tiempo Ordinario (semana 1)** — [Cuando se cumplió el tiempo, envió Dios a su Hijo para que recibiéramos el ser hijos por adopción](../r/725fe8cb33.md) — San Cirilo de Alejandría · PG 77, 27-30
- **Jueves de la semana I del Tiempo Ordinario (semana 1)** — [El sacrificio del justo Abel significó que el Señor Jesús iba a ofrecerse por nosotros](../r/b0ade8e55e.md) — San Ambrosio de Milán · 39 11-14: PL 14, 1061-1062
- **Viernes de la semana I del Tiempo Ordinario (semana 1)** — [Producid el fruto que la conversión pide](../r/e7160069cd.md) — Orígenes · Hom. 22, 7-10: SC 87. 306-308
- **Sábado de la semana I del Tiempo Ordinario (semana 1)** — [Han cambiado los signos, no la fe](../r/e67c28db12.md) — San Agustín de Hipona · 19 3: CCL 41, 253-254
- **En lugar del Domingo I del tiempo ordinario se tiene la fiesta del Bautismo del Señor.** — [Purificados por su palabra, Dios hace resplandecer en nosotros la imagen del hombre celestial](../r/9af756d022.md) — Orígenes · Hom. 4: PG 12, 234-235

## Semana 2 del Tiempo Ordinario

- **Domingo de la semana II del Tiempo Ordinario (semana 2)** — [Gracia y paz a vosotros de parte del Dios omnipotente](../r/f3d4f33212.md) — San Clemente I, papa · 1: Funk 1,61-62
- **Martes de la semana II del Tiempo Ordinario (semana 2)** — [Pongamos ante nuestros ojos a los santos apóstoles](../r/fbde44fddc.md) — San Clemente I, papa · 4-5: Funk 1, 65-69
- **Miércoles de la semana II del Tiempo Ordinario (semana 2)** — [De generación en generación, el Señor concedió un tiempo de penitencia a los que deseaban convertirse a él](../r/81d6c4e5f2.md) — San Clemente I, papa · 6-8: Funk 1,69-73
- **Jueves de la semana II del Tiempo Ordinario (semana 2)** — [Abrahán, llamado amigo, fue hallado fiel](../r/7b98ac4792.md) — San Clemente I, papa · 9-11: Funk 1, 73-75
- **Viernes de la semana II del Tiempo Ordinario (semana 2)** — [Seamos humildes de corazón](../r/0aff14047c.md) — San Clemente I, papa · 12-13: Funk 1, 75-79
- **Sábado de la semana II del Tiempo Ordinario (semana 2)** — [Ved qué dechado se nos propone](../r/6f6658c7d6.md) — San Clemente I, papa · 14-17: Funk 1, 79-85
- **Del comentario de san Cirilo de Alejandría, obispo, sobre el evangelio de san Juan** — [Sed solícitos día y noche por la fraternidad universal](../r/57ba417109.md) — San Clemente I, papa · 2-3: Funk 1, 63-65

## Semana 3 del Tiempo Ordinario

- **Domingo de la semana III del Tiempo Ordinario (semana 3)** — [Inclinaos bajo la poderosísima mano de Dios](../r/fe8a505dfd.md) — San Cesáreo de Arlés · Sermón 114, 1.4: CCL 104, 593-595
- **Domingo de la semana III del Tiempo Ordinario (semana 3)** — [Arrepiéntete y te salvaré](../r/eb29316629.md) — Tertuliano · 2, 3-7; 4,1-3: CCL 1, 322-323; 326
- **Domingo de la semana III del Tiempo Ordinario (semana 3)** — [Hoy, en esta reunión, habla el Señor](../r/eb688c45c6.md) — Orígenes · Hom. 32, 2-6: SC 87, 386-392
- **Domingo de la semana III del Tiempo Ordinario (semana 3)** — [El Señor del universo ha querido que reinara la paz y la concordia](../r/c78db01ded.md) — San Clemente I, papa · 18-20: Funk 1, 85-89
- **Lunes de la semana III del Tiempo Ordinario (semana 3)** — [No nos apartamos nunca de la voluntad de Dios](../r/182965a898.md) — San Clemente I, papa · 21, 1—22, 5; 23, 1-2: Funk 1, 89-93
- **Martes de la semana III del Tiempo Ordinario (semana 3)** — [Dios es fiel en sus promesas](../r/8498354e55.md) — San Clemente I, papa · 24, 1-5; 27, 1—29, 1
- **Miércoles de la semana III del Tiempo Ordinario (semana 3)** — [Busquemos en Dios nuestra alabanza, no en nosotros mismos](../r/8a27d297eb.md) — San Clemente I, papa · 30.31.32: Funk 1, 97-101
- **Jueves de la semana III del Tiempo Ordinario (semana 3)** — [Nuestra gloria y nuestra confianza estén siempre en Dios](../r/3fe4e895e8.md) — San Clemente I, papa · 33-34: Funk 1, 101-103
- **Viernes de la semana III del Tiempo Ordinario (semana 3)** — [¡Qué grandes y maravillosos son los dones de Dios!](../r/fd3d8ee34f.md) — San Clemente I, papa · 35-36: Funk 1, 105-107
- **Sábado de la semana III del Tiempo Ordinario (semana 3)** — [Tomemos como ejemplo a nuestro cuerpo](../r/a75a5ecd6c.md) — San Clemente I, papa · 37-38: Funk 1, 107-109

## Semana 4 del Tiempo Ordinario

- **Domingo de la semana IV del Tiempo Ordinario (semana 4)** — [Cristo promulga el código de la vida celestial](../r/48f93d7eba.md) — San Hilario de Poitiers · Cap. 4, 1-3. 9: PL 9, 931-934
- **Domingo de la semana IV del Tiempo Ordinario (semana 4)** — [Los apóstoles salieron a anunciar la llegada del reino de Dios](../r/1b11eaab85.md) — San Clemente I, papa · 40-43: Funk 1, 109-115
- **Lunes de la semana IV del Tiempo Ordinario (semana 4)** — [Los justos sufrieron persecución](../r/4fa2e87fc4.md) — San Clemente I, papa · 44-45: Funk 1,115-119
- **Miércoles de la semana IV del Tiempo Ordinario (semana 4)** — [¿Quién será capaz de explicar el vínculo del amor divino?](../r/ce13c14964.md) — San Clemente I, papa · 49-50: Funck 1, 123-125
- **Jueves de la semana IV del Tiempo Ordinario (semana 4)** — [Más le vale al hombre confesar sus caídas que endurecer su corazón](../r/58742b75c4.md) — San Clemente I, papa · 51-52.54: Funk 1, 129.130
- **Viernes de la semana IV del Tiempo Ordinario (semana 4)** — [Obedezcamos a su nombre santísimo y glorioso](../r/2b24452bb1.md) — San Clemente I, papa · 56, 1-2.16; 57, 1-2; 58,1-2: Funk 1, 131-135
- **Sábado de la semana IV del Tiempo Ordinario (semana 4)** — [La oración de los fieles](../r/2b20a7925d.md) — San Clemente I, papa · 59, 1–60,4; 61, 3: Funk 1, 135-137
- **Semana IV del Tiempo Ordinario** — [Busque cada uno no sólo su propio interés, sino también el de la comunidad](../r/05272e8936.md) — San Clemente I, papa · 46, 2-47, 4; 48, 1-6: Funk 1,119-123

## Semana 5 del Tiempo Ordinario

- **Domingo de la semana V del Tiempo Ordinario (semana 5)** — [La lámpara no luce para sí, sino para los que viven en tinieblas](../r/96eb272374.md) — San Juan Crisóstomo · Homilía 12, 20-2: PG 51, 174
- **Domingo de la semana V del Tiempo Ordinario (semana 5)** — [Dios busca a los hombres, no las cosas de los hombres](../r/997afad38a.md) — San Pedro Crisólogo · Sermón 18 : PL 52, 246-249
- **Domingo de la semana V del Tiempo Ordinario (semana 5)** — [Cristo eligió para apóstoles a unos pescadores](../r/b671c49b45.md) — San Agustín de Hipona · Sermón 43, 5-6: PL 38, 256-257
- **Domingo de la semana V del Tiempo Ordinario (semana 5)** — [Mantened la concordia en la caridad y en la paz](../r/b47e1080e5.md) — San Clemente I, papa · 62-63: Funk 1, 141-143
- **Lunes de la semana V del Tiempo Ordinario (semana 5)** — [La gracia de nuestro Señor Jesucristo esté con vosotros y con todos los llamados](../r/1a3d34e7da.md) — San Clemente I, papa · 64-65: Funk 1, 143-145
- **Martes de la semana V del Tiempo Ordinario (semana 5)** — [Renueva los tiempos pasados](../r/39c4d616d3.md) — San Atanasio de Alejandría · 10: PG 25, 111-114
- **Miércoles de la semana V del Tiempo Ordinario (semana 5)** — [El pueblo cristiano, apoyándose en la humildad, se eleva a la cumbre de la virtud](../r/82f5d5d1e4.md) — San Cesáreo de Arlés · Sermón 90, 4.6: CCL 103, 372.373. 374
- **Jueves de la semana V del Tiempo Ordinario (semana 5)** — [¡Ay del alma en la que no habita Cristo!](../r/70a0489e16.md) — San Macario · 28, PG 34, 710-711
- **Viernes de la semana V del Tiempo Ordinario (semana 5)** — [Hambre de oír la palabra del Señor](../r/3ad0ac9e0d.md) — Orígenes · 16, 4: PG 12, 249-250
- **Sábado de la semana V del Tiempo Ordinario (semana 5)** — [Cristo lava a su Iglesia con el baño del segundo nacimiento](../r/05bf451db9.md) — Orígenes · 17, 8.9: PG 12,260-261

## Semana 6 del Tiempo Ordinario

- **Domingo de la semana VI del Tiempo Ordinario (semana 6)** — [Para que conservemos la inocencia en el corazón](../r/5afb02b4e2.md) — San Agustín de Hipona · Sermón sobre el discurso del Monte 1, 9, 21: CCL 35, 22-23
- **Domingo de la semana VI del Tiempo Ordinario (semana 6)** — [Estad siempre alegres en el Señor](../r/5bd4840128.md) — San Ambrosio de Milán · PLS 1, 617-618
- **Lunes de la semana VI del Tiempo Ordinario (semana 6)** — [La multitud de los creyentes no era sino un solo corazón y una sola alma](../r/4ff59ffcd4.md) — San Hilario de Poitiers · 132, PLS 1, 244-245
- **Martes de la semana VI del Tiempo Ordinario (semana 6)** — [Comportémonos de modo que, arrebatados en la nube, estemos siempre con el Señor](../r/00dcdf7ccf.md) — San Juan Crisóstomo · 6: PG 51, 352-353
- **Miércoles de la semana VI del Tiempo Ordinario (semana 6)** — [El discernimiento de espíritus se adquiere por el gusto espiritual](../r/10093d4583.md) — Diádoco de Fótice · 6.26.27.30: PG 65, 1169.1175-1176
- **Jueves de la semana VI del Tiempo Ordinario (semana 6)** — [Que la cruz sea tu gozo también en tiempo de persecución](../r/48bf85a08e.md) — San Cirilo de Jerusalén · Catequesis 13, 1.3.6.23: PG 33, 771-774.779.799.802
- **Viernes de la semana VI del Tiempo Ordinario (semana 6)** — [Llegaréis a vuestra plenitud, según la plenitud total de Cristo](../r/f9b2209e6f.md) — Actas y escritos anónimos · 18, 7-11: PG 34, 639-642
- **Sábado de la semana VI del Tiempo Ordinario (semana 6)** — [La actividad humana](../r/605dbf61df.md) — Concilio Vaticano II · Núms 33-36

## Semana 7 del Tiempo Ordinario

- **Domingo de la semana VII del Tiempo Ordinario (semana 7)** — [Eficacia de la oración](../r/a0995eb2f0.md) — San Juan Crisóstomo · Homilía 2, 4-5: PG 61, 397- 399
- **Domingo de la semana VII del Tiempo Ordinario (semana 7)** — [Que nuestras obras proclamen la generosidad de Dios](../r/12594d815b.md) — San Cipriano de Cartago · Trat. 12-13.15: CSEL 3, 427-430
- **Domingo de la semana VII del Tiempo Ordinario (semana 7)** — [Todas estas cosas las realizan las manos consagradas de los sacerdotes](../r/bf3186e110.md) — San Juan Crisóstomo · Lib 3, 3-6: PG 48, 643-644
- **Domingo de la semana VII del Tiempo Ordinario (semana 7)** — [Tu bienhechor te quiere espléndido](../r/fd2cdd2f44.md) — San León Magno · Tratado 17, 1-4: CCL 138, 68-71
- **Lunes de la semana VII del Tiempo Ordinario (semana 7)** — [Los apóstoles predicaban a Jesús crucificado](../r/ddc0985751.md) — Sin identificar · 14, 7-8: ed. E. M. Buytaert, Spicilegium S. Lovaniense 26 [1953], 326-328
- **Martes de la semana VII del Tiempo Ordinario (semana 7)** — [Somos el incienso de Cristo](../r/280c02e6ee.md) — San Agustín de Hipona · Comentario 2, sobre el salmo 92: CCL 39, 1292
- **Miércoles de la semana VII del Tiempo Ordinario (semana 7)** — [La fidelidad del Señor dura por siempre](../r/110fa39002.md) — Tomás de Kempis (Imitación de Cristo) · Lib. 3, cap. 14
- **Jueves de la semana VII del Tiempo Ordinario (semana 7)** — [Ha resplandecido sobre nosotros la luz de tu rostro](../r/7df7edd773.md) — San Ambrosio de Milán · Sal 43, 89-90: CSEL 64, 324-326
- **Viernes de la semana VII del Tiempo Ordinario (semana 7)** — [Cristo reconcilió el mundo con Dios por su propia sangre](../r/2bfe06e12f.md) — San Ambrosio de Milán · Salmo 48, 14-15: CSEL 64, 368-370
- **Sábado de la semana VII del Tiempo Ordinario (semana 7)** — [Sentimos el corazón ensanchado](../r/6c343c8be8.md) — San Juan Crisóstomo · Homilías 13 1-2: PG 61, 491-492

## Semana 8 del Tiempo Ordinario

- **Domingo de la semana VIII del Tiempo Ordinario (semana 8)** — [Sobre todo buscad el reino de Dios y su justicia](../r/44dce7017a.md) — San Cirilo de Alejandría · Hom. 62. Edit R.R. Tonneau: CSCO t. 70, 160-164
- **Domingo de la semana VIII del Tiempo Ordinario (semana 8)** — [Trayéndose a sí mismo, Cristo nos trajo toda novedad](../r/369a33f64a.md) — San Ireneo de Lyon · Lib 4, 34, 1.2.3: SC 100, 846-848; 850-854
- **Domingo de la semana VIII del Tiempo Ordinario (semana 8)** — [Los discípulos llamados a ser los iniciadores y maestros del mundo entero](../r/c14c90a2fa.md) — San Cirilo de Alejandría · Cap 6: PG 72, 602-603
- **Domingo de la semana VIII del Tiempo Ordinario (semana 8)** — [En toda esta lucha me siento rebosando de alegría](../r/d04fcccd5f.md) — San Juan Crisóstomo · 14, 1-2: PG 61, 497-499
- **Lunes de la semana VIII del Tiempo Ordinario (semana 8)** — [La misericordia divina y la misericordia humana](../r/7313f6cdba.md) — San Cesáreo de Arlés · Sermón 25, 1: CCL 103, 111-112
- **Martes de la semana VIII del Tiempo Ordinario (semana 8)** — [Sembrad justicia, y cosecharéis misericordia](../r/6d345c210a.md) — San Basilio Magno · Hom. 3 sobre la caridad, 6: PG 31, 266-267.275
- **Miércoles de la semana VIII del Tiempo Ordinario (semana 8)** — [La Iglesia o convocación del pueblo de Dios](../r/d9e6653345.md) — San Cirilo de Jerusalén · Catequesis 18, 23 25: PG 33,1043-1047
- **Jueves de la semana VIII del Tiempo Ordinario (semana 8)** — [La Iglesia es la esposa de Cristo](../r/f37a58b599.md) — San Cirilo de Jerusalén · Catequesis 18, 26-29: PG 33,1047-1050
- **Viernes de la semana VIII del Tiempo Ordinario (semana 8)** — [La cruz de Cristo, remedio, ejemplo y misterio](../r/714af941f8.md) — Gualterio de San Víctor · Sermón 3, 2.3.4: CCL CM 30, 250.251.252
- **Sábado de la semana VIII del Tiempo Ordinario (semana 8)** — [Necesidad de la penitencia cotidiana](../r/4c89525d86.md) — San Agustín de Hipona · Carta 265, 7-8: CSEL 57, 645-646

## Semana 9 del Tiempo Ordinario

- **Domingo de la semana IX del Tiempo Ordinario (semana 9)** — [Fundemos en Cristo nuestra fe](../r/5abe0bb926.md) — Sin identificar · Hom 21: PLS 3, 854-855
- **Domingo de la semana IX del Tiempo Ordinario (semana 9)** — [Nuestro sábado es el gozo en el sosiego de nuestra esperanza](../r/05a0e26e98.md) — San Agustín de Hipona · Comentario 1-2 sobre el Salmo 91: CCL 39, 1278-1280
- **Domingo de la semana IX del Tiempo Ordinario (semana 9)** — [La humilde fe del centurión](../r/d54992b215.md) — San Agustín de Hipona · Sermón 62, 1.3-4: PL 38, 414-416
- **Domingo de la semana IX del Tiempo Ordinario (semana 9)** — [Entendamos la gracia de Dios](../r/b5028b7176.md) — San Agustín de Hipona · Prefacio: PL 35, 2105-2107
- **Lunes de la semana IX del Tiempo Ordinario (semana 9)** — [La predicación apostólica](../r/3507799aac.md) — Tertuliano · Caps. 20,1-9; 21, 3; 22, 8-10: CCL 1, 201-204
- **Martes de la semana IX del Tiempo Ordinario (semana 9)** — [El sacrificio de Abrahán](../r/49961f1e03.md) — Orígenes · Hom. 8, 6.8.9: PG 12, 206-209
- **Miércoles de la semana IX del Tiempo Ordinario (semana 9)** — [Somos herederos de Dios y coherederos con Cristo](../r/e26880d2c0.md) — San Ambrosio de Milán · Carta 35 4-6.13: PL 16 [ed. 1845] 1078-1079. 1081
- **Jueves de la semana IX del Tiempo Ordinario (semana 9)** — [Hasta ver a Cristo formado en vosotros](../r/17402f5f03.md) — San Agustín de Hipona · 37-38: PL 35, 2131-2132
- **Viernes de la semana IX del Tiempo Ordinario (semana 9)** — [Santa y piadosa es la idea de rezar por los muertos](../r/6b354aa221.md) — San Gregorio Nacianceno · Sermón 7, 23-24: PG 35, 786-787
- **Sábado de la semana IX del Tiempo Ordinario (semana 9)** — [El soldado de Cristo debe renunciar a su propia voluntad](../r/39a2ae4fc0.md) — Gualterio de San Víctor · Sermón 3, 5.6.7.9: CCL CM 30, 252.253.254.255

## Semana 10 del Tiempo Ordinario

- **Domingo de la semana X del Tiempo Ordinario (semana 10)** — [He venido a llamar a los pecadores a que se conviertan](../r/5b9d807bc8.md) — San Agustín de Hipona · 1,7: CCL, 39, 733-734
- **Domingo de la semana X del Tiempo Ordinario (semana 10)** — [La penitencia obtiene el perdón en esta vida, valedero para la futura](../r/7d1afd160f.md) — San Agustín de Hipona · Sermón 71,1.13.14.19.20: PL 38, 445.451-452.454-456
- **Domingo de la semana X del Tiempo Ordinario (semana 10)** — [La Madre Iglesia se regocija por los hombres que cada día resucitan espiritualmente](../r/afd3c7afa4.md) — San Agustín de Hipona · Sermón 98, 1-3: PL 38, 591-592
- **Domingo de la semana X del Tiempo Ordinario (semana 10)** — [Estáis salvados por gracia](../r/085faee859.md) — San Policarpo de Esmirna · Caps 1, 1-2,3: Funk 1, 267-269
- **Lunes de la semana X del Tiempo Ordinario (semana 10)** — [Armémonos con las armas de la justicia](../r/3083347799.md) — San Policarpo de Esmirna · Caps 3 1-5, 2: Funk 1, 269-273
- **Martes de la semana X del Tiempo Ordinario (semana 10)** — [Cristo nos ha dejado un ejemplo en su propia persona](../r/fc4eeed4c1.md) — San Policarpo de Esmirna · Caps 6, 1-8, 2: Funk 1, 273-275
- **Miércoles de la semana X del Tiempo Ordinario (semana 10)** — [Andemos en la fe y en la justicia](../r/15f0e83e8c.md) — San Policarpo de Esmirna · Caps 9, 1-11, 4: Funk 1, 275-279
- **Jueves de la semana X del Tiempo Ordinario (semana 10)** — [Que Jesucristo os haga crecer en la fe y en la verdad](../r/988e466f02.md) — San Policarpo de Esmirna · Caps. 12 1-14: Funk 1, 279-283
- **Viernes de la semana X del Tiempo Ordinario (semana 10)** — [Es necesario no sólo llamarse cristianos, sino serlo en realidad](../r/9bec4bf3f9.md) — San Ignacio de Antioquía · Caps 1, 1-5,2: Funk 1, 191-195
- **Sábado de la semana X del Tiempo Ordinario (semana 10)** — [Una sola oración y una sola esperanza en la caridad y en la santa alegría](../r/93fc0da3b2.md) — San Ignacio de Antioquía · Caps 6 1-9, 2: Funk 1,195-199

## Semana 11 del Tiempo Ordinario

- **Domingo de la semana XI del Tiempo Ordinario (semana 11)** — [Así se alegran lo mismo el sembrador y el segador](../r/4b78f47a8f.md) — San Agustín de Hipona · Tratado 15, 32: CCL 36, 163-164
- **Domingo de la semana XI del Tiempo Ordinario (semana 11)** — [Cristo es el grano que ha disipado las tinieblas y ha renovado la Iglesia](../r/69e8e87870.md) — San Juan Crisóstomo · Homilía 7 [atribuida] : PG 64, 21-26
- **Domingo de la semana XI del Tiempo Ordinario (semana 11)** — [Dios no nos pide otra cosa que la conversión](../r/322d41302c.md) — Sin identificar · PG 61, 745-751
- **Domingo de la semana XI del Tiempo Ordinario (semana 11)** — [Tenéis a Cristo en vosotros](../r/130f9e8ff3.md) — San Ignacio de Antioquía · Caps 10, 1—15: Funk 1, 199-203
- **Lunes de la semana XI del Tiempo Ordinario (semana 11)** — [La Jerusalén celestial está fundada como ciudad](../r/13f817887a.md) — San Gregorio Magno · Lib 2, Hom 1, 5: CCL 142, 210-212
- **Martes de la semana XI del Tiempo Ordinario (semana 11)** — [Si el Señor no construye la casa, en vano se cansan los albañiles](../r/ba889777d2.md) — San Agustín de Hipona · Sal. 126, 2-3: CCL 40, 1857-1859
- **Miércoles de la semana XI del Tiempo Ordinario (semana 11)** — [Es grande mi nombre entre las naciones](../r/589ee3d49b.md) — San Cirilo de Alejandría · 14: PG 71. 1047 1050
- **Jueves de la semana XI del Tiempo Ordinario (semana 11)** — [La participación del cuerpo y sangre de Cristo nos santifica](../r/04f4dd0742.md) — San Fulgencio de Ruspe · Cap 28, 16-19: CCL 91A, 813-814
- **Viernes de la semana XI del Tiempo Ordinario (semana 11)** — [Luz perenne en el templo del Pontífice eterno](../r/dfba97fbd7.md) — San Columbano · 12, 2-3 Opera, Dublín 1957, pp. 112-114
- **Sábado de la semana XI del Tiempo Ordinario (semana 11)** — [El Señor mandó que todo se hiciese en paz y concordia](../r/673425bb2f.md) — San Agustín de Hipona · 146, 4-5.6: CCL 40, 2124-2125.2126

## Semana 12 del Tiempo Ordinario

- **Domingo de la semana XII del Tiempo Ordinario (semana 12)** — [El Salvador ha resucitado; Cristo vive; Cristo es la vida misma](../r/19fcd0f9a3.md) — San Atanasio de Alejandría · 29-30: PG 25, 146-147
- **Domingo de la semana XII del Tiempo Ordinario (semana 12)** — [A una orden de Cristo se produce la calma](../r/84e338d484.md) — San Agustín de Hipona · Sermón 43, 1-3: PL 38, 424-425
- **Domingo de la semana XII del Tiempo Ordinario (semana 12)** — [Pedro hace una precisa profesión de fe en Cristo](../r/9e6b5865fb.md) — San Cirilo de Alejandría · Homilía 39 : Edit R.M. Tonneau, CSCO Script Syri 70,110-115
- **Domingo de la semana XII del Tiempo Ordinario (semana 12)** — [La luz que alumbra a todo hombre](../r/987e53bad8.md) — San Máximo el Confesor · Cuestiones a Talasio (63: PG 90, 667-670
- **Lunes de la semana XII del Tiempo Ordinario (semana 12)** — [Yo salvaré a mi pueblo](../r/b2f4fb2da2.md) — San Agustín de Hipona · 4-6: CCL 36, 261-263
- **Martes de la semana XII del Tiempo Ordinario (semana 12)** — [Somos templo del Dios vivo](../r/0a8742f347.md) — San León Magno · 1.2.3.4: CCL 138A, 252.253.254.255
- **Miércoles de la semana XII del Tiempo Ordinario (semana 12)** — [Tú que has sido crucificado juntamente con Cristo, ofrécete a Dios como sacerdote sin tacha](../r/8f7e4d66a0.md) — San Gregorio de Nisa · Cap 24: PG 46, 414-416
- **Jueves de la semana XII del Tiempo Ordinario (semana 12)** — [Sobre el fundamento de la oración](../r/ed22e2548f.md) — Actas y escritos anónimos · Hom 6, 1-3: PG 34, 518-519
- **Viernes de la semana XII del Tiempo Ordinario (semana 12)** — [Esperamos la celestial consolación](../r/029e1ed3d1.md) — San Bernardo de Claraval · Sermón 5 sobre la Ascensión del Señor: Opera omnia Edit Cister. t. 5, 149 150.
- **Sábado de la semana XII del Tiempo Ordinario (semana 12)** — [Llama al Monte Sión «madre de los primogénitos»; en ella estaremos juntamente con Cristo](../r/80681d693a.md) — San Cirilo de Alejandría · Cap 3, 35-36; 37; 40; 41: PG 71, 689-692; 694; 702-703; 705.

## Semana 13 del Tiempo Ordinario

- **Domingo de la semana XIII del Tiempo Ordinario (semana 13)** — [Si quieres seguir a Cristo, vuélvete a la cruz; soporta, aguanta, manténte firme](../r/4c4859e6de.md) — San Agustín de Hipona · Sermón 96, 1-4: PL 38, 584-586
- **Domingo de la semana XIII del Tiempo Ordinario (semana 13)** — [Realmente, para Dios la muerte es un sueño](../r/be5df8c8d9.md) — San Pedro Crisólogo · Sermón 34, 1.5: CCL 34,193.197-199
- **Domingo de la semana XIII del Tiempo Ordinario (semana 13)** — [Velad, para que os ilumine la luz de la mañana](../r/d34dcc30b7.md) — Beato Guerrico de Igny · Sermón 3 sobre la Resurrección del Señor (3.5: SC 202,250-252.256-258
- **Lunes de la semana XIII del Tiempo Ordinario (semana 13)** — [Conviene orar y hacer votos a Dios continua y atentamente](../r/eaaa797aeb.md) — Actas y escritos anónimos · Hom 33: PG 34, 741-743
- **Martes de la semana XIII del Tiempo Ordinario (semana 13)** — [Yo soy vuestro preceptor](../r/0f206e38b9.md) — Clemente de Alejandría · Lib 1, cap 7: PG 8, 315-318
- **Miércoles de la semana XIII del Tiempo Ordinario (semana 13)** — [Cristo nos dio la paz y nos mandó que tuviéramos un solo corazón y una sola alma](../r/00176a31e1.md) — San Cipriano de Cartago · 12-14: CCL 3, 257-259
- **Jueves de la semana XIII del Tiempo Ordinario (semana 13)** — [Hemos de honrar a Dios durante toda la vida](../r/5a0b00949d.md) — Clemente de Alejandría · Lib 7, cap 7: PG 9, 450-451.458-459
- **Viernes de la semana XIII del Tiempo Ordinario (semana 13)** — [Él mismo fundó su Iglesia](../r/601a3ebc0d.md) — San Ambrosio de Milán · 16-17: PL 14, 1152-1153
- **Sábado de la semana XIII del Tiempo Ordinario (semana 13)** — [Haz penitencia y vuelve al Señor](../r/df54d31b6c.md) — Actas y escritos anónimos · Patericon 196: CSCO, Scriptores Aethiopici, t. 54, 118-121

## Semana 14 del Tiempo Ordinario

- **Domingo de la semana XIV del Tiempo Ordinario (semana 14)** — [Imitemos al Señor](../r/b1a26e4086.md) — San Juan Crisóstomo · Homilía 1,5 sobre la cruz y el ladrón : PG 49, 405-408
- **Domingo de la semana XIV del Tiempo Ordinario (semana 14)** — [El Padre mismo me ha enviado](../r/22272b79e1.md) — San Agustín de Hipona · Tratado 31, 3-4: CCL 36, 294-295
- **Domingo de la semana XIV del Tiempo Ordinario (semana 14)** — [Envió Cristo a los segadores con la hoz del evangelio](../r/14e11815c2.md) — San Agustín de Hipona · Sermón 101 (1.2.3.11: PL 38, 605.606.607.610
- **Domingo de la semana XIV del Tiempo Ordinario (semana 14)** — [La palabra de Dios, fuente inagotable de vida](../r/99d985a24e.md) — San Efrén · Cap 1, 18-19: SC 121, 52-53
- **Lunes de la semana XIV del Tiempo Ordinario (semana 14)** — [Hay que buscar la sabiduría](../r/d2a885ce99.md) — San Bernardo de Claraval · PL 184, 577 579
- **Martes de la semana XIV del Tiempo Ordinario (semana 14)** — [El conocimiento del Padre por medio de la Sabiduría creadora y hecha carne](../r/0a92a088e9.md) — San Atanasio de Alejandría · 78.81-82: PG 26, 311.319
- **Miércoles de la semana XIV del Tiempo Ordinario (semana 14)** — [La sabiduría de Dios nos mezcló su vino y puso su mesa](../r/2e681c01ed.md) — Sin identificar · Cap 9: PG 87, 1,1299-1303
- **Jueves de la semana XIV del Tiempo Ordinario (semana 14)** — [Abre tu boca a la palabra de Dios](../r/caa68ab4ff.md) — San Ambrosio de Milán · 65-66: CSEL 64, 123-125
- **Viernes de la semana XIV del Tiempo Ordinario (semana 14)** — [Considérate pecador si quieres llegar a ser justo](../r/087e405f59.md) — Actas y escritos anónimos · Patericon 142b: CSCO, Scriptores Aethiopici, t. 54, 62-64
- **Sábado de la semana XIV del Tiempo Ordinario (semana 14)** — [Sobre el pueblo bien dispuesto que se prepara para el Señor](../r/f502198632.md) — San Elredo de Rievaulx · Edit C.H. Talbot, SSOC, I, 1952, 40-41

## Semana 15 del Tiempo Ordinario

- **Domingo de la semana XV del Tiempo Ordinario (semana 15)** — [Sobre el servicio de la predicación](../r/6167b0216d.md) — San Gregorio Magno · Homilía 17, 5.6.7.8: PL 76, 1140-1142
- **Domingo de la semana XV del Tiempo Ordinario (semana 15)** — [Debemos atender a todos por igual](../r/e223ba2b3f.md) — San Juan Crisóstomo · Homilía 10, cap. 6, 4: PG 63, 88-89
- **Domingo de la semana XV del Tiempo Ordinario (semana 15)** — [Un certísimo ejemplo de paciencia](../r/b7b2d31044.md) — San Juan Crisóstomo · PG 51, 62-63
- **Domingo de la semana XV del Tiempo Ordinario (semana 15)** — [Al hombre le toca sembrar; a Dios, dar el crecimiento](../r/ef908b46ce.md) — San Atanasio de Alejandría · Homilía [atribuida] sobre la sementera, 2.3.4: PG 28, 146-150
- **Lunes de la semana XV del Tiempo Ordinario (semana 15)** — [Si aceptamos de Dios los bienes, ¿no vamos a aceptar los males?](../r/12210ea6cb.md) — San Gregorio Magno · Lib 3, 15-16: PL 75, 606-608
- **Martes de la semana XV del Tiempo Ordinario (semana 15)** — [A ti, Señor, me manifiesto tal como soy](../r/48a69222f7.md) — San Agustín de Hipona · Lib 10,1,1—2, 2; 5,7: CSEL 33, 226-227.230-231
- **Miércoles de la semana XV del Tiempo Ordinario (semana 15)** — [Cristo murió por todos](../r/b9878f6295.md) — San Agustín de Hipona · Lib 10, 43, 68-70: CSEL 33, 278-280
- **Jueves de la semana XV del Tiempo Ordinario (semana 15)** — [Señor, Dios mío, atiende a mi súplica](../r/00d00e544b.md) — San Agustín de Hipona · Lib 11, 1, 1-2, 3: CSEL 33, 283-285
- **Viernes de la semana XV del Tiempo Ordinario (semana 15)** — [¡Ánimo, soy yo!](../r/be670aeb6d.md) — Orígenes · Lib 11, 6: PG 13, 919-923
- **Sábado de la semana XV del Tiempo Ordinario (semana 15)** — [Toda mi esperanza está puesta en tu gran misericordia](../r/4aeecbf94e.md) — San Agustín de Hipona · Lib 10, 26, 37—29, 40: CSEL 33, 255-256

## Semana 16 del Tiempo Ordinario

- **Domingo de la semana XVI del Tiempo Ordinario (semana 16)** — [Lo mismo que la levadura hace fermentar toda la masa, así vosotros convertiréis el mundo entero](../r/332b82a482.md) — San Juan Crisóstomo · Homilía 46, 2-3: PG 58, 478-480
- **Domingo de la semana XVI del Tiempo Ordinario (semana 16)** — [Yo soy el que cura a las ovejas enfermas](../r/ee25c94dcc.md) — San Basilio Magno · Homilía 26 (2: PG 85, 306-307
- **Domingo de la semana XVI del Tiempo Ordinario (semana 16)** — [Sobre la vida activa y la vida contemplativa](../r/58095cee69.md) — San Gregorio Magno · Lib 2, Hom 2, 8-9: CCL 142, 230-231
- **Domingo de la semana XVI del Tiempo Ordinario (semana 16)** — [La ley del Señor abarca muchos aspectos](../r/84ba8dfe58.md) — San Gregorio Magno · Lib 10, 7-8.10: PL 75. 922.925-926
- **Martes de la semana XVI del Tiempo Ordinario (semana 16)** — [Job era figura de Cristo](../r/e1071ac4f3.md) — San Zenón de Verona · Tratado 15, 2: PL 11, 441-443
- **Miércoles de la semana XVI del Tiempo Ordinario (semana 16)** — [Mira, tu voz es mi gozo](../r/8f60202a79.md) — San Agustín de Hipona · Lib 11, 2, 3-3, 5: CSEL 33, 282-284
- **Jueves de la semana XVI del Tiempo Ordinario (semana 16)** — [Me llamaste para que te invocara](../r/943e15e5f2.md) — San Agustín de Hipona · Lib 13, 1, 1—2, 3 CSEL 33, 344-347
- **Viernes de la semana XVI del Tiempo Ordinario (semana 16)** — [Tu palabra, oh Dios, es fuente de vida eterna](../r/cd790af346.md) — San Agustín de Hipona · Lib 13, 21, 31—22, 32: CSEL 33, 369-371
- **Sábado de la semana XVI del Tiempo Ordinario (semana 16)** — [Señor, nos lo has dado todo: la paz del descanso, la paz del sábado, la paz sin ocaso](../r/041bfd6f1e.md) — San Agustín de Hipona · Lib 13, 35, 50—38, 53: CSEL 33, 386-388
- **Ciclo B Mc 6, 30-34** — [El testigo interior](../r/f9e6b6ff9e.md) — San Gregorio Magno · Lib 10, 47-48: PL 75, 946-947

## Semana 17 del Tiempo Ordinario

- **Domingo de la semana XVII del Tiempo Ordinario (semana 17)** — [Las perlas finas conducen a la perla de gran valor](../r/63588c45c3.md) — Orígenes · Lib. 10, 9-10: SC 162, 173-177
- **Domingo de la semana XVII del Tiempo Ordinario (semana 17)** — [Se nos invita a la fe, que es el trabajo de Dios](../r/ce3b699180.md) — Balduino de Canterbury · Parte 2,3: SC 93, 248-252
- **Domingo de la semana XVII del Tiempo Ordinario (semana 17)** — [Éstos son los bienes que principalmente hemos de pedir](../r/f06c6b1ae4.md) — San Beda el Venerable · Homilía 14 (CCL 122, 272-273.277-279
- **Domingo de la semana XVII del Tiempo Ordinario (semana 17)** — [Nuestro corazón no halla sosiego hasta que descanse en ti](../r/bb670e480b.md) — San Agustín de Hipona · Lib 1, 1,1—2, 2; 5, 5: CSEL 33, 1-5
- **Lunes de la semana XVII del Tiempo Ordinario (semana 17)** — [La causa de toda perturbación consiste en que nadie se acusa a sí mismo](../r/1c903959cf.md) — San Doroteo de Gaza · 1-2: PG 88, 1695-1699
- **Martes de la semana XVII del Tiempo Ordinario (semana 17)** — [La falsa paz de espíritu](../r/bf33aae1e6.md) — San Doroteo de Gaza · 2-3: PG 88, 1699
- **Miércoles de la semana XVII del Tiempo Ordinario (semana 17)** — [La verdadera enseñanza evita la arrogancia](../r/06b4fcbe1f.md) — San Gregorio Magno · Lib 23, 23-24: PL 76, 265-266
- **Jueves de la semana XVII del Tiempo Ordinario (semana 17)** — [La Iglesia se asoma como el alba](../r/48866c8da6.md) — San Gregorio Magno · Lib 29, 2-4: PL 76, 478-480
- **Viernes de la semana XVII del Tiempo Ordinario (semana 17)** — [El Señor discierne los pensamientos y sentimientos del corazón](../r/d17c56f285.md) — Balduino de Canterbury · PL 204, 466-467
- **Sábado de la semana XVII del Tiempo Ordinario (semana 17)** — [El camino para llegar a la vida verdadera](../r/b2065445a8.md) — Santo Tomás de Aquino · Cap 14, lec. 2

## Semana 18 del Tiempo Ordinario

- **Domingo de la semana XVIII del Tiempo Ordinario (semana 18)** — [Cristo, en su dignidad, es siempre deseable](../r/3a5a65ad35.md) — Balduino de Canterbury · Parte 2,3: SC 93, 252-254
- **Domingo de la semana XVIII del Tiempo Ordinario (semana 18)** — [Cristo bebió mis amarguras para darme la suavidad de su gracia](../r/82b165e619.md) — San Ambrosio de Milán · Sermón 18, 26-29: PL 15, 1461-1463
- **Domingo de la semana XVIII del Tiempo Ordinario (semana 18)** — [Vayamos de una vez en pos del Verbo, busquemos aquel descanso](../r/40d24d66d4.md) — San Gregorio Nacianceno · Sermón 14, 20-22 sobre el amor a los pobres: PG 35, 882-886
- **Domingo de la semana XVIII del Tiempo Ordinario (semana 18)** — [Venid a curaros los que os sentís enfermos](../r/b4098e9edf.md) — San Gregorio de Nisa · Comienza el discurso sobre el bautismo (PG 415-418.419
- **Domingo de la semana XVIII del Tiempo Ordinario (semana 18) - Año A: Mt 14, 13-21** — [Abre tu alma a una educación esmerada](../r/8f6adc85dc.md) — San Gregorio de Nisa · PG 46, 420-422.426
- **Martes de la semana XVIII del Tiempo Ordinario (semana 18)** — [Amad los trofeos y las coronas que Dios tiene preparados para sus atletas](../r/d4fd282d4b.md) — San Gregorio de Nisa · PG 46, 427-430
- **Miércoles de la semana XVIII del Tiempo Ordinario (semana 18)** — [Venid vosotros, benditos de mi Padre; heredad el reino preparado para vosotros desde la creación del mundo](../r/bdc3de38da.md) — San Gregorio de Nisa · PG 46, 430-432
- **Jueves de la semana XVIII del Tiempo Ordinario (semana 18)** — [Vivimos en la esperanza](../r/e911f8177e.md) — San Bernardo de Claraval · Sermón 7 sobre el salmo 90, 1.3.5.6.12: Opera omnia, edit Cister. t. 4, 1966, 412-416. 421
- **Viernes de la semana XVIII del Tiempo Ordinario (semana 18)** — [En todo lugar ofrecerán incienso a mi nombre y una ofrenda pura](../r/88d8325c07.md) — San Agustín de Hipona · Lib 10, 6: CCL 47, 278-279
- **Sábado de la semana XVIII del Tiempo Ordinario (semana 18)** — [Yo soy el alfa y la omega, el primero y el último](../r/8c0c449131.md) — Concilio Vaticano II · núm. 40.45

## Semana 19 del Tiempo Ordinario

- **Domingo de la semana XIX del Tiempo Ordinario (semana 19)** — [¡Señor, sálvame, que me hundo!](../r/02dc062052.md) — San Agustín de Hipona · Sermón 76, 1. 4.-6. 8-9: PL 38, 479-483
- **Domingo de la semana XIX del Tiempo Ordinario (semana 19)** — [Y el pan que yo daré es mi carne, para la vida del mundo](../r/8d3ac54668.md) — Ruperto de Deutz · Lib 6, 51-52: CCL CM 9, 356-357
- **Domingo de la semana XIX del Tiempo Ordinario (semana 19)** — [Que la Palabra de Dios sea lámpara para mis pasos](../r/5f72dc08c5.md) — San Ambrosio de Milán · Sermón 14, 11-13: PL 15, 1394-1395
- **Domingo de la semana XIX del Tiempo Ordinario (semana 19)** — [Sobre el signo de Jonás](../r/baf984048c.md) — San Ambrosio de Milán · 83-85: PL 14, 1129-1130
- **Domingo de la semana XIX del Tiempo Ordinario (semana 19) - Año A: Mt 14, 22-33** — [El Señor es pronto a la misericordia y salva a los que hacen penitencia](../r/9a4312e08b.md) — San Cirilo de Alejandría · Cap 3, 23—4, 29: PG 71, 631.638
- **Martes de la semana XIX del Tiempo Ordinario (semana 19)** — [Mira a tu rey, que viene a ti justo y victorioso](../r/b775312098.md) — San Andrés de Creta · Sermón 9, sobre el domingo de Ramos : PG 97, 1002
- **Miércoles de la semana XIX del Tiempo Ordinario (semana 19)** — [El corazón del justo se gozará en el Señor](../r/50c05378a5.md) — San Agustín de Hipona · Sermón 21, 1-4: CCL 41, 276-278
- **Jueves de la semana XIX del Tiempo Ordinario (semana 19)** — [Oración del buen pastor](../r/6083068f4d.md) — San Gregorio de Nisa · Cap 2: PG 44, 802
- **Viernes de la semana XIX del Tiempo Ordinario (semana 19)** — [El misterio de Cristo en nosotros y en la Iglesia](../r/233f2e3ced.md) — San Juan Eudes · Parte 3, 4: Opera omnia 1, 310-312
- **Sábado de la semana XIX del Tiempo Ordinario (semana 19)** — [Me saciaré de tu semblante](../r/a30f280228.md) — Santo Tomás de Aquino · Opúsculos teológicos 2, Turín 1954, pp. 216-217

## Semana 20 del Tiempo Ordinario

- **Domingo de la semana XX del Tiempo Ordinario (semana 20)** — [El Señor otorgó a la mujer el fruto de su fe](../r/a991414d70.md) — San Atanasio de Alejandría · Carta Pascual 7, 6-8: PG 26, 1393-1394
- **Domingo de la semana XX del Tiempo Ordinario (semana 20)** — [Nuestro Señor Jesucristo nos alimenta para la vida eterna](../r/4b38ea0581.md) — San Cirilo de Alejandría · Lib 2, 3: PG 69, 455-459
- **Domingo de la semana XX del Tiempo Ordinario (semana 20)** — [He venido a prender fuego en el mundo](../r/d72fd096ca.md) — Pedro de Blois · Sermón 25 : PL 207, 635-637
- **Domingo de la semana XX del Tiempo Ordinario (semana 20)** — [Sin la caridad, todo es vanidad de vanidades](../r/a03ef7baec.md) — San Máximo el Confesor · Centuria 1, cap 1, 4-5.16-17.23-24.26-28.30-40: PG 90, 962-967
- **Domingo de la semana XX del Tiempo Ordinario (semana 20) - Año A: Mt 15, 21-28** — [El sabio tiene sus ojos puestos en la cabeza](../r/88dcfd0b52.md) — San Gregorio de Nisa · Hom. 5 : PG 44, 683-686
- **Martes de la semana XX del Tiempo Ordinario (semana 20)** — [Tiene su tiempo el nacer y su tiempo el morir](../r/1f2d5b0c97.md) — San Gregorio de Nisa · Homilía 6 : PG 44, 702-703
- **Miércoles de la semana XX del Tiempo Ordinario (semana 20)** — [Buscad los bienes de arriba](../r/c40d478a83.md) — San Jerónimo · PL 23, 1057-1059
- **Jueves de la semana XX del Tiempo Ordinario (semana 20)** — [La insondable profundidad de Dios](../r/a01fe6e6fa.md) — San Columbano · Instrucción 1, 3-5 sobre la fe: Opera omnia, Dublín 1957, pp. 62-66
- **Viernes de la semana XX del Tiempo Ordinario (semana 20)** — [Mi corazón se alegra en el Señor](../r/c2d6bdb3e8.md) — San Gregorio de Agrigento · Lib 8, 6: PG 98, 1071-1074
- **Sábado de la semana XX del Tiempo Ordinario (semana 20)** — [Contemplad al Señor, y quedaréis radiantes](../r/10c778e2a7.md) — San Gregorio de Agrigento · Lib 10, 2: PG 98, 1138-1139

## Semana 21 del Tiempo Ordinario

- **Domingo de la semana XXI del Tiempo Ordinario (semana 21)** — [Cristo entregó las llaves a aquel que extendió la Iglesia por todo el orbe de la tierra](../r/f7ec2e21d8.md) — San Juan Crisóstomo · Homilía 54, 1-2: PG 58, 533-536
- **Domingo de la semana XXI del Tiempo Ordinario (semana 21)** — [Sobre la fe de los apóstoles](../r/cd6c6d0a05.md) — Balduino de Canterbury · Parte 2, 3: SC 93, 296-300
- **Domingo de la semana XXI del Tiempo Ordinario (semana 21)** — [Da amor y recibe el reino; ama y toma](../r/35f4c22795.md) — San Anselmo de Canterbury · Carta 112 : Opera omnia, t. 3, 1946, 244-246
- **Domingo de la semana XXI del Tiempo Ordinario (semana 21)** — [El pastor debe saber guardar silencio con discreción y hablar cuando es útil](../r/1a4a086f98.md) — San Gregorio Magno · Lib 2, 4: PL 77, 30-31
- **Domingo de la semana XXI del Tiempo Ordinario (semana 21) - Año A: Mt 16, 13-20** — [Hay que orar especialmente por todo el cuerpo de la Iglesia](../r/01bd9472a1.md) — San Ambrosio de Milán · Lib 1, 9, 34. 38-39: CSEL 32, 369.371-372
- **Martes de la semana XXI del Tiempo Ordinario (semana 21)** — [Que nadie desespere por la gravedad de sus pecados](../r/2e16f6e3c8.md) — Actas y escritos anónimos · Sermón 4, 2-7: SC 161, 170-175
- **Miércoles de la semana XXI del Tiempo Ordinario (semana 21)** — [Actúa con valentía, cual experto timonel](../r/f787acc67d.md) — San Basilio Magno · Carta 161, 1-2 al obispo Anfiloquio : PG 32, 630-631
- **Jueves de la semana XXI del Tiempo Ordinario (semana 21)** — [Que toda nuestra oración esté impregnada de acción de gracias](../r/a23bb9a637.md) — San Juan Crisóstomo · Hom. 6, 1-2: PG 62, 529-531
- **Viernes de la semana XXI del Tiempo Ordinario (semana 21)** — [Os quiero prevenir como a hijos míos amadísimos](../r/2c1505fe25.md) — San Ignacio de Antioquía · Caps 1, 1-3; 2; 4,1-2; 6,1; 7, 1-8, 1: Funk 1, 203-209
- **Sábado de la semana XXI del Tiempo Ordinario (semana 21)** — [Convertíos en criaturas nuevas por medio de la fe, que es como la carne del Señor, y por medio de la caridad, que es como su sangre](../r/f31dedede1.md) — San Ignacio de Antioquía · Caps 8, 1-9, 2; 11, 1—13 3: Funk 1, 209-211

## Semana 22 del Tiempo Ordinario

- **Domingo de la semana XXII del Tiempo Ordinario (semana 22)** — [La Iglesia sigue a Cristo por doquier](../r/b9c5d88962.md) — San Cirilo de Alejandría · Lib 5: PG 68, 391-395
- **Domingo de la semana XXII del Tiempo Ordinario (semana 22)** — [Tanto en la ley como en el evangelio, el primero y principal mandamiento es amar a Dios](../r/23eb3ac28c.md) — San Ireneo de Lyon · Lib 4, 12,1—13,3: SC 100, 508-516
- **Domingo de la semana XXII del Tiempo Ordinario (semana 22)** — [Sobre la verdadera humildad](../r/bd20d73331.md) — San Elredo de Rievaulx · Edit C.H. Talbot, SSOC vol 1, 78-80
- **Domingo de la semana XXII del Tiempo Ordinario (semana 22)** — [No os hablo con autoridad, como si fuera alguien](../r/fc21868788.md) — San Ignacio de Antioquía · 1-3: Funk 2, 183-185
- **Domingo de la semana XXII del Tiempo Ordinario (semana 22) - Año A: Mt 12, 21-27** — [En la concordia de la unidad](../r/6c2424659b.md) — San Ignacio de Antioquía · n. 4-6: Funk 2, 183-185
- **Martes de la semana XXII del Tiempo Ordinario (semana 22)** — [Todo lo hacéis en Cristo Jesús](../r/a284268d38.md) — San Ignacio de Antioquía · 7-9: Funk 2, 189-193
- **Miércoles de la semana XXII del Tiempo Ordinario (semana 22)** — [Las cadenas, perlas espirituales](../r/2e388de472.md) — San Ignacio de Antioquía · 10-12: Funk 2, 195-197
- **Jueves de la semana XXII del Tiempo Ordinario (semana 22)** — [Nada mejor que la paz en Cristo](../r/83a5ee7288.md) — San Ignacio de Antioquía · 13-15: Funk 2, 197-201
- **Viernes de la semana XXII del Tiempo Ordinario (semana 22)** — [La cruz es para nosotros salvación y vida eterna](../r/f0f069b8a1.md) — San Ignacio de Antioquía · 16-19: Funk 2,201-203
- **Sábado de la semana XXII del Tiempo Ordinario (semana 22)** — [Doy mi vida por vosotros](../r/c2af025683.md) — San Ignacio de Antioquía · 20-21: Funk 2, 203-205

## Semana 23 del Tiempo Ordinario

- **Domingo de la semana XXIII del Tiempo Ordinario (semana 23)** — [El número prescrito no limita, sino que dilata el perdón](../r/886620014a.md) — San Pedro Crisólogo · Sermón 139 : PL 52, 573-575
- **Domingo de la semana XXIII del Tiempo Ordinario (semana 23)** — [Todo lo ha hecho bien](../r/0a55e767ce.md) — San Lorenzo de Brindis · Homilía 1 en el domingo XI de Pentecostés, 1.9.11.12: Opera omnia, t. 8, 124.134.136-138
- **Domingo de la semana XXIII del Tiempo Ordinario (semana 23)** — [Sobre las tres renuncias](../r/6366588797.md) — Juan Casiano · Conf 3, cap 6-7: PL 564-567
- **Domingo de la semana XXIII del Tiempo Ordinario (semana 23)** — [Cual sea el trabajo de cada uno, tal será su ganancia](../r/41cb16cc22.md) — San León Magno · Serm. 92, 1.2.3: PL 54, 454-455
- **Domingo de la semana XXIII del Tiempo Ordinario (semana 23) - Año A: Mt 18, 15-20** — [Llegarás a la fuente, verás la luz](../r/7631cdbf18.md) — San Agustín de Hipona · Tratado 35, 8-9: CCL 36, 321-323
- **Martes de la semana XXIII del Tiempo Ordinario (semana 23)** — [Primicia de la sabiduría es el temor del Señor](../r/b1c609f2f7.md) — San Bernardo de Claraval · Sermón 37, 5-7: Opera omnia, Edit. Cister. t. 2, 1958, 12-14
- **Miércoles de la semana XXIII del Tiempo Ordinario (semana 23)** — [No desprecies a los pobres como si fuesen de ningún valor](../r/6509ff94e2.md) — San Gregorio de Nisa · Hom. 1 sobre el amor a los pobres : PG 46, 459-462
- **Jueves de la semana XXIII del Tiempo Ordinario (semana 23)** — [Llevemos desde ahora una vida sobria, honrada y religiosa aguardando la aparición gloriosa del gran Dios](../r/b42ff5f42f.md) — Clemente de Alejandría · Cap 1: PG 8, 59-63
- **Viernes de la semana XXIII del Tiempo Ordinario (semana 23)** — [El Hijo del hombre vendrá con la gloria de su Padre](../r/45947dda33.md) — San Beda el Venerable · Hom. 1, 24: CCL 122, 170-171
- **Sábado de la semana XXIII del Tiempo Ordinario (semana 23)** — [Cantemos el Aleluya al Dios bueno que nos libra del mal](../r/b74d1f4513.md) — San Agustín de Hipona · Sermón 256, 1.2.3: PL 38, 1191-1193

## Semana 24 del Tiempo Ordinario

- **Domingo de la semana XXIV del Tiempo Ordinario (semana 24)** — [Perdónanos nuestras deudas, así como nosotros perdonamos a nuestros deudores](../r/a4550dd350.md) — San Agustín de Hipona · Sermón 83, 2-4: PL 38, 515-516
- **Domingo de la semana XXIV del Tiempo Ordinario (semana 24)** — [No es duro lo que manda aquel que ayuda a realizar lo que ordena](../r/cc26755d11.md) — San Cesáreo de Arlés · Sermón 159,1.4-6: CCL 104, 652-654
- **Domingo de la semana XXIV del Tiempo Ordinario (semana 24)** — [Cristo nos buscó en la tierra: busquémosle nosotros en el cielo](../r/b5869e43f5.md) — San Pedro Crisólogo · Sermón 168 :PL 52, 639-641
- **Domingo de la semana XXIV del Tiempo Ordinario (semana 24)** — [Que nuestro deseo de la vida eterna se ejercite en la oración](../r/0573eb6e12.md) — San Agustín de Hipona · Carta 130, 8, 15.17-9 18 a Proba: CSEL 44, 6-57.59-60
- **Domingo de la semana XXIV del Tiempo Ordinario (semana 24) - Año A: Mt 18, 21-35** — [Debemos, en ciertos momentos, amonestarnos a nosotros mismos con la oración vocal](../r/bbe052a0b3.md) — San Agustín de Hipona · Carta 130, 9,18—10, 20 a Proba: CSEL 44, 60-63
- **Martes de la semana XXIV del Tiempo Ordinario (semana 24)** — [Sobre la oración dominical](../r/2542b38d42.md) — San Agustín de Hipona · Carta 130, 11, 21-12, 22 a Proba: CSEL 44, 63-64
- **Miércoles de la semana XXIV del Tiempo Ordinario (semana 24)** — [Nada hallarás que no se encuentre en esta oración dominical](../r/189d6951dc.md) — San Agustín de Hipona · Carta 130, 12, 22-13, 24 a Proba: CSEL 44, 65-68
- **Jueves de la semana XXIV del Tiempo Ordinario (semana 24)** — [No sabemos pedir lo que nos conviene](../r/551dcea6e8.md) — San Agustín de Hipona · Carta 130, 14, 25-26 a Proba: CSEL 44, 68-71
- **Viernes de la semana XXIV del Tiempo Ordinario (semana 24)** — [El Espíritu intercede por nosotros](../r/e8800b5b1c.md) — San Agustín de Hipona · Carta 130, 14, 27—15, 28 a Proba: CSEL 44, 71-73
- **Sábado de la semana XXIV del Tiempo Ordinario (semana 24)** — [En la sombra observamos las palabras de Dios](../r/a2a9510017.md) — San Ambrosio de Milán · Sermón 3, 19-21: CSEL 62, 50-53

## Semana 25 del Tiempo Ordinario

- **Domingo de la semana XXV del Tiempo Ordinario (semana 25)** — [El denario es la vida eterna](../r/9541849bd8.md) — San Agustín de Hipona · Sermón 87, 1.5.6: PL 38, 530. 531.532.533
- **Domingo de la semana XXV del Tiempo Ordinario (semana 25)** — [Por la humildad se llega al reino; por la sencillez se entra en el cielo](../r/48b8e98e34.md) — San Máximo de Turín · Sermón 48, 1-2: CCL 23, 187-188
- **Domingo de la semana XXV del Tiempo Ordinario (semana 25)** — [Sobre la perfecta fe en Dios](../r/a92602f258.md) — Actas y escritos anónimos · Homilía 48,1-6: PG 34, 807-811
- **Domingo de la semana XXV del Tiempo Ordinario (semana 25)** — [Todo para gloria de Dios](../r/b128a96f35.md) — San Máximo de Turín · Sermón 73, 1-4: CCL 23, 305-307
- **Domingo de la semana XXV del Tiempo Ordinario (semana 25) - Año A: Mt 20, 1-16a** — [Jesús es vida incluso para los que abandonan este mundo](../r/3e38f9c873.md) — San Juan Crisóstomo · Sermón 1, 5-7: PG 56, 297-298
- **Martes de la semana XXV del Tiempo Ordinario (semana 25)** — [Todos nosotros te glorificamos a ti, Dios nuestro, en medio de una profunda tranquilidad](../r/301204af5c.md) — San Germán de Constantinopla · PG 98, 442-443
- **Miércoles de la semana XXV del Tiempo Ordinario (semana 25)** — [Ésta es la luz: es una y uno son todos cuantos la ven y la aman](../r/d2c882c9f4.md) — San Agustín de Hipona · Lib 10,34: CSEL 33, 265-267
- **Jueves de la semana XXV del Tiempo Ordinario (semana 25)** — [Éste es el grupo que busca al Señor](../r/06878379d0.md) — San Gregorio de Nisa · Sermón sobre la ascensión de Cristo : PG 46, 690-691
- **Viernes de la semana XXV del Tiempo Ordinario (semana 25)** — [El tiempo de las bodas es aquel en que, por el misterio de la encarnación, el Señor se unió a la Iglesia](../r/1db5456fa0.md) — San Beda el Venerable · Hom. 14 : CCL 122, 95-96
- **Sábado de la semana XXV del Tiempo Ordinario (semana 25)** — [Apresurémonos al encuentro de los que nos esperan](../r/5e7b4b54b7.md) — San Bernardo de Claraval · Sermón 5, 2-3.6 en la fiesta de Todos los Santos : Opera omnia, Edit. Cister. t. 5, 1968, 362-363.365

## Semana 26 del Tiempo Ordinario

- **Domingo de la semana XXVI del Tiempo Ordinario (semana 26)** — [La oración es luz del alma](../r/b8f4cab50c.md) — San Juan Crisóstomo · Homilía 6 sobre la oración, suplemento: PG 64, 462-466
- **Domingo de la semana XXVI del Tiempo Ordinario (semana 26)** — [La verdadera penitencia consiste en no recaer en las mismas faltas](../r/43d600ead2.md) — Clemente de Alejandría · 39-40: PG 9, 643-646
- **Domingo de la semana XXVI del Tiempo Ordinario (semana 26)** — [Sed imitadores de Dios, como hijos queridos](../r/2eb63dac29.md) — Ricardo de San Víctor · 42-45: Ed. G. Dumeige, Paris 1955, 171-175
- **Domingo de la semana XXVI del Tiempo Ordinario (semana 26)** — [Lo que se aprende en la escuela de Cristo maestro](../r/8c5179b2ac.md) — San Agustín de Hipona · Sermón 33 A,4 sobre el antiguo Testamento : CCL 41, 421-422
- **Domingo de la semana XXVI del Tiempo Ordinario (semana 26) - Año A: Mt 21, 28-32** — [Esto es lo que hay que pedir en la oración](../r/e4760ca876.md) — Orígenes · 1-2: PG 11,415-418
- **Martes de la semana XXVI del Tiempo Ordinario (semana 26)** — [Cómo hemos de orar](../r/181d11236a.md) — Orígenes · 2: PG 11, 418-422
- **Miércoles de la semana XXVI del Tiempo Ordinario (semana 26)** — [Dios lo sabe todo antes de que suceda](../r/f9f5e440af.md) — Orígenes · 2.5: PG 11, 422-423. 430-434
- **Jueves de la semana XXVI del Tiempo Ordinario (semana 26)** — [Dios preordena todas las cosas](../r/0d5ca5be23.md) — Orígenes · 6: PG 11, 438
- **Viernes de la semana XXVI del Tiempo Ordinario (semana 26)** — [Sobre la oración asidua](../r/eed65ad257.md) — Orígenes · 7-8: PG 11, 439-442
- **Sábado de la semana XXVI del Tiempo Ordinario (semana 26)** — [Sobre la oración pura](../r/e6eab0e084.md) — Orígenes · 9-10: PG 11, 442-446

## Semana 27 del Tiempo Ordinario

- **Domingo de la semana XXVII del Tiempo Ordinario (semana 27)** — [Sobre el juicio pronunciado por el Padre](../r/c5156a9791.md) — San Cirilo de Alejandría · Lib 4, Sermón 4: PG 70, 1042-1043
- **Domingo de la semana XXVII del Tiempo Ordinario (semana 27)** — [Es éste un gran misterio](../r/38055f282f.md) — San Gregorio Nacianceno · Sermón 37, 5-7 sobre Mateo 19, 1-12: PG 36, 287-291
- **Domingo de la semana XXVII del Tiempo Ordinario (semana 27)** — [Despierta a tu fe, mira la vida futura con los ojos de la fe](../r/f65efc4d12.md) — San Agustín de Hipona · 3: CCL 40, 2140-2141
- **Domingo de la semana XXVII del Tiempo Ordinario (semana 27)** — [Nuestro ángel custodio reza con nosotros](../r/353befe22e.md) — Orígenes · 10-11 PG 11, 446-
- **Domingo de la semana XXVII del Tiempo Ordinario (semana 27) - Año A: Mt 21, 33-43** — [Ser constantes en orar](../r/15231c1c18.md) — Orígenes · 12-13: PG 11, 451-455
- **Martes de la semana XXVII del Tiempo Ordinario (semana 27)** — [Vosotros que aspiráis a ser espirituales, pedid bienes celestiales en la oración](../r/b1cc2948aa.md) — Orígenes · 13-14: PG 11, 455-459
- **Miércoles de la semana XXVII del Tiempo Ordinario (semana 27)** — [Da a cada uno lo que le es debido](../r/142dab8662.md) — Orígenes · 28: PG 11, 522-523
- **Jueves de la semana XXVII del Tiempo Ordinario (semana 27)** — [Todos tenemos potestad para perdonar los pecados cometidos contra nosotros](../r/09bcf23721.md) — Orígenes · 28-33: PG 11, 526. 527.558-562
- **Viernes de la semana XXVII del Tiempo Ordinario (semana 27)** — [Un amigo fiel es un talismán](../r/c2a57cb06a.md) — San Elredo de Rievaulx · Lib 2: Edit J. Dubois, 53-57
- **Sábado de la semana XXVII del Tiempo Ordinario (semana 27)** — [Si os mantenéis en mi palabra, seréis de verdad discípulos míos](../r/2eb4de2277.md) — San Basilio Magno · Lib 1, 1-2: PG 31,1514-1515

## Semana 28 del Tiempo Ordinario

- **Domingo de la semana XXVIII del Tiempo Ordinario (semana 28)** — [El traje de fiesta es el amor](../r/2c74d5d1e8.md) — San Agustín de Hipona · Sermón 90,1.5.6: PL 38, 559.561-563
- **Domingo de la semana XXVIII del Tiempo Ordinario (semana 28)** — [Si quieres ser perfecto](../r/c16b0fcd99.md) — Clemente de Alejandría · Caps 5.10: PG 9, 610.614
- **Domingo de la semana XXVIII del Tiempo Ordinario (semana 28)** — [Grande es el poder de la fe](../r/bb7c688e40.md) — San Bruno de Segni · Parte 2, 40: PL 165, 426-428
- **Domingo de la semana XXVIII del Tiempo Ordinario (semana 28)** — [Vivo yo, pero no soy yo, es Cristo quien vive en mí](../r/f77a852684.md) — San Basilio Magno · Lib 1, 2.3: PG 31,1515-1519
- **Domingo de la semana XXVIII del Tiempo Ordinario (semana 28) - Año A: Mt 22, 1-14** — [Siento en mi interior la voz de un agua viva que me habla y me dice: «Ven al Padre»](../r/8f48d496e5.md) — San Nicolás Cabasilas · Lib 1: PG 150, 494-495
- **Martes de la semana XXVIII del Tiempo Ordinario (semana 28)** — [A través de los sacramentos, el sol de justicia penetra en este mundo tenebroso](../r/fcfac63708.md) — San Nicolás Cabasilas · Lib 1: PG 150, 502-503
- **Miércoles de la semana XXVIII del Tiempo Ordinario (semana 28)** — [Cristo por nosotros se hizo pan](../r/716852074c.md) — Pedro de Blois · Sermón 54, sobre el sacrificio del altar : PL 207, 720-721
- **Jueves de la semana XXVIII del Tiempo Ordinario (semana 28)** — [La bondad de Dios es inexplicable](../r/ade73bb72c.md) — San Nicolás Cabasilas · Lib 1 PG 150, 498-499
- **Viernes de la semana XXVIII del Tiempo Ordinario (semana 28)** — [El hombre inmortal es un magnífico himno de Dios](../r/4abea81449.md) — Clemente de Alejandría · Cap 10: PG 8, 223-228
- **Sábado de la semana XXVIII del Tiempo Ordinario (semana 28)** — [El Padre es conocido por la manifestación del Hijo](../r/e86b5adad4.md) — San Ireneo de Lyon · Lib 4, 6, 3.5.6.7: SC 100, 442.446.448-454

## Semana 29 del Tiempo Ordinario

- **Domingo de la semana XXIX del Tiempo Ordinario (semana 29)** — [Tú, cristiano, eres la moneda del impuesto](../r/dcd3aa2f3d.md) — San Lorenzo de Brindis · Homilía l,2.3.4.6 en el domingo 22 después de Pentecostés: Opera omnia, t. 8, 335-336.339-340.346
- **Domingo de la semana XXIX del Tiempo Ordinario (semana 29)** — [No es tiempo de coronas y de premios, sino de luchas](../r/003d3e3372.md) — San Juan Crisóstomo · Homilía 7, 4-5: PG 48, 773-775
- **Domingo de la semana XXIX del Tiempo Ordinario (semana 29)** — [Se aparta de Dios quien no se une a él en la oración](../r/a984b84447.md) — San Gregorio de Nisa · PG 44,1119. 1123-1126
- **Domingo de la semana XXIX del Tiempo Ordinario (semana 29)** — [Tanto amó Dios al mundo](../r/edc954382f.md) — San Lorenzo de Brindis · Hom. 1, 5-6 en el lunes después de Pentecostés: Opera omnia, t. 8, 1943, 85-87
- **Domingo de la semana XXIX del Tiempo Ordinario (semana 29) - Año A: Mt 22, 15-21** — [Sobre la victoria de Cristo](../r/b4f7430136.md) — San Nicolás Cabasilas · Lib 1: PG 150, 515-518
- **Martes de la semana XXIX del Tiempo Ordinario (semana 29)** — [¡Oh preclara herencia de los pobres!](../r/8f246de85c.md) — Beato Guerrico de Igny · Sermón 5.6.7 en la solemnidad de Todos los Santos: SC 202, 508.510.512.514
- **Miércoles de la semana XXIX del Tiempo Ordinario (semana 29)** — [Piensa en qué misterios te es dado participar](../r/4f2f093cbc.md) — San Juan Crisóstomo · Hom. 4 : PG 51, 179-180
- **Jueves de la semana XXIX del Tiempo Ordinario (semana 29)** — [En Cristo nos convertimos en una criatura nueva](../r/6dae77c3b2.md) — San Cirilo de Alejandría · Lib 4, Sermón 2: PG 70, 975-978
- **Viernes de la semana XXIX del Tiempo Ordinario (semana 29)** — [El Verbo del Padre embellece, ordena y contiene todas las cosas](../r/bdb1867799.md) — San Atanasio de Alejandría · Sermón 40-42: PG 25, 79-83
- **Sábado de la semana XXIX del Tiempo Ordinario (semana 29)** — [Demos gracias a Dios Padre que nos ha sacado del dominio de las tinieblas](../r/ae64e5bd70.md) — San Cirilo de Alejandría · Lib 4, Sermón 4: PG 70, 1090-1091

## Semana 30 del Tiempo Ordinario

- **Domingo de la semana XXX del Tiempo Ordinario (semana 30)** — [Éste es el camino que recorrió Cristo](../r/545404835a.md) — Actas y escritos anónimos · PL 3, 312-313
- **Domingo de la semana XXX del Tiempo Ordinario (semana 30)** — [Acojamos la luz y hagámonos discípulos del Señor](../r/d870d7bad4.md) — Clemente de Alejandría · Cap 11: PG 8, 230-234
- **Domingo de la semana XXX del Tiempo Ordinario (semana 30)** — [Sé humilde y te habrás librado de los lazos del pecado](../r/3992da7d4f.md) — San Juan Crisóstomo · Homilía 2,4-5 sobre la penitencia : PG 49, 289-292
- **Domingo de la semana XXX del Tiempo Ordinario (semana 30)** — [Cristo penetra el alma y la ilumina cual reflejo de la luz eterna](../r/39451898e8.md) — San Ambrosio de Milán · Sermón 19, 36-40: PL 15, 1480-1482
- **Domingo de la semana XXX del Tiempo Ordinario (semana 30) - Año A: Mt 22, 34-40** — [Eres, oh hombre, una obra maestra, animada por la potencia creadora de Dios](../r/892a7ed985.md) — San Ambrosio de Milán · Sermón 10, 10-11: PL 14, 1332-1334
- **Martes de la semana XXX del Tiempo Ordinario (semana 30)** — [Dios es admirable en sus santos](../r/4a4a71e856.md) — San Gregorio Palamás · Hom. 25 : PG 151, 322-323
- **Miércoles de la semana XXX del Tiempo Ordinario (semana 30)** — [La comunión de los santos en la unidad de la fe](../r/2926f32127.md) — San Pedro Damiani · Opúsculo 11, 56.10: PL 145, 235-236. 239
- **Jueves de la semana XXX del Tiempo Ordinario (semana 30)** — [Cristo en persona es nuestro arquetipo](../r/cbb9bcbdc9.md) — San Nicolás Cabasilas · Lib 6: PG 150, 678-679
- **Viernes de la semana XXX del Tiempo Ordinario (semana 30)** — [Buscaba tu rostro, Señor](../r/8840c50d4c.md) — Beato Guigo · Cap 3, 6-7: SC 163, 84-86.94-96
- **Sábado de la semana XXX del Tiempo Ordinario (semana 30)** — [Las obras de la creación, reflejo de la Sabiduría eterna](../r/929ecafbef.md) — San Atanasio de Alejandría · Sermón 2, 78.79: PG 26, 311.314

## Semana 31 del Tiempo Ordinario

- **Domingo de la semana XXXI del Tiempo Ordinario (semana 31)** — [Somos hombres de fe para salvar el alma](../r/7061e4609d.md) — San Orsiesio · Nn. 23,35.38: ed. Lefort, Louvain 1932, 124-125; 132-133.134
- **Domingo de la semana XXXI del Tiempo Ordinario (semana 31)** — [Al crecer el amor, el alma se siente segura](../r/2833bd0914.md) — San Agustín de Hipona · Sermón Mai 14,1-2: PLS 2, 449-450
- **Domingo de la semana XXXI del Tiempo Ordinario (semana 31)** — [La perfecta conversión a Dios](../r/dc871aa846.md) — Sin identificar · Hom. en la dedicación de una iglesia : Opera omnia, t. 1, 1888, 701-702
- **Domingo de la semana XXXI del Tiempo Ordinario (semana 31)** — [La palabra de Dios es viva y eficaz](../r/32cd282677.md) — Balduino de Canterbury · Tratado 6 : PL 204, 451-453
- **Domingo de la semana XXXI del Tiempo Ordinario (semana 31) - Año A: Mt 23, 1-12** — [Sobre el misterio de la encarnación del Verbo](../r/3b74049bd7.md) — Orígenes · Lib 2, 6, 2: PG 11, 210-211
- **Martes de la semana XXXI del Tiempo Ordinario (semana 31)** — [La ciencia de los santos consiste en sufrir aquí temporalmente y deleitarse eternamente.](../r/fe313db7c0.md) — San Bernardo de Claraval · Sermón 21, 1-3: Opera omnia, Edit Cister t. 6, 1, 1970, 168-170
- **Miércoles de la semana XXXI del Tiempo Ordinario (semana 31)** — [Cuán bueno y cuán suave es, Señor, tu Espíritu para con todos nosotros](../r/fabf5f6856.md) — Santa Catalina de Siena · Cap 134: ed. latina, Ingolstadt 1583, ff. 215v-216
- **Jueves de la semana XXXI del Tiempo Ordinario (semana 31)** — [El Espíritu Santo, que lo ha creado todo, es Dios](../r/6133979ad2.md) — San Basilio Magno · Carta 8, 11: PG 32, 263-266
- **Viernes de la semana XXXI del Tiempo Ordinario (semana 31)** — [En el tiempo de nuestra humillación, la esperanza nos consuela](../r/1391eb43d5.md) — San Ambrosio de Milán · Sermón 7, 7-8: PL 15, 1282-1283
- **Sábado de la semana XXXI del Tiempo Ordinario (semana 31)** — [La palabra todopoderosa vino desde el trono real](../r/0a14e9d96e.md) — Guillermo de Saint-Thierry · 10: SC 61, 91-94

## Semana 32 del Tiempo Ordinario

- **Domingo de la semana XXXII del Tiempo Ordinario (semana 32)** — [Salgamos al encuentro de Cristo, el esposo, con las espléndidas lámparas de la fe](../r/1c56f81552.md) — San Gregorio Nacianceno · Sermón 40,46 en la festividad del bautismo : PG 36, 426-428
- **Domingo de la semana XXXII del Tiempo Ordinario (semana 32)** — [Demos al Señor, que recibe en la persona de cada pobre](../r/bcdcdd3aa2.md) — San Paulino de Nola · Carta 34,2-4: CSEL 29, 305-306
- **Domingo de la semana XXXII del Tiempo Ordinario (semana 32)** — [Yo soy la resurrección y la vida](../r/7b0c930c6e.md) — San Ireneo de Lyon · Lib 4, 5, 2—5, 4: SC 100, 428-436
- **Domingo de la semana XXXII del Tiempo Ordinario (semana 32)** — [Naturaleza de la paz](../r/36c5530c4b.md) — Concilio Vaticano II · N. 78
- **Domingo de la semana XXXII del Tiempo Ordinario (semana 32) - Año A: Mt 25, 1-13** — [Necesidad de inculcar sentimientos que llevan a la paz](../r/c703d5c365.md) — Concilio Vaticano II · Nn. 82-83
- **Martes de la semana XXXII del Tiempo Ordinario (semana 32)** — [Muchos son los males que sufre el justo](../r/8753cd8196.md) — Beato Ammonio · Carta 9, 2-5: PO t. 10, fasc. 6, 590-593
- **Miércoles de la semana XXXII del Tiempo Ordinario (semana 32)** — [Dichosos los que derraman su sangre por causa de Dios](../r/430d190746.md) — Clemente de Alejandría · Lib 4, 7: PG 8, 1255.1259.1263.1266.1267
- **Jueves de la semana XXXII del Tiempo Ordinario (semana 32)** — [Cristo atestigua la resurrección futura, y, con él, los apóstoles, los mártires y la madre de los Macabeos](../r/c2667f227c.md) — San Juan Crisóstomo · Sermón 2, 4-5 sobre la consolación de la muerte : PG 56, 301-302
- **Viernes de la semana XXXII del Tiempo Ordinario (semana 32)** — [Papel de los cristianos en la construcción de la paz](../r/eb6cacbd72.md) — Concilio Vaticano II · Nn. 88-90
- **Sábado de la semana XXXII del Tiempo Ordinario (semana 32)** — [La fe realiza obras que superan las fuerzas humanas](../r/f03cdc315f.md) — San Cirilo de Jerusalén · Catequesis 5, 10-11, sobre la fe y el símbolo : PG 33, 518-519

## Semana 33 del Tiempo Ordinario

- **Domingo de la semana XXXIII del Tiempo Ordinario (semana 33) - Año A: Mt 25, 14-30** — [Santa y piadosa es la idea de rezar por los muertos](../r/6b354aa221.md) — San Gregorio Nacianceno · Sermón 7, 23-24: PG 35, 786-787
- **Domingo de la semana XXXIII del Tiempo Ordinario (semana 33)** — [El justo siembra para el espíritu, y del Espíritu cosechará vida eterna](../r/edeb5e425e.md) — Orígenes · nn. 68-69: PG 13, 1709-1710
- **Domingo de la semana XXXIII del Tiempo Ordinario (semana 33)** — [¡Ojalá que en el siglo futuro nos hallemos también nosotros agregados a la muchedumbre de los salvados!](../r/261713739a.md) — San Gregorio Palamás · Homilía 26 : PG 151, 339-342
- **Domingo de la semana XXXIII del Tiempo Ordinario (semana 33)** — [No pongamos resistencia a su primera venida, y no temeremos la segunda](../r/605a7a962e.md) — San Agustín de Hipona · 14.15: CCL 39, 1351-1353
- **Domingo de la semana XXXIII del Tiempo Ordinario (semana 33)** — [Sobre el símbolo de la fe](../r/1d590d4f81.md) — San Cirilo de Jerusalén · Catequesis 5, 12-13, sobre la fe y el símbolo : PG 33, 519-523
- **Martes de la semana XXXIII del Tiempo Ordinario (semana 33)** — [Cristo, como buen pastor, intercede por nosotros, miserables](../r/9c2948857b.md) — Sin identificar · Parte 2, 3-4: Ed. J. Leclercq, 1946, 125-126
- **Miércoles de la semana XXXIII del Tiempo Ordinario (semana 33)** — [En toda ocasión, llevemos en el cuerpo la muerte de Jesús](../r/8e4bec49b2.md) — San Ambrosio de Milán · Caps 3, 9; 4, 15: CSEL 32, 710.716-717
- **Jueves de la semana XXXIII del Tiempo Ordinario (semana 33)** — [Cristo quiso salvar a los que estaban a punto de perecer](../r/9044b9826e.md) — Actas y escritos anónimos · Caps 1, 1-2,7: Funk 1, 145-149
- **Viernes de la semana XXXIII del Tiempo Ordinario (semana 33)** — [Confesemos a Dios con nuestras obras](../r/342902a7bd.md) — Actas y escritos anónimos · Caps 3-4, 5; 7, 1-6: Funk 1, 149-152
- **Sábado de la semana XXXIII del Tiempo Ordinario (semana 33)** — [El arrepentimiento de un corazón sincero](../r/d20a4e07ea.md) — Actas y escritos anónimos · Caps 8, 1-9,11: Funk 1, 152-156

## Semana 34 del Tiempo Ordinario

- **Domingo de la semana XXXIV del Tiempo Ordinario (semana 34) - Año A: Mt 25, 31-46** — [Perseveremos en la esperanza](../r/488932356d.md) — Actas y escritos anónimos · 10, 1-12,1; 13, 1: Funk 1, 157-159
- **Martes de la semana XXXIV del Tiempo Ordinario (semana 34)** — [La Iglesia viva es el cuerpo de Cristo](../r/b6823698de.md) — Actas y escritos anónimos · Caps 13, 2-14, 5: Funk 1, 159-161
- **Miércoles de la semana XXXIV del Tiempo Ordinario (semana 34)** — [Convirtámonos a Dios, que nos llama](../r/fcca96fd11.md) — Actas y escritos anónimos · Caps 15, 1-17, 2: Funk 1, 161-167
- **Jueves de la semana XXXIV del Tiempo Ordinario (semana 34)** — [Practiquemos el bien, para que al fin nos salvemos](../r/71016dbe6c.md) — Actas y escritos anónimos · Caps 18,1—20,5 Funk 1, 167-171
- **Viernes de la semana XXXIV del Tiempo Ordinario (semana 34)** — [Ha aparecido Cristo, nuestra paz](../r/b8b0574de8.md) — San Cirilo de Alejandría · Lib 5, t. 1: PG 70, 1151-1155
- **Sábado de la semana XXXIV del Tiempo Ordinario (semana 34)** — [Cristo hablaba del templo de su cuerpo](../r/851038a444.md) — Orígenes · Tomo 10, 20: PG, 14, 370-371

## Otras lecturas del Tiempo Ordinario

- **Solemnidad** — [Cuando aparezca Cristo, entonces también vosotros apareceréis juntamente con él, en la gloria](../r/788d36160e.md) — San Cirilo de Alejandría · Lib 9: PG 74, 266
- **Solemnidad** — [El reino de Cristo hasta el fin del mundo](../r/5a7223397d.md) — San Agustín de Hipona · Tratado 115, 2-5: CCL 36, 644-646).
- **Solemnidad** — [La cruz, símbolo del reino](../r/5b5014cee9.md) — San Juan Crisóstomo · Homilía sobre la cruz y el ladrón 1, 3-4: PG 49, 403-404
- **Solemnidad** — [Cristo se rebajó, para que siendo el primero en regresar al reino, fuera para nosotros el principio y el camino hacia la gloria real](../r/81652d3bda.md) — San Cirilo de Alejandría · Lib 2: PG 73, 283-286
