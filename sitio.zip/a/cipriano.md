# San Cipriano de Cartago

c. 210–258 · St. Cyprian of Carthage · 31 lecturas

- [La esperanza nos sostiene](../r/05c8e6f390.md) — San Cipriano de Cartago · Tratado 13.15: CSEL 3, 406-408 · Sábado de la semana I de Adviento (semana 1), año par
- [Los mártires están reservados para la diadema del Señor](../r/db808d8174.md) — San Cipriano de Cartago · Cap. 2: PL 4, 479-480 · 10 de diciembre. Santa Eulalia de Mérida Virgen y Mártir — Santoral, año par
- [Los que deseamos alcanzar las promesas del Señor debemos imitarle en todo](../r/4a6dcb0d37.md) — San Cipriano de Cartago · Carta 6,1-2: CSEL 3, 480-482 · Para varios mártires — Comunes, año par
- [El coro numeroso de las vírgenes acrecienta el gozo de la madre Iglesia](../r/c4251428aa.md) — San Cipriano de Cartago · Núms. 3-4. 22. 23: CSEL 3,189-190. 202-204 · Común de vírgenes — Comunes, año par
- [El que nos dio la vida nos enseñó también a orar](../r/38e10541fe.md) — San Cipriano de Cartago · Caps. 1-3: CSEL 3, 267-268 · Martes de la semana I de Cuaresma (semana 1), año par
- [La lucha por la fe](../r/068c24c3a0.md) — San Cipriano de Cartago · Carta 58, 8-9.11: CSEL 3, 663-666 · 11 de abril. San Estanislao, Obispo y Mártir — Santoral, año par
- [Los sacramentos vitales](../r/552b0fdedc.md) — San Cipriano de Cartago · Carta 63, 8-9: CSEL 3, parte 2, 706-708 · Viernes de la semana V de Pascua (semana 5), año impar
- [Que nuestras obras proclamen la generosidad de Dios](../r/12594d815b.md) — San Cipriano de Cartago · Trat. 12-13.15: CSEL 3, 427-430 · Domingo de la semana VII del Tiempo Ordinario (semana 7), año impar
- [La oración ha de salir de un corazón humilde](../r/666e7df380.md) — San Cipriano de Cartago · Tratado 4-6: CSEL 3, 268-270 · Martes de la semana XI del Tiempo Ordinario (semana 11), año impar
- [Nuestra oración es pública y común](../r/2094475dc3.md) — San Cipriano de Cartago · Tratado 8-9: CSEL 3, 271-272 · Alma mía, camina con brío. — Tiempo Ordinario, año impar
- [Santificado sea tu nombre](../r/0f5b8c96e4.md) — San Cipriano de Cartago · Tratado 11-12: CSEL 3, 274-275 · Jueves de la semana XI del Tiempo Ordinario (semana 11), año impar
- [Venga a nosotros tu reino, hágase tu voluntad](../r/8b192cfbaf.md) — San Cipriano de Cartago · Tratado 13-14: CSEL 3, 275-277 · Viernes de la semana XI del Tiempo Ordinario (semana 11), año impar
- [No anteponer nada a Cristo](../r/e416f734b4.md) — San Cipriano de Cartago · Tratado 15-16: CSEL 3, 277-279 · Sábado de la semana XI del Tiempo Ordinario (semana 11), año impar
- [Pedimos de modo que nuestra oración recabe la salvación de todos](../r/ed27a80d31.md) — San Cipriano de Cartago · Tratado 17-18: CSEL 3, 279-281 · Domingo de la semana XII del Tiempo Ordinario (semana 12), año impar
- [No os agobiéis por el mañana](../r/ba194f7b71.md) — San Cipriano de Cartago · Tratado 19-20: CSEL 3, 281-282 · Lunes de la semana XII del Tiempo Ordinario (semana 12), año impar
- [Después del alimento, pedimos el perdón de los pecados](../r/3304215b4f.md) — San Cipriano de Cartago · Tratado 22-23: CSEL 3, 283-285 · Martes de la semana XII del Tiempo Ordinario (semana 12), año impar
- [Que los que somos hijos de Dios permanezcamos en la paz de Dios](../r/3c35940af5.md) — San Cipriano de Cartago · Tratado 24-25: CSEL 3, 285-286 · Miércoles de la semana XII del Tiempo Ordinario (semana 12), año impar
- [Velad y orad](../r/0e919e3a25.md) — San Cipriano de Cartago · Tratado 26-27: CSEL 3, 286-287 · Jueves de la semana XII del Tiempo Ordinario (semana 12), año impar
- [Hay que orar no sólo con palabras, sino también con los hechos](../r/b5c94abe00.md) — San Cipriano de Cartago · Tratado 28-29: CSEL 3, 287-288 · Viernes de la semana XII del Tiempo Ordinario (semana 12), año impar
- [El Señor oraba por nuestros pecados](../r/d484a6587a.md) — San Cipriano de Cartago · Tratado 30-31: CSEL 3, 288-290 · Sábado de la semana XII del Tiempo Ordinario (semana 12), año impar
- [Buena es la oración con el ayuno y la limosna](../r/4d60a58aa9.md) — San Cipriano de Cartago · Tratado 32-33: CSEL 3, 290-292 · Domingo de la semana XIII del Tiempo Ordinario (semana 13), año impar
- [Los cristianos han de adorar a Dios frecuentemente y siempre](../r/0a855058aa.md) — San Cipriano de Cartago · Tratado 34-35: CSEL 3, 292-293 · Lunes de la semana XIII del Tiempo Ordinario (semana 13), año impar
- [Los que estamos siempre en Cristo, no cesemos de orar ni siquiera de noche](../r/acf0e00bc7.md) — San Cipriano de Cartago · Tratado 36: CSEL 3, 293-294 · Martes de la semana XIII del Tiempo Ordinario (semana 13), año impar
- [Fabián nos da ejemplo de fe y de fortaleza](../r/2f0e69b904.md) — San Cipriano de Cartago · Cartas 9,1; 8, 2-3: CSEL 3, 488-489. 487-488 · El mismo día 20 de enero San Fabián, Papa y Mártir — Santoral, año impar
- [Cristo nos dio la paz y nos mandó que tuviéramos un solo corazón y una sola alma](../r/00176a31e1.md) — San Cipriano de Cartago · 12-14: CCL 3, 257-259 · Miércoles de la semana XIII del Tiempo Ordinario (semana 13), año par
- [Volved a mí, dice el Señor](../r/41af6be4ba.md) — San Cipriano de Cartago · Tratado 3-4: CSEL 3, 398-399 · Viernes de la semana XXVII del Tiempo Ordinario (semana 27), año impar
- [Sabemos que los soldados de Cristo no son destruidos sino coronados](../r/7aadec9b6e.md) — San Cipriano de Cartago · Carta 80: CSEL 3, 839-840 · 7 de agosto San Sixto, papay compañeros, mártires — Santoral, año impar
- [Fe inquebrantable](../r/9dba0b4911.md) — San Cipriano de Cartago · Carta 10, 2-3. 5: CSEL 3, 491-492. 494-495 · 13 de agosto San Ponciano, papay San Hipólito, presbítero, mártires — Santoral, año impar
- [Una fe generosa y firme](../r/fbfbe6ebca.md) — San Cipriano de Cartago · Carta 60,1-2. 5: CSEL 3, 691-692. 694-695 · 16 de septiembre San Cornelio, papa, y Cipriano, obispo, mártires — Santoral, año impar
- [Tratándose de un asunto tan claro, no hay por qué pensarlo más](../r/e58894e986.md) — San Cipriano de Cartago · Cap. 3-6: CSEL 3,112-114 · Propio de los santos — Santoral, año impar
- [En la persecución se inflige la muerte, pero sigue la inmortalidad](../r/9863921d18.md) — San Cipriano de Cartago · Cap. 13: CSEL 3, 346-347 · 14 de octubre San Calixto I, papa y mártir — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
