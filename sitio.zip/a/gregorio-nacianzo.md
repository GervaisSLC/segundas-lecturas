# San Gregorio Nacianceno

329–390 · St. Gregory Nazianzen · 12 lecturas

- [¡Qué admirable intercambio!](../r/a7d27195ee.md) — San Gregorio Nacianceno · Disertación 45, 9.22.26.28: PG 36, 634-635.654.658-659.662 · Martes de la semana I de Adviento (semana 1), año par
- [Como si una misma alma sustentase dos cuerpos](../r/9956ad976a.md) — San Gregorio Nacianceno · Sermón 43, en alabanza de Basilio Magno, 15. 16-17. 19-21: PG 36, 514-523 · 2 de enero. San Basilio Magno y San Gregorio Nacianceno Obispos y Doctores de la Iglesia — Santoral, año par
- [El bautismo de Cristo](../r/acb09b1995.md) — San Gregorio Nacianceno · Disertación 39, en las santas Luminarias, 14-16.20: PG 36, 350-351.354.358-359 · Ferias anteriores a la Epifanía — Adviento y Navidad, año impar
- [El cristiano dispone de medios para superar las tentaciones](../r/ea0a56ed1a.md) — San Gregorio Nacianceno · Discurso 40, 10: PG 36, 370-371 · Semana I de Cuaresma — Cuaresma y Pascua, año par
- [Actualicemos unos con otros la bondad del Señor](../r/f26d548244.md) — San Gregorio Nacianceno · Sermón 14, 23-25 sobre el amor a los pobres: PG 35, 887-890 · Domingo de la semana I de Cuaresma (semana 1) - Año A: Mt 4, 1-11, año par
- [Sirvamos a Cristo en los pobres](../r/5ff73fcee1.md) — San Gregorio Nacianceno · Sermón 14, sobre el amor a los pobres, 38. 40: PG 35, 907-910 · Sábado de la semana III de Cuaresma (semana 3), año par
- [Vamos a participar en la Pascua](../r/f91e84f3c0.md) — San Gregorio Nacianceno · Sermón 45, 23-24: PG 36, 654-655 · Miércoles de la semana IV de Cuaresma (semana 4), año par
- [Santa y piadosa es la idea de rezar por los muertos](../r/6b354aa221.md) — San Gregorio Nacianceno · Sermón 7, 23-24: PG 35, 786-787 · Viernes de la semana IX del Tiempo Ordinario (semana 9), año par
- [Vayamos de una vez en pos del Verbo, busquemos aquel descanso](../r/40d24d66d4.md) — San Gregorio Nacianceno · Sermón 14, 20-22 sobre el amor a los pobres: PG 35, 882-886 · Domingo de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [Demos a los pobres nuestros bienes, para enriquecernos con los del cielo](../r/550ec07de8.md) — San Gregorio Nacianceno · Sermón 14, 21-22: PG 35, 883-886 · Sábado de la semana XXV del Tiempo Ordinario (semana 25), año impar
- [Es éste un gran misterio](../r/38055f282f.md) — San Gregorio Nacianceno · Sermón 37, 5-7 sobre Mateo 19, 1-12: PG 36, 287-291 · Domingo de la semana XXVII del Tiempo Ordinario (semana 27), año impar
- [Salgamos al encuentro de Cristo, el esposo, con las espléndidas lámparas de la fe](../r/1c56f81552.md) — San Gregorio Nacianceno · Sermón 40,46 en la festividad del bautismo : PG 36, 426-428 · Semana XXXII DEL TIEMPO ORDINARIO, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
