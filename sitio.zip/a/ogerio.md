# Beato Ogerio de Lucedio

c. 1136–1214 · Bl. Oglerius of Lucedio · 2 lecturas

- [Ésta es la escuela de Cristo: la caridad](../r/5640d397e2.md) — Beato Ogerio de Lucedio · Sermón 5: PL 184, 901-902 · Lunes de la semana XXI del Tiempo Ordinario (semana 21), año impar
- [Dios Padre flagela a la Iglesia para que crezca más vigorosa y fecunda](../r/3f5f9d4fa9.md) — Beato Ogerio de Lucedio · Serm. 10, 13-14: PL 184, 927-928 · Viernes de la semana XXII del Tiempo Ordinario (semana 22), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
