# Santo Tomás Becket

None · None · 1 lecturas

- [Nadie recibe el premio si no compite conforme al reglamento](../r/8ea94cc172.md) — Santo Tomás Becket · Carta 74: PL 190, 533-536 · 29 de diciembre. Santo Tomás Becket, Obispo y Mártir — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
