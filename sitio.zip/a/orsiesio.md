# San Orsiesio

d. c. 380 · St. Horsiesi · 1 lecturas

- [Somos hombres de fe para salvar el alma](../r/7061e4609d.md) — San Orsiesio · Nn. 23,35.38: ed. Lefort, Louvain 1932, 124-125; 132-133.134 · Semana XXXI DEL TIEMPO ORDINARIO, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
