# Calendario

Qué segunda lectura corresponde a cada día del Oficio de Lectura, según el Leccionario Bienal (año par / año impar).

Cómo buscar un día: abre el tiempo litúrgico y el año; busca la semana y el día (p. ej. «Jueves de la semana XXIX del Tiempo Ordinario (semana 29)»). Las fiestas de santos están en Santoral, por mes y día. Puede haber varias lecturas para un mismo día (lecturas alternativas o terceras lecturas dominicales).

- [Adviento y Navidad — año par](adviento-navidad-par.md) (41 entradas)
- [Adviento y Navidad — año impar](adviento-navidad-impar.md) (44 entradas)
- [Cuaresma y Pascua — año par](cuaresma-pascua-par.md) (140 entradas)
- [Cuaresma y Pascua — año impar](cuaresma-pascua-impar.md) (143 entradas)
- [Tiempo Ordinario — año par](ordinario-par.md) (328 entradas)
- [Tiempo Ordinario — año impar](ordinario-impar.md) (329 entradas)
- [Solemnidades del Señor — año par](solemnidades-par.md) (3 entradas)
- [Solemnidades del Señor — año impar](solemnidades-impar.md) (3 entradas)
- [Santoral — año par](santoral-par.md) (387 entradas)
- [Santoral — año impar](santoral-impar.md) (378 entradas)
- [Comunes — año par](comunes-par.md) (124 entradas)
- [Comunes — año impar](comunes-impar.md) (124 entradas)
- [Oficio de difuntos — año par](difuntos-par.md) (9 entradas)
- [Oficio de difuntos — año impar](difuntos-impar.md) (8 entradas)

[Guía para IAs](../llms.txt)
