# Papa León XIII

1810–1903 · Pope Leo XIII · 1 lecturas

- [La Eucaristía, vínculo de paz y de unidad](../r/d393e9f40d.md) — Papa León XIII · 28 de noviembre de 1897 · 17 de mayo. San Pascual Bailón, Religioso — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
