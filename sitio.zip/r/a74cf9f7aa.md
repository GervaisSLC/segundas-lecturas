# La voluntad de Cristo, norma de nuestra vida

**San Gregorio de Nisa** (c. 335–395) · Segunda lectura del Oficio de Lectura

- id: `a74cf9f7aa`
- Fuente: Del tratado sobre el perfecto modelo del cristiano, de San Gregorio de Nisa, obispo
- Cita patrística: PG 46, 262-263
- Se lee: Jueves de la semana III de Pascua (semana 3), año par
- Escritura: [Hch 10, 1-33](../escritura/hch.md) (primera lectura del día); [Hb 13, 21](../escritura/hb.md) (responsorio); [2 M 1, 4](../escritura/2m.md) (responsorio)
- Temas (automáticos): [Pecado y redención](../temas/salvacion.md), [Santidad y perfección](../temas/santidad.md), [Pastores y ministerio](../temas/pastores.md), [Obediencia y voluntad de Dios](../temas/obediencia.md)
- Cómo citar: San Gregorio de Nisa, PG 46, 262-263, «La voluntad de Cristo, norma de nuestra vida». Liturgia de las Horas, Oficio de Lectura, segunda lectura, Jueves de la semana III de Pascua (semana 3), año par. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-a74cf9f7aa](../index.html#r-a74cf9f7aa)
- Autor: [San Gregorio de Nisa](../a/gregorio-nisa.md)

## Texto

Cuando se nos enseña que Cristo es la redención y que para redimirnos él mismo se entregó como precio, confesamos al mismo tiempo que, al constituirse en precio de cada una de las almas y otorgándonos la inmortalidad, nos ha convertido —a nosotros comprados por él dando vida por muerte— en posesión suya propia. Ahora bien, si somos propiedad del que nos redimió, sigamos incondicionalmente al Señor, de modo que ya no vivamos para nosotros, sino para el que nos compró al precio de su vida: pues ya no somos dueños de nosotros mismos; nuestro Señor es aquel que nos compró y nosotros estamos sometidos a su dominio. En consecuencia, su voluntad ha de ser la norma de nuestro vivir.

Y así como cuando la muerte nos oprimía con tiránica dominación, todo en nosotros lo disponía la ley del pecado, así ahora que estamos destinados a la vida es lógico que nos gobierne la voluntad del Todopoderoso, no sea que renunciando por el pecado a la voluntad de vivir, nuevamente caigamos por decisión propia bajo la impía dominación del pecado.

Esta reflexión nos unirá más estrechamente al Señor, sobre todo si escucháramos a Pablo llamarle unas veces Pascua, otras sacerdote: porque Cristo se inmoló por nosotros como verdadera Pascua, y, en calidad de sacerdote, el mismo Cristo se ofreció a Dios en sacrificio. Se entregó —dice— por nosotros como oblación y víctima de suave olor. Lo cual es una lección para nosotros. Pues quien ve que Cristo se ha entregado a Dios como oblación y víctima y se ha convertido en nuestra Pascua, él mismo presenta su cuerpo a Dios como hostia viva, santa, agradable, hecho un culto razonable. El modo de realizar el sacrificio es: no ajustarse a este mundo, sino transformarse por la renovación de la mente, para saber discernir lo que es la voluntad de Dios, lo bueno, lo que le agrada, lo perfecto.

En efecto, la voluntad amorosa de Dios no puede manifestarse en la carne no sacrificada por la ley del espíritu, ya que la tendencia de la carne es rebelarse contra Dios, y no se somete a la ley de Dios. De donde se sigue que si antes no se ofrece la carne —mortificado todo lo terreno que hay en ella y con lo que condesciende con el apetito— como hostia viva, no puede llevarse a cabo sin dificultad en la vida de los creyentes la voluntad de Dios agradable y perfecta. Igualmente, la mera consideración de que Cristo se ha erigido en propiciación nuestra a partir de su sangre, nos induce a constituirnos en nuestra propia propiciación y, mortificando nuestros miembros, lograr la inmortalidad de nuestras almas.

Y cuando se dice que Cristo es el reflejo de la gloria de Dios e impronta de su ser, la expresión nos sugiere la idea de su adorable majestad. En efecto, Pablo inspirado por el Espíritu de Dios e instruido directamente por Dios, que en el abismo de generosidad, de sabiduría y conocimiento de Dios había rastreado lo arcano y recóndito de los misterios divinos; y, sintiéndose incapaz de expresar en lenguaje humano los esplendores de aquellas cosas que están más allá de toda indagación o investigación y que sin embargo le habían sido divinamente reveladas, para que los oídos de sus oyentes pudieran captar la inteligencia que él tenía del misterio, echa mano de algunas aproximaciones, hablando en tanto en cuanto sus palabras eran capaces de trasvasar su pensamiento.

## Responsorio (Hb 13, 21; 2M 1, 4)

R. Dios os haga perfectos en toda clase de bienes para cumplir su voluntad; * realizando él en vosotros lo que es agradable a sus ojos, por mediación de Jesucristo. Aleluya.  
V. Que abra vuestro corazón a su ley y a sus preceptos.  
R. Realizando él en vosotros lo que es agradable a sus ojos, por mediación de Jesucristo. Aleluya.  

## Oración

Dios todopoderoso y eterno, que en estos días de Pascua nos has revelado más claramente tu amor y nos has permitido conocerlo con más profundidad, concede a quienes has librado de las tinieblas del error adherirse con firmeza a las enseñanzas de tu verdad. Por nuestro Señor Jesucristo.

## Primera lectura del día

**De los Hechos de los apóstoles 10, 1-33** — *Pedro en casa del centurión Cornelio*

En aquellos días, había en Cesarea un hombre llamado Cornelio, centurión de la cohorte llamada Itálica, piadoso y temeroso de Dios, al igual que toda su casa; daba muchas limosnas al pueblo y oraba continuamente a Dios.

Este, hacia la hora de nona, vio claramente en visión un ángel de Dios que fue a su encuentro y le dijo:

«Cornelio».

Él se quedó mirando, lleno de miedo, y dijo:

«¿Qué hay, señor?».

Le respondió:

«Tus oraciones y tus limosnas han subido como memorial a la presencia de Dios. Ahora manda a alguien a Jafa y haz venir a un tal Simón llamado Pedro, que se aloja en casa de un tal Simón curtidor, que tiene su casa a orillas del mar».

Tan pronto como se marchó el ángel que le había hablado, llamó a dos siervos y a un soldado piadoso de los que estaban a su servicio, les contó todo y los mandó a Jafa.

Al día siguiente, mientras estos caminaban y se acercaban a la ciudad, subió Pedro a la terraza hacia la hora de sexta para orar. Sintió hambre y quería tomar algo. Mientras se lo preparaban, le sobrevino un éxtasis: contemplando el cielo abierto y una especie de recipiente que bajaba, semejante a un gran lienzo, que era descolgado a la tierra sostenido por los cuatro extremos. Estaba lleno de toda especie de cuadrúpedos, reptiles de la tierra y aves del cielo.

Y una voz le dijo:

«Levántate, Pedro, mata y come».

Pedro replicó:

«De ningún modo, Señor, pues nunca comí cosa profana e impura».

Y de nuevo por segunda vez le dice una voz:

«Lo que Dios ha purificado, tú no lo consideres profano».

Esto sucedió hasta tres veces y luego el receptáculo fue subido al cielo. Estaba todavía Pedro dándole vueltas al significado de la visión que había visto, cuando los hombres enviados por Cornelio, después de haber preguntado por la casa de Simón, llegaron a la puerta, y, a voces, preguntaban si Simón, llamado Pedro, se alojaba allí.

Entonces dijo el Espíritu a Pedro, que seguía perplejo con la visión:

«Mira, tres hombres te están buscando; levántate, baja y ponte en camino con ellos sin dudar, pues yo los he enviado».

Bajando Pedro al encuentro de los hombres, les dijo:

«Aquí estoy, yo soy el que buscáis. ¿Cuál es el motivo de vuestra venida?».

Ellos le dijeron:

«El centurión Cornelio, hombre justo y temeroso de Dios, acreditado además por el testimonio de todo el pueblo judío, ha recibido de un ángel santo la orden de hacerte ir a su casa y de escuchar tus palabras».

Él los invitó a entrar y los alojó. Al día siguiente, se levantó y marchó con ellos, haciéndose acompañar por algunos de los hermanos de Jafa.

Al día siguiente entró en Cesarea, donde Cornelio lo estaba esperando, reunido con sus parientes y amigos íntimos. Cuando iba a entrar Pedro, Cornelio le salió al encuentro y, postrándose, le quiso rendir homenaje.

Pero Pedro lo levantó, diciéndole:

«Levántate, que soy un hombre como tú».

Entró en la casa conversando con él y encontró a muchas personas reunidas.

Entonces les dijo:

«Vosotros sabéis que a un judío no le está permitido relacionarse con extranjeros ni entrar en su casa, pero a mí Dios me ha mostrado que no debo llamar profano o impuro a ningún hombre; por eso, al recibir la llamada, he venido sin poner objeción. Decidme, pues, por qué motivo me habéis hecho venir».

Cornelio dijo:

«Hace cuatro días, a esta misma hora, cuando estaba haciendo la oración de la hora de nona en mi casa, se me presentó un hombre con vestido resplandeciente y me dijo: “Cornelio, Dios ha oído tu oración y ha recordado tus limosnas; envía, pues, a Jafa y haz venir a Simón, llamado Pedro, que se aloja en casa de un tal Simón curtidor, a orillas del mar”. Enseguida envié a por ti, y tú has hecho bien en venir. Ahora, aquí nos tienes a todos delante de Dios, para escuchar lo que el Señor te haya encargado decirnos».

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
