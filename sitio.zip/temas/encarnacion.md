# Encarnación y Navidad

33 lecturas (tema asignado automáticamente).

[Todos los temas](index.md) · [Guía para IAs](../llms.txt)

- [María y la Iglesia](../r/2e003688b6.md) — Isaac de Stella · Sermón 51: PL 194, 1862-1863.1865 · Sábado de la semana II de Adviento (semana 2), año par
- [La economía de la encarnación redentora](../r/86d68262d2.md) — San Ireneo de Lyon · Lib. 3, 20, 2-3: SC 34, 342-344 · 19 de Diciembre — Santoral, año par
- [La fidelidad brota de la tierra y la justicia mira desde el cielo](../r/16ce118d06.md) — San Agustín de Hipona · Sermón 185 PL 38, 997-999 · 24 de Diciembre — Santoral, año par
- [Hoy nos ha nacido un Salvador](../r/59135e1d09.md) — San Elredo de Rievaulx · Sermón 1 de la Natividad del Señor : PL 195, 226-227 · 25 de Diciembre. LA NATIVIDAD DEL SEÑOR — Santoral, año par
- [El Dueño de todo vino en forma de siervo](../r/44914f3857.md) — Sin identificar · En la Natividad del Salvador Edic Schwartz, ACO t. 3, parte 1,157-159. · 25 de Diciembre. LA NATIVIDAD DEL SEÑOR — Santoral, año par
- [El Verbo se hizo carne y puso su morada entre nosotros](../r/b9eb587bee.md) — San Basilio Magno · 2, 6; PG 31, 1459-1462. 1471-1474 · 25 de Diciembre. LA NATIVIDAD DEL SEÑOR — Santoral, año par
- [Junto al Niño Jesús están María y José](../r/6ac6ae87ce.md) — San Juan Crisóstomo · Homilía sobre el día de Navidad: PG 56, 392 · Navidad y su Octava — Adviento y Navidad, año par
- [Todavía no hablan, y ya confiesan a Cristo](../r/d7169f3b32.md) — San Quodvultdeus · Sermón 2 sobre el Símbolo: PL 40, 655 · 28 de Diciembre. Santos Inocentes — Santoral, año par
- [Venía a salvar, pero le era también necesario morir](../r/ed41f518b9.md) — San Proclo de Constantinopla · Sermón 1 en alabanza de santa María, 4. 5. 6. 9. 10 : PG 65, 683-687. 690-691 · 7 de Enero — Santoral, año par
- [Del seno de la Virgen nació el que es Siervo y Señor a la vez](../r/eee161dda5.md) — San Ambrosio de Milán · 4-5 : CCL 64, 52-53 · Domingo después del 6 de Enero. EL BAUTISMO DEL SEÑOR — Adviento y Navidad, año par
- [La bendición del Padre ha brillado para los hombres por medio de María](../r/d7928279c6.md) — San Sofronio de Jerusalén · Sermón 2, en la Anunciación de la Santísima Virgen, 21-22. 26: PG 87, 3, 3242. 3250 · Común de Santa maría virgen — Comunes, año par
- [El amigo de los hombres se ha hecho hombre, naciendo de la Virgen](../r/c519c14650.md) — San Proclo de Constantinopla · Sobre la Natividad del Señor, 1-2: PG 65, 843-846 · Común de Santa maría virgen — Comunes, año par
- [Los hombres de fe son los que reciben la bendición con Abrahán el fiel](../r/d83ed7ae20.md) — San Cirilo de Alejandría · Num. 7, 72: PG 71, 774-775 · Semana III de Adviento — Adviento y Navidad, año impar
- [El profeta inspirado vaticinó al Dios-con-nosotros](../r/cef9fba750.md) — San Cirilo de Alejandría · Lib. 4, or. 4: PG 70, 1035-1038 · 20 de Diciembre — Santoral, año impar
- [Todos verán la salvación de Dios](../r/148463c667.md) — San Cirilo de Alejandría · Lib. 3, t. 4: PG 70, 802-803 · 24 de Diciembre — Santoral, año impar
- [El nacimiento del Señor es el nacimiento de la paz](../r/70b8f9f18e.md) — San León Magno · Sermón 6, 2-3 en la Natividad del Señor: PL 54, 213-216 · 31 de Diciembre. Día VII - Octava de Navidad — Santoral, año impar
- [Misterio siempre nuevo](../r/9421a345dc.md) — San Máximo el Confesor · Centuria 1, 8-13: PG 90, 1182-86 · Ferias anteriores a la Epifanía — Adviento y Navidad, año impar
- [El Señor ama a sus discípulos, y, sin embargo, los envía al mundo a padecer](../r/2bbaebe809.md) — San Gregorio Magno · Homilía 26, 1-2: PL 76, 1197-1198 · Domingo de la Octava de Pascua — Cuaresma y Pascua, año par
- [La encarnación del Verbo y el sacramento de la Eucaristía nos hacen partícipes de la naturaleza divina](../r/89efb41c8a.md) — San Hilario de Poitiers · Lib 8, 13-16: CCL 62A, 325-328 · Domingo de la semana IV de Pascua (semana 4), año par
- [El Señor creó y redimió a sus siervos](../r/49e81f538f.md) — San Agustín de Hipona · Sermón 130, 2: Edit. Maurist. t. 5, 637-638 · Jueves de la semana IV de Pascua (semana 4), año par
- [De la encarnación del Verbo](../r/d9ad87be06.md) — San Atanasio de Alejandría · Sermón sobre la encarnación del Verbo, 8-9: PG 25,110-111 · 2 de mayo. San Atanasio, Obispo y Doctor de la Iglesia — Santoral, año par
- [El sacerdote debe ser santo](../r/054f297271.md) — San Juan de Ávila · Plática enviada al padre Francisco Gómez, S. I:, para ser predicada en el Sínodo diocesano de Córdoba del año 1563: BAC 304, Obras completas del santo maestro Juan de Ávila, 3, pp. 364-365. 370. 373 · 10 de mayo. San Juan de Ávila, Presbítero — Santoral, año par
- [El cordero inmolado nos ha hecho pasar de la muerte a la vida](../r/9a88925868.md) — San Melitón de Sardes · Núms. 65-71: SC 123, 95-101 · Jueves Santo — Cuaresma y Pascua, año impar
- [Cristo es cabeza del hombre](../r/4123eda5b6.md) — San Agustín de Hipona · Comentario 19-20, sobre el Salmo 44: CCL 38, 507-508 · Lunes de la semana VII del Tiempo Ordinario (semana 7), año impar
- [Dios mismo será su más preciado galardón, él que es la encarnación del precepto](../r/3b303920c9.md) — San León Magno · Sermón 16, 1-2: CCL 138, 61-62 · Miércoles de la semana IX del Tiempo Ordinario (semana 9), año impar
- [Acojamos la luz clara y eterna](../r/eea7e82284.md) — San Sofronio de Jerusalén · Sermón 3, Sobre el Hypapanté, 6. 7: PG 87, 3, 3291-3293 · 2 de febrero LA PRESENTACIÓN DEL SEÑOR — Santoral, año impar
- [El misterio de la Encarnación](../r/1b5c4949b3.md) — San Pedro Crisólogo · Sermón 148: PL 52, 596-598 · 30 de julio San Pedro Crisólogo, Obispo y Doctor de la Iglesia — Santoral, año impar
- [¿Qué no hizo nuestro Creador para lograr nuestra enmienda?](../r/1d20141cad.md) — San Gregorio Palamás · Homilía 3 : PG, 151, 35 · Miércoles de la semana XXX del Tiempo Ordinario (semana 30), año impar
- [Cristo se hizo carne para hacernos a nosotros espirituales](../r/31e9531468.md) — San Gregorio Magno · Lib. 2, Hom. 4, 19-20: CCL 142, 271-273 · Sábado de la semana XXXIII del Tiempo Ordinario (semana 33), año impar
- [El tiempo de las bodas es aquel en que, por el misterio de la encarnación, el Señor se unió a la Iglesia](../r/1db5456fa0.md) — San Beda el Venerable · Hom. 14 : CCL 122, 95-96 · Viernes de la semana XXV del Tiempo Ordinario (semana 25), año par
- [Sobre el misterio de la encarnación del Verbo](../r/3b74049bd7.md) — Orígenes · Lib 2, 6, 2: PG 11, 210-211 · Domingo de la semana XXXI del Tiempo Ordinario (semana 31) - Año A: Mt 23, 1-12, año par
- [Cristo se rebajó, para que siendo el primero en regresar al reino, fuera para nosotros el principio y el camino hacia la gloria real](../r/81652d3bda.md) — San Cirilo de Alejandría · Lib 2: PG 73, 283-286 · Solemnidad — Tiempo Ordinario, año par
- [Ha aparecido Cristo, nuestra paz](../r/b8b0574de8.md) — San Cirilo de Alejandría · Lib 5, t. 1: PG 70, 1151-1155 · Viernes de la semana XXXIV del Tiempo Ordinario (semana 34), año par
