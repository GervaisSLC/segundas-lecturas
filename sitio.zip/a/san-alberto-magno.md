# San Alberto Magno

None · None · 1 lecturas

- [Pastor y doctor para la edificación del Cuerpo de Cristo](../r/e4c27abffa.md) — San Alberto Magno · Lc 22,19: Opera omnia, París 1890-1899, 23, 672-674 · 15 de noviembre San Alberto Magno, obispo y doctor de la Iglesia — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
