# San Melitón de Sardes

d. c. 180 · St. Melito of Sardis · 2 lecturas

- [El cordero inmolado nos ha hecho pasar de la muerte a la vida](../r/9a88925868.md) — San Melitón de Sardes · Núms. 65-71: SC 123, 95-101 · Jueves Santo — Cuaresma y Pascua, año impar
- [Alabanza de Cristo](../r/478f38dfc4.md) — San Melitón de Sardes · Homilía 2-7. 100-103: SC 123, 60-64. 120-122 · Lunes de la Octava de Pascua — Cuaresma y Pascua, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
