# San Policarpo de Esmirna

c. 69–155 · St. Polycarp of Smyrna · 5 lecturas

- [Estáis salvados por gracia](../r/085faee859.md) — San Policarpo de Esmirna · Caps 1, 1-2,3: Funk 1, 267-269 · Domingo de la semana X del Tiempo Ordinario (semana 10), año par
- [Armémonos con las armas de la justicia](../r/3083347799.md) — San Policarpo de Esmirna · Caps 3 1-5, 2: Funk 1, 269-273 · Lunes de la semana X del Tiempo Ordinario (semana 10), año par
- [Cristo nos ha dejado un ejemplo en su propia persona](../r/fc4eeed4c1.md) — San Policarpo de Esmirna · Caps 6, 1-8, 2: Funk 1, 273-275 · Martes de la semana X del Tiempo Ordinario (semana 10), año par
- [Andemos en la fe y en la justicia](../r/15f0e83e8c.md) — San Policarpo de Esmirna · Caps 9, 1-11, 4: Funk 1, 275-279 · Miércoles de la semana X del Tiempo Ordinario (semana 10), año par
- [Que Jesucristo os haga crecer en la fe y en la verdad](../r/988e466f02.md) — San Policarpo de Esmirna · Caps. 12 1-14: Funk 1, 279-283 · Jueves de la semana X del Tiempo Ordinario (semana 10), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
