# La misión del Espíritu Santo en la Iglesia

**Concilio Vaticano II** (1962–1965) · Segunda lectura del Oficio de Lectura

- id: `28f5fcdbaf`
- Fuente: De la Constitución dogmática Lumen gentium, sobre la Iglesia, del Concilio Vaticano segundo
- Cita patrística: Núms. 4. 12
- Se lee: Miércoles de la semana VII de Pascua (semana 7), año par
- Escritura: [Hch 27, 1-20](../escritura/hch.md) (primera lectura del día); [Jn 7, 37. 38. 39](../escritura/jn.md) (responsorio)
- Temas (automáticos): [Espíritu Santo](../temas/espiritu.md), [Iglesia](../temas/iglesia.md), [Misión y evangelización](../temas/mision.md), [Pastores y ministerio](../temas/pastores.md)
- Cómo citar: Concilio Vaticano II, Núms. 4. 12, «La misión del Espíritu Santo en la Iglesia». Liturgia de las Horas, Oficio de Lectura, segunda lectura, Miércoles de la semana VII de Pascua (semana 7), año par. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-28f5fcdbaf](../index.html#r-28f5fcdbaf)
- Autor: [Concilio Vaticano II](../a/vaticano-ii.md)

## Texto

Consumada la obra que el Padre confió al Hijo en la tierra, fue enviado el Espíritu Santo en el día de Pentecostés, para que indeficientemente santificara a la Iglesia y, de esta forma, los que creen en Cristo pudieran acercarse al Padre en un mismo Espíritu. Él es el Espíritu de vida o la fuente del agua que brota para comunicar vida eterna; por el cual el Padre vivifica a todos los muertos por el pecado, hasta que el mismo Espíritu resucite en Cristo sus cuerpos mortales.

El Espíritu habita en la Iglesia y en los corazones de los fieles como en un templo, y en ellos ora y da testimonio de la adopción de hijos. Con diversos dones jerárquicos y carismáticos dirige a la Iglesia, a la que guía hacia toda verdad, y la unifica en comunión y ministerio, enriqueciéndola con todos sus frutos.

Con la fuerza del Evangelio hace rejuvenecer a la Iglesia, la renueva constantemente y la conduce a la unión consumada con su Esposo. Pues el Espíritu y la Esposa dicen al Señor Jesús: «¡Ven!»

Así se manifiesta la Iglesia como una muchedumbre reunida por la unidad del Padre y del Hijo y del Espíritu Santo.

La universalidad de los fieles que tiene la unción del Espíritu Santo no puede fallar en su creencia, y ejerce esta peculiar propiedad mediante el sentido sobrenatural de la fe de todo el pueblo, cuando desde los obispos hasta los últimos fieles seglares manifiestan un asentimiento universal en las cosas de fe y de costumbres.

Con ese sentido de la fe, que el Espíritu Santo mueve y sostiene, el pueblo de Dios, bajo la dirección del magisterio, al que sigue fidelísimamente, recibe no ya la palabra de los hombres, sino la verdadera palabra de Dios; se adhiere indefectiblemente a la fe que ha sido transmitida de una vez para siempre a los fieles; penetra profundamente en ella con rectitud de juicio y la aplica más íntegramente en la vida.

Además, el mismo Espíritu Santo no solamente santifica y dirige al pueblo de Dios por los sacramentos y los ministerios y lo enriquece con las virtudes, sino que, distribuyéndolos a cada uno en particular según le place, reparte entre los fieles dones de todo género, incluso especiales, con que los dispone y prepara para realizar variedad de obras y de oficios provechosos para la renovación y una más amplia edificación de la Iglesia, según aquellas palabras: A cada uno se le otorga la manifestación del Espíritu para común utilidad.

Estos carismas, tanto los extraordinarios como los más sencillos y comunes, por el hecho de que son muy conformes y útiles a las necesidades de la Iglesia, hay que recibirlos con agradecimiento y consuelo.

## Responsorio (Jn 7, 37. 38. 39)

R. El último día de la fiesta, Jesús clamaba en alta voz: «Del que crea en mí brotarán torrentes de agua viva.» * Esto lo dijo del Espíritu, que habían de recibir los que a él se unieran por la fe. Aleluya.  
V. El que tenga sed que venga a mí y que beba; brotarán de él torrentes de agua viva.  
R. Esto lo dijo del Espíritu, que habían de recibir los que a él se unieran por la fe. Aleluya.  

## Oración

Padre, lleno de amor, concede a tu Iglesia congregada por el Espíritu Santo, dedicarse plenamente a tu servicio y vivir unida en el amor, según tu voluntad. Por nuestro Señor Jesucristo.

## Primera lectura del día

**De los Hechos de los apóstoles 27, 1-20** — *Viaje de Pablo por mar hacia Roma*

En aquellos días, cuando se decidió que emprendiésemos la navegación hacia Italia, encomendaron la custodia de Pablo y de otros prisioneros a un centurión de nombre Julio, perteneciente a la cohorte Augusta. Embarcamos en una nave adramitena que iba a navegar hacia lugares de Asia y nos hicimos a la mar. Estaba con nosotros Aristarco, macedonio de Tesalónica.

Al día siguiente arribamos a Sidón. Allí, Julio, tratando con humanidad a Pablo, le permitió ir a ver a sus amigos y ser atendido por ellos. Desde allí nos hicimos a la mar y navegamos a sotavento de Chipre, porque los vientos eran contrarios, y, después de hacer la travesía por alta mar frente a las costas de Cilicia y Panfilia, llegamos a Mira de Licia. Allí encontró el centurión una nave alejandrina que navegaba para Italia y nos embarcó en ella. Durante bastantes días navegamos despacio, y habiendo llegado a duras penas frente a Gnido, por no permitirlo el viento, navegamos a sotavento de Creta, frente a Salmón, y, después de costearla con dificultad, llegamos a un lugar llamado Puertos Hermosos, que estaba cerca de la ciudad de Lasea.

Habiendo transcurrido bastante tiempo y siendo ya insegura la navegación porque ya había pasado el Ayuno, Pablo les aconsejaba, diciéndoles:

«Amigos, veo que la navegación va a ser un sufrimiento y un perjuicio no solo para la carga y la nave, sino también para nuestras personas».

Pero el centurión daba más crédito al piloto y al patrón que a lo que Pablo había dicho. Como, por otra parte, el puerto no era adecuado para invernar, la mayoría acordó hacerse a la mar, intentando llegar a Fénica, puerto de Creta que mira al ábrego y al cauro, para pasar allí el invierno. Habiéndose levantado una brisa del sur, creyeron que podían realizar su propósito y, levando anclas, fueron costeando Creta. Pero no mucho después irrumpió contra la nave un viento huracanado, el llamado euroaquilón. La nave fue arrastrada y no pudimos hacer frente al viento, quedando a la deriva. Navegando a sotavento de una isleta llamada Cauda, con dificultad pudimos hacernos con el bote; lo izaron a bordo y se emplearon cables de refuerzo para ceñir el casco de la nave y, por temor a ser arrojados a la Sirte, se echó el ancla flotante y así seguían a la deriva.

Al día siguiente, como el temporal continuaba azotando con fuerza, echaron al mar parte de la carga, y, al tercer día, arrojamos con nuestras propias manos el aparejo de la nave. Durante muchos días, no aparecieron ni sol ni estrellas; y, como seguíamos acosados por una tempestad no pequeña, ya habíamos perdido toda esperanza de salvarnos.

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
