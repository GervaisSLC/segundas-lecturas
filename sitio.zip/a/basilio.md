# San Basilio Magno

c. 330–379 · St. Basil the Great · 13 lecturas

- [El Verbo se hizo carne y puso su morada entre nosotros](../r/b9eb587bee.md) — San Basilio Magno · 2, 6; PG 31, 1459-1462. 1471-1474 · 25 de Diciembre. LA NATIVIDAD DEL SEÑOR — Santoral, año par
- [El Señor vivifica su cuerpo en el Espíritu](../r/5c5447bf82.md) — San Basilio Magno · Cap. 26, 61. 64: PG 32, 179-182. 186 · 2 de Enero — Santoral, año impar
- [Es una sola la muerte en favor del mundo y una sola la resurrección de entre los muertos](../r/6cfdbd8b87.md) — San Basilio Magno · Cap. 15, núm. 35: PG 32, 127-130 · Martes Santo — Cuaresma y Pascua, año par
- [La inefable benignidad de Cristo colmó a su Iglesia de innumerables dones](../r/00147757ce.md) — San Basilio Magno · SC 187, 275-277 · Viernes de la semana II de Pascua (semana 2), año par
- [La acción del Espíritu Santo](../r/669853f286.md) — San Basilio Magno · Cap. 9, núms. 22-23: PG 32, 107-110 · Martes de la semana VII de Pascua (semana 7), año par
- [Es una sola la muerte en favor del mundo y una sola la resurrección de entre los muertos](../r/ea2526ef25.md) — San Basilio Magno · Capítulo 15, 35: PG 32, 127-130 · Miércoles de la semana V de Cuaresma (semana 5), año impar
- [El Espíritu, dador de vida](../r/6e44231b61.md) — San Basilio Magno · Cap. 15, 35-36: PG 32, 130-131 · Domingo de la semana IV de Pascua (semana 4) - Año A: Jn 10, 1-10, año impar
- [¿Cómo pagaremos al Señor todo el bien que nos ha hecho?](../r/71be3b19dd.md) — San Basilio Magno · Regla 2, 2-4: PG 31, 914-915 · Viernes de la semana II del Tiempo Ordinario (semana 2), año impar
- [Yo soy el que cura a las ovejas enfermas](../r/ee25c94dcc.md) — San Basilio Magno · Homilía 26 (2: PG 85, 306-307 · Domingo de la semana XVI del Tiempo Ordinario (semana 16), año impar
- [Sembrad justicia, y cosecharéis misericordia](../r/6d345c210a.md) — San Basilio Magno · Hom. 3 sobre la caridad, 6: PG 31, 266-267.275 · Martes de la semana VIII del Tiempo Ordinario (semana 8), año par
- [El que se gloríe, que se gloríe en el Señor](../r/36c5b91118.md) — San Basilio Magno · Homilía sobre la humildad 20, 3: PG 31, 530-531 · Jueves de la semana XIX del Tiempo Ordinario (semana 19), año impar
- [Actúa con valentía, cual experto timonel](../r/f787acc67d.md) — San Basilio Magno · Carta 161, 1-2 al obispo Anfiloquio : PG 32, 630-631 · Miércoles de la semana XXI del Tiempo Ordinario (semana 21), año par
- [El Espíritu Santo, que lo ha creado todo, es Dios](../r/6133979ad2.md) — San Basilio Magno · Carta 8, 11: PG 32, 263-266 · Jueves de la semana XXXI del Tiempo Ordinario (semana 31), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
