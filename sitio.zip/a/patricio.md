# San Patricio

5th c. · St. Patrick · 1 lecturas

- [Muchos pueblos renacieron a Dios por mí](../r/8a72452eac.md) — San Patricio · Caps. 14-16: PL 53, 808-809 · 17 de marzo. San Patricio, Obispo — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
