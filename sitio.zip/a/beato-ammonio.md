# Beato Ammonio

None · None · 1 lecturas

- [Muchos son los males que sufre el justo](../r/8753cd8196.md) — Beato Ammonio · Carta 9, 2-5: PO t. 10, fasc. 6, 590-593 · Martes de la semana XXXII del Tiempo Ordinario (semana 32), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
