# San Braulio de Zaragoza

c. 590–651 · St. Braulio of Zaragoza · 1 lecturas

- [Cristo resucitado, esperanza de todos los creyentes](../r/f7ced45d54.md) — San Braulio de Zaragoza · Carta 19: PL 80, 665-666 · Oficio de Difuntos, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
