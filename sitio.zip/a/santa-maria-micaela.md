# Santa María Micaela

None · None · 1 lecturas

- [Nada hay comparable a la dicha de servir a Dios](../r/764c816e47.md) — Santa María Micaela · Cf. Archivo de la Santa, en Madrid · 15 de junio Santa María Micaela del Santísimo Sacramento — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
