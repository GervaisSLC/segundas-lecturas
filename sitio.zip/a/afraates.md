# Afraates

c. 270–345 · Aphrahat · 1 lecturas

- [La circuncisión del corazón](../r/d7258f781c.md) — Afraates · Demostración 11, Sobre la circuncisión, 11-12: PS 1, 498-503 · Miércoles de la semana I de Cuaresma (semana 1), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
