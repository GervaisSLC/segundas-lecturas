# Diádoco de Fótice

c. 400–486 · Diadochus of Photice · 2 lecturas

- [Hay que amar solamente a Dios](../r/c962725789.md) — Diádoco de Fótice · Caps. 12. 13. 14: PG 65, 1171- 1172 · Miércoles de la semana I de Cuaresma (semana 1), año impar
- [El discernimiento de espíritus se adquiere por el gusto espiritual](../r/10093d4583.md) — Diádoco de Fótice · 6.26.27.30: PG 65, 1169.1175-1176 · Miércoles de la semana VI del Tiempo Ordinario (semana 6), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
