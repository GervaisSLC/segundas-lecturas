# Santa Catalina de Siena

1347–1380 · St. Catherine of Siena · 3 lecturas

- [Gusté y vi](../r/54eb3be049.md) — Santa Catalina de Siena · Cap. 167, Acción de gracias a la Santísima Trinidad: edición latina, Ingolstadt 1583, ff. 290v-291 · 29 de abril. Santa Catalina de Siena, Virgen y Doctora de la IglesiaPatrona de Europa — Santoral, año par
- [Con lazos de amor](../r/00459668d3.md) — Santa Catalina de Siena · Cap. 4, 13 ed. latina, Ingolstadt 1583, ff. 19v-20 · Miércoles de la semana XXIV del Tiempo Ordinario (semana 24), año impar
- [Cuán bueno y cuán suave es, Señor, tu Espíritu para con todos nosotros](../r/fabf5f6856.md) — Santa Catalina de Siena · Cap 134: ed. latina, Ingolstadt 1583, ff. 215v-216 · Miércoles de la semana XXXI del Tiempo Ordinario (semana 31), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
