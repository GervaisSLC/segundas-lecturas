# Beata Mariana de Jesús

None · None · 1 lecturas

- [La Iglesia nos ofrece a Cristo en la Eucaristía](../r/eecf988e6c.md) — Beata Mariana de Jesús · Ed. Madrid 1965, pág. 254 · 17 de abril. Beata Mariana de Jesús Navarro, Virgen — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
