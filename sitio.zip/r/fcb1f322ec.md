# Revistámonos con las armas de la paz

**Clemente de Alejandría** (c. 150–215) · Segunda lectura del Oficio de Lectura

- id: `fcb1f322ec`
- Fuente: De las exhortaciones de san Clemente de Alejandría
- Cita patrística: Exhortación a los paganos, Cap. 11; PG 8, 235-238
- Se lee: Viernes de la semana XXI del Tiempo Ordinario (semana 21), año impar
- Escritura: [Ef 6, 10-24](../escritura/ef.md) (primera lectura del día); [Ef 6, 14. 15. 18](../escritura/ef.md) (responsorio)
- Temas (automáticos): [Paz y unidad](../temas/paz.md), [Obediencia y voluntad de Dios](../temas/obediencia.md), [Pecado y redención](../temas/salvacion.md), [Alabanza y acción de gracias](../temas/alabanza.md)
- Cómo citar: Clemente de Alejandría, Exhortación a los paganos, Cap. 11; PG 8, 235-238, «Revistámonos con las armas de la paz». Liturgia de las Horas, Oficio de Lectura, segunda lectura, Viernes de la semana XXI del Tiempo Ordinario (semana 21), año impar. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-fcb1f322ec](../index.html#r-fcb1f322ec)
- Autor: [Clemente de Alejandría](../a/clemente-alejandria.md)

## Texto

Es la Verdad la que clama: Brille la luz del seno de las tinieblas. Sí, que brille la luz en la zona más oculta del hombre, es decir, en su corazón, e irradien los rayos de la ciencia que, con su esplendor, revelen al hombre interior, al discípulo de la luz, al familiar y coheredero de Cristo; sobre todo cuando el hijo bueno y piadoso haya llegado al conocimiento del augusto y venerable nombre del Padre bueno, que manda cosas fáciles y salutíferas a su hijo.

El que le obedece es superior con mucho a todas las cosas, sigue a Dios, obedece al Padre, llegó a conocerle por el camino del error, amó a Dios, amó al prójimo, cumplió lo mandado, espera el premio, exige lo prometido. El plan de Dios fue siempre el de salvar la grey de los hombres: por eso el Dios bueno envió al buen Pastor. En cuanto al Verbo, después de haber explicado la verdad, mostró a los hombres la grandeza de la salvación, para que, o bien movidos a penitencia consiguieran la salvación, o bien, si se negasen a obedecer, se hicieran reos de condenación. Esta es la predicación de la justicia, que es una buena noticia para quienes obedecen; en cambio, para los demás, para los que no quisieran obedecer, es motivo de condenación.

Ahora bien: una trompeta guerrera puede legítimamente congregar con su toque a los soldados y anunciar el comienzo de la batalla; ¿y no le va a estar permitido a Cristo, que hace oír su dulce himno de paz hasta los confines de la tierra, reunir a sus pacíficos guerreros? Sí, hombre; congregó con su sangre y su palabra un ejército incruento, al que ha hecho entrega del reino de los cielos.

La trompeta de Cristo es su evangelio. Él mismo tocó la trompeta, y nosotros la hemos oído. Revistámonos con las armas de la paz: por coraza poneos la justicia, tened embrazado el escudo de la fe y puesto el casco de la salvación, y desenvainemos además la espada del Espíritu, es decir, la palabra de Dios. Con este atuendo de paz nos pertrecha el Apóstol. Estas son nuestras armas, armas que nos hacen invulnerables a todo evento. Pertrechados con estas armas, estemos firmes en el combate contra el adversario, apaguemos las flechas incendiarias del malo, intercambiando los beneficios recibidos con himnos de alabanza y honrando a Dios por medio del Verbo divino. Entonces clamarás al Señor —dice— y te dirá: «Aquí estoy».

¡Oh santo y dichoso poder, por el que Dios mora con los hombres! ¡Bien vale la pena que el hombre se convierta en imitador y adorador de una naturaleza tan sumamente buena y excelente! No es lícito, en efecto, imitar a Dios de otro modo que honrándolo santamente; ni honrarlo y venerarlo sino imitándolo. Porque sólo entonces el celestial y verdaderamente divino amor se granjea la voluntad de los hombres, cuando resplandeciere en la misma alma la verdadera belleza suscitada por el Verbo. Lo cual se realiza en grado superlativo, cuando la salvación corre a la par de una sincera voluntad; y la vida pende, por decirlo así, libremente del mismo yugo.

En conclusión: esta exhortación de la verdad es la única que permanece con nosotros hasta el último aliento, como el más fiel amigo; y si alguien se dirige hacia el cielo, ella es el mejor guía para el espíritu íntegro y perfecto del alma. ¿Que para qué te exhorto? Ni más ni menos que para que te salves. Esto es lo que Cristo quiere: y, para decirlo todo en una sola palabra, él es quien te comunica la vida. Y ¿quién es él? Te lo diré en pocas palabras: la Palabra de verdad, la Palabra que preserva de la muerte, que regenera al hombre reduciéndolo a la verdad; es el estímulo de la salvación, que ahuyenta la ruina, expulsa la muerte, edifica un templo en los hombres para establecer en ellos la morada de Dios. Procura que este templo sea puro, y abandona al viento y al fuego, como flores caducas, los placeres y la molicie. Cultiva, en cambio, con prudencia los frutos de la templanza, y consagra tu ser a Dios como primicia, para que suya sea no sólo la obra, sino también la gracia de la obra. Ambas cosas se requieren del discípulo de Cristo: que se muestre digno del reino y que sea juzgado digno del reino.

## Responsorio (Ef 6, 14. 15. 18)

R. Ceñíos vuestra cintura con la verdad y revestíos con la coraza de la justicia y con el celo * para anunciar el Evangelio de la paz.  
V. Orad incesantemente con toda clase de oraciones y súplicas en el Espíritu.  
R. Para anunciar el Evangelio de la paz.  

## Oración

Oh Dios, que unes los corazones de tus fieles en un mismo deseo, inspira a tu pueblo el amor a tus preceptos y esperanza en tus promesas, para que, en medio de las vicisitudes del mundo, nuestros corazones estén firmes en la verdadera alegría. Por nuestro Señor Jesucristo.

## Primera lectura del día

**De la carta a los Efesios 6, 10-24** — *El combate espiritual. Epílogo de la Carta.*

Hermanos:

Buscad vuestra fuerza en el Señor y en su invencible poder. Poneos las armas de Dios, para poder afrontar las asechanzas del diablo, porque nuestra lucha no es contra hombres de carne y hueso sino contra los principados, contra las potestades, contra los dominadores de este mundo de tinieblas, contra los espíritus malignos del aire.

Por eso, tomad las armas de Dios para poder resistir en el día malo y manteneros firmes después de haber superado todas las pruebas.

Estad firmes; ceñid la cintura con la verdad, y revestid la coraza de la justicia; calzad los pies con la prontitud para el evangelio de la paz. Embrazad el escudo de la fe, donde se apagarán las flechas incendiarias del maligno. Poneos el casco de la salvación y empuñad la espada del Espíritu que es la palabra de Dios.

Siempre en oración y súplica, orad en toda ocasión en el Espíritu, velando juntos con constancia, y suplicando por todos los santos. Pedid también por mí, para que cuando abra mi boca, se me conceda el don de la palabra, y anuncie con valentía el misterio del Evangelio, del que soy embajador en cadenas, y tenga valor para hablar de él como debo.

Tíquico, hermano querido y ministro fiel del Señor, os informará de todo para que sepáis cómo me va y lo que hago. Para ello os lo envío, para que tengáis noticias mías y para que os dé ánimos.

A los hermanos, paz, amor y fe de parte de Dios Padre y del Señor Jesucristo. La gracia para todos los que aman al Señor Jesucristo con amor incorruptible.

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
