# Cristo, Dios y hombre

45 lecturas (tema asignado automáticamente).

[Todos los temas](index.md) · [Guía para IAs](../llms.txt)

- [Una voz grita en el desierto](../r/4cf2a921bf.md) — Eusebio de Cesarea · Cap 40: PG 24, 366-367 · Domingo de la semana II de Adviento (semana 2), año par
- [El Dueño de todo vino en forma de siervo](../r/44914f3857.md) — Sin identificar · En la Natividad del Salvador Edic Schwartz, ACO t. 3, parte 1,157-159. · 25 de Diciembre. LA NATIVIDAD DEL SEÑOR — Santoral, año par
- [El Verbo se hizo carne y puso su morada entre nosotros](../r/b9eb587bee.md) — San Basilio Magno · 2, 6; PG 31, 1459-1462. 1471-1474 · 25 de Diciembre. LA NATIVIDAD DEL SEÑOR — Santoral, año par
- [Juan es aquel a quien Cristo amó con amor de predilección](../r/5fa731094e.md) — San Gregorio Palamás · Homilía 20: PG 151, 266.271 · 27 de Diciembre. San Juan Apóstol y Evangelista — Santoral, año par
- [Dios se ha manifestado en la carne](../r/12af9921bd.md) — San Gregorio de Nisa · Homilía 5: PG 44, 859-862. 863. 874. 875 · 31 de Diciembre. Día VII - Octava de Navidad — Santoral, año par
- [La santísima Virgen ha de ser llamada Madre de Dios](../r/8fcc68c757.md) — San Cirilo de Alejandría · Homilía 15, 1-3 sobre la encarnación del Verbo: PG 77, 1090-1091 · 1 de Enero. SANTA MARÍA, MADRE DE DIOS — Santoral, año par
- [El misterio de nuestra salvación](../r/7cc7b1e9e5.md) — San Fulberto de Chartres · Carta 5: PL 141, 198-199 · 8 de Enero o Martes después del Domingo de Epifanía — Santoral, año par
- [María, antes de concebir corporalmente, concibió en su espíritu](../r/19a318fd82.md) — San León Magno · Sermón 1 en la Natividad del Señor, 2. 3: PL 54,191-192 · Común de Santa maría virgen — Comunes, año par
- [El amigo de los hombres se ha hecho hombre, naciendo de la Virgen](../r/c519c14650.md) — San Proclo de Constantinopla · Sobre la Natividad del Señor, 1-2: PG 65, 843-846 · Común de Santa maría virgen — Comunes, año par
- [El Verbo de Dios vino por su benignidad hacia nosotros](../r/55d9831093.md) — San Atanasio de Alejandría · Núm. 8-9: PG 25, 110-111 · Viernes de la semana III de Adviento (semana 3), año impar
- [En la plenitud de los tiempos vino la plenitud de la divinidad](../r/e242732ddb.md) — San Bernardo de Claraval · Sermón 1-2 en la Epifanía del Señor, 1-2: PL 183, 141-143 · 29 de Diciembre. Día V - Octava de Navidad — Santoral, año impar
- [Misterio siempre nuevo](../r/9421a345dc.md) — San Máximo el Confesor · Centuria 1, 8-13: PG 90, 1182-86 · Ferias anteriores a la Epifanía — Adviento y Navidad, año impar
- [El cristiano dispone de medios para superar las tentaciones](../r/ea0a56ed1a.md) — San Gregorio Nacianceno · Discurso 40, 10: PG 36, 370-371 · Semana I de Cuaresma — Cuaresma y Pascua, año par
- [Bendito el que viene, como rey, en nombre del Señor](../r/1d1605e628.md) — San Andrés de Creta · Sermón 9 sobre el domingo de Ramos : PG 97, 990-994 · Domingo de Ramos en la Pasión del Señor — Cuaresma y Pascua, año par
- [Mirad al Rey justo](../r/141ee5d69e.md) — San Cirilo de Alejandría · Lib 4, orat 2: PG 70, 967-970 · Domingo de Ramos en la Pasión del Señor — Cuaresma y Pascua, año par
- [La encarnación del Verbo y el sacramento de la Eucaristía nos hacen partícipes de la naturaleza divina](../r/89efb41c8a.md) — San Hilario de Poitiers · Lib 8, 13-16: CCL 62A, 325-328 · Domingo de la semana IV de Pascua (semana 4), año par
- [Nosotros os anunciamos la promesa que Dios hizo a nuestros padres](../r/814402f643.md) — San Cirilo de Alejandría · Cap. 2, 14: PG 74, 925-926 · Martes de la semana IV de Pascua (semana 4), año par
- [Yo soy la vid, vosotros los sarmientos](../r/fd8dc977cf.md) — San Cirilo de Alejandría · Lib 10, 2: PG 74, 331-334 · Domingo de la semana V de Pascua (semana 5), año par
- [Nadie ha subido al cielo sino aquel que ha bajado del cielo](../r/b30382d55d.md) — San Agustín de Hipona · Sermón Mai 98, Sobre la Ascensión del Señor, 1-2: PLS 2, 494-495 · Solemnidad — Cuaresma y Pascua, año par
- [Me he hecho Hijo del hombre, para que vosotros podáis ser hijos de Dios](../r/4834ea815e.md) — San León Magno · Tratado 77, 4-6: CCL 138A, 490-493 · Domingo de Pentecostés — Cuaresma y Pascua, año par
- [Gusté y vi](../r/54eb3be049.md) — Santa Catalina de Siena · Cap. 167, Acción de gracias a la Santísima Trinidad: edición latina, Ingolstadt 1583, ff. 290v-291 · 29 de abril. Santa Catalina de Siena, Virgen y Doctora de la IglesiaPatrona de Europa — Santoral, año par
- [De la encarnación del Verbo](../r/d9ad87be06.md) — San Atanasio de Alejandría · Sermón sobre la encarnación del Verbo, 8-9: PG 25,110-111 · 2 de mayo. San Atanasio, Obispo y Doctor de la Iglesia — Santoral, año par
- [Ven, Espíritu Santo](../r/42d74366c9.md) — Santa María Magdalena de Pazzi · Manuscritos III, 186. 264; IV, 716: Opere di santa María Magdalena de' Pazzi, Florencia 1965, 4, pp. 200. 269; 6, p.194 · El mismo día 25 de mayo. Santa María Magdalena de Pazzi, Virgen — Santoral, año par
- [Abiertamente se nos predica el misterio de Cristo](../r/7c29394bc3.md) — San Cirilo de Alejandría · Lib. 3, cap. 3: PG 73, 427-434 · Semana II de Cuaresma — Cuaresma y Pascua, año impar
- [Jesucristo ora por nosotros, ora en nosotros y es invocado por nosotros](../r/6605249262.md) — San Agustín de Hipona · Comentario sobre el Salmo 85, n. 1: CCL 39, 1176-1177 · Sábado de la semana III de Cuaresma (semana 3), año impar
- [De la plenitud del Verbo todos hemos recibido](../r/12ab1036e1.md) — San Ambrosio de Milán · Sermón 20, 54-55: CSEL 62, 471-472 · Domingo de la semana V de Pascua (semana 5) - Año A: Jn 14, 1-12, año impar
- [Cristo, primicias de nuestra resurrección](../r/f0844ab785.md) — San Ireneo de Lyon · Lib. 3, 19, 1. 3-20, 1: SC 34, 332. 336-338 · Domingo de la semana VI del Tiempo Ordinario (semana 6), año impar
- [Jesucristo es del linaje de David según la carne](../r/dc6dfeea18.md) — San Agustín de Hipona · Cap. 15, 30-31: PL 44, 981-983 · Jueves de la semana XV del Tiempo Ordinario (semana 15), año impar
- [Defensor de la maternidad divina de la virgen María](../r/3b24f12532.md) — San Cirilo de Alejandría · Carta 1: PG 77,14-18. 27-30 · 27 de junio San Cirilo de Alejandría, Obispo y Doctor de la Iglesia — Santoral, año impar
- [La gloria de Dios consiste en que el hombre viva, y la vida del hombre consiste en la visión de Dios](../r/24a9abe2f2.md) — San Ireneo de Lyon · Libro 4, 20, 5-7: SC 100, 640-642. 644-648 · 28 de junio San Ireneo, Obispo y Mártir — Santoral, año impar
- [Cuando se cumplió el tiempo, envió Dios a su Hijo para que recibiéramos el ser hijos por adopción](../r/725fe8cb33.md) — San Cirilo de Alejandría · PG 77, 27-30 · Miércoles de la semana I del Tiempo Ordinario (semana 1), año par
- [Renueva los tiempos pasados](../r/39c4d616d3.md) — San Atanasio de Alejandría · 10: PG 25, 111-114 · Martes de la semana V del Tiempo Ordinario (semana 5), año par
- [Vayamos de una vez en pos del Verbo, busquemos aquel descanso](../r/40d24d66d4.md) — San Gregorio Nacianceno · Sermón 14, 20-22 sobre el amor a los pobres: PG 35, 882-886 · Domingo de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [La economía del madero nos ha manifestado al Verbo, que estaba oculto a nuestros ojos](../r/62832f273e.md) — San Ireneo de Lyon · Lib. 5, 17, 3-4: SC 153, 230-234 · Domingo de la semana XIX del Tiempo Ordinario (semana 19), año impar
- [Y el pan que yo daré es mi carne, para la vida del mundo](../r/8d3ac54668.md) — Ruperto de Deutz · Lib 6, 51-52: CCL CM 9, 356-357 · Domingo de la semana XIX del Tiempo Ordinario (semana 19), año impar
- [El vástago legítimo es el Verbo, coeterno siempre con Dios Padre](../r/18088bc160.md) — San Martín de León · Sermón 1 en el Adviento del Señor : PL 208, 31-33. 38 · Semana XXX DEL TIEMPO ORDINARIO, año impar
- [No hubo tiempo alguno en que Dios no llamase a todos a la salvación](../r/c8f52cda57.md) — San Cirilo de Alejandría · Homilía pascual 2, 8: PG 77, 447-450 · Martes de la semana XXX del Tiempo Ordinario (semana 30), año impar
- [Yo soy la resurrección y la vida](../r/7b0c930c6e.md) — San Ireneo de Lyon · Lib 4, 5, 2—5, 4: SC 100, 428-436 · Semana XXXII DEL TIEMPO ORDINARIO, año impar
- [Toda la alabanza del Padre viene del Hijo](../r/6a6033e644.md) — San Hilario de Poitiers · Lib. 3, 15-16: PL 10, 84-85 · Sábado de la semana XXXIV del Tiempo Ordinario (semana 34), año impar
- [Llevemos desde ahora una vida sobria, honrada y religiosa aguardando la aparición gloriosa del gran Dios](../r/b42ff5f42f.md) — Clemente de Alejandría · Cap 1: PG 8, 59-63 · Jueves de la semana XXIII del Tiempo Ordinario (semana 23), año par
- [El Padre es conocido por la manifestación del Hijo](../r/e86b5adad4.md) — San Ireneo de Lyon · Lib 4, 6, 3.5.6.7: SC 100, 442.446.448-454 · Sábado de la semana XXVIII del Tiempo Ordinario (semana 28), año par
- [El Verbo del Padre embellece, ordena y contiene todas las cosas](../r/bdb1867799.md) — San Atanasio de Alejandría · Sermón 40-42: PG 25, 79-83 · Viernes de la semana XXIX del Tiempo Ordinario (semana 29), año par
- [Las obras de la creación, reflejo de la Sabiduría eterna](../r/929ecafbef.md) — San Atanasio de Alejandría · Sermón 2, 78.79: PG 26, 311.314 · Sábado de la semana XXX del Tiempo Ordinario (semana 30), año par
- [Sobre el misterio de la encarnación del Verbo](../r/3b74049bd7.md) — Orígenes · Lib 2, 6, 2: PG 11, 210-211 · Domingo de la semana XXXI del Tiempo Ordinario (semana 31) - Año A: Mt 23, 1-12, año par
- [Cuán bueno y cuán suave es, Señor, tu Espíritu para con todos nosotros](../r/fabf5f6856.md) — Santa Catalina de Siena · Cap 134: ed. latina, Ingolstadt 1583, ff. 215v-216 · Miércoles de la semana XXXI del Tiempo Ordinario (semana 31), año par
