# Matrimonio y familia

30 lecturas (tema asignado automáticamente).

[Todos los temas](index.md) · [Guía para IAs](../llms.txt)

- [Criado fiel y solícito](../r/c754ee4157.md) — San Fulgencio de Ruspe · Sermón 1, 2-3: CCL 91 A, 889-890 · Común de pastores — Comunes, año par
- [Sobre la vocación universal a la santidad](../r/a7d31d4110.md) — San Agustín de Hipona · Sermón 96,1. 4. 9: PL 38, 584. 586. 588 · Común de santos varones — Comunes, año par
- [La esposa es el sol de la familia](../r/b6123f0872.md) — Papa Pío XII · Discorsi e radiomessaggi, 11 de marzo de 1942:3,385-390 · Común de santas mujeres — Comunes, año par
- [El ejemplo de Nazaret](../r/be0ff28b89.md) — San Pablo VI · Alocución en Nazaret, 5 de enero de 1964 · Domingo dentro de la Octava de Navidad. LA SAGRADA FAMILIA DE JESÚS, MARÍA Y JOSÉ — Adviento y Navidad, año impar
- [Me alejé mucho, y tú estabas aquí](../r/20f6f15993.md) — San Agustín de Hipona · Comentario sobre el salmo 138, nn. 5-6: CCL 40, 1992-1993 · Semana IV de Cuaresma — Cuaresma y Pascua, año par
- [Que toda la actividad del hombre se purifique en el misterio pascual](../r/86849e4b14.md) — Concilio Vaticano II · Núms. 37-38 · Sábado de la semana IV de Cuaresma (semana 4), año par
- [Hagamos el elogio de los hombres ilustres](../r/7ae9f1b7dd.md) — Actas y escritos anónimos · Monumenta Ordinis Servorum Beatae Maríae Virginis, 1, 3. 5. 6. 9.11: pp. 71 ss. · Mes de febrero — Santoral, año par
- [Sobre la actividad humana en todo el mundo](../r/a04ff4c74d.md) — Concilio Vaticano II · Núms. 33-34 · 1 de mayo. San José, Obrero — Santoral, año par
- [El amor lo puede todo](../r/f00fa1090a.md) — Actas y escritos anónimos · 22 de mayo. Santa Joaquina Vedruna, Religiosa — Santoral, año par
- [Santidad del matrimonio y de la familia](../r/939a0a6b7a.md) — Concilio Vaticano II · Núm. 48 · Domingo de la semana II de Cuaresma (semana 2) - Año A: Mt 17, 1-9, año impar
- [Somos hijos de Dios y constituimos una familia en Cristo](../r/fff850c4a1.md) — Concilio Vaticano II · Cap. 7, 50-51 · Jueves de la semana V de Pascua (semana 5), año impar
- [Dios busca a los hombres, no las cosas de los hombres](../r/997afad38a.md) — San Pedro Crisólogo · Sermón 18 : PL 52, 246-249 · Domingo de la semana V del Tiempo Ordinario (semana 5), año impar
- [La Madre Iglesia se regocija por los hombres que cada día resucitan espiritualmente](../r/afd3c7afa4.md) — San Agustín de Hipona · Sermón 98, 1-3: PL 38, 591-592 · Domingo de la semana X del Tiempo Ordinario (semana 10), año impar
- [La conquista de Jericó](../r/8a95135e92.md) — Orígenes · Homilía 6, 4: PG 12, 855-856 · Jueves de la semana X del Tiempo Ordinario (semana 10), año impar
- [Debemos atender a todos por igual](../r/e223ba2b3f.md) — San Juan Crisóstomo · Homilía 10, cap. 6, 4: PG 63, 88-89 · Domingo de la semana XV del Tiempo Ordinario (semana 15), año impar
- [La devoción se ha de ejercitar de diversas maneras](../r/2cd76a804d.md) — San Francisco de Sales · Parte 1, cap. 3 · 24 de enero San Francisco de Sales, Obispo y Doctor de la Iglesia — Santoral, año impar
- [Por sus frutos los conoceréis](../r/acd120a7f7.md) — San Juan Damasceno · Sermón 6, Sobre la Natividad de la Virgen María, 2. 4. 5. 6: PG 96, 663. 667. 670 · 26 de julio Santos Joaquín y Ana, Padres de la Virgen María — Santoral, año impar
- [Eucaristía: Sacramento de vida](../r/93f52ebe30.md) — San Pedro Julián Eymard · La Présence réelle, vol. 1, París, 1950, pp. 270-271 et 307-308). · El mismo día 2 de agosto San Pedro Julián Eymard, presbítero — Santoral, año impar
- [Renueva los tiempos pasados](../r/39c4d616d3.md) — San Atanasio de Alejandría · 10: PG 25, 111-114 · Martes de la semana V del Tiempo Ordinario (semana 5), año par
- [Este sacramento que recibes se realiza por la palabra de Cristo](../r/831f9b4b3b.md) — San Ambrosio de Milán · Tratado 52-54. 58: SC 25bis, 186-188. 190 · Jueves de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [Irá delante del Señor con el espíritu y poder de Elías](../r/fa78490b30.md) — San Elredo de Rievaulx · Sermón «Quomodo referatur», Edit C.H. Talbot, SSOC vol 1, 120-121 · Sábado de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [La esperanza de los premios celestiales](../r/926ac40229.md) — San Gregorio Magno · Lib. 2, Homilía 1, 7: CCL 142, 213- 214 · Jueves de la semana XXI del Tiempo Ordinario (semana 21), año impar
- [Me casaré contigo en matrimonio perpetuo](../r/d2a792832d.md) — San Juan de la Cruz · Canción 39, 4-7 · Jueves de la semana XXIII del Tiempo Ordinario (semana 23), año impar
- [Es éste un gran misterio](../r/38055f282f.md) — San Gregorio Nacianceno · Sermón 37, 5-7 sobre Mateo 19, 1-12: PG 36, 287-291 · Domingo de la semana XXVII del Tiempo Ordinario (semana 27), año impar
- [Estuve enfermo, y me visitasteis](../r/3ee6be000e.md) — San Pablo VI · 25 de enero de 1970: AAS 62, 1970, 82-88 · El mismo día 10 de octubre San Luis Beltrán, presbítero — Santoral, año impar
- [Santidad del matrimonio y de la familia](../r/29ededa159.md) — Concilio Vaticano II · Núm. 48 · 16 de noviembre Santa Margarita de Escocia — Santoral, año impar
- [Yo soy el alfa y la omega, el primero y el último](../r/8c0c449131.md) — Concilio Vaticano II · núm. 40.45 · Sábado de la semana XVIII del Tiempo Ordinario (semana 18), año par
- [El tiempo de las bodas es aquel en que, por el misterio de la encarnación, el Señor se unió a la Iglesia](../r/1db5456fa0.md) — San Beda el Venerable · Hom. 14 : CCL 122, 95-96 · Viernes de la semana XXV del Tiempo Ordinario (semana 25), año par
- [La bondad de Dios es inexplicable](../r/ade73bb72c.md) — San Nicolás Cabasilas · Lib 1 PG 150, 498-499 · Jueves de la semana XXVIII del Tiempo Ordinario (semana 28), año par
- [Cristo quiso salvar a los que estaban a punto de perecer](../r/9044b9826e.md) — Actas y escritos anónimos · Caps 1, 1-2,7: Funk 1, 145-149 · Jueves de la semana XXXIII del Tiempo Ordinario (semana 33), año par
