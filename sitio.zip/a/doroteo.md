# San Doroteo de Gaza

c. 505–565 · St. Dorotheus of Gaza · 2 lecturas

- [La causa de toda perturbación consiste en que nadie se acusa a sí mismo](../r/1c903959cf.md) — San Doroteo de Gaza · 1-2: PG 88, 1695-1699 · Lunes de la semana XVII del Tiempo Ordinario (semana 17), año par
- [La falsa paz de espíritu](../r/bf33aae1e6.md) — San Doroteo de Gaza · 2-3: PG 88, 1699 · Martes de la semana XVII del Tiempo Ordinario (semana 17), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
