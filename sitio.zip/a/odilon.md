# San Odilón de Cluny

c. 962–1049 · St. Odilo of Cluny · 4 lecturas

- [El que por nosotros se hizo mortal, es confesado Rey y Señor](../r/a7d7fadb84.md) — San Odilón de Cluny · Sermón 9 en el día de Pentecostés : PL 142, 1015-1016 · 10 de Enero o Jueves después del Domingo de Epifanía — Santoral, año par
- [Mira, yo envío mi mensajero delante de ti](../r/ad27e05cbb.md) — San Odilón de Cluny · Sermón 10, sobre San Juan Bautista: PL 142, 1019-1020 · Jueves de la semana I de Adviento (semana 1), año impar
- [Mirad, llegan días en que suscitaré a David un vástago legítimo](../r/782290f4d1.md) — San Odilón de Cluny · Sermón 1 en la Navidad del Señor: PL 142, 993-994 · 21 de Diciembre — Santoral, año impar
- [Cristo resucitó para que no dude el cristiano de la propia resurrección](../r/70bb6bef66.md) — San Odilón de Cluny · Sermón 5: PL 142, 1004-1005 · Oficio de Difuntos, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
