# San Máximo el Confesor

c. 580–662 · St. Maximus the Confessor · 4 lecturas

- [Misterio siempre nuevo](../r/9421a345dc.md) — San Máximo el Confesor · Centuria 1, 8-13: PG 90, 1182-86 · Ferias anteriores a la Epifanía — Adviento y Navidad, año impar
- [La misericordia de Dios para con los penitentes](../r/b6f3fc8b09.md) — San Máximo el Confesor · Carta 11 : PG 91, 454-455 · Jueves de la semana IV de Cuaresma (semana 4), año par
- [La luz que alumbra a todo hombre](../r/987e53bad8.md) — San Máximo el Confesor · Cuestiones a Talasio (63: PG 90, 667-670 · Domingo de la semana XII del Tiempo Ordinario (semana 12), año par
- [Sin la caridad, todo es vanidad de vanidades](../r/a03ef7baec.md) — San Máximo el Confesor · Centuria 1, cap 1, 4-5.16-17.23-24.26-28.30-40: PG 90, 962-967 · Domingo de la semana XX del Tiempo Ordinario (semana 20), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
