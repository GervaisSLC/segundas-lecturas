# Ayunamos por nuestros pecados, pues vamos a acercarnos a los sagrados misterios

**San Juan Crisóstomo** (c. 349–407) · Segunda lectura del Oficio de Lectura

- id: `bd3dfce7fa`
- Fuente: De los discursos de san Juan Crisóstomo, obispo
- Cita patrística: Discurso 3, contra los judíos: PG 48, 867-868
- Se lee: Jueves después de Ceniza — Cuaresma y Pascua, año impar
- Escritura: [Dt 1, 1. 6-18](../escritura/dt.md) (primera lectura del día); [Ba 3, 2](../escritura/ba.md) (responsorio); [Sal 105, 6](../escritura/sal.md) (responsorio)
- Temas (automáticos): [Cruz y Pasión](../temas/cruz.md), [Ayuno y Cuaresma](../temas/ayuno.md), [Pecado y redención](../temas/salvacion.md), [Oración](../temas/oracion.md)
- Cómo citar: San Juan Crisóstomo, Discurso 3, contra los judíos: PG 48, 867-868, «Ayunamos por nuestros pecados, pues vamos a acercarnos a los sagrados misterios». Liturgia de las Horas, Oficio de Lectura, segunda lectura, Jueves después de Ceniza — Cuaresma y Pascua, año impar. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-bd3dfce7fa](../index.html#r-bd3dfce7fa)
- Autor: [San Juan Crisóstomo](../a/juan-crisostomo.md)

## Texto

¿Por qué ayunamos durante estos cuarenta días? En el pasado, muchos se acercaban a los sagrados misterios temerariamente y sin ninguna preparación, especialmente en estos días en que Cristo se entregó a sí mismo. Por ese motivo, los Padres, conscientes del daño que podía derivarse de ese acercarse irresponsablemente a los misterios, juzgaron oportuno prescribir cuarenta días de ayuno, de oraciones, de escucha de la palabra de Dios y de reuniones, para que todos, diligentemente purificados por la plegaria, la limosna, el ayuno, las vigilias, las lágrimas, la confesión y las demás obras, podamos acercarnos a los sagrados misterios con la conciencia limpia, según nuestra capacidad receptiva. La experiencia nos dice que, con esta unánime decisión, aseguraron, incluso para los tiempos venideros, algo grande y excelente, consiguiendo hacernos llegar a la habitual observancia del ayuno.

De hecho, aunque durante todo el año, nosotros no nos cansamos de predicar y proclamar el ayuno, nadie presta atención a nuestras palabras. En cambio, al solo anuncio de la Cuaresma, aunque nadie estimule, aunque nadie exhorte, hasta el más negligente se reanima y acoge las exhortaciones y las incitaciones que nos hace el mismo tiempo cuaresmal.

Por tanto, si alguno te pregunta por qué ayunas, no digas que es por la Pascua, ni siquiera por la cruz. En efecto, no ayunamos ni por la Pascua ni por la cruz, sino a causa de nuestros pecados, pues vamos a acercarnos a los sagrados misterios. Además, la Pascua no es motivo de ayuno o de luto, sino de alegría y de gozo.

Finalmente, la cruz tomó sobre sí el pecado, fue expiación por todo el mundo y reconciliación de un odio inveterado, abrió las puertas del cielo, devolvió a la amistad a los que antes eran enemigos, nos hizo subir al cielo, colocó a nuestra naturaleza a la derecha del trono, y nos concedió otros innumerables bienes.

Así que no debemos llorar y afligirnos por todas estas cosas, sino gozarnos y alegrarnos. El mismo san Pablo dice: Dios me libre de gloriarme sino en la cruz de nuestro Señor Jesucristo. Y de nuevo: La prueba de que Dios nos ama es que Cristo, siendo nosotros todavía pecadores, murió por nosotros.

En el mismo sentido se expresa claramente san Juan: Tanto amó Dios al mundo. ¿Cómo le amó? Dejando perder todas las demás cosas, levantó una cruz. Después de haber dicho: Tanto amó Dios al mundo, añadió: que entregó a su Hijo único para que lo crucificaran, para que no perezca ninguno de los que creen en él, sino que tengan vida eterna. Luego si la cruz es motivo de amor y de glorificación, no digamos que nos afligimos por ella. Nunca jamás lloremos por la cruz, sino por nuestros pecados. Por eso ayunamos.

## Responsorio (Cf. Ba 3, 2; Sal 105, 6)

R. Enmendémonos de nuestros pecados, cometidos por ignorancia, para que, sorprendidos por la muerte, no busquemos el tiempo de hacer penitencia sin encontrarlo. * Escucha, Señor, ten piedad, porque hemos pecado contra ti.  
V. Hemos pecado como nuestros padres, obramos el mal, hemos sido impíos.  
R. Escucha, Señor, ten piedad, porque hemos pecado contra ti.  

## Oración

Señor, que tu gracia inspire, sostenga y acompañe nuestras obras, para que nuestro trabajo comience en ti, como en su fuente, y tienda siempre a ti, como a su fin. Por nuestro Señor Jesucristo.

## Primera lectura del día

**Comienza el libro del Deuteronomio 1, 1. 6-18** — *Últimas palabras de Moisés en Moab*

Estas son las palabras que Moisés dijo a todo Israel, al otro lado del Jordán, en el desierto, en la Arabá, frente a Suf, entre Farán y Tofel, Labán, Jaserot y Dizahab:

«El Señor nuestro Dios nos dijo en el Horeb: “Ya habéis pasado bastante tiempo en esta montaña. Poneos en marcha y dirigíos a la montaña de los amorreos y a todos los pueblos vecinos de la Arabá, a la montaña, a la Sefelá, al Negueb y a la costa —el territorio cananeo— al Líbano y hasta el Río Grande, el Éufrates. Mirad: yo os entrego esa tierra; id y tomad posesión de la tierra que el Señor juró dar a vuestros padres, Abrahán, Isaac y Jacob, y a sus descendientes”.

Entonces yo os dije: “Yo solo no puedo cargar con vosotros. El Señor, vuestro Dios, os ha multiplicado, y hoy sois tan numerosos como las estrellas del cielo. Que el Señor, Dios de vuestros antepasados, os haga crecer mil veces más y os bendiga, como os prometió. Pero ¿cómo voy a soportar yo solo vuestras cargas, vuestros asuntos y vuestros pleitos? Elegid entre vuestras tribus hombres sabios, prudentes y expertos, y yo los nombraré jefes vuestros”. Y me contestasteis: “Está bien lo que nos propones”.

Entonces tomé de los jefes de vuestras tribus, hombres sabios y expertos, y los constituí jefes vuestros: jefes de mil, de cien, de cincuenta y de diez, y oficiales para vuestras tribus. Y di esta orden a vuestros jueces: “Escuchad a vuestros hermanos y juzgad con justicia las causas que surjan entre vuestros hermanos o con emigrantes. No seáis parciales en la sentencia, oíd por igual a pequeños y grandes; no os dejéis intimidar por nadie, que la sentencia es de Dios. Si una causa os resulta demasiado difícil, pasádmela, y yo la resolveré”. En aquella circunstancia os mandé todo lo que teníais que hacer.»

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
