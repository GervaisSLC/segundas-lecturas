# Tiempo Ordinario — año impar

[Volver al calendario](index.md) · [Guía para IAs](../llms.txt)

## Semana 1 del Tiempo Ordinario

- **Martes de la semana I del Tiempo Ordinario (semana 1)** — [El error es múltiple; la virtud, una](../r/c9144e902c.md) — San Juan Crisóstomo · Homilía 3, 1: PG 60, 411-412
- **Miércoles de la semana I del Tiempo Ordinario (semana 1)** — [Dios no es parcial con nadie](../r/49c7857711.md) — Orígenes · Lib. 2, 7: PG 14, 887-889
- **Jueves de la semana I del Tiempo Ordinario (semana 1)** — [Sé hombre sujeto a Cristo, súbdito de la sabiduría de Dios](../r/a354bce37b.md) — San Ambrosio de Milán · Comentario 16, sobre el salmo 36: PL 14, 973-974
- **Viernes de la semana I del Tiempo Ordinario (semana 1)** — [Esta carne que era sombra de muerte, comenzó a resplandecer gracias al Señor](../r/50e412b781.md) — San Ambrosio de Milán · Comentario 75-77 sobre el salmo 43: PL 14, 1125-1126
- **Sábado de la semana I del Tiempo Ordinario (semana 1)** — [Dios nos amonestó por medio de la ley, los profetas, el evangelio y los apóstoles](../r/6a4aa20a60.md) — San Ambrosio de Milán · Comentario 1, 14-15 sobre el Salmo 118: PL 15, 1270
- **En lugar del Domingo I del tiempo ordinario se tiene la fiesta del Bautismo del Señor.** — [Esta fe que profesan los romanos es la misma que se anuncia y crece en todo el mundo](../r/271e4463ea.md) — Orígenes · Lib. 1, 7-9: PG 14, 852-855

## Semana 2 del Tiempo Ordinario

- **Domingo de la semana II del Tiempo Ordinario (semana 2)** — [Abrahán creyó en lo que había de venir, nosotros creemos en lo que ya ha venido](../r/ec0db05da8.md) — Orígenes · Lib. 7: PG 14, 981-985
- **Martes de la semana II del Tiempo Ordinario (semana 2)** — [Asumió Cristo la obediencia para inoculárnosla a nosotros](../r/d224627c36.md) — San Ambrosio de Milán · Comentario 4-6 sobre el salmo 61: PL 14, 1224-1225
- **Miércoles de la semana II del Tiempo Ordinario (semana 2)** — [También vosotros habéis resucitado juntamente con él](../r/26b1ffd050.md) — Orígenes
- **Jueves de la semana II del Tiempo Ordinario (semana 2)** — [El medio que separa es el pecado, el mediador que reconcilia es el Señor Jesús](../r/5293bff5d8.md) — San Agustín de Hipona · Tratado 41, 4-5: CCL 36, 360
- **Viernes de la semana II del Tiempo Ordinario (semana 2)** — [¿Cómo pagaremos al Señor todo el bien que nos ha hecho?](../r/71be3b19dd.md) — San Basilio Magno · Regla 2, 2-4: PG 31, 914-915
- **Sábado de la semana II del Tiempo Ordinario (semana 2)** — [Del conocimiento de Jesucristo dimana la comprensión de toda la sagrada Escritura](../r/305dbf7e7f.md) — San Buenaventura · Prólogo: Opera omnia 5, 201-202
- **Del comentario de san Cirilo de Alejandría, obispo, sobre el evangelio de san Juan** — [Emigremos por la caridad, habitemos allá arriba.](../r/f512af401c.md) — San Agustín de Hipona · Tratado 33, 9: CCL 36, 305-306

## Semana 3 del Tiempo Ordinario

- **Domingo de la semana III del Tiempo Ordinario (semana 3)** — [Somos, no simplemente herederos, sino coherederos con Cristo](../r/dbe2649821.md) — San Juan Crisóstomo · Homilía 14, 3: PG 60, 527-528
- **Domingo de la semana III del Tiempo Ordinario (semana 3)** — [Inclinaos bajo la poderosísima mano de Dios](../r/fe8a505dfd.md) — San Cesáreo de Arlés · Sermón 114, 1.4: CCL 104, 593-595
- **Domingo de la semana III del Tiempo Ordinario (semana 3)** — [Arrepiéntete y te salvaré](../r/eb29316629.md) — Tertuliano · 2, 3-7; 4,1-3: CCL 1, 322-323; 326
- **Domingo de la semana III del Tiempo Ordinario (semana 3)** — [Hoy, en esta reunión, habla el Señor](../r/eb688c45c6.md) — Orígenes · Hom. 32, 2-6: SC 87, 386-392
- **Lunes de la semana III del Tiempo Ordinario (semana 3)** — [Lo que parecía molesto, es lo que ha salvado a todo el mundo](../r/c0d814f10b.md) — San Juan Crisóstomo · Homilía 15, 2: PG 60, 542-543
- **Martes de la semana III del Tiempo Ordinario (semana 3)** — [Son peregrinos y extranjeros en la tierra quienes viven una vida celestial](../r/11658d785d.md) — San Cirilo de Alejandría · Lib. 10: PG 74, 386-387
- **Miércoles de la semana III del Tiempo Ordinario (semana 3)** — [La única descendencia de Abrahán: Cristo y la Iglesia](../r/73f7393eb9.md) — San Agustín de Hipona · Lib. 1, 27-28: CSEL 84, 92-94
- **Jueves de la semana III del Tiempo Ordinario (semana 3)** — [Predicamos a Cristo](../r/54f860650b.md) — San Ambrosio de Milán · Carta 29, 6-9: PL 16, 1100-1101
- **Viernes de la semana III del Tiempo Ordinario (semana 3)** — [Se nos llama cristianos o pueblo de Dios](../r/72d6678f8f.md) — San Cirilo de Alejandría · Lib. 4, or. 1: PG 70, 890-891
- **Sábado de la semana III del Tiempo Ordinario (semana 3)** — [Id y haced discípulos de todos los pueblos](../r/94532375d7.md) — Concilio Vaticano II · Núms. 4-5

## Semana 4 del Tiempo Ordinario

- **Domingo de la semana IV del Tiempo Ordinario (semana 4)** — [La sabiduría de Dios en la obra de la redención](../r/33ace1b87f.md) — San Cesáreo de Arlés · Sermón 11, 1. 4. 6: CCL 103, 54. 56-57
- **Domingo de la semana IV del Tiempo Ordinario (semana 4)** — [Cristo promulga el código de la vida celestial](../r/48f93d7eba.md) — San Hilario de Poitiers · Cap. 4, 1-3. 9: PL 9, 931-934
- **Lunes de la semana IV del Tiempo Ordinario (semana 4)** — [Todos los miembros de la Iglesia ofrecen la hostia viva](../r/97e05e1649.md) — Orígenes · Lib. 91: PG 14, 1204-1205. 1206-1207
- **Martes de la semana IV del Tiempo Ordinario (semana 4)** — [No quiero agradar a los hombres, sino a Dios](../r/aac0d1bb9b.md) — San Ignacio de Antioquía · 1, 1-2, 2: Funck 1, 213-215
- **Miércoles de la semana IV del Tiempo Ordinario (semana 4)** — [Ser cristiano no sólo de nombre, sino también de hecho](../r/0e47fbe144.md) — San Ignacio de Antioquía · 3-4: Funck 1, 215-219
- **Jueves de la semana IV del Tiempo Ordinario (semana 4)** — [Permitid que imite la pasión de mi Dios](../r/6375a11b8c.md) — San Ignacio de Antioquía · 5-6: Funck 1, 219-221
- **Viernes de la semana IV del Tiempo Ordinario (semana 4)** — [Os escribo en vida, pero deseando morir](../r/b460a51b8d.md) — San Ignacio de Antioquía · 7-8: Funck 1, 121-123
- **Sábado de la semana IV del Tiempo Ordinario (semana 4)** — [Os saluda mi espíritu y la caridad de las Iglesias](../r/ffed9a4f26.md) — San Ignacio de Antioquía · 9-10: Funck 1, 223

## Semana 5 del Tiempo Ordinario

- **Domingo de la semana V del Tiempo Ordinario (semana 5)** — [Piensa, oh hombre, de cuántos y cuáles dones hoy has sido enriquecido](../r/73cdd58cd1.md) — San Juan Crisóstomo · Homilía 3, sobre la limosna: PG 51, 263-265
- **Domingo de la semana V del Tiempo Ordinario (semana 5)** — [La lámpara no luce para sí, sino para los que viven en tinieblas](../r/96eb272374.md) — San Juan Crisóstomo · Homilía 12, 20-2: PG 51, 174
- **Domingo de la semana V del Tiempo Ordinario (semana 5)** — [Dios busca a los hombres, no las cosas de los hombres](../r/997afad38a.md) — San Pedro Crisólogo · Sermón 18 : PL 52, 246-249
- **Domingo de la semana V del Tiempo Ordinario (semana 5)** — [Cristo eligió para apóstoles a unos pescadores](../r/b671c49b45.md) — San Agustín de Hipona · Sermón 43, 5-6: PL 38, 256-257
- **Lunes de la semana V del Tiempo Ordinario (semana 5)** — [La sabiduría de la cruz del Señor](../r/4b5ddff48a.md) — Balduino de Canterbury · 9: PL 204, 501-502. 504
- **Martes de la semana V del Tiempo Ordinario (semana 5)** — [Enseñamos una sabiduría divina, misteriosa](../r/c45afd4117.md) — San Juan Crisóstomo · Homilía 7, 1-2: PG 61, 55-56
- **Miércoles de la semana V del Tiempo Ordinario (semana 5)** — [Adhirámonos a Cristo, pues si estamos separados, perecemos](../r/2627bffc61.md) — San Juan Crisóstomo · Homilía 8, 4: PG 61, 72-73
- **Jueves de la semana V del Tiempo Ordinario (semana 5)** — [Dad pruebas continuamente de que sois servidores de Dios](../r/a14ea2378f.md) — Balduino de Canterbury · PL 204, 413-414
- **Viernes de la semana V del Tiempo Ordinario (semana 5)** — [El progreso del dogma cristiano](../r/49144faee1.md) — San Vicente de Lerins · Capítulo 23: PL 50, 667-668
- **Sábado de la semana V del Tiempo Ordinario (semana 5)** — [La semilla de todos es Cristo](../r/953f5c18ae.md) — San Ambrosio de Milán · Comentario 36-39, sobre el salmo 43: CSEL 64, 288-290

## Semana 6 del Tiempo Ordinario

- **Domingo de la semana VI del Tiempo Ordinario (semana 6)** — [Cristo, primicias de nuestra resurrección](../r/f0844ab785.md) — San Ireneo de Lyon · Lib. 3, 19, 1. 3-20, 1: SC 34, 332. 336-338
- **Domingo de la semana VI del Tiempo Ordinario (semana 6)** — [Para que conservemos la inocencia en el corazón](../r/5afb02b4e2.md) — San Agustín de Hipona · Sermón sobre el discurso del Monte 1, 9, 21: CCL 35, 22-23
- **Lunes de la semana VI del Tiempo Ordinario (semana 6)** — [Debemos amar todos a la Iglesia como a una madre](../r/5ff347b3af.md) — San Agustín de Hipona · Sermón 37 sobre perícopas del Antiguo Testamento n. 2-3: CCL 41, 448-451
- **Martes de la semana VI del Tiempo Ordinario (semana 6)** — [El momento es apremiante](../r/3847ae03e0.md) — San León Magno · Tratado 90, 2-3: CCL 138A, 558-561
- **Miércoles de la semana VI del Tiempo Ordinario (semana 6)** — [Jesús mismo es el premio y la corona de los combatientes](../r/2f3da720ed.md) — San Nicolás Cabasilas · Tratado 6: PG 150, 678-679
- **Jueves de la semana VI del Tiempo Ordinario (semana 6)** — [Los apóstoles predican al mundo la alegría](../r/d95128de92.md) — San Cirilo de Alejandría · Lib. 4, or. 2: PG 70, 938-939
- **Viernes de la semana VI del Tiempo Ordinario (semana 6)** — [Sed siervos de los siervos](../r/e53469763a.md) — Balduino de Canterbury · Tratado para los sacerdotes, 12: PL 204, 533-536
- **Sábado de la semana VI del Tiempo Ordinario (semana 6)** — [Han variado los tiempos, no la fe](../r/cf0ba170ae.md) — San Agustín de Hipona · Tratado 45, 9: CCL 36, 392-393

## Semana 7 del Tiempo Ordinario

- **Domingo de la semana VII del Tiempo Ordinario (semana 7)** — [Qué significa comer la cena del Señor](../r/9b6dd5b7f5.md) — San Juan Crisóstomo · Homilía 11, 19: PG 51, 257-258
- **Domingo de la semana VII del Tiempo Ordinario (semana 7)** — [Que nuestras obras proclamen la generosidad de Dios](../r/12594d815b.md) — San Cipriano de Cartago · Trat. 12-13.15: CSEL 3, 427-430
- **Domingo de la semana VII del Tiempo Ordinario (semana 7)** — [Todas estas cosas las realizan las manos consagradas de los sacerdotes](../r/bf3186e110.md) — San Juan Crisóstomo · Lib 3, 3-6: PG 48, 643-644
- **Domingo de la semana VII del Tiempo Ordinario (semana 7)** — [Tu bienhechor te quiere espléndido](../r/fd2cdd2f44.md) — San León Magno · Tratado 17, 1-4: CCL 138, 68-71
- **Lunes de la semana VII del Tiempo Ordinario (semana 7)** — [Cristo es cabeza del hombre](../r/4123eda5b6.md) — San Agustín de Hipona · Comentario 19-20, sobre el Salmo 44: CCL 38, 507-508
- **Martes de la semana VII del Tiempo Ordinario (semana 7)** — [Somos el incienso de Cristo](../r/280c02e6ee.md) — San Agustín de Hipona · Comentario 2, sobre el salmo 92: CCL 39, 1292
- **Miércoles de la semana VII del Tiempo Ordinario (semana 7)** — [La fidelidad del Señor dura por siempre](../r/110fa39002.md) — Tomás de Kempis (Imitación de Cristo) · Lib. 3, cap. 14
- **Sábado de la semana VII del Tiempo Ordinario (semana 7)** — [Cantar salmos con el espíritu, pero cantarlos también con la mente](../r/60e2a904e2.md) — San Ambrosio de Milán · Salmo 1, 9-12: CSEL 64, 7. 9-10

## Semana 8 del Tiempo Ordinario

- **Domingo de la semana VIII del Tiempo Ordinario (semana 8)** — [Los misterios, tan pletóricos de gracia de salvación que celebramos en cada reunión, reciben el nombre de Eucaristía](../r/d6488f9494.md) — San Juan Crisóstomo · Homilía 3-4: PG 57, 331
- **Domingo de la semana VIII del Tiempo Ordinario (semana 8)** — [Sobre todo buscad el reino de Dios y su justicia](../r/44dce7017a.md) — San Cirilo de Alejandría · Hom. 62. Edit R.R. Tonneau: CSCO t. 70, 160-164
- **Domingo de la semana VIII del Tiempo Ordinario (semana 8)** — [Trayéndose a sí mismo, Cristo nos trajo toda novedad](../r/369a33f64a.md) — San Ireneo de Lyon · Lib 4, 34, 1.2.3: SC 100, 846-848; 850-854
- **Domingo de la semana VIII del Tiempo Ordinario (semana 8)** — [Los discípulos llamados a ser los iniciadores y maestros del mundo entero](../r/c14c90a2fa.md) — San Cirilo de Alejandría · Cap 6: PG 72, 602-603
- **Lunes de la semana VIII del Tiempo Ordinario (semana 8)** — [Qué significa resucitar con Cristo](../r/a7407ce584.md) — Orígenes · Lib. 5, 8: PG 14, 1041-1042
- **Martes de la semana VIII del Tiempo Ordinario (semana 8)** — [Como Adán es la primicia de la muerte, así Cristo es la primicia de la resurrección](../r/956cb4a7fc.md) — San Ambrosio de Milán · Lib. 2, 89-93: CSEL 73, 298-300
- **Miércoles de la semana VIII del Tiempo Ordinario (semana 8)** — [La Iglesia o convocación del pueblo de Dios](../r/d9e6653345.md) — San Cirilo de Jerusalén · Catequesis 18, 23 25: PG 33,1043-1047
- **Jueves de la semana VIII del Tiempo Ordinario (semana 8)** — [La Iglesia es la esposa de Cristo](../r/f37a58b599.md) — San Cirilo de Jerusalén · Catequesis 18, 26-29: PG 33,1047-1050
- **Viernes de la semana VIII del Tiempo Ordinario (semana 8)** — [La cruz de Cristo, remedio, ejemplo y misterio](../r/714af941f8.md) — Gualterio de San Víctor · Sermón 3, 2.3.4: CCL CM 30, 250.251.252
- **Sábado de la semana VIII del Tiempo Ordinario (semana 8)** — [Necesidad de la penitencia cotidiana](../r/4c89525d86.md) — San Agustín de Hipona · Carta 265, 7-8: CSEL 57, 645-646

## Semana 9 del Tiempo Ordinario

- **Domingo de la semana IX del Tiempo Ordinario (semana 9)** — [Me ofrezco como víctima de expiación](../r/986002afe9.md) — San Ignacio de Antioquía · Carta 6-8: Funck 1, 251
- **Domingo de la semana IX del Tiempo Ordinario (semana 9)** — [Fundemos en Cristo nuestra fe](../r/5abe0bb926.md) — Sin identificar · Hom 21: PLS 3, 854-855
- **Domingo de la semana IX del Tiempo Ordinario (semana 9)** — [Nuestro sábado es el gozo en el sosiego de nuestra esperanza](../r/05a0e26e98.md) — San Agustín de Hipona · Comentario 1-2 sobre el Salmo 91: CCL 39, 1278-1280
- **Domingo de la semana IX del Tiempo Ordinario (semana 9)** — [La humilde fe del centurión](../r/d54992b215.md) — San Agustín de Hipona · Sermón 62, 1.3-4: PL 38, 414-416
- **Lunes de la semana IX del Tiempo Ordinario (semana 9)** — [La plenitud del amor](../r/24728f67a7.md) — San Agustín de Hipona · Tratado 84, 1-2: CCL 36, 536-538
- **Martes de la semana IX del Tiempo Ordinario (semana 9)** — [La caridad trabaja en el mundo, descansa en Dios](../r/04c3565c0a.md) — San Fulgencio de Ruspe · Sermón 5, 5-6: CCL 91A, 921-923
- **Miércoles de la semana IX del Tiempo Ordinario (semana 9)** — [Dios mismo será su más preciado galardón, él que es la encarnación del precepto](../r/3b303920c9.md) — San León Magno · Sermón 16, 1-2: CCL 138, 61-62
- **Jueves de la semana IX del Tiempo Ordinario (semana 9)** — [La preeminencia de la caridad](../r/07b20b4aa7.md) — Isaac de Stella · Sermón 31: PL 194, 1292-1293
- **Viernes de la semana IX del Tiempo Ordinario (semana 9)** — [Es cristiano el que en todo imita a Cristo](../r/d738f99d0e.md) — San Cipriano · PLS 1, 51-52
- **Sábado de la semana IX del Tiempo Ordinario (semana 9)** — [El perdón de los pecados](../r/dadcef5dbc.md) — Orígenes · Homilía 2, 4: PG 12, 417-419

## Semana 10 del Tiempo Ordinario

- **Domingo de la semana X del Tiempo Ordinario (semana 10)** — [Liberados de una servidumbre espiritual](../r/895f798eae.md) — San Cirilo de Alejandría · Lib. 4, orat. 1: PG 70, 859-862
- **Domingo de la semana X del Tiempo Ordinario (semana 10)** — [He venido a llamar a los pecadores a que se conviertan](../r/5b9d807bc8.md) — San Agustín de Hipona · 1,7: CCL, 39, 733-734
- **Domingo de la semana X del Tiempo Ordinario (semana 10)** — [La penitencia obtiene el perdón en esta vida, valedero para la futura](../r/7d1afd160f.md) — San Agustín de Hipona · Sermón 71,1.13.14.19.20: PL 38, 445.451-452.454-456
- **Domingo de la semana X del Tiempo Ordinario (semana 10)** — [La Madre Iglesia se regocija por los hombres que cada día resucitan espiritualmente](../r/afd3c7afa4.md) — San Agustín de Hipona · Sermón 98, 1-3: PL 38, 591-592
- **Lunes de la semana X del Tiempo Ordinario (semana 10)** — [Paraos en el camino del Señor](../r/25374fe54b.md) — San Hilario de Poitiers · Tratado sobre el Salmo 127, 2-3. 6: CSEL 22, 629-632
- **Martes de la semana X del Tiempo Ordinario (semana 10)** — [No nos pertenecemos: somos de quien nos compró y salvó](../r/8e555ed88a.md) — San Cirilo de Alejandría · Lib. 4, or. 2: PG 70, 967-970
- **Miércoles de la semana X del Tiempo Ordinario (semana 10)** — [El paso del Jordán](../r/d9f05c795d.md) — Orígenes · Homilía 4, 11: PG 12, 842-843
- **Jueves de la semana X del Tiempo Ordinario (semana 10)** — [La conquista de Jericó](../r/8a95135e92.md) — Orígenes · Homilía 6, 4: PG 12, 855-856
- **Viernes de la semana X del Tiempo Ordinario (semana 10)** — [Dulzura del libro de los salmos](../r/1e92ea8fb1.md) — San Ambrosio de Milán · Comentario al Salmo 1, 4. 7-8: CSEL 64, 4-7
- **Sábado de la semana X del Tiempo Ordinario (semana 10)** — [Estudiad las Escrituras, pues ellas están dando testimonio de mí](../r/0360ee18db.md) — San Ambrosio de Milán · Comentario sobre el Salmo 1, 33: CSEL 64, 28-30

## Semana 11 del Tiempo Ordinario

- **Domingo de la semana XI del Tiempo Ordinario (semana 11)** — [La Iglesia, comunión de los santos](../r/3c7d58442c.md) — San Nicetas de Remesiana · Núm. 8. 10. 11. 14: PL 52, 870-874
- **Domingo de la semana XI del Tiempo Ordinario (semana 11)** — [Así se alegran lo mismo el sembrador y el segador](../r/4b78f47a8f.md) — San Agustín de Hipona · Tratado 15, 32: CCL 36, 163-164
- **Domingo de la semana XI del Tiempo Ordinario (semana 11)** — [Cristo es el grano que ha disipado las tinieblas y ha renovado la Iglesia](../r/69e8e87870.md) — San Juan Crisóstomo · Homilía 7 [atribuida] : PG 64, 21-26
- **Domingo de la semana XI del Tiempo Ordinario (semana 11)** — [Dios no nos pide otra cosa que la conversión](../r/322d41302c.md) — Sin identificar · PG 61, 745-751
- **Lunes de la semana XI del Tiempo Ordinario (semana 11)** — [El que nos dio la vida nos enseñó también a orar](../r/38e10541fe.md) — San Cipriano de Cartago · Caps. 1-3: CSEL 3, 267-268
- **Martes de la semana XI del Tiempo Ordinario (semana 11)** — [La oración ha de salir de un corazón humilde](../r/666e7df380.md) — San Cipriano de Cartago · Tratado 4-6: CSEL 3, 268-270
- **Jueves de la semana XI del Tiempo Ordinario (semana 11)** — [Santificado sea tu nombre](../r/0f5b8c96e4.md) — San Cipriano de Cartago · Tratado 11-12: CSEL 3, 274-275
- **Viernes de la semana XI del Tiempo Ordinario (semana 11)** — [Venga a nosotros tu reino, hágase tu voluntad](../r/8b192cfbaf.md) — San Cipriano de Cartago · Tratado 13-14: CSEL 3, 275-277
- **Sábado de la semana XI del Tiempo Ordinario (semana 11)** — [No anteponer nada a Cristo](../r/e416f734b4.md) — San Cipriano de Cartago · Tratado 15-16: CSEL 3, 277-279
- **Alma mía, camina con brío.** — [Nuestra oración es pública y común](../r/2094475dc3.md) — San Cipriano de Cartago · Tratado 8-9: CSEL 3, 271-272

## Semana 12 del Tiempo Ordinario

- **Domingo de la semana XII del Tiempo Ordinario (semana 12)** — [Pedimos de modo que nuestra oración recabe la salvación de todos](../r/ed27a80d31.md) — San Cipriano de Cartago · Tratado 17-18: CSEL 3, 279-281
- **Domingo de la semana XII del Tiempo Ordinario (semana 12)** — [El Salvador ha resucitado; Cristo vive; Cristo es la vida misma](../r/19fcd0f9a3.md) — San Atanasio de Alejandría · 29-30: PG 25, 146-147
- **Domingo de la semana XII del Tiempo Ordinario (semana 12)** — [A una orden de Cristo se produce la calma](../r/84e338d484.md) — San Agustín de Hipona · Sermón 43, 1-3: PL 38, 424-425
- **Domingo de la semana XII del Tiempo Ordinario (semana 12)** — [Pedro hace una precisa profesión de fe en Cristo](../r/9e6b5865fb.md) — San Cirilo de Alejandría · Homilía 39 : Edit R.M. Tonneau, CSCO Script Syri 70,110-115
- **Lunes de la semana XII del Tiempo Ordinario (semana 12)** — [No os agobiéis por el mañana](../r/ba194f7b71.md) — San Cipriano de Cartago · Tratado 19-20: CSEL 3, 281-282
- **Martes de la semana XII del Tiempo Ordinario (semana 12)** — [Después del alimento, pedimos el perdón de los pecados](../r/3304215b4f.md) — San Cipriano de Cartago · Tratado 22-23: CSEL 3, 283-285
- **Miércoles de la semana XII del Tiempo Ordinario (semana 12)** — [Que los que somos hijos de Dios permanezcamos en la paz de Dios](../r/3c35940af5.md) — San Cipriano de Cartago · Tratado 24-25: CSEL 3, 285-286
- **Jueves de la semana XII del Tiempo Ordinario (semana 12)** — [Velad y orad](../r/0e919e3a25.md) — San Cipriano de Cartago · Tratado 26-27: CSEL 3, 286-287
- **Viernes de la semana XII del Tiempo Ordinario (semana 12)** — [Hay que orar no sólo con palabras, sino también con los hechos](../r/b5c94abe00.md) — San Cipriano de Cartago · Tratado 28-29: CSEL 3, 287-288
- **Sábado de la semana XII del Tiempo Ordinario (semana 12)** — [El Señor oraba por nuestros pecados](../r/d484a6587a.md) — San Cipriano de Cartago · Tratado 30-31: CSEL 3, 288-290

## Semana 13 del Tiempo Ordinario

- **Domingo de la semana XIII del Tiempo Ordinario (semana 13)** — [Buena es la oración con el ayuno y la limosna](../r/4d60a58aa9.md) — San Cipriano de Cartago · Tratado 32-33: CSEL 3, 290-292
- **Domingo de la semana XIII del Tiempo Ordinario (semana 13)** — [Si quieres seguir a Cristo, vuélvete a la cruz; soporta, aguanta, manténte firme](../r/4c4859e6de.md) — San Agustín de Hipona · Sermón 96, 1-4: PL 38, 584-586
- **Domingo de la semana XIII del Tiempo Ordinario (semana 13)** — [Realmente, para Dios la muerte es un sueño](../r/be5df8c8d9.md) — San Pedro Crisólogo · Sermón 34, 1.5: CCL 34,193.197-199
- **Lunes de la semana XIII del Tiempo Ordinario (semana 13)** — [Los cristianos han de adorar a Dios frecuentemente y siempre](../r/0a855058aa.md) — San Cipriano de Cartago · Tratado 34-35: CSEL 3, 292-293
- **Martes de la semana XIII del Tiempo Ordinario (semana 13)** — [Los que estamos siempre en Cristo, no cesemos de orar ni siquiera de noche](../r/acf0e00bc7.md) — San Cipriano de Cartago · Tratado 36: CSEL 3, 293-294
- **Miércoles de la semana XIII del Tiempo Ordinario (semana 13)** — [Cristo es Rey, Cristo es Sacerdote: alegrémonos en él](../r/5e97cedfc5.md) — San Agustín de Hipona · Comentario al Salmo 149,6: CCL 40, 2182-2183
- **Jueves de la semana XIII del Tiempo Ordinario (semana 13)** — [La carga del gobierno](../r/68bafd79a7.md) — San Gregorio Magno · Parte 1, cap. 3: PL 177, 16-17
- **Viernes de la semana XIII del Tiempo Ordinario (semana 13)** — [La salvación proviene de la misericordia de Dios](../r/0462812923.md) — San Cirilo de Jerusalén · Catequesis 2, 5-8: Edit Reisch 1, 445-449
- **Sábado de la semana XIII del Tiempo Ordinario (semana 13)** — [Cristo es rey y sacerdote eterno](../r/bb6ef23e3c.md) — Sin identificar · Tratado 39-40: CCL 69, 340-341

## Semana 14 del Tiempo Ordinario

- **Domingo de la semana XIV del Tiempo Ordinario (semana 14)** — [El aleluya pascual](../r/7d316b21f6.md) — San Agustín de Hipona · Salmo 148, 1-2: CCL 40, 2165-2166
- **Domingo de la semana XIV del Tiempo Ordinario (semana 14)** — [Imitemos al Señor](../r/b1a26e4086.md) — San Juan Crisóstomo · Homilía 1,5 sobre la cruz y el ladrón : PG 49, 405-408
- **Domingo de la semana XIV del Tiempo Ordinario (semana 14)** — [El Padre mismo me ha enviado](../r/22272b79e1.md) — San Agustín de Hipona · Tratado 31, 3-4: CCL 36, 294-295
- **Domingo de la semana XIV del Tiempo Ordinario (semana 14)** — [Envió Cristo a los segadores con la hoz del evangelio](../r/14e11815c2.md) — San Agustín de Hipona · Sermón 101 (1.2.3.11: PL 38, 605.606.607.610
- **Lunes de la semana XIV del Tiempo Ordinario (semana 14)** — [David fue figura de Cristo](../r/fc932760ff.md) — San Hipólito de Roma · Homilía 1, 1-4. 2 sobre David y Goliat: CSCO 264 [Scriptores Iberici t. 16] 1-3
- **Martes de la semana XIV del Tiempo Ordinario (semana 14)** — [La amistad verdadera es perfecta y constante](../r/014f6734cf.md) — San Elredo de Rievaulx · Lib. 3, 92. 93. 94. 96: CCL CM 1, 337-338
- **Miércoles de la semana XIV del Tiempo Ordinario (semana 14)** — [Dios es como una roca inaccesible](../r/102aa17cf4.md) — San Gregorio de Nisa · Homilía 6 sobre las bienaventuranzas : PG 44, 1263-1266
- **Jueves de la semana XIV del Tiempo Ordinario (semana 14)** — [La esperanza de ver a Dios](../r/ee579cdb9d.md) — San Gregorio de Nisa · Homilía 6 sobre las bienaventuranzas : PG 44, 1266-1267
- **Viernes de la semana XIV del Tiempo Ordinario (semana 14)** — [Dios puede ser hallado en el corazón del hombre](../r/44add5a207.md) — San Gregorio de Nisa · Homilía 6 sobre las bienaventuranzas: PG 44, 1270-1271
- **Sábado de la semana XIV del Tiempo Ordinario (semana 14)** — [Aplicaos, hermanos, a meditar las palabras de Dios](../r/f462a86078.md) — San Gregorio Magno · Lib. 2, homilía 3, 18. 19. 21: CCL 142, 250. 252. 253. 254

## Semana 15 del Tiempo Ordinario

- **Domingo de la semana XV del Tiempo Ordinario (semana 15)** — [El Señor es nuestro Dios, y nosotros su pueblo, el rebaño que él guía](../r/88a1259124.md) — San Agustín de Hipona · Sermón sobre las ovejas, 47, 1. 2. 3. 6: CCL 41, 572-573. 575-576
- **Domingo de la semana XV del Tiempo Ordinario (semana 15)** — [Sobre el servicio de la predicación](../r/6167b0216d.md) — San Gregorio Magno · Homilía 17, 5.6.7.8: PL 76, 1140-1142
- **Domingo de la semana XV del Tiempo Ordinario (semana 15)** — [Debemos atender a todos por igual](../r/e223ba2b3f.md) — San Juan Crisóstomo · Homilía 10, cap. 6, 4: PG 63, 88-89
- **Lunes de la semana XV del Tiempo Ordinario (semana 15)** — [Si buscare agradar a los hombres no sería siervo de Cristo](../r/3b1bd7b318.md) — San Agustín de Hipona · Sermón sobre las ovejas, 47, 12-14: CCL 41, 582-584
- **Martes de la semana XV del Tiempo Ordinario (semana 15)** — [Venga a nosotros tu reino](../r/986f957467.md) — Santa Teresa de Jesús · Cap 51: BAC 120, 221-224
- **Miércoles de la semana XV del Tiempo Ordinario (semana 15)** — [Pasaré al lugar del tabernáculo admirable](../r/436f6e04e0.md) — San Jerónimo · Homilía a los recién bautizados, sobre el salmo 41: CCL 78, 542-544
- **Jueves de la semana XV del Tiempo Ordinario (semana 15)** — [Jesucristo es del linaje de David según la carne](../r/dc6dfeea18.md) — San Agustín de Hipona · Cap. 15, 30-31: PL 44, 981-983
- **Viernes de la semana XV del Tiempo Ordinario (semana 15)** — [Reconoce el mal que has hecho, ahora que es el tiempo propicio](../r/e98c202850.md) — San Cirilo de Jerusalén · Catequesis 1, 2-3. 5-6: PG 33, 371. 375-378
- **Sábado de la semana XV del Tiempo Ordinario (semana 15)** — [Mi sacrificio es un espíritu quebrantado](../r/62960979d6.md) — San Agustín de Hipona · Sermón 19, 2-3: CCL 41, 252-254

## Semana 16 del Tiempo Ordinario

- **Domingo de la semana XVI del Tiempo Ordinario (semana 16)** — [Llora Cristo por la sinagoga, a la que tanto amaba](../r/6d03db7ff2.md) — San Lorenzo de Brindis · Homilía en el domingo noveno de Pentecostés 2, 6-7: Opera omnia, t. 8, 514-517
- **Domingo de la semana XVI del Tiempo Ordinario (semana 16)** — [Lo mismo que la levadura hace fermentar toda la masa, así vosotros convertiréis el mundo entero](../r/332b82a482.md) — San Juan Crisóstomo · Homilía 46, 2-3: PG 58, 478-480
- **Domingo de la semana XVI del Tiempo Ordinario (semana 16)** — [Yo soy el que cura a las ovejas enfermas](../r/ee25c94dcc.md) — San Basilio Magno · Homilía 26 (2: PG 85, 306-307
- **Domingo de la semana XVI del Tiempo Ordinario (semana 16)** — [Sobre la vida activa y la vida contemplativa](../r/58095cee69.md) — San Gregorio Magno · Lib 2, Hom 2, 8-9: CCL 142, 230-231
- **Martes de la semana XVI del Tiempo Ordinario (semana 16)** — [Acerca de la eucaristía](../r/db7079df63.md) — Didaché · Caps. 9, 1-10, 6; 14, 1-3: Funk 2, 19-22. 26
- **Miércoles de la semana XVI del Tiempo Ordinario (semana 16)** — [El templo de Dios es santo: ese templo sois vosotros](../r/d33503e222.md) — San Ambrosio de Milán · Comentario sobre el salmo 118, n. 12, 13. 14: CSEL 62, 258-259
- **Viernes de la semana XVI del Tiempo Ordinario (semana 16)** — [El rey pacífico gobierna a su pueblo con justicia](../r/9f55629b0e.md) — San Gregorio de Nisa · Homilía 7: PG 44, 907-910
- **Sábado de la semana XVI del Tiempo Ordinario (semana 16)** — [Alegrémonos, pues hemos merecido ser templo de Dios](../r/36229c5e51.md) — San Cesáreo de Arlés · Sermón 229, 2: CCL 104, 905-907
- **Ciclo B Mc 6, 30-34** — [Los de fuera, lo quieran o no, son hermanos nuestros](../r/fed425a575.md) — San Agustín de Hipona · Comentario sobre el salmo 32, n. 29: CCL 38, 272-273
- **Semana XVI del Tiempo Ordinario** — [Por la unción recibida, los cristianos están consagrados de por vida a la cruz de Cristo](../r/49deef3d29.md) — Actas y escritos anónimos · Homilía 17, 1-4: PG 34, 623-626

## Semana 17 del Tiempo Ordinario

- **Domingo de la semana XVII del Tiempo Ordinario (semana 17)** — [Preciosa la sabiduría que nos da a conocer a Dios](../r/8ea4f062f5.md) — San Bernardo de Claraval · Sermón 7, en la Epifanía: Opera omnia, ed. Cister 1970, 671, 26-27
- **Domingo de la semana XVII del Tiempo Ordinario (semana 17)** — [Las perlas finas conducen a la perla de gran valor](../r/63588c45c3.md) — Orígenes · Lib. 10, 9-10: SC 162, 173-177
- **Domingo de la semana XVII del Tiempo Ordinario (semana 17)** — [Se nos invita a la fe, que es el trabajo de Dios](../r/ce3b699180.md) — Balduino de Canterbury · Parte 2,3: SC 93, 248-252
- **Domingo de la semana XVII del Tiempo Ordinario (semana 17)** — [Éstos son los bienes que principalmente hemos de pedir](../r/f06c6b1ae4.md) — San Beda el Venerable · Homilía 14 (CCL 122, 272-273.277-279
- **Lunes de la semana XVII del Tiempo Ordinario (semana 17)** — [Cristo es la sabiduría](../r/1125d61f8f.md) — Pedro de Blois · Sermón 53: PL 207, 715-716
- **Martes de la semana XVII del Tiempo Ordinario (semana 17)** — [Convertíos, porque está cerca el reino de los cielos](../r/a1796f64d3.md) — San Pedro Crisólogo · Sermón 167: PL 52, 637-638
- **Miércoles de la semana XVII del Tiempo Ordinario (semana 17)** — [Cristo murió por todos](../r/fda6608720.md) — San Cirilo de Alejandría · Lib. 5, t. 1: PG 70, 1190-1191
- **Jueves de la semana XVII del Tiempo Ordinario (semana 17)** — [Institución del culto en espíritu y en verdad, por obra de los oráculos evangélicos](../r/cbcd2b67d1.md) — San Cirilo de Alejandría · Lib. 5, t. 2: PG 70, 1223-1226
- **Viernes de la semana XVII del Tiempo Ordinario (semana 17)** — [Catequesis sobre los ritos que preceden al bautismo](../r/04fbacfbde.md) — San Ambrosio de Milán · Tratado 1-7: SC 25bis, 156-158
- **Sábado de la semana XVII del Tiempo Ordinario (semana 17)** — [Renacemos del agua y del Espíritu Santo](../r/e5042d6cf5.md) — San Ambrosio de Milán · Tratado 8-11: SC 25bis, 158-160

## Semana 18 del Tiempo Ordinario

- **Domingo de la semana XVIII del Tiempo Ordinario (semana 18)** — [Todo les sucedía como un ejemplo](../r/8729068593.md) — San Ambrosio de Milán · Tratado 12-16. 19: SC 25bis, 162-164
- **Domingo de la semana XVIII del Tiempo Ordinario (semana 18)** — [Cristo, en su dignidad, es siempre deseable](../r/3a5a65ad35.md) — Balduino de Canterbury · Parte 2,3: SC 93, 252-254
- **Domingo de la semana XVIII del Tiempo Ordinario (semana 18)** — [Cristo bebió mis amarguras para darme la suavidad de su gracia](../r/82b165e619.md) — San Ambrosio de Milán · Sermón 18, 26-29: PL 15, 1461-1463
- **Domingo de la semana XVIII del Tiempo Ordinario (semana 18)** — [Vayamos de una vez en pos del Verbo, busquemos aquel descanso](../r/40d24d66d4.md) — San Gregorio Nacianceno · Sermón 14, 20-22 sobre el amor a los pobres: PG 35, 882-886
- **Lunes de la semana XVIII del Tiempo Ordinario (semana 18)** — [El agua no purifica sin la acción del Espíritu Santo](../r/3b061a82d0.md) — San Ambrosio de Milán · Tratado 19-21. 24. 26-38: SC 25bis, 164-170
- **Martes de la semana XVIII del Tiempo Ordinario (semana 18)** — [Catequesis de los ritos que siguen al bautismo](../r/248ffc6293.md) — San Ambrosio de Milán · Tratado 29-30. 34-35. 37. 42: SC 25bis, 172-178
- **Miércoles de la semana XVIII del Tiempo Ordinario (semana 18)** — [Instrucción a los recién bautizados sobre la eucaristía](../r/aad5c1eb73.md) — San Ambrosio de Milán · Tratado 43. 47-49: SC 25bis, 178-180. 182
- **Jueves de la semana XVIII del Tiempo Ordinario (semana 18)** — [Este sacramento que recibes se realiza por la palabra de Cristo](../r/831f9b4b3b.md) — San Ambrosio de Milán · Tratado 52-54. 58: SC 25bis, 186-188. 190
- **Viernes de la semana XVIII del Tiempo Ordinario (semana 18)** — [Considerad, hermanos, vuestra vocación](../r/41bb11475e.md) — San Elredo de Rievaulx · Edit C.H. Talbot, SSOC vol 1, 102-103
- **Sábado de la semana XVIII del Tiempo Ordinario (semana 18)** — [Irá delante del Señor con el espíritu y poder de Elías](../r/fa78490b30.md) — San Elredo de Rievaulx · Sermón «Quomodo referatur», Edit C.H. Talbot, SSOC vol 1, 120-121

## Semana 19 del Tiempo Ordinario

- **Domingo de la semana XIX del Tiempo Ordinario (semana 19)** — [La economía del madero nos ha manifestado al Verbo, que estaba oculto a nuestros ojos](../r/62832f273e.md) — San Ireneo de Lyon · Lib. 5, 17, 3-4: SC 153, 230-234
- **Domingo de la semana XIX del Tiempo Ordinario (semana 19)** — [¡Señor, sálvame, que me hundo!](../r/02dc062052.md) — San Agustín de Hipona · Sermón 76, 1. 4.-6. 8-9: PL 38, 479-483
- **Domingo de la semana XIX del Tiempo Ordinario (semana 19)** — [Y el pan que yo daré es mi carne, para la vida del mundo](../r/8d3ac54668.md) — Ruperto de Deutz · Lib 6, 51-52: CCL CM 9, 356-357
- **Domingo de la semana XIX del Tiempo Ordinario (semana 19)** — [Que la Palabra de Dios sea lámpara para mis pasos](../r/5f72dc08c5.md) — San Ambrosio de Milán · Sermón 14, 11-13: PL 15, 1394-1395
- **Lunes de la semana XIX del Tiempo Ordinario (semana 19)** — [Hemos de bañarnos en la misma fuente en que Cristo se bañó para llegar a ser lo que Cristo es](../r/1659ce947a.md) — San Máximo de Turín · Sermón 13, 1-4: CCL 23, 51-52
- **Martes de la semana XIX del Tiempo Ordinario (semana 19)** — [Purificados nuestros sentidos de toda levadura de maldad, con mucho gusto habitará en nosotros nuestro Señor Jesucristo](../r/7ab2ace5dc.md) — San Paulino de Nola · Carta 32, 23-24. 25: CSEL 29, 297-300
- **Miércoles de la semana XIX del Tiempo Ordinario (semana 19)** — [Adorna tu morada, Sión, porque el Señor te prefiere a ti](../r/11dfef9993.md) — San Bernardo de Claraval · Sermón 2, 1. 2. 3 en la dedicación de la Iglesia: Opera omnia, Edic. Cister. t. 5, 375-377
- **Jueves de la semana XIX del Tiempo Ordinario (semana 19)** — [El que se gloríe, que se gloríe en el Señor](../r/36c5b91118.md) — San Basilio Magno · Homilía sobre la humildad 20, 3: PG 31, 530-531
- **Viernes de la semana XIX del Tiempo Ordinario (semana 19)** — [He venido para que tengan vida](../r/a3d804ce2b.md) — San Nicolás Cabasilas · Lib. 1: PG 150, 510-511
- **Sábado de la semana XIX del Tiempo Ordinario (semana 19)** — [Surgió un hombre enviado por Dios](../r/3fed855ce6.md) — San Elredo de Rievaulx · Sermón sobre la interrelación Elías y Juan Bautista, Edit. C.H. Talbot, SSOC vol 1, p. 118
- **SEMANA XX del tiempo ordinario** — [Gran cosa es que se nos hayan perdonado los pecados; pero lo es aún mayor que este perdón se nos haya otorgado por la sangre del Señor](../r/c84f825e00.md) — San Juan Crisóstomo · Homilía 1, 3: PG 62, 13-14
- **SEMANA XX del tiempo ordinario** — [El Señor otorgó a la mujer el fruto de su fe](../r/a991414d70.md) — San Atanasio de Alejandría · Carta Pascual 7, 6-8: PG 26, 1393-1394
- **SEMANA XX del tiempo ordinario** — [Nuestro Señor Jesucristo nos alimenta para la vida eterna](../r/4b38ea0581.md) — San Cirilo de Alejandría · Lib 2, 3: PG 69, 455-459
- **SEMANA XX del tiempo ordinario** — [He venido a prender fuego en el mundo](../r/d72fd096ca.md) — Pedro de Blois · Sermón 25 : PL 207, 635-637

## Semana 20 del Tiempo Ordinario

- **Lunes de la semana XX del Tiempo Ordinario (semana 20)** — [Tenemos a Cristo que es nuestra paz y nuestra luz](../r/ff2e247cbc.md) — San Gregorio de Nisa · PG 46, 259-262
- **Martes de la semana XX del Tiempo Ordinario (semana 20)** — [La gracia del perdón es una e idéntica para todos](../r/d3eeb474de.md) — Ruperto de Deutz · Lib 2: CCL CM 9, 60-62
- **Miércoles de la semana XX del Tiempo Ordinario (semana 20)** — [Por la participación en la mesa eucarística, Cristo en nosotros y nosotros en Cristo formamos una sola realidad](../r/65a1d59c60.md) — San Cirilo de Alejandría · Lib. 10: PG 74, 342
- **Jueves de la semana XX del Tiempo Ordinario (semana 20)** — [El misterio de la Iglesia](../r/262cc27437.md) — San Gregorio de Nisa · Hom. 8 : PG 44, 947-950
- **Viernes de la semana XX del Tiempo Ordinario (semana 20)** — [En su último discurso, Cristo consolidó más firmemente el amor en el corazón de sus discípulos con la palabra y el ejemplo](../r/1b03f878b0.md) — San Martín de León · Sermón 21 en la Cena del Señor : PL 208, 839-840
- **Sábado de la semana XX del Tiempo Ordinario (semana 20)** — [¡Fijaos qué esperanza tan cierta de salvación se ha dado a los creyentes!](../r/b267d1cb80.md) — San Pascasio Radberto · Lib. 4, cap. 6: PL 120, 280-281

## Semana 21 del Tiempo Ordinario

- **Domingo de la semana XXI del Tiempo Ordinario (semana 21)** — [El bautismo del Señor es nuestra sepultura](../r/e26191fd7e.md) — San Máximo de Turín · Sermón 59, 2-4: CCL 23, 236-238
- **Domingo de la semana XXI del Tiempo Ordinario (semana 21)** — [Cristo entregó las llaves a aquel que extendió la Iglesia por todo el orbe de la tierra](../r/f7ec2e21d8.md) — San Juan Crisóstomo · Homilía 54, 1-2: PG 58, 533-536
- **Domingo de la semana XXI del Tiempo Ordinario (semana 21)** — [Sobre la fe de los apóstoles](../r/cd6c6d0a05.md) — Balduino de Canterbury · Parte 2, 3: SC 93, 296-300
- **Domingo de la semana XXI del Tiempo Ordinario (semana 21)** — [Da amor y recibe el reino; ama y toma](../r/35f4c22795.md) — San Anselmo de Canterbury · Carta 112 : Opera omnia, t. 3, 1946, 244-246
- **Lunes de la semana XXI del Tiempo Ordinario (semana 21)** — [Ésta es la escuela de Cristo: la caridad](../r/5640d397e2.md) — Beato Ogerio de Lucedio · Sermón 5: PL 184, 901-902
- **Martes de la semana XXI del Tiempo Ordinario (semana 21)** — [En la salmodia, todos deben salmodiar](../r/27587121a3.md) — San Nicetas de Remesiana · 413-14: PLS 3, 196-198
- **Miércoles de la semana XXI del Tiempo Ordinario (semana 21)** — [Es éste un gran misterio](../r/774d60a6f8.md) — San Juan Crisóstomo · Homilía 3, sobre cómo han de ser los desposados : PG 51, 229-230
- **Jueves de la semana XXI del Tiempo Ordinario (semana 21)** — [La esperanza de los premios celestiales](../r/926ac40229.md) — San Gregorio Magno · Lib. 2, Homilía 1, 7: CCL 142, 213- 214
- **Viernes de la semana XXI del Tiempo Ordinario (semana 21)** — [Revistámonos con las armas de la paz](../r/fcb1f322ec.md) — Clemente de Alejandría · Exhortación a los paganos, Cap. 11; PG 8, 235-238
- **Sábado de la semana XXI del Tiempo Ordinario (semana 21)** — [Reformemos nuestras costumbres en Cristo, por el Espíritu Santo](../r/2c20a66f69.md) — San Paciano de Barcelona · Sobre el bautismo, Sermón 5-6: PL 13, 1092-1093

## Semana 22 del Tiempo Ordinario

- **Domingo de la semana XXII del Tiempo Ordinario (semana 22)** — [¿Qué Dios como tú, que perdonas el pecado?](../r/a461f30df9.md) — San Paciano de Barcelona · Sermón sobre el bautismo, 6-7: PL 13, 1093-1094
- **Domingo de la semana XXII del Tiempo Ordinario (semana 22)** — [La Iglesia sigue a Cristo por doquier](../r/b9c5d88962.md) — San Cirilo de Alejandría · Lib 5: PG 68, 391-395
- **Domingo de la semana XXII del Tiempo Ordinario (semana 22)** — [Tanto en la ley como en el evangelio, el primero y principal mandamiento es amar a Dios](../r/23eb3ac28c.md) — San Ireneo de Lyon · Lib 4, 12,1—13,3: SC 100, 508-516
- **Domingo de la semana XXII del Tiempo Ordinario (semana 22)** — [Sobre la verdadera humildad](../r/bd20d73331.md) — San Elredo de Rievaulx · Edit C.H. Talbot, SSOC vol 1, 78-80
- **Lunes de la semana XXII del Tiempo Ordinario (semana 22)** — [La esperanza de la vida, principio y término de nuestra fe](../r/25b6a5afa4.md) — Carta de Bernabé · Caps. 1, 1-8; 2, 1-5: Funk 1, 3-7
- **Martes de la semana XXII del Tiempo Ordinario (semana 22)** — [La nueva ley de nuestro Señor](../r/030e029d3e.md) — Carta de Bernabé · Caps. 2, 6-10; 3, 1. 3, 4, 10-14: Funk 1, 7-9. 13
- **Miércoles de la semana XXII del Tiempo Ordinario (semana 22)** — [La segunda creación](../r/800e42d611.md) — Carta de Bernabé · Caps. 5, 1-8; 6, 11-16: Funk 1, 13-15. 19-21
- **Jueves de la semana XXII del Tiempo Ordinario (semana 22)** — [El camino de la luz](../r/d2a8a4e203.md) — Carta de Bernabé · Cap. 19, 1-3. 5-7. 8-12: Funk 1, 53-57
- **Viernes de la semana XXII del Tiempo Ordinario (semana 22)** — [Dios Padre flagela a la Iglesia para que crezca más vigorosa y fecunda](../r/3f5f9d4fa9.md) — Beato Ogerio de Lucedio · Serm. 10, 13-14: PL 184, 927-928

## Semana 23 del Tiempo Ordinario

- **Domingo de la semana XXIII del Tiempo Ordinario (semana 23)** — [Adorar a Dios mediante la verdadera santidad de las obras y del conocimiento](../r/d770b471d1.md) — Clemente de Alejandría · Lib. 6: PG 9, 295-298
- **Domingo de la semana XXIII del Tiempo Ordinario (semana 23)** — [El número prescrito no limita, sino que dilata el perdón](../r/886620014a.md) — San Pedro Crisólogo · Sermón 139 : PL 52, 573-575
- **Domingo de la semana XXIII del Tiempo Ordinario (semana 23)** — [Todo lo ha hecho bien](../r/0a55e767ce.md) — San Lorenzo de Brindis · Homilía 1 en el domingo XI de Pentecostés, 1.9.11.12: Opera omnia, t. 8, 124.134.136-138
- **Domingo de la semana XXIII del Tiempo Ordinario (semana 23)** — [Sobre las tres renuncias](../r/6366588797.md) — Juan Casiano · Conf 3, cap 6-7: PL 564-567
- **Lunes de la semana XXIII del Tiempo Ordinario (semana 23)** — [Éstos son los pastos que dio Dios a los creyentes](../r/a34aa0b1e4.md) — San Juan Crisóstomo · Homilía 50: PLS 4, 825-826. 828-830
- **Martes de la semana XXIII del Tiempo Ordinario (semana 23)** — [Somos el pueblo de Dios](../r/9c470a3e48.md) — San Beda el Venerable · Homilía 1, 16: CCL 122, 117-118
- **Miércoles de la semana XXIII del Tiempo Ordinario (semana 23)** — [Es fuerte el amor como la muerte](../r/bc06846301.md) — Balduino de Canterbury · Tratado 10: PL 204, 513-514. 516
- **Jueves de la semana XXIII del Tiempo Ordinario (semana 23)** — [Me casaré contigo en matrimonio perpetuo](../r/d2a792832d.md) — San Juan de la Cruz · Canción 39, 4-7
- **Viernes de la semana XXIII del Tiempo Ordinario (semana 23)** — [Jesucristo es el mismo ayer y hoy y siempre](../r/97d65785e5.md) — Sin identificar · PLS 4, 34-35
- **Sábado de la semana XXIII del Tiempo Ordinario (semana 23)** — [Todas estas cosas tuvieron en Cristo su cumplimiento](../r/430ac70c53.md) — San Martín de León · Sermón 26, en la resurrección del Señor: PL 208, 938-939

## Semana 24 del Tiempo Ordinario

- **Domingo de la semana XXIV del Tiempo Ordinario (semana 24)** — [La salvación del mundo ha sido distribuida y ordenada en una escalonada serie de tiempos](../r/5a87b09956.md) — Balduino de Canterbury · Sobre el sacramento del altar, parte 2, 1: SC 93, 178-182
- **Domingo de la semana XXIV del Tiempo Ordinario (semana 24)** — [Perdónanos nuestras deudas, así como nosotros perdonamos a nuestros deudores](../r/a4550dd350.md) — San Agustín de Hipona · Sermón 83, 2-4: PL 38, 515-516
- **Domingo de la semana XXIV del Tiempo Ordinario (semana 24)** — [No es duro lo que manda aquel que ayuda a realizar lo que ordena](../r/cc26755d11.md) — San Cesáreo de Arlés · Sermón 159,1.4-6: CCL 104, 652-654
- **Domingo de la semana XXIV del Tiempo Ordinario (semana 24)** — [Cristo nos buscó en la tierra: busquémosle nosotros en el cielo](../r/b5869e43f5.md) — San Pedro Crisólogo · Sermón 168 :PL 52, 639-641
- **Lunes de la semana XXIV del Tiempo Ordinario (semana 24)** — [Dichoso el hombre que confía en Dios](../r/61b7f26154.md) — San Cirilo de Alejandría · Lib. 2, 5: PG 70, 502-503
- **Martes de la semana XXIV del Tiempo Ordinario (semana 24)** — [Haced resplandecer para vosotros la luz del conocimiento](../r/ac70f5c570.md) — San Ambrosio de Milán · Sermón 1, 2 sobre el Salmo 118: PL 15, 1199-1200
- **Miércoles de la semana XXIV del Tiempo Ordinario (semana 24)** — [Con lazos de amor](../r/00459668d3.md) — Santa Catalina de Siena · Cap. 4, 13 ed. latina, Ingolstadt 1583, ff. 19v-20
- **Jueves de la semana XXIV del Tiempo Ordinario (semana 24)** — [Toda nuestra esperanza está puesta en Cristo](../r/5bdb3aebce.md) — San Cirilo de Alejandría · Lib. 3, t. 1: PG 70, 571-573
- **Viernes de la semana XXIV del Tiempo Ordinario (semana 24)** — [Yo curaré sus extravíos](../r/5d275096d6.md) — Teodoreto de Ciro · Tratado 26-27: PG 75, 1466-1467
- **Sábado de la semana XXIV del Tiempo Ordinario (semana 24)** — [La tierra estaba llena de la gloria del Señor](../r/d0b24ad571.md) — San Elredo de Rievaulx · Sermón sobre la venida del Señor, Edit. C.H. Talbot, SSOC, vol 1, Roma 1952, 32-33

## Semana 25 del Tiempo Ordinario

- **Domingo de la semana XXV del Tiempo Ordinario (semana 25)** — [El altar celestial, figura del altar eclesial](../r/a6336379cd.md) — San Juan Crisóstomo · Homilía sobre el serafín 6, 3: PG 56, 138-139
- **Domingo de la semana XXV del Tiempo Ordinario (semana 25)** — [El denario es la vida eterna](../r/9541849bd8.md) — San Agustín de Hipona · Sermón 87, 1.5.6: PL 38, 530. 531.532.533
- **Domingo de la semana XXV del Tiempo Ordinario (semana 25)** — [Por la humildad se llega al reino; por la sencillez se entra en el cielo](../r/48b8e98e34.md) — San Máximo de Turín · Sermón 48, 1-2: CCL 23, 187-188
- **Domingo de la semana XXV del Tiempo Ordinario (semana 25)** — [Sobre la perfecta fe en Dios](../r/a92602f258.md) — Actas y escritos anónimos · Homilía 48,1-6: PG 34, 807-811
- **Lunes de la semana XXV del Tiempo Ordinario (semana 25)** — [Ataques por fuera y temores por dentro](../r/7e1909eaad.md) — San Gregorio Magno · Lib. 3, 39-40: PL 75, 619-620
- **Martes de la semana XXV del Tiempo Ordinario (semana 25)** — [¡Habitantes de la tierra, aprended justicia!](../r/1b4e67baf5.md) — San Cirilo de Alejandría · Lib. 3, 1: PG 70, 575-578
- **Miércoles de la semana XXV del Tiempo Ordinario (semana 25)** — [Preparada por el Altísimo, designada anticipadamente por los padres antiguos](../r/625e179c36.md) — San Bernardo de Claraval · Homilía 2, 1-2.4: Opera omnia ed. Cister, 4, 1966, 21-23
- **Jueves de la semana XXV del Tiempo Ordinario (semana 25)** — [El que persevere hasta el final se salvará](../r/461da55541.md) — San Agustín de Hipona · Sermón Caillau-Saint-Yves 2, 92: PLS 2, 441-552
- **Viernes de la semana XXV del Tiempo Ordinario (semana 25)** — [Esperamos el juicio futuro](../r/293e757270.md) — San Cirilo de Alejandría · Lib. 3, t. 2: PG 70, 631-633
- **Sábado de la semana XXV del Tiempo Ordinario (semana 25)** — [Demos a los pobres nuestros bienes, para enriquecernos con los del cielo](../r/550ec07de8.md) — San Gregorio Nacianceno · Sermón 14, 21-22: PG 35, 883-886

## Semana 26 del Tiempo Ordinario

- **Domingo de la semana XXVI del Tiempo Ordinario (semana 26)** — [Sus cicatrices nos curaron](../r/3d444b91bc.md) — Teodoreto de Ciro · Tratado 28: PG 75, 1467-1470
- **Domingo de la semana XXVI del Tiempo Ordinario (semana 26)** — [La verdadera penitencia consiste en no recaer en las mismas faltas](../r/43d600ead2.md) — Clemente de Alejandría · 39-40: PG 9, 643-646
- **Domingo de la semana XXVI del Tiempo Ordinario (semana 26)** — [Sed imitadores de Dios, como hijos queridos](../r/2eb63dac29.md) — Ricardo de San Víctor · 42-45: Ed. G. Dumeige, Paris 1955, 171-175
- **Domingo de la semana XXVI del Tiempo Ordinario (semana 26)** — [Lo que se aprende en la escuela de Cristo maestro](../r/8c5179b2ac.md) — San Agustín de Hipona · Sermón 33 A,4 sobre el antiguo Testamento : CCL 41, 421-422
- **Lunes de la semana XXVI del Tiempo Ordinario (semana 26)** — [Volveos a mí por la penitencia](../r/409b07119b.md) — San Cirilo de Alejandría · Lib. 3, t. 5: PG 70, 826-828
- **Martes de la semana XXVI del Tiempo Ordinario (semana 26)** — [Sobre la naturaleza de la Iglesia y sobre los sacramentos](../r/0f4d4a3164.md) — San Germán de Constantinopla · PG 98, 383-387
- **Miércoles de la semana XXVI del Tiempo Ordinario (semana 26)** — [La nueva Iglesia de los fieles fue reunida por la gracia del Espíritu Santo](../r/d335a9a570.md) — San Anselmo de Canterbury · Lib. 1, 6: SC 118, 64-66
- **Jueves de la semana XXVI del Tiempo Ordinario (semana 26)** — [En nuestra Pascua, Cristo es inmolado no en figura, sino en realidad](../r/bd2259cb6c.md) — San Elredo de Rievaulx · Sermón en el día de Pascua, Edit. C.H. Talbot, SSOC, vol 1, 94-95
- **Viernes de la semana XXVI del Tiempo Ordinario (semana 26)** — [Se nos llama cristianos o pueblo de Dios](../r/cdc971a06b.md) — San Cirilo de Alejandría · Lib. 4, Sermón 1: PG 70, 887-890
- **Sábado de la semana XXVI del Tiempo Ordinario (semana 26)** — [Seremos posesión y herencia de Dios](../r/35d77dd7b3.md) — San Cirilo de Alejandría · Lib. 3, t. 1: PG 70, 579-582

## Semana 27 del Tiempo Ordinario

- **Domingo de la semana XXVII del Tiempo Ordinario (semana 27)** — [Dios Padre domina todas las cosas](../r/16b2af142c.md) — San Cirilo de Alejandría · Homilía pascual 9, 6: PG 77, 599-602
- **Domingo de la semana XXVII del Tiempo Ordinario (semana 27)** — [Sobre el juicio pronunciado por el Padre](../r/c5156a9791.md) — San Cirilo de Alejandría · Lib 4, Sermón 4: PG 70, 1042-1043
- **Domingo de la semana XXVII del Tiempo Ordinario (semana 27)** — [Es éste un gran misterio](../r/38055f282f.md) — San Gregorio Nacianceno · Sermón 37, 5-7 sobre Mateo 19, 1-12: PG 36, 287-291
- **Domingo de la semana XXVII del Tiempo Ordinario (semana 27)** — [Despierta a tu fe, mira la vida futura con los ojos de la fe](../r/f65efc4d12.md) — San Agustín de Hipona · 3: CCL 40, 2140-2141
- **Lunes de la semana XXVII del Tiempo Ordinario (semana 27)** — [Uno solo es el mediador entre Dios y los hombres, el hombre Cristo Jesús](../r/1ae4fbbe76.md) — San Ambrosio de Milán · Comentario sobre el Salmo 48, nn. 13-14: CSEL 64, 367-368
- **Martes de la semana XXVII del Tiempo Ordinario (semana 27)** — [Vamos a subir al monte del Señor](../r/5d62be4f4f.md) — San Agustín de Hipona · Comentario sobre el Salmo 47, 7: CCL 38, 543-545
- **Miércoles de la semana XXVII del Tiempo Ordinario (semana 27)** — [Me casaré contigo en misericordia y en fidelidad](../r/da8d3f0224.md) — San Bernardo de Claraval · Sermón 27, 4. 6-7: Opera omnia, Edit. Cister. t. 1, 1957, 185-187
- **Jueves de la semana XXVII del Tiempo Ordinario (semana 27)** — [Cristo reconcilió el mundo con Dios por su propia sangre](../r/2bfe06e12f.md) — San Ambrosio de Milán · Salmo 48, 14-15: CSEL 64, 368-370
- **Viernes de la semana XXVII del Tiempo Ordinario (semana 27)** — [Volved a mí, dice el Señor](../r/41af6be4ba.md) — San Cipriano de Cartago · Tratado 3-4: CSEL 3, 398-399
- **Sábado de la semana XXVII del Tiempo Ordinario (semana 27)** — [La esperanza de la tierra nueva](../r/c49315d7b3.md) — Concilio Vaticano II · n. 39

## Semana 28 del Tiempo Ordinario

- **Domingo de la semana XXVIII del Tiempo Ordinario (semana 28)** — [El resto de Israel pastará y se tenderá sin sobresaltos](../r/ded54e0dc5.md) — Santo Tomás de Aquino · Cap. 10, lección 3
- **Domingo de la semana XXVIII del Tiempo Ordinario (semana 28)** — [El traje de fiesta es el amor](../r/2c74d5d1e8.md) — San Agustín de Hipona · Sermón 90,1.5.6: PL 38, 559.561-563
- **Domingo de la semana XXVIII del Tiempo Ordinario (semana 28)** — [Si quieres ser perfecto](../r/c16b0fcd99.md) — Clemente de Alejandría · Caps 5.10: PG 9, 610.614
- **Domingo de la semana XXVIII del Tiempo Ordinario (semana 28)** — [Grande es el poder de la fe](../r/bb7c688e40.md) — San Bruno de Segni · Parte 2, 40: PL 165, 426-428
- **Lunes de la semana XXVIII del Tiempo Ordinario (semana 28)** — [Dios prefirió que la salvación del hombre viniese por el camino de la fe, más que por el de las obras](../r/029f292942.md) — San Ambrosio de Milán · Comentario sobre el Salmo 43, 10-14: CSEL 64, 268-272
- **Martes de la semana XXVIII del Tiempo Ordinario (semana 28)** — [El que tenga sed que venga a mí y que beba](../r/34e88ee304.md) — San Columbano · Instrucción sobre Cristo, fuente de vida 13, 1-2: Opera, Dublín 1957, pp. 116-118
- **Miércoles de la semana XXVIII del Tiempo Ordinario (semana 28)** — [Tú, Señor, eres todo lo nuestro](../r/5ad1b14266.md) — San Columbano · Instrucción sobre Cristo, fuente de vida 13, 2-3: Opera, Dublín 1957, pp. 118-120
- **Jueves de la semana XXVIII del Tiempo Ordinario (semana 28)** — [Convertíos a mí](../r/faf7967eca.md) — San Jerónimo · PL 25, 967-968
- **Viernes de la semana XXVIII del Tiempo Ordinario (semana 28)** — [Al adornar el templo, no desprecies al hermano necesitado](../r/0379d6bc51.md) — San Juan Crisóstomo · Homilía 50, 3-4: PG 58, 508-509
- **Sábado de la semana XXVIII del Tiempo Ordinario (semana 28)** — [¿Quién es el sabio capaz de entender estas cosas?](../r/8e328d63f4.md) — Balduino de Canterbury · Parte 2, 1: SC 93, 194-200
- **Semana XXIX DEL TIEMPO ORDINARIO** — [Este día os trajo el comienzo de toda gracia](../r/00fe1ffb8c.md) — San Eusebio de Alejandría · Sermón 6, 1. 3. 6: PG 86, 415-418. 422
- **Semana XXIX DEL TIEMPO ORDINARIO** — [Tú, cristiano, eres la moneda del impuesto](../r/dcd3aa2f3d.md) — San Lorenzo de Brindis · Homilía l,2.3.4.6 en el domingo 22 después de Pentecostés: Opera omnia, t. 8, 335-336.339-340.346
- **Semana XXIX DEL TIEMPO ORDINARIO** — [No es tiempo de coronas y de premios, sino de luchas](../r/003d3e3372.md) — San Juan Crisóstomo · Homilía 7, 4-5: PG 48, 773-775
- **Semana XXIX DEL TIEMPO ORDINARIO** — [Se aparta de Dios quien no se une a él en la oración](../r/a984b84447.md) — San Gregorio de Nisa · PG 44,1119. 1123-1126
- **Semana XXX DEL TIEMPO ORDINARIO** — [El vástago legítimo es el Verbo, coeterno siempre con Dios Padre](../r/18088bc160.md) — San Martín de León · Sermón 1 en el Adviento del Señor : PL 208, 31-33. 38
- **Semana XXX DEL TIEMPO ORDINARIO** — [Éste es el camino que recorrió Cristo](../r/545404835a.md) — Actas y escritos anónimos · PL 3, 312-313
- **Semana XXX DEL TIEMPO ORDINARIO** — [Acojamos la luz y hagámonos discípulos del Señor](../r/d870d7bad4.md) — Clemente de Alejandría · Cap 11: PG 8, 230-234
- **Semana XXX DEL TIEMPO ORDINARIO** — [Sé humilde y te habrás librado de los lazos del pecado](../r/3992da7d4f.md) — San Juan Crisóstomo · Homilía 2,4-5 sobre la penitencia : PG 49, 289-292
- **Semana XXXI DEL TIEMPO ORDINARIO** — [La misericordia y la fidelidad se encuentran en el camino, que es Cristo](../r/1e792e302c.md) — Beato Pedro · 165-167: CCL CM 10, 97. 99. 100
- **Semana XXXI DEL TIEMPO ORDINARIO** — [Somos hombres de fe para salvar el alma](../r/7061e4609d.md) — San Orsiesio · Nn. 23,35.38: ed. Lefort, Louvain 1932, 124-125; 132-133.134
- **Semana XXXI DEL TIEMPO ORDINARIO** — [Al crecer el amor, el alma se siente segura](../r/2833bd0914.md) — San Agustín de Hipona · Sermón Mai 14,1-2: PLS 2, 449-450
- **Semana XXXI DEL TIEMPO ORDINARIO** — [La perfecta conversión a Dios](../r/dc871aa846.md) — Sin identificar · Hom. en la dedicación de una iglesia : Opera omnia, t. 1, 1888, 701-702
- **Semana XXXII DEL TIEMPO ORDINARIO** — [Somos cristianos y somos obispos](../r/d835377faf.md) — San Agustín de Hipona · Sermón 46, 1-2: CCL 41, 529-530
- **Semana XXXII DEL TIEMPO ORDINARIO** — [Salgamos al encuentro de Cristo, el esposo, con las espléndidas lámparas de la fe](../r/1c56f81552.md) — San Gregorio Nacianceno · Sermón 40,46 en la festividad del bautismo : PG 36, 426-428
- **Semana XXXII DEL TIEMPO ORDINARIO** — [Demos al Señor, que recibe en la persona de cada pobre](../r/bcdcdd3aa2.md) — San Paulino de Nola · Carta 34,2-4: CSEL 29, 305-306
- **Semana XXXII DEL TIEMPO ORDINARIO** — [Yo soy la resurrección y la vida](../r/7b0c930c6e.md) — San Ireneo de Lyon · Lib 4, 5, 2—5, 4: SC 100, 428-436

## Semana 29 del Tiempo Ordinario

- **Lunes de la semana XXIX del Tiempo Ordinario (semana 29)** — [Los santos profetas se han convertido en ojos para nosotros](../r/9408ff87e1.md) — San Hipólito de Roma · Tratado 2: Edit CSCO vol 264 [Scriptores Iberici t. 16], 55
- **Martes de la semana XXIX del Tiempo Ordinario (semana 29)** — [Amemos el camino angosto y trillado que conduce a la verdadera vida](../r/e3c9e99f5c.md) — San Gregorio Palamás · Homilía 10 : PG 151, 111-114
- **Miércoles de la semana XXIX del Tiempo Ordinario (semana 29)** — [Me pondré de centinela para escuchar lo que me dice](../r/897154fd9d.md) — San Bernardo de Claraval · Sermón 5, 1-4: Opera omnia, Edit Cist. 6, 1, 1970, 98-103
- **Jueves de la semana XXIX del Tiempo Ordinario (semana 29)** — [Sobre los grados de la contemplación](../r/7c47dd64b0.md) — San Bernardo de Claraval · Sermón 5, 4-5: Opera omnia, Edit Cist. 6, 1, 1970, 103-104
- **Viernes de la semana XXIX del Tiempo Ordinario (semana 29)** — [¿Quién es capaz de conocer el pensamiento de Dios?](../r/85b3f009bf.md) — San Cirilo de Alejandría · Lib. 5, t. 2: PG 70, 1230-1231
- **Sábado de la semana XXIX del Tiempo Ordinario (semana 29)** — [Yo instruiré a mis profetas](../r/3a6b6d9e42.md) — Tomás de Kempis (Imitación de Cristo) · Lib. 3, cap. 3

## Semana 30 del Tiempo Ordinario

- **Lunes de la semana XXX del Tiempo Ordinario (semana 30)** — [Aplastar bajo los pies a todos los prisioneros de la tierra](../r/ab911b8f02.md) — San Ambrosio de Milán · Sermón 12, 3-6, sobre el Salmo 118: PL 15, 1361-1362
- **Martes de la semana XXX del Tiempo Ordinario (semana 30)** — [No hubo tiempo alguno en que Dios no llamase a todos a la salvación](../r/c8f52cda57.md) — San Cirilo de Alejandría · Homilía pascual 2, 8: PG 77, 447-450
- **Miércoles de la semana XXX del Tiempo Ordinario (semana 30)** — [¿Qué no hizo nuestro Creador para lograr nuestra enmienda?](../r/1d20141cad.md) — San Gregorio Palamás · Homilía 3 : PG, 151, 35
- **Jueves de la semana XXX del Tiempo Ordinario (semana 30)** — [Muy a gusto hemos de presumir de nuestras debilidades, para que así resida en nosotros la fuerza de Dios](../r/50970e6693.md) — San Hilario de Poitiers · Tratado 3. 7. 11 sobre el Salmo 15: PL 9, 892. 894. 896. 897
- **Viernes de la semana XXX del Tiempo Ordinario (semana 30)** — [Sé benigno con los hermanos desgraciados](../r/d378e3c3a1.md) — San Gregorio de Nisa · Homilía 1 sobre el amor a los pobres: PG 46, 458-459
- **Sábado de la semana XXX del Tiempo Ordinario (semana 30)** — [Yo pienso designios de paz](../r/e7d56ab0b4.md) — San Bernardo de Claraval · Sermón 2, 1-2 en el día de Pentecostés: Opera omnia, Edit. Cist. t. 5, 1968, 165-166

## Semana 31 del Tiempo Ordinario

- **Lunes de la semana XXXI del Tiempo Ordinario (semana 31)** — [No temas, que te he redimido: he dado mi vida por ti](../r/01c8d07af0.md) — San Anselmo de Canterbury · Meditación 3 : Opera omnia, 1946, 88-90
- **Martes de la semana XXXI del Tiempo Ordinario (semana 31)** — [Nuestra gloria, posesión y reino es Cristo](../r/b3a3bc94e1.md) — San Paulino de Nola · Carta 38, 3-4. 6: CSEL 29, 326-327. 329
- **Miércoles de la semana XXXI del Tiempo Ordinario (semana 31)** — [La renovación ha sido llevada a cabo en Cristo](../r/330fb94b71.md) — San Cirilo de Alejandría · Lib. 4, Sermón 1: PG 70, 891-894
- **Jueves de la semana XXXI del Tiempo Ordinario (semana 31)** — [Cristo, en cuanto Hijo y Señor, se ha convertido en administrador del nuevo Testamento](../r/3c773fdfda.md) — San Cirilo de Alejandría · Lib. 4, Sermón 1: PG 70, 858-859
- **Viernes de la semana XXXI del Tiempo Ordinario (semana 31)** — [Viene el Deseado de todas las naciones](../r/a4e3adfbb5.md) — San Martín de León · Sermón 2 : PL 208, 37-39
- **Sábado de la semana XXXI del Tiempo Ordinario (semana 31)** — [No llores, Jerusalén, porque está para llegar tu salvación](../r/ff059949c1.md) — San Bernardo de Claraval · Sermón 10-11: Opera omnia, Edit. Cister t. 6, 1, 1970, 19-20

## Semana 32 del Tiempo Ordinario

- **Lunes de la semana XXXII del Tiempo Ordinario (semana 32)** — [Los pastores que se apacientan a sí mismos](../r/a4a03a7f7b.md) — San Agustín de Hipona · Sermón 46, 3-4: CCL 41, 530-531
- **Martes de la semana XXXII del Tiempo Ordinario (semana 32)** — [El ejemplo de Pablo](../r/fbce0e7abc.md) — San Agustín de Hipona · Sermón 46, 4-5 CCL 41, 531-533
- **Miércoles de la semana XXXII del Tiempo Ordinario (semana 32)** — [Que nadie busque su interés, sino el de Jesucristo](../r/23484ff7cf.md) — San Agustín de Hipona · Sermón 46, 6-7: CCL 41, 533-534
- **Jueves de la semana XXXII del Tiempo Ordinario (semana 32)** — [Sé un modelo para los fieles](../r/7f94983d82.md) — San Agustín de Hipona · Sermón 46, 9: CCL 41, 535-536
- **Viernes de la semana XXXII del Tiempo Ordinario (semana 32)** — [Prepárate para las pruebas](../r/8726c3cf1a.md) — San Agustín de Hipona · Sermón 46, 10-11: CCL 41, 536-538

## Semana 33 del Tiempo Ordinario

- **Lunes de la semana XXXIII del Tiempo Ordinario (semana 33)** — [Insiste a tiempo y a destiempo](../r/1e37fbea34.md) — San Agustín de Hipona · Sermón 46, 14-15: CCL 41, 541-542
- **Martes de la semana XXXIII del Tiempo Ordinario (semana 33)** — [La Iglesia, como una vid que crece y se difunde por doquier](../r/a7c852c4d9.md) — San Agustín de Hipona · Sermón 46, 18-19: CCL 41, 544-546
- **Miércoles de la semana XXXIII del Tiempo Ordinario (semana 33)** — [Haced lo que os digan, pero no hagáis lo que ellos hacen](../r/0a34227076.md) — San Agustín de Hipona · Sermón 46, 20-21: CCL 41, 546-548
- **Jueves de la semana XXXIII del Tiempo Ordinario (semana 33)** — [Apacentaré a mis ovejas en ricos pastizales](../r/90859682aa.md) — San Agustín de Hipona · Sermón 46, 24-25. 27: CCL 41, 551-553
- **Viernes de la semana XXXIII del Tiempo Ordinario (semana 33)** — [Todos los buenos pastores se identifican con el único pastor](../r/0de8e1b2ca.md) — San Agustín de Hipona · Sermón 46, 29-30: CCL 41, 555-557
- **Sábado de la semana XXXIII del Tiempo Ordinario (semana 33)** — [Cristo se hizo carne para hacernos a nosotros espirituales](../r/31e9531468.md) — San Gregorio Magno · Lib. 2, Hom. 4, 19-20: CCL 142, 271-273

## Semana 34 del Tiempo Ordinario

- **Domingo de la semana XXXIV del Tiempo Ordinario (semana 34) JESUCRISTO, REY DEL UNIVERSO** — [Venga a nosotros tu reino](../r/3690d04b07.md) — Orígenes · Cap. 25: PG 11, 495-499
- **Domingo de la semana XXXIV del Tiempo Ordinario (semana 34) JESUCRISTO, REY DEL UNIVERSO** — [Cuando aparezca Cristo, entonces también vosotros apareceréis juntamente con él, en la gloria](../r/788d36160e.md) — San Cirilo de Alejandría · Lib 9: PG 74, 266
- **Domingo de la semana XXXIV del Tiempo Ordinario (semana 34) JESUCRISTO, REY DEL UNIVERSO** — [El reino de Cristo hasta el fin del mundo](../r/5a7223397d.md) — San Agustín de Hipona · Tratado 115, 2-5: CCL 36, 644-646).
- **Domingo de la semana XXXIV del Tiempo Ordinario (semana 34) JESUCRISTO, REY DEL UNIVERSO** — [La cruz, símbolo del reino](../r/5b5014cee9.md) — San Juan Crisóstomo · Homilía sobre la cruz y el ladrón 1, 3-4: PG 49, 403-404
- **Lunes de la semana XXXIV del Tiempo Ordinario (semana 34)** — [Meteré mi ley en su pecho](../r/ce0979b035.md) — San León Magno · Sermón 95, 1-2: CCL 138A, 582-584
- **Martes de la semana XXXIV del Tiempo Ordinario (semana 34)** — [Dichosos los pobres en el espíritu](../r/39e3b6c454.md) — San León Magno · Sermón 95, 2-3: CCL 138A, 584-585
- **Miércoles de la semana XXXIV del Tiempo Ordinario (semana 34)** — [La dicha del reino de Cristo](../r/eec49d0442.md) — San León Magno · Sermón 95, 4-5: CCL 138A, 585-587
- **Jueves de la semana XXXIV del Tiempo Ordinario (semana 34)** — [Feliz el alma que ambiciona este manjar](../r/c9c0bb105e.md) — San León Magno · Sermón 95, 6-7: CCL 138A, 587-588
- **Viernes de la semana XXXIV del Tiempo Ordinario (semana 34)** — [Mucha paz tienen los que aman tu nombre, Señor](../r/8144211397.md) — San León Magno · Sermón 95, 8-9: CCL 138 A, 588-590
- **Sábado de la semana XXXIV del Tiempo Ordinario (semana 34)** — [Toda la alabanza del Padre viene del Hijo](../r/6a6033e644.md) — San Hilario de Poitiers · Lib. 3, 15-16: PL 10, 84-85

## Otras lecturas del Tiempo Ordinario

- **De las Homilías sobre la primera carta a los Corintios de San Juan Crisóstomo, obispo** — [En la Iglesia, que es el cuerpo de Cristo, cada uno ejercemos distintas funciones](../r/39a0050e30.md) — Orígenes · Lib. 9, 2: PG 14, 1211-1212
- **Tiempo Ordinario** — [Proveía a la paz y tranquilidad de la Iglesia](../r/48d1a10586.md) — Actas y escritos anónimos · MGH, Scriptores 4, 792-799
- **El mismo día 14 de julio San Francisco Solano, Presbítero** — [¡Dios, vida mía, qué suave eres: seas siempre bendito!](../r/b3b0350d74.md) — Actas y escritos anónimos · Acta Sanctorum julii V, París 1868, pp. 884-886).
- **Tiempo Ordinario** — [Partícipes de la pasión de Cristo](../r/051b1721c1.md) — San Juan Crisóstomo · Homilía 65, 2-4: PG 58, 619-622
- **Tiempo Ordinario** — [Quiero misericordia y no sacrificios](../r/5b23edcf95.md) — San Ireneo de Lyon · Lib. 4, 17, 4-6: SC 100, 590-594
- **Sabado XXXII** — [Ofrece el alivio de la consolación](../r/2771143b3d.md) — San Agustín de Hipona · Sermón 46, 11-12: CCL 41, 538-539
- **Semana XXXIII DEL TIEMPO ORDINARIO** — [Los cristianos débiles](../r/0c8ce890d8.md) — San Agustín de Hipona · Sermón 46, 13: CCL 41, 539-540
- **Semana XXXIII DEL TIEMPO ORDINARIO** — [El justo siembra para el espíritu, y del Espíritu cosechará vida eterna](../r/edeb5e425e.md) — Orígenes · nn. 68-69: PG 13, 1709-1710
- **Semana XXXIII DEL TIEMPO ORDINARIO** — [¡Ojalá que en el siglo futuro nos hallemos también nosotros agregados a la muchedumbre de los salvados!](../r/261713739a.md) — San Gregorio Palamás · Homilía 26 : PG 151, 339-342
- **Semana XXXIII DEL TIEMPO ORDINARIO** — [No pongamos resistencia a su primera venida, y no temeremos la segunda](../r/605a7a962e.md) — San Agustín de Hipona · 14.15: CCL 39, 1351-1353
