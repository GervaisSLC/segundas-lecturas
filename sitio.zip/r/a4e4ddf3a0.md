# Tras la tristeza, espera con alegría el gozo

**San Pedro Damiani** (1007–1072) · Segunda lectura del Oficio de Lectura

- id: `a4e4ddf3a0`
- Fuente: De las cartas de san Pedro Damiani, obispo
- Cita patrística: Libro 8, 6: PL 144, 473-476
- Se lee: 21 de febrero. San Pedro Damiani, Obispo y Doctor de la Iglesia — Santoral, año par; 21 de febrero. San Pedro Damiani, Obispo y Doctor de la Iglesia — Santoral, año impar; 21 de febrero San Pedro Damiani, Obispo y Doctor de la Iglesia — Santoral, año impar; 21 de febrero San Pedro Damiani, Obispo y Doctor de la Iglesia — Santoral, año par
- Escritura: [Si 31, 8. 11. 10](../escritura/si.md) (responsorio)
- Temas (automáticos): [Paciencia en la prueba](../temas/tribulacion.md), [Esperanza y vida eterna](../temas/esperanza.md), [Alabanza y acción de gracias](../temas/alabanza.md)
- Cómo citar: San Pedro Damiani, Libro 8, 6: PL 144, 473-476, «Tras la tristeza, espera con alegría el gozo». Liturgia de las Horas, Oficio de Lectura, segunda lectura, 21 de febrero. San Pedro Damiani, Obispo y Doctor de la Iglesia — Santoral, año par. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-a4e4ddf3a0](../index.html#r-a4e4ddf3a0)
- Autor: [San Pedro Damiani](../a/pedro-damiani.md)

## Texto

Me has pedido, dilectísimo hermano, que te transmita por carta unas palabras de consuelo capaces de endulzar tu corazón, amargado por tantos sufrimientos como te afligen.

Pero si tu inteligencia está despierta, a mano tienes el consuelo que necesitas, pues la misma palabra divina te instruye como a hijo, destinado a obtener la herencia. Medita en aquellas palabras: Hijo mío, cuando te acerques al temor de Dios, prepárate para las pruebas; mantén el corazón firme, sé valiente.

Donde está el temor está la justicia. La prueba que para nosotros supone cualquier adversidad no es un castigo de esclavos, sino una corrección paterna.

Por esto Job, en medio de sus calamidades, si bien dice: Que Dios se digne triturarme y cortar de un tirón la trama de mi vida, añade a continuación: Sería un consuelo para mi; aun torturado sin piedad, saltaría de gozo.

Para los elegidos de Dios, sus mismas pruebas son un consuelo, pues en virtud de estos sufrimientos momentáneos dan grandes pasos por el camino de la esperanza hasta alcanzar la felicidad del cielo.

Lo mismo hacen el martillo y la lima con el oro, quitándole la escoria para que brille más. El horno prueba la vasija del alfarero, el hombre se prueba en la tribulación. Por esto dice también Santiago: Hermanos míos: Teneos por muy dichosos cuando os veáis asediados por toda clase de pruebas.

Con razón deben alegrarse quienes sufren por sus malas obras una pena temporal, y, en cambio, obtienen por sus obras buenas los premios sempiternos del cielo:

Todo ello significa que no deben deprimir tu espíritu los sufrimientos que padeces y las correcciones con que te aflige la disciplina celestial; no murmures ni te lamentes, no te consumas en la tristeza o la pusilanimidad. Que resplandezca en tu rostro la serenidad, en tu mente la alegría, en tu boca la acción de gracias.

Alabanza merece la dispensación divina, que aflige temporalmente a los suyos para librarlos del castigo eterno, que derriba para exaltar, corta para curar y deprime para elevar.

Robustece tu espíritu con éstos y otros testimonios de la Escritura y, tras la tristeza, espera con alegría el gozo que vendrá.

Que la esperanza te levante ese gozo, que la caridad encienda tu fervor. As¡ tu mente, bien saciada, será capaz de olvidar los sufrimientos exteriores y progresar en la posesión de los bienes que contempla en su interior.

## Nota

> Nació en Ravena, el año 1007; acabados los estudios, ejerció la docencia, pero se retiró en seguida al yermo de Fonte Avellana, donde fue elegido prior. Fue gran propagador de la vida religiosa allí y en otras regiones de Italia. En aquella dura época ayudó eficazmente a los papas, con sus escritos y legaciones, en la reforma de la Iglesia. Creado por Esteban IX cardenal y obispo de Ostia, murió el año 1072 y al poco tiempo era venerado como santo.

> Del Común de pastores o de doctores de la Iglesia.

> En el tiempo de Cuaresma: Para la conmemoración sólo lo siguiente:

## Responsorio (Sir 31, 8. 11. 10)

R. Dichoso el hombre que se conserva íntegro y no se pervierte por la riqueza. * Su dicha será consolidada por el Señor.  
V. Pudo desviarse y no se desvió, hacer el mal y no lo hizo.  
R. Su dicha será consolidada por el Señor.  

## Oración

Dios todopoderoso, concédenos seguir con fidelidad los consejos y ejemplos de san Pedro Damiani, obispo, para que, amando a Cristo sobre todas las cosas, y dedicados siempre al servicio de tu Iglesia, merezcamos llegar a los gozos eternos. Por nuestro Señor Jesucristo.

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
