# San Bruno

None · None · 1 lecturas

- [Se alegra mi espíritu en el Señor](../r/a3f7308201.md) — San Bruno · Núms. 1-3: SC 88, 82-84 · 6 de octubre San Bruno, presbítero — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
