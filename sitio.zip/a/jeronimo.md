# San Jerónimo

c. 347–420 · St. Jerome · 6 lecturas

- [El que nació una vez de María, nace a diario en nosotros](../r/3408481e13.md) — San Jerónimo · Salmo 84: CCL 78, 107-108 · 23 de Diciembre — Santoral, año impar
- [Sólo en el Señor debemos confiar](../r/59fcf49321.md) — San Jerónimo · Venecia, 21 de junio de 1535 · 8 de febrero. San Jerónimo Emiliani — Santoral, año par
- [Pasaré al lugar del tabernáculo admirable](../r/436f6e04e0.md) — San Jerónimo · Homilía a los recién bautizados, sobre el salmo 41: CCL 78, 542-544 · Miércoles de la semana XV del Tiempo Ordinario (semana 15), año impar
- [Convertíos a mí](../r/faf7967eca.md) — San Jerónimo · PL 25, 967-968 · Jueves de la semana XXVIII del Tiempo Ordinario (semana 28), año impar
- [Ignorar las Escrituras es ignorar a Cristo](../r/d02922eeb5.md) — San Jerónimo · Núms. 1. 2: CCL 73,1-3 · 30 de septiembre San Jerónimo, presbítero y doctor de la Iglesia — Santoral, año impar
- [Buscad los bienes de arriba](../r/c40d478a83.md) — San Jerónimo · PL 23, 1057-1059 · Miércoles de la semana XX del Tiempo Ordinario (semana 20), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
