# San Isidoro de Sevilla

c. 560–636 · St. Isidore of Seville · 3 lecturas

- [El obispo debe tener su puerta abierta a todo el que llegue](../r/bec7de5d5e.md) — San Isidoro de Sevilla · Cap. 5,1. 2: PL 83, 785 · 4 de abril. San Isidoro de Sevilla, Obispo y Doctor de la Iglesia — Santoral, año par
- [Superaba a todo el mundo en sabiduría y, más aún, en obras de caridad](../r/0775337ac3.md) — San Isidoro de Sevilla · PL 81,15-17 · Mes de abril — Santoral, año par
- [Defensor y restaurador de la fe](../r/8d0e6ef591.md) — San Isidoro de Sevilla · Cap. 41: PL 83, 1103-1104 · Mes de octubre — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
