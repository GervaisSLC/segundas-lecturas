# Cuaresma y Pascua — año par

[Volver al calendario](index.md) · [Guía para IAs](../llms.txt)

## Semana de Ceniza

- **Miércoles de Ceniza** — [Convertíos](../r/f1ef327991.md) — San Clemente I, papa · Caps. 7, 4-8, 5-9. 1; 13, 1-4; 19, 2: Funck 1, 71-73.77-78.87
- **Jueves después de Ceniza** — [Purificación espiritual por el ayuno y la misericordia](../r/1429eb9b65.md) — San León Magno · Sermón sobre la Cuaresma, 1-2; PL 54, 285-287
- **Viernes después de Ceniza** — [La oración es luz del alma](../r/b8f4cab50c.md) — San Juan Crisóstomo · Homilía 6 sobre la oración, suplemento: PG 64, 462-466
- **Sábado después de Ceniza** — [La amistad de Dios](../r/823ba7d8e6.md) — San Ireneo de Lyon · Lib. 4, 13—14, 1: SC 100, 534-540

## Semana I de Cuaresma

- [En Cristo fuimos tentados, en él vencimos al diablo](../r/de2cf91fb5.md) — San Agustín de Hipona · Comentario sobre el salmo 60, 2-3: CCL 39, 766
- [El cristiano dispone de medios para superar las tentaciones](../r/ea0a56ed1a.md) — San Gregorio Nacianceno · Discurso 40, 10: PG 36, 370-371
- [La pasión de Cristo como premio de la piedad](../r/15aaa03b4f.md) — San Agustín de Hipona · Carta 140, 13-15, Libro sobre la gracia del nuevo Testamento: CSEL 44, 164-166
- [Jesús fue tentado por el diablo para que la Iglesia aprendiera que a Cristo se llega a través de muchas tribulaciones y tentaciones](../r/f5f6e62054.md) — Orígenes · Hom 3: GCS t. 8, 221, 19-223, 5
- **Domingo de la semana I de Cuaresma (semana 1) - Año A: Mt 4, 1-11** — [Actualicemos unos con otros la bondad del Señor](../r/f26d548244.md) — San Gregorio Nacianceno · Sermón 14, 23-25 sobre el amor a los pobres: PG 35, 887-890
- **Martes de la semana I de Cuaresma (semana 1)** — [El que nos dio la vida nos enseñó también a orar](../r/38e10541fe.md) — San Cipriano de Cartago · Caps. 1-3: CSEL 3, 267-268
- **Miércoles de la semana I de Cuaresma (semana 1)** — [La circuncisión del corazón](../r/d7258f781c.md) — Afraates · Demostración 11, Sobre la circuncisión, 11-12: PS 1, 498-503
- **Jueves de la semana I de Cuaresma (semana 1)** — [El verdadero cordero se inmoló por nosotros](../r/41363641c2.md) — San Cirilo de Alejandría · Homilía pascual 2: PG 77, 823-825
- **Viernes de la semana I de Cuaresma (semana 1)** — [Debemos practicar la caridad fraterna según el ejemplo de Cristo](../r/68613b723f.md) — San Elredo de Rievaulx · Lib. 3, 5: PL 195, 582
- **Sábado de la semana I de Cuaresma (semana 1)** — [Los interrogantes más profundos del hombre](../r/adec0c6885.md) — Concilio Vaticano II · Núms. 9-10

## Semana II de Cuaresma

- [Angosto y estrecho es el callejón que lleva a la vida](../r/7690c32b46.md) — Orígenes · Homilía 5 sobre el libro del Exodo, 3-4: Ed. Maurist. t. 2, 145-146
- [La ley se dio por medio de Moisés, la gracia y la verdad vinieron por medio de Jesucristo](../r/b1d42366fc.md) — San León Magno · Sermón 51, 3-4.8: PL 54, 310-311.313
- [Hablaban de la muerte que Jesús iba a consumar en Jerusalén](../r/a3bfdc045d.md) — San Cirilo de Alejandría · Homilía 9 en la transfiguración del Señor: PG 77, 1011-1014
- [Sólo Jesús es la luz verdadera y eterna](../r/d1b313970e.md) — San Ambrosio de Milán · Comentario sobre el salmo 45, 2: PL 14, 1188-1189
- **Domingo de la semana II de Cuaresma (semana 2) - Año A: Mt 17, 1-9** — [Moisés y Cristo](../r/a501777566.md) — San Juan Crisóstomo · Catequesis 3, 24-27: SC 50, 165-167
- **Martes de la semana II de Cuaresma (semana 2)** — [La pasión de todo el cuerpo de Cristo](../r/c2d0870d12.md) — San Agustín de Hipona · Comentario sobre el Salmo 140, 4-6: CCL 40, 2028-2029
- **Miércoles de la semana II de Cuaresma (semana 2)** — [Las brillantes gestas de Cristo](../r/d5f38b47bf.md) — San Cirilo de Alejandría · Lib. 3: PG 68, 275-278
- **Jueves de la semana II de Cuaresma (semana 2)** — [Del verdadero temor de Dios](../r/f2d6cd7f2c.md) — San Hilario de Poitiers · Sobre el salmo 127, 1-3: CSEL 24, 628-630
- **Viernes de la semana II de Cuaresma (semana 2)** — [La alianza del Señor](../r/c65064c94e.md) — San Ireneo de Lyon · Lib. 4,16, 1-5: SC 100, 564-572
- **Sábado de la semana II de Cuaresma (semana 2)** — [Unirse a Dios, único bien verdadero](../r/9a750ec3e1.md) — San Ambrosio de Milán · Caps. 6, 36; 7, 44; 9, 52

## Semana III de Cuaresma

- [Para tener un corazón sensible a la miseria ajena, es necesario que primero reconozcas la tuya propia](../r/1b34d49f2e.md) — San Bernardo de Claraval · Tratado III, 6: Opera omnia, Edit. Cisterc. 3, 1963, 20-21
- [Llega una mujer de Samaria a sacar agua](../r/e18bd75a0d.md) — San Agustín de Hipona · Tratado 15, 10-12.16-17: CCL 36, 154-156
- [Somos las piedras vivas con las que se edifica el templo de Dios](../r/2f18b12780.md) — San Agustín de Hipona · Comentario sobre el salmo 130, nn. 1-3: CCL 40, 1198-1200
- [Convertíos y creed en la Buena Noticia](../r/291db60636.md) — San Pablo VI · AAS t. 58, 1966, pp. 179-180
- **Domingo de la semana III de Cuaresma (semana 3) - Año A: Jn 4, 5-42** — [Esta cruz no es cruz de solos cuarenta días, sino de toda la vida](../r/f8c9c8f957.md) — San Agustín de Hipona · Sermón 205, 1: 1 de Cuaresma: Edit. Maurist., t. 5, 919-920
- **Martes de la semana III de Cuaresma (semana 3)** — [La oración llama, el ayuno intercede, la misericordia recibe](../r/715216298e.md) — San Pedro Crisólogo · Sermón 43: PL 52, 320. 322
- **Miércoles de la semana III de Cuaresma (semana 3)** — [Dichosos los limpios de corazón, porque ellos verán a Dios](../r/f9227e0c2e.md) — San Teófilo de Antioquía · Lib. 1, 2. 7: PG 6, 1026-1027. 1035
- **Jueves de la semana III de Cuaresma (semana 3)** — [El sacrificio espiritual](../r/08aecd5e23.md) — Tertuliano · Caps. 28-29: CCL 1, 273-274
- **Viernes de la semana III de Cuaresma (semana 3)** — [Cristo se consagró a sí mismo por nuestros pecados](../r/e847690f36.md) — San Cirilo de Alejandría · Lib. 11, cap. 10: PG 74, 543-546
- **Sábado de la semana III de Cuaresma (semana 3)** — [Sirvamos a Cristo en los pobres](../r/5ff73fcee1.md) — San Gregorio Nacianceno · Sermón 14, sobre el amor a los pobres, 38. 40: PG 35, 907-910

## Semana IV de Cuaresma

- [Y tal convenía que fuese nuestro Pontífice: santo, inocente, sin mancha](../r/76e6c169aa.md) — Eusebio de Cesarea · Lib. 5, 3: PG 22, 366-367
- [La carne de nuestro barro recibe la luz de la vida eterna, mediante el sacramento del bautismo](../r/5ba10226c2.md) — San Ambrosio de Milán · Carta 80,1-6: PL 16, 1271- 1272
- [Dios no perdonó a su propio Hijo, sino que lo entregó a la muerte por nosotros](../r/9126879a10.md) — San Juan Crisóstomo · 17, 1-8: PG 52, 516-518
- [Me alejé mucho, y tú estabas aquí](../r/20f6f15993.md) — San Agustín de Hipona · Comentario sobre el salmo 138, nn. 5-6: CCL 40, 1992-1993
- **Domingo de la semana IV de Cuaresma (semana 4) - Año A: Jn 9, 1-41** — [Cristo es nuestro sumo sacerdote, nuestra propiciación](../r/72b0cb876b.md) — Orígenes · Homilía 9, 5. 10: PG 12, 515. 523
- **Martes de la semana IV de Cuaresma (semana 4)** — [Del bien de la caridad](../r/4d875d01f1.md) — San León Magno · Sermón 10, 3-5 sobre la Cuaresma: PL 54, 299-301
- **Miércoles de la semana IV de Cuaresma (semana 4)** — [Vamos a participar en la Pascua](../r/f91e84f3c0.md) — San Gregorio Nacianceno · Sermón 45, 23-24: PG 36, 654-655
- **Jueves de la semana IV de Cuaresma (semana 4)** — [La misericordia de Dios para con los penitentes](../r/b6f3fc8b09.md) — San Máximo el Confesor · Carta 11 : PG 91, 454-455
- **Viernes de la semana IV de Cuaresma (semana 4)** — [La Iglesia sigue a Cristo doquiera que va](../r/efddfb7a4e.md) — San Cirilo de Alejandría · Lib. 5: PG 68, 394-395
- **Sábado de la semana IV de Cuaresma (semana 4)** — [Que toda la actividad del hombre se purifique en el misterio pascual](../r/86849e4b14.md) — Concilio Vaticano II · Núms. 37-38

## Semana V de Cuaresma

- [Por la penitencia, nos purificamos de la impureza de nuestra lepra](../r/e7a3484ec0.md) — Orígenes · Homilía 7, 1-2, Ed. GCS t. 8, 37 40: SC 29, 133-136
- [Era necesaria la muerte de Lázaro para que, con Lázaro ya en el sepulcro, resucitase la fe de los discípulos](../r/aff6915957.md) — San Pedro Crisólogo · Sermón 6 : PL 52, 375-377
- [Cristo brotó en medio de nosotros como una espiga de trigo; murió y produce mucho fruto](../r/71e9db2881.md) — San Cirilo de Alejandría · 2: PG 69, 619-623
- [Observa los misterios de Dios y la clemencia de Cristo](../r/c99be23c72.md) — San Ambrosio de Milán · Carta 26 11-20: PL 16, 1088-1090
- **Domingo de la semana V de Cuaresma (semana 5) - Año A: Jn 11, 1-45** — [La Iglesia, sacramento visible de la unidad](../r/7602f78e00.md) — Concilio Vaticano II · Núm. 9).
- **Martes de la semana V de Cuaresma (semana 5)** — [Cristo, al tiempo de su pasión, no rehusó morir por los impíos y los injustos](../r/00b8df9b92.md) — Orígenes · 4, 10. 11: PG 14, 997-999
- **Miércoles de la semana V de Cuaresma (semana 5)** — [Hemos de adorar en espíritu y en verdad](../r/ae219c9165.md) — San Cirilo de Alejandría · Lib. 9: PG 68, 587-589
- **Jueves de la semana V de Cuaresma (semana 5)** — [El misterio del agua](../r/901aba4fc6.md) — Dídimo de Alejandría · Lib. 2, 13-14: PG 39, 691-698
- **Viernes de la semana V de Cuaresma (semana 5)** — [Por nosotros los hombres, envió Dios a su único Hijo, para ser muerto por nosotros y para nosotros](../r/5af1abe6e9.md) — San Agustín de Hipona · 31-32. 33.39: PL 40, 333-334. 338
- **Sábado de la semana V de Cuaresma (semana 5)** — [Gloriémonos también nosotros en la cruz de nuestro Señor Jesucristo](../r/9fae8afd89.md) — San Agustín de Hipona · PLS 2, 545-546

## Semana Santa

- **Domingo de Ramos en la Pasión del Señor** — [Carguemos con la cruz del Señor para que, crucificando nuestra carne, destruya el pecado](../r/5a0c6c74bf.md) — San Ambrosio de Milán · Homilía 15, 37-40: PL 15, 1423-1424
- **Domingo de Ramos en la Pasión del Señor** — [Bendito el que viene, como rey, en nombre del Señor](../r/1d1605e628.md) — San Andrés de Creta · Sermón 9 sobre el domingo de Ramos : PG 97, 990-994
- **Domingo de Ramos en la Pasión del Señor** — [Mirad al Rey justo](../r/141ee5d69e.md) — San Cirilo de Alejandría · Lib 4, orat 2: PG 70, 967-970
- **Domingo de Ramos en la Pasión del Señor** — [Si aquella sangre no hubiese sido derramada, el mundo no hubiera sido redimido](../r/ef03a2b0aa.md) — San Agustín de Hipona · Tratado 37, 9-10: CCL 36, 336-338
- **Domingo de Ramos - Año A: Mt 21, 1-11** — [Gloriémonos también nosotros en la cruz del Señor](../r/9d3c1c5d11.md) — San Agustín de Hipona · Sermón Güelferbitano 3: PLS 2, 545-546
- **Martes Santo** — [Es una sola la muerte en favor del mundo y una sola la resurrección de entre los muertos](../r/6cfdbd8b87.md) — San Basilio Magno · Cap. 15, núm. 35: PG 32, 127-130
- **Miércoles Santo** — [La plenitud del amor](../r/94d6859b80.md) — San Agustín de Hipona · Tratado 84, 1-2: CCL 36, 536-538
- **Jueves Santo** — [El que era inmortal se revistió de mortalidad para poder morir por nosotros](../r/e099b4ea76.md) — San Agustín de Hipona · Sermón sobre el Antiguo Testamento, 23A, 2-3: CCL 41, 322

## Triduo pascual

- [El valor de la sangre de Cristo](../r/256817152a.md) — San Juan Crisóstomo · Catequesis 3, 13-19: SC 50, 174-177
- [Cristo entregó su alma en manos del Padre, abriéndonos a nuevas y luminosas esperanzas](../r/afc91a377d.md) — San Cirilo de Alejandría · Lib. 12: PG 74, 667-670
- **Sábado Santo** — [El descenso del Señor al abismo](../r/7f9072e0fa.md) — Actas y escritos anónimos · PG 43, 439. 451. 462-463

## Semana I de Pascua

- **Domingo de Pascua de la Resurrección del Señor** — [Derramaré sobre vosotros un agua pura, y os daré un corazón nuevo](../r/161f6bc7e1.md) — Sin identificar
- **Domingo de Pascua de la Resurrección del Señor** — [Cristo, una vez resucitado de entre los muertos, ya no muere más](../r/2de3a46031.md) — San Pablo
- **Lunes de la Octava de Pascua** — [¡Oh mística largueza! ¡Oh Pascua divina!](../r/1078775c5c.md) — San Hipólito · Homilía 6, 1. 5 en la Pascua: PG 59, 735. 743-746
- **Martes de la Octava de Pascua** — [Con razón en estos días desbordamos de gozo, como si ya estuviéramos con el Esposo](../r/9068ddd6c2.md) — Eusebio de Cesarea · Tratado 4-5: PG 24, 698-699
- **Miércoles de la Octava de Pascua** — [Si alguien ha sido reconciliado por la sangre de Cristo, que no se relacione más con lo que es enemigo de Dios](../r/7e2f8b4b9f.md) — Orígenes · Lib. 4, 7: PG 14, 986-988
- **Jueves de la Octava de Pascua** — [Constantemente somos saciados con el cuerpo del Salvador y constantemente participamos de la sangre del Cordero](../r/50961e1f2f.md) — Eusebio de Cesarea · Tratado 7. 9. 10-12: PG 24, 702-706
- **Viernes de la Octava de Pascua** — [El bautismo nos hace inmortales y nos deifica](../r/f7c9c0463f.md) — Dídimo de Alejandría · Lib. 2, 14: PG 39, 710-718
- **Sábado de la Octava de Pascua** — [¿Qué mejor noticia podemos dar que ésta: el Salvador ha resucitado?](../r/fc844bb028.md) — San Agustín de Hipona · Sermón 45, 5 sobre el Antiguo Testamento: CCL 41, 519-520

## Semana II de Pascua

- **Domingo de la Octava de Pascua** — [La Pascua espiritual](../r/c9ce7e6e34.md) — Actas y escritos anónimos · PG 59, 723-724
- **Domingo de la Octava de Pascua** — [Los que gozan de la presencia de Cristo, es lógico que estén tranquilos](../r/72cf11214d.md) — San Cirilo de Alejandría · Lib. 12, Cap. 1: PG 74, 703-706
- **Domingo de la Octava de Pascua** — [El Señor ama a sus discípulos, y, sin embargo, los envía al mundo a padecer](../r/2bbaebe809.md) — San Gregorio Magno · Homilía 26, 1-2: PL 76, 1197-1198
- **Domingo de la Octava de Pascua** — [Gran mérito tiene nuestra fe](../r/105f657142.md) — San Agustín de Hipona · Sermón 88, 1-2: Edit Maurist t. 5 469-470
- **Domingo de la semana II de Pascua (semana 2) - Año A: Jn 20, 19-31** — [No es lícito mentir a Dios](../r/b79c98b140.md) — San Agustín de Hipona · Sermón 148: PL 38, 799-800
- **Martes de la semana II de Pascua (semana 2)** — [El bautismo, un injerto para la inmortalidad](../r/571941439e.md) — Actas y escritos anónimos · PG 28, 1080-1082
- **Miércoles de la semana II de Pascua (semana 2)** — [Cristo nos ha abierto las puertas de la eternidad](../r/d4939584b9.md) — San Nicolás Cabasilas · Lib. 1: PG 150, 510-511
- **Jueves de la semana II de Pascua (semana 2)** — [Misterios antiguos y nuevos](../r/aa2d5ece60.md) — San Epifanio de Salamina · Homilía 3 [atribuida] sobre la santa resurrección de Cristo: PG: 43, 466-470
- **Viernes de la semana II de Pascua (semana 2)** — [La inefable benignidad de Cristo colmó a su Iglesia de innumerables dones](../r/00147757ce.md) — San Basilio Magno · SC 187, 275-277
- **Sábado de la semana II de Pascua (semana 2)** — [La economía de la salvación](../r/f248d4d4d4.md) — Concilio Vaticano II · Núms. 5-6

## Semana III de Pascua

- **Domingo de la semana III de Pascua (semana 3)** — [Cantemos al Señor el cántico del amor](../r/6da14eecd8.md) — San Agustín de Hipona · Sermón 34, 13. 56: CCL 41, 424. 426
- **Domingo de la semana III de Pascua (semana 3)** — [Sobre la resurrección de Cristo](../r/d366e72497.md) — San Agustín de Hipona · Sermón 234,1-2: Edit Maurist t. 5, 987-988
- **Domingo de la semana III de Pascua (semana 3)** — [Dichosos los que crean sin haber visto](../r/6c0243ea7f.md) — San Cirilo de Alejandría · Lib. 12, cap. 1: PG 74, 730-735
- **Domingo de la semana III de Pascua (semana 3)** — [Interrogando a Pedro, el Señor nos interroga a todos](../r/5ccc1963f5.md) — San Agustín de Hipona · Sermón Güelferbitano 16 (2-3: PLS 2, 580-581
- **Domingo de la semana III de Pascua (semana 3) - Año A: Lc 24, 13-35** — [En seguir a Cristo está nuestra salvación](../r/f42ba11338.md) — Clemente de Alejandría · Lib. 1, cap. 6, 2627. 3031: SC 70, 159. 161. 167
- **Martes de la semana III de Pascua (semana 3)** — [Cristo, primogénito de entre los muertos](../r/3f5cca1ed6.md) — San Gregorio de Nisa · Lib. 4: PG 45, 634-635. 638
- **Miércoles de la semana III de Pascua (semana 3)** — [Los sagrados misterios nos unen a Cristo](../r/0bb696bafd.md) — San Nicolás Cabasilas · Lib. 2: PG 150, 522-523
- **Jueves de la semana III de Pascua (semana 3)** — [La voluntad de Cristo, norma de nuestra vida](../r/a74cf9f7aa.md) — San Gregorio de Nisa · PG 46, 262-263
- **Viernes de la semana III de Pascua (semana 3)** — [El baño de regeneración](../r/73763c8cac.md) — San Justino · Cap. 61: PG 6, 419-422
- **Sábado de la semana III de Pascua (semana 3)** — [El cristiano es otro Cristo](../r/25eec95cd9.md) — San Gregorio de Nisa · PG 46, 254-255

## Semana IV de Pascua

- **Domingo de la semana IV de Pascua (semana 4)** — [Nadie opta por una vida nueva sin antes arrepentirse de la pasada](../r/4d45e5d467.md) — San Agustín de Hipona · Sermón 352, 2: PL 39, 1550-1551
- **Domingo de la semana IV de Pascua (semana 4)** — [Cristo, el buen Pastor](../r/aa65a3247f.md) — San Gregorio Magno · Homilía 14 sobre los evangelios, 3-6: PL 76, 1129-1130
- **Domingo de la semana IV de Pascua (semana 4)** — [Del cielo vino el Pastor para reconducir las ovejas descarriadas a los pastos de la vida](../r/8d7fa4584f.md) — San Pedro Crisólogo · Sermón 6 (CCL 24, 44-47
- **Domingo de la semana IV de Pascua (semana 4)** — [La encarnación del Verbo y el sacramento de la Eucaristía nos hacen partícipes de la naturaleza divina](../r/89efb41c8a.md) — San Hilario de Poitiers · Lib 8, 13-16: CCL 62A, 325-328
- **Domingo de la semana IV de Pascua (semana 4) - Año A: Jn 10, 1-10** — [Cristo ha hecho partícipes de su consagración y de su misión a los obispos por medio de los apóstoles](../r/1be233be4b.md) — Concilio Vaticano II · Capítulo III, n. 28
- **Martes de la semana IV de Pascua (semana 4)** — [Nosotros os anunciamos la promesa que Dios hizo a nuestros padres](../r/814402f643.md) — San Cirilo de Alejandría · Cap. 2, 14: PG 74, 925-926
- **Miércoles de la semana IV de Pascua (semana 4)** — [La ley vivificante del Espíritu en Cristo Jesús](../r/2e06527521.md) — San Agustín de Hipona · Sermón 155, 65-66: PL 38, 843-844
- **Jueves de la semana IV de Pascua (semana 4)** — [El Señor creó y redimió a sus siervos](../r/49e81f538f.md) — San Agustín de Hipona · Sermón 130, 2: Edit. Maurist. t. 5, 637-638
- **Viernes de la semana IV de Pascua (semana 4)** — [Muchos son los senderos, pero uno solo es el camino](../r/219f8f89fc.md) — San Clemente I, papa · Cap. 36, 1-2; 37-38: Funk 1, 145-149
- **Sábado de la semana IV de Pascua (semana 4)** — [Alcanzó a todos la misericordia divina y fue salvado todo el mundo](../r/28d6555629.md) — San Cirilo de Alejandría · Cap. 15, 7: PG 74, 854-855

## Semana V de Pascua

- **Domingo de la semana V de Pascua (semana 5)** — [Cristo es el día](../r/e220f9d839.md) — San Máximo de Turín · Sermón 53, 1-2. 4: CCL 23, 214-216
- **Domingo de la semana V de Pascua (semana 5)** — [El lugar: junto al Padre; el camino: Cristo](../r/39a356a679.md) — San Ambrosio de Milán · Cap 12, 52-55: CSEL 32, 747-750
- **Domingo de la semana V de Pascua (semana 5)** — [Yo soy la vid, vosotros los sarmientos](../r/fd8dc977cf.md) — San Cirilo de Alejandría · Lib 10, 2: PG 74, 331-334
- **Domingo de la semana V de Pascua (semana 5)** — [El mandamiento nuevo](../r/90887759f2.md) — San Agustín de Hipona · Tratado 65, 1-3: CCL 36, 490-492
- **Domingo de la semana V de Pascua (semana 5) - Año A: Jn 14, 1-12** — [Primogénito de muchos hermanos](../r/aecae9447b.md) — Isaac de Stella · Sermón 42: PL 194, 1831-1832
- **Martes de la semana V de Pascua (semana 5)** — [Cristo es al mismo tiempo sacerdote y altar, ofrenda y oferente, sujeto y objeto de la ofrenda](../r/9f9c046a35.md) — San Nicolás Cabasilas · Lib. 3: PG 150, 578-579
- **Miércoles de la semana V de Pascua (semana 5)** — [Si moramos en Cristo, ¿qué más podemos desear?](../r/d18f6b0c49.md) — San Nicolás Cabasilas · Lib. 4: PG 150, 582-583
- **Jueves de la semana V de Pascua (semana 5)** — [La unción del Espíritu Santo](../r/8f4e53a22c.md) — San Nicolás Cabasilas · Lib. 6: PG 150, 574-575
- **Viernes de la semana V de Pascua (semana 5)** — [En el momento de la tentación, nos consuela la esperanza](../r/c5e6ba0f4f.md) — San Ambrosio de Milán · Sermón 7, 6-7: CSEL 62, 130-131
- **Sábado de la semana V de Pascua (semana 5)** — [El aleluya pascual](../r/7d316b21f6.md) — San Agustín de Hipona · Salmo 148, 1-2: CCL 40, 2165-2166

## Semana VI de Pascua

- **Domingo de la semana VI de Pascua (semana 6)** — [Dios nos ha reconciliado por medio de Cristo y nos ha confiado el ministerio de esta reconciliación](../r/ca0d5e5e88.md) — San Cirilo de Alejandría · Cap. 5, 5-6. 2: PG 74, 942-943
- **Domingo de la semana VI de Pascua (semana 6)** — [No os dejaré desamparados](../r/d75fddcbb0.md) — San Juan Crisóstomo · Homilía 75, 1: PG 59, 403-405
- **Domingo de la semana VI de Pascua (semana 6)** — [Amamos a Cristo en la medida en que guardamos sus mandamientos](../r/fdb02dc490.md) — San Agustín de Hipona · Tratado sobre el evangelio de san Juan, 82, 1-4: CCL 36, 532-534
- **Domingo de la semana VI de Pascua (semana 6)** — [Si no tengo amor, no soy nada](../r/f442fae2c7.md) — San Bernardo de Claraval · Sermón sobre el Cantar de los cantares, 27, 8-10: Opera omnia, Edit Cisterc 1, 1957, 187-189
- **Domingo de la semana VI de Pascua (semana 6) - Año A: Jn 14, 15-21** — [El Espíritu Santo nos renueva en el bautismo](../r/ea8251735b.md) — Dídimo de Alejandría · Libro 2, 12: PG 39, 667-674
- **Martes de la semana VI de Pascua (semana 6)** — [Demos gracias por la divina economía](../r/ec232e6688.md) — San León Magno · Sermón 73, 1-2: CCL 138A, 450-452
- **Miércoles de la semana VI de Pascua (semana 6)** — [La ascensión de Cristo es nuestra propia exaltación](../r/2803c22368.md) — San León Magno · Sermón sobre la Ascensión, 73, 3-5: CCL A 452-454

## La Ascensión del Señor

- **Solemnidad** — [Nadie ha subido al cielo sino aquel que ha bajado del cielo](../r/b30382d55d.md) — San Agustín de Hipona · Sermón Mai 98, Sobre la Ascensión del Señor, 1-2: PLS 2, 494-495
- **Solemnidad** — [Lo que fue visible en nuestro Redentor, ha pasado a los ritos sacramentales](../r/2516d02265.md) — San León Magno · Tratado 74 (1-2: CCL 138A 455-457
- **Solemnidad** — [Creemos en Jesús, a quien no hemos visto](../r/3f8f65031e.md) — San Agustín de Hipona · Tratado 4 sobre la primera carta de san Juan, 2-3: SC 75, 220-224
- **Solemnidad** — [Nuestro Señor Jesucristo nos ha inaugurado un camino nuevo y vivo](../r/a102ae9b6f.md) — San Cirilo de Alejandría · Lib 9: PG 74, 182-183
- **Ascensión - Año A: Mt 28, 16-20** — [La Ascensión del Señor alimenta nuestra fe](../r/3d60196d53.md) — San León Magno · Sermón 2 sobre la Ascensión, 1-4: PL 54, 397-399
- **Después de la Ascensión** — [Por el camino del amor, también nosotros podemos ascender hasta Cristo](../r/48a896fb12.md) — San León Magno · Tratado 74, 5: CCL 138 A, 459-461

## Semana VII de Pascua

- [Yo les he dado la gloria que tú me diste](../r/6b85e551c4.md) — San Gregorio de Nisa · Homilía 15: PG 44, 1115-1118
- [La cruz es voluntad del Padre, gloria del Hijo, gozo del Espíritu Santo](../r/13be837936.md) — San Juan Crisóstomo · Homilías sobre el nuevo Testamento : PG 51, 34-35
- [Les di a ellos la gloria que me diste](../r/82d00ca2ca.md) — San Gregorio de Nisa · Homilía 15 : PG 44, 1115-1118
- [Jesucristo ruega no sólo por los Doce, sino por todos aquellos que, en diversas épocas, han de creer por la palabra de ellos](../r/c1178a9714.md) — San Cirilo de Alejandría · Lib 11, cap 11: PG 74, 551-554
- **Domingo de la semana VII de Pascua (semana 7) - Año A: Jn 17, 1-11a** — [El agua viva del Espíritu Santo](../r/35035c1f6b.md) — San Cirilo de Jerusalén · Catequesis sobre el Espíritu Santo, 16, 1, 11-12. 16: PG 33, 931-935. 939-942
- **Martes de la semana VII de Pascua (semana 7)** — [La acción del Espíritu Santo](../r/669853f286.md) — San Basilio Magno · Cap. 9, núms. 22-23: PG 32, 107-110
- **Miércoles de la semana VII de Pascua (semana 7)** — [La misión del Espíritu Santo en la Iglesia](../r/28f5fcdbaf.md) — Concilio Vaticano II · Núms. 4. 12
- **Jueves de la semana VII de Pascua (semana 7)** — [Si no me voy, el Abogado no vendrá a vosotros](../r/00e4683758.md) — San Cirilo de Alejandría · Libro 10, 16, 6-7: PG 74, 434
- **Viernes de la semana VII de Pascua (semana 7)** — [El don del Padre en Cristo](../r/864ac189c6.md) — San Hilario de Poitiers · Libro 2, 1, 33. 35: PL 10, 50-51. 73-75
- **Sábado de la semana VII de Pascua (semana 7)** — [La unidad de la Iglesia se manifiesta en la pluralidad de lenguas](../r/9295660c2b.md) — Actas y escritos anónimos · Sermón 8, 1-3: PL 65, 743-744

## Pentecostés

- **Domingo de Pentecostés** — [El envío del Espíritu Santo](../r/5942ae421e.md) — San Ireneo de Lyon · Libro 3, 17, 1-3: SC 34, 302-306
- **Domingo de Pentecostés** — [En vosotros se realiza lo que se preanunciaba en los días de la venida del Espíritu Santo](../r/890db2a56e.md) — San Agustín de Hipona · Sermón 271 : PL 38, 1245-1246
- **Domingo de Pentecostés** — [Me he hecho Hijo del hombre, para que vosotros podáis ser hijos de Dios](../r/4834ea815e.md) — San León Magno · Tratado 77, 4-6: CCL 138A, 490-493
- **Domingo de Pentecostés** — [El Espíritu de la verdad os guiará hasta la verdad plena](../r/3007a374ff.md) — San León Magno · Tratado 75, 1-3: CCL 138A, 465-468
