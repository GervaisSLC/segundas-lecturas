# Didaché

1st–2nd c. · Didache · 1 lecturas

- [Acerca de la eucaristía](../r/db7079df63.md) — Didaché · Caps. 9, 1-10, 6; 14, 1-3: Funk 2, 19-22. 26 · Martes de la semana XVI del Tiempo Ordinario (semana 16), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
