# Balduino de Canterbury

d. 1190 · Baldwin of Canterbury · 11 lecturas

- [La sabiduría de la cruz del Señor](../r/4b5ddff48a.md) — Balduino de Canterbury · 9: PL 204, 501-502. 504 · Lunes de la semana V del Tiempo Ordinario (semana 5), año impar
- [Dad pruebas continuamente de que sois servidores de Dios](../r/a14ea2378f.md) — Balduino de Canterbury · PL 204, 413-414 · Jueves de la semana V del Tiempo Ordinario (semana 5), año impar
- [Sed siervos de los siervos](../r/e53469763a.md) — Balduino de Canterbury · Tratado para los sacerdotes, 12: PL 204, 533-536 · Viernes de la semana VI del Tiempo Ordinario (semana 6), año impar
- [Se nos invita a la fe, que es el trabajo de Dios](../r/ce3b699180.md) — Balduino de Canterbury · Parte 2,3: SC 93, 248-252 · Domingo de la semana XVII del Tiempo Ordinario (semana 17), año impar
- [El Señor discierne los pensamientos y sentimientos del corazón](../r/d17c56f285.md) — Balduino de Canterbury · PL 204, 466-467 · Viernes de la semana XVII del Tiempo Ordinario (semana 17), año par
- [Cristo, en su dignidad, es siempre deseable](../r/3a5a65ad35.md) — Balduino de Canterbury · Parte 2,3: SC 93, 252-254 · Domingo de la semana XVIII del Tiempo Ordinario (semana 18), año impar
- [Sobre la fe de los apóstoles](../r/cd6c6d0a05.md) — Balduino de Canterbury · Parte 2, 3: SC 93, 296-300 · Domingo de la semana XXI del Tiempo Ordinario (semana 21), año impar
- [Es fuerte el amor como la muerte](../r/bc06846301.md) — Balduino de Canterbury · Tratado 10: PL 204, 513-514. 516 · Miércoles de la semana XXIII del Tiempo Ordinario (semana 23), año impar
- [La salvación del mundo ha sido distribuida y ordenada en una escalonada serie de tiempos](../r/5a87b09956.md) — Balduino de Canterbury · Sobre el sacramento del altar, parte 2, 1: SC 93, 178-182 · Domingo de la semana XXIV del Tiempo Ordinario (semana 24), año impar
- [¿Quién es el sabio capaz de entender estas cosas?](../r/8e328d63f4.md) — Balduino de Canterbury · Parte 2, 1: SC 93, 194-200 · Sábado de la semana XXVIII del Tiempo Ordinario (semana 28), año impar
- [La palabra de Dios es viva y eficaz](../r/32cd282677.md) — Balduino de Canterbury · Tratado 6 : PL 204, 451-453 · Domingo de la semana XXXI del Tiempo Ordinario (semana 31), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
