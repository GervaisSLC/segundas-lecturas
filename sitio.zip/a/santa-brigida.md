# Santa Brígida

None · None · 1 lecturas

- [Elevación de la mente a Cristo Salvador](../r/73ef712659.md) — Santa Brígida · Oración 2: Revelationum S. Birgittae libri, 2, Roma 1628, pp. 408-410 · 23 de julio SANTA BRÍGIDA, Religiosa, Patrona de Europa — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
