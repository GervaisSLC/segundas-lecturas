# San Antonio de Padua

1195–1231 · St. Anthony of Padua · 1 lecturas

- [La palabra tiene fuerza cuando va acompañada de las obras](../r/d22e844e93.md) — San Antonio de Padua · I, 226 · 13 de junio San Antonio de Padua, Presbítero y Doctor de la Iglesia — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
