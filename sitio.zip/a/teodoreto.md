# Teodoreto de Ciro

c. 393–458 · Theodoret of Cyrus · 2 lecturas

- [Yo curaré sus extravíos](../r/5d275096d6.md) — Teodoreto de Ciro · Tratado 26-27: PG 75, 1466-1467 · Viernes de la semana XXIV del Tiempo Ordinario (semana 24), año impar
- [Sus cicatrices nos curaron](../r/3d444b91bc.md) — Teodoreto de Ciro · Tratado 28: PG 75, 1467-1470 · Domingo de la semana XXVI del Tiempo Ordinario (semana 26), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
