# San Luis María Grignion de Montfort

1673–1716 · St. Louis de Montfort · 1 lecturas

- [Todo tuyo](../r/ae951caf61.md) — San Luis María Grignion de Montfort · nn. 120-121.125-126: oeuvres completes, Seuil, Paris 1966, 562-563.566-567). (cf. Obras completas, BAC, n. 451). · El mismo día 28 de abril. San Luis María Griñón de Montfort, Presbítero — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
