# San Juan de Ávila

1499–1569 · St. John of Ávila · 2 lecturas

- [El sacerdote debe ser santo](../r/054f297271.md) — San Juan de Ávila · Plática enviada al padre Francisco Gómez, S. I:, para ser predicada en el Sínodo diocesano de Córdoba del año 1563: BAC 304, Obras completas del santo maestro Juan de Ávila, 3, pp. 364-365. 370. 373 · 10 de mayo. San Juan de Ávila, Presbítero — Santoral, año par
- [Porque la vida de Jesucristo sea manifestada en nosotros](../r/f403aeea37.md) — San Juan de Ávila · Carta 58, a unos amigos suyos: BAC 313, Obras completas del santo maestro Juan de Ávila, 5, pp. 298-299 · 18 de mayo. San Juan I, Papa y Mártir — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
