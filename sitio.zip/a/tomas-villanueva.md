# Santo Tomás de Villanueva

1488–1555 · St. Thomas of Villanova · 2 lecturas

- [María, elegida para ser nuestra abogada](../r/98f163b2ae.md) — Santo Tomás de Villanueva · Sermón 3, de la Natividad de la B. V.M. Sermones de la Virgen, Madrid 1952, pp. 208-212). · Sábado anterior al segundo domingo de mayo. NUESTRA SEÑORA DE LOS DESAMPARADOS — Santoral, año par
- [Santidad e integridad de vida, virtudes indispensables del buen prelado](../r/c5a518b588.md) — Santo Tomás de Villanueva · Jn, 10, 1-11: Divi Thomae a Villanueva, Opera omnia, Manila, 1822, pp. 324-325 · 10 de octubre Santo Tomás de Villanueva, obispo — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
