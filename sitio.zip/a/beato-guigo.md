# Beato Guigo

None · None · 1 lecturas

- [Buscaba tu rostro, Señor](../r/8840c50d4c.md) — Beato Guigo · Cap 3, 6-7: SC 163, 84-86.94-96 · Viernes de la semana XXX del Tiempo Ordinario (semana 30), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
