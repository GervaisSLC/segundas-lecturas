# San Francisco de Borja

None · None · 1 lecturas

- [Sólo son grandes antes Dios los que se tienen por pequeños](../r/ea2adada04.md) — San Francisco de Borja · Carta 7, año 1545: Monumenta historica Societatis Iesu, Madrid 1908, III, pp. 9-10 · 3 de octubre San Francisco de Borja, presbítero — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
