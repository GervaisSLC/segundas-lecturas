# San Juan Mediocre de Nápoles

d. 835 · St. John IV of Naples · 1 lecturas

- [Ama al Señor y sigue sus caminos](../r/13baf76547.md) — San Juan Mediocre de Nápoles · Sermón 7: PLS 4, 785-786 · Jueves de la semana II de Cuaresma (semana 2), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
