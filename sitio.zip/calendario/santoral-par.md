# Santoral — año par

[Volver al calendario](index.md) · [Guía para IAs](../llms.txt)

## Enero

- **1 de Enero. SANTA MARÍA, MADRE DE DIOS** — [La Palabra tomó de María nuestra condición](../r/8f640cd3d0.md) — San Atanasio de Alejandría · Carta a Epicteto, 5-9: PG 26,1058.1062-1066
- **1 de Enero. SANTA MARÍA, MADRE DE DIOS** — [La santísima Virgen ha de ser llamada Madre de Dios](../r/8fcc68c757.md) — San Cirilo de Alejandría · Homilía 15, 1-3 sobre la encarnación del Verbo: PG 77, 1090-1091
- **2 de Enero** — [Jesús es miel en la boca, melodía en el oído, júbilo en el corazón](../r/ec17481b39.md) — San Bernardo de Claraval · Sermón 15, 4-6: Opera omnia. Edit. Cister. 1957, 1, 84-86
- **2 de enero. San Basilio Magno y San Gregorio Nacianceno Obispos y Doctores de la Iglesia** — [Como si una misma alma sustentase dos cuerpos](../r/9956ad976a.md) — San Gregorio Nacianceno · Sermón 43, en alabanza de Basilio Magno, 15. 16-17. 19-21: PG 36, 514-523
- **3 de Enero** — [Habitaré y caminaré con ellos](../r/33407fe91e.md) — San Bernardo de Claraval · Sermón 27, 7.9 Opera omnia. Edit. Cister. 1957, I, 186-188
- **3 de enero. SANTO NOMBRE DE JESÚS** — [El Nombre de Jesús, el gran fundamento de la fe](../r/9ba66f290c.md) — San Bernardino de Siena · Sermón 49, art. 1: Opera omnia 4, 495ss.
- **4 de Enero** — [Venga también ahora la Palabra del Señor a quienes la esperamos en silencio](../r/5f39d26e02.md) — Sin identificar · Sermón 1: SC 192, 45. 52. 60
- **5 de Enero** — [Él es el pastor, él es pasto, él es la redención](../r/315d65ea42.md) — San Bernardo de Claraval · Sermón 31, 8-10: Opera omnia. Edit Cisterc. 1957, I, 224-226
- **6 de Enero. LA EPIFANÍA DEL SEÑOR** — [¡Oh Dios, que te alaben los pueblos!](../r/5f4bc601f1.md) — San Hilario de Poitiers · 3-5 : CSEL 22, 271-273
- **7 de Enero** — [Venía a salvar, pero le era también necesario morir](../r/ed41f518b9.md) — San Proclo de Constantinopla · Sermón 1 en alabanza de santa María, 4. 5. 6. 9. 10 : PG 65, 683-687. 690-691
- **7 de Enero o Lunes después del Domingo de Epifanía** — [Venía a salvar, pero le era también necesario morir](../r/ed41f518b9.md) — San Proclo de Constantinopla · Sermón 1 en alabanza de santa María, 4. 5. 6. 9. 10 : PG 65, 683-687. 690-691
- **7 de enero. San Raimundo de Peñafort, Presbítero** — [Que el Dios del amor y de la paz purifique vuestros corazones](../r/2e76c8c221.md) — San Raimundo de Peñafort · Monumenta Ordinis Praedicatorum Historica 6, 2, Roma 1901, pp. 84-85
- **8 de Enero o Martes después del Domingo de Epifanía** — [El misterio de nuestra salvación](../r/7cc7b1e9e5.md) — San Fulberto de Chartres · Carta 5: PL 141, 198-199
- **9 de Enero o Miércoles después del Domingo de Epifanía** — [Y verán los confines de la tierra la victoria de nuestro Dios](../r/c1839c131d.md) — San León Magno · Tratado 36 ,1-2 CCL 138, 195-196
- **9 de enero. San Eulogio de Córdoba, Presbítero y Mártir** — [El Señor nos ayuda en la tribulación y nos da fortaleza en los combates](../r/c6ba7cec23.md) — San Eulogio de Córdoba · Documentum Martyrii, 25, epílogo: PL 115, 834
- **10 de Enero o Jueves después del Domingo de Epifanía** — [El que por nosotros se hizo mortal, es confesado Rey y Señor](../r/a7d7fadb84.md) — San Odilón de Cluny · Sermón 9 en el día de Pentecostés : PL 142, 1015-1016
- **10 de enero. Beata Ana de los Ángeles Monteagudo** — [La vocación, misterio de amor](../r/b77a3e2728.md) — San Juan Pablo II · AAS 76 (1984) 513-546, n. 3
- **11 de Enero o Viernes después del Domingo de Epifanía** — [Éste es el trabajo que Dios quiere: que creáis en el que Él ha enviado](../r/fdba8b81d1.md) — San Agustín de Hipona · Sermón 49 sobre el Antiguo Testamento, 2-3 CCL 41, 614-616
- **12 de Enero oSábado después del Domingo de Epifanía** — [La navidad y el bautismo de Cristo son mi misterio y mi salvación](../r/daf22ae4b0.md) — San Máximo de Turín · Sermón 45, 1-3 CCL 23, 182-183
- **13 de enero San Hilario, obispo y Doctor de la Iglesia** — [Te serviré predicándote](../r/c8c8b91dce.md) — San Hilario de Poitiers · Libro 1, 37-38: PL 10, 48-49
- **17 de enero San Antonio, Abad** — [La vocación de san Antonio](../r/89aa82679d.md) — San Atanasio de Alejandría · Caps. 2-4: PG 26, 842-846
- **20 de enero San Fructuoso, Obispo y Mártir y sus Diáconos, Santos Augurio y Eulogio** — [Honrar a los mártires es honrar a Dios](../r/63fd664665.md) — San Agustín de Hipona · Sermón 273, En el día de los santos Fructuoso, Augurio y Eulogio, 2-3. 9: PL 38,1248-1249.1252
- **20 de enero San Fructuoso, Obispo y Mártir y sus Diáconos, Santos Augurio y Eulogio** — [Alegría en el martirio](../r/1a55b69402.md) — Actas y escritos anónimos · Caps. 3-4
- **21 de enero Santa Inés, Virgen y Mártir** — [No tenía aún edad de ser condenada, pero estaba ya madura para la victoria](../r/208e557c5b.md) — San Ambrosio de Milán · Libro 1, Caps. 2. 5. 7-9: PL 16 [edición 1845], 189-191
- **22 de enero San Vicente, Diácono y Mártir** — [Vicente venció en aquel por quien había sido vencido el mundo](../r/5a6cbeffdb.md) — San Agustín de Hipona · Sermón 276,1-2: PL 38,1256
- **22 de enero San Vicente, Diácono y Mártir** — [Vicente, por su fe, fue vencedor en todo](../r/6f5a6d7d55.md) — San Agustín de Hipona · Sermón 274, sobre el martirio de san Vicente: PL 38, 1252.1253
- **23 de enero San Ildefonso, Obispo** — [En el Bautismo, Cristo es quien bautiza](../r/f0cdccf1a9.md) — San Ildefonso de Toledo · Caps. 15-16: PL 96,117-118
- **24 de enero San Francisco de Sales, Obispo y Doctor de la Iglesia** — [La devoción se ha de ejercitar de diversas maneras](../r/2cd76a804d.md) — San Francisco de Sales · Parte 1, cap. 3
- **25 de enero LA CONVERSIÓN DEL APÓSTOL SAN PABLO** — [Pablo lo sufrió todo por amor a Cristo](../r/9f28295575.md) — San Juan Crisóstomo · Homilía 2 sobre las alabanzas de san Pablo: PG 50, 477-480
- **26 de enero Santos Timoteo y Tito, Obispos** — [He combatido bien mi combate](../r/30a460dc53.md) — San Juan Crisóstomo · Homilía 2 sobre las alabanzas de san Pablo: PG 50, 480-484
- **27 de enero Santa Ángela de Mérici, Virgen** — [Lo dispuso todo con suavidad](../r/87e9700f44.md) — Santa Ángela de Mérici
- **28 de enero Santo Tomás de Aquino, Presbítero y Doctor de la Iglesia** — [En la cruz hallamos el ejemplo de todas las virtudes](../r/b545ad6f4f.md) — Santo Tomás de Aquino · Conferencia 6 sobre el Credo
- **31 de enero San Juan Bosco, Presbítero** — [Trabajé siempre por amor](../r/cfb1e9932c.md) — San Juan Bosco · Epistolario, 4, 201-203: Turín 1959

## Febrero

- **2 de febrero LA PRESENTACIÓN DEL SEÑOR** — [Acojamos la luz clara y eterna](../r/eea7e82284.md) — San Sofronio de Jerusalén · Sermón 3, Sobre el Hypapanté, 6. 7: PG 87, 3, 3291-3293
- **3 de febrero San Blas, Obispo y Mártir** — [Sufre por mis ovejas](../r/9826817596.md) — San Agustín de Hipona · Sermón Güelferbitano 32, Sobre la ordenación episcopal: PLS 2, 639-640
- **5 de febrero. Santa Águeda, Virgen y Mártir** — [Su bondad provenía del mismo Dios, fuente de todo bien](../r/4a33254134.md) — San Metodio de Sicilia · Analecta Bollandiana 68, 76-78
- **5 de febrero Santa Águeda, Virgen y Mártir** — [Su bondad provenía del mismo Dios, fuente de todo bien](../r/4a33254134.md) — San Metodio de Sicilia · Analecta Bollandiana 68, 76-78
- **6 de febrero. San Pablo Miki y Compañeros, Mártires** — [Seréis mis testigos](../r/896dfc62cf.md) — Actas y escritos anónimos · Cap. 14,109-110: Acta Sanctorum Februarii,1, 769
- **6 de febrero San Pablo Miki y Compañeros, Mártires** — [Seréis mis testigos](../r/896dfc62cf.md) — Actas y escritos anónimos · Cap. 14,109-110: Acta Sanctorum Februarii,1, 769
- **8 de febrero. San Jerónimo Emiliani** — [Sólo en el Señor debemos confiar](../r/59fcf49321.md) — San Jerónimo · Venecia, 21 de junio de 1535
- **8 de febrero San Jerónimo Emiliani** — [Sólo en el Señor debemos confiar](../r/59fcf49321.md) — San Jerónimo · Venecia, 21 de junio de 1535
- **10 de febrero. Santa Escolástica, Virgen** — [Pudo más porque amó más](../r/a6a4457c58.md) — San Gregorio Magno · Libro 2, 33: PL 66,194-196
- **10 de febrero Santa Escolástica, Virgen** — [Pudo más porque amó más](../r/a6a4457c58.md) — San Gregorio Magno · Libro 2, 33: PL 66,194-196
- **11 de febrero. NUESTRA SEÑORA DE LOURDES** — [La Señora me habló](../r/0b0cc88cd1.md) — Santa María Bernarda Soubirous · Carta al padre Gondrand, año 1861: cf. A. Ravier, Les ècrits de sainte Bernadette Soubirous, París 1961, pp. 53-59
- **11 de febrero Nuestra Señora de Lourdes** — [La Señora me habló](../r/0b0cc88cd1.md) — Santa María Bernarda Soubirous · Carta al padre Gondrand, año 1861: cf. A. Ravier, Les ècrits de sainte Bernadette Soubirous, París 1961, pp. 53-59
- **14 de febrero. San Cirilo, Monje, y San Metodio, Obispo, Patronos de Europa** — [Acrecienta tu Iglesia y reúne a todos sus miembros en la unidad](../r/22f1964afd.md) — Actas y escritos anónimos · Cap. 18: Denkschriften der kaiserl. Akademie der Wissei schaften 19, Viena 1870, p. 246
- **14 de febrero SAN CIRILO, Monje, y SAN METODIO, Obispo, Patronos de Europa** — [Acrecienta tu Iglesia y reúne a todos sus miembros en la unidad](../r/22f1964afd.md) — Actas y escritos anónimos · Cap. 18: Denkschriften der kaiserl. Akademie der Wissei schaften 19, Viena 1870, p. 246
- **21 de febrero. San Pedro Damiani, Obispo y Doctor de la Iglesia** — [Tras la tristeza, espera con alegría el gozo](../r/a4e4ddf3a0.md) — San Pedro Damiani · Libro 8, 6: PL 144, 473-476
- **21 de febrero San Pedro Damiani, Obispo y Doctor de la Iglesia** — [Tras la tristeza, espera con alegría el gozo](../r/a4e4ddf3a0.md) — San Pedro Damiani · Libro 8, 6: PL 144, 473-476
- **22 de febrero. La Cátedra del Apóstol San Pedro** — [La Iglesia de Cristo se levanta sobre la firmeza de la fe de Pedro](../r/cb45c59739.md) — San León Magno · Sermón 4 en el aniversario de su consagración episcopal, 2-3: PL 54,149-151
- **22 de febrero La Cátedra del Apóstol San Pedro** — [La Iglesia de Cristo se levanta sobre la firmeza de la fe de Pedro](../r/cb45c59739.md) — San León Magno · Sermón 4 en el aniversario de su consagración episcopal, 2-3: PL 54,149-151
- **23 de febrero. San Policarpo, Obispo y Mártir** — [Como un sacrificio enjundioso y agradable](../r/4d7cf6151b.md) — Actas y escritos anónimos · Caps. 13, 2-5, 2: Funk 1, 297-299
- **23 de febrero San Policarpo, Obispo y Mártir** — [Como un sacrificio enjundioso y agradable](../r/4d7cf6151b.md) — Actas y escritos anónimos · Caps. 13, 2-5, 2: Funk 1, 297-299

## Marzo

- **4 de marzo. San Casimiro** — [Invirtió su tesoro según el mandato del Altísimo](../r/5dc0bc6209.md) — Actas y escritos anónimos · Caps. 2-3: Acta Sanctorum Martii 1, 347-348
- **4 de marzo San Casimiro** — [Invirtió su tesoro según el mandato del Altísimo](../r/5dc0bc6209.md) — Actas y escritos anónimos · Caps. 2-3: Acta Sanctorum Martii 1, 347-348
- **7 de marzo. Santas Perpetua y Felicidad, Mártires** — [Llamados y elegidos para gloria del Señor](../r/c29a94cdbf.md) — Actas y escritos anónimos · Caps. 18. 20-21: edición van Beek, Nimega 1936, pp. 42. 46-52
- **7 de marzo Santas Perpetua y Felicidad, Mártires** — [Llamados y elegidos para gloria del Señor](../r/c29a94cdbf.md) — Actas y escritos anónimos · Caps. 18. 20-21: edición van Beek, Nimega 1936, pp. 42. 46-52
- **8 de marzo. San Juan de Dios, Religioso** — [Jesucristo es fiel, lo provee todo](../r/2f14ed18c3.md) — San Juan de Dios · Archivo general de la Orden Hospitalaria, Cuaderno: De las cartas..., ff. 23v-24r, 27rv: O. Marcos, Cartas y escritos de nuestro glorioso padre san Juan de Dios, Madrid 1935, pp. 18-19. 48-50
- **8 de marzo San Juan de Dios, Religioso** — [Jesucristo es fiel, lo provee todo](../r/2f14ed18c3.md) — San Juan de Dios · Archivo general de la Orden Hospitalaria, Cuaderno: De las cartas..., ff. 23v-24r, 27rv: O. Marcos, Cartas y escritos de nuestro glorioso padre san Juan de Dios, Madrid 1935, pp. 18-19. 48-50
- **9 de marzo. Santa Francisca Romana, Religiosa** — [La paciencia y caridad de Santa Francisca](../r/cf156644ef.md) — Actas y escritos anónimos · Caps. 6-7: Acta Sanctorum Martii 2, *188—*189
- **9 de marzo Santa Francisca Romana, Religiosa** — [La paciencia y caridad de Santa Francisca](../r/cf156644ef.md) — Actas y escritos anónimos · Caps. 6-7: Acta Sanctorum Martii 2, *188—*189
- **17 de marzo. San Patricio, Obispo** — [Muchos pueblos renacieron a Dios por mí](../r/8a72452eac.md) — San Patricio · Caps. 14-16: PL 53, 808-809
- **17 de marzo San Patricio, Obispo** — [Muchos pueblos renacieron a Dios por mí](../r/8a72452eac.md) — San Patricio · Caps. 14-16: PL 53, 808-809
- **18 de marzo. San Cirilo de JerusalénObispo y Doctor de la Iglesia** — [Preparad limpios los vasos para recibir al Espíritu Santo](../r/70548f1247.md) — San Cirilo de Jerusalén · Catequesis 3 1-3: PG 33, 426-430
- **18 de marzo San Cirilo de JerusalénObispo y Doctor de la Iglesia** — [Preparad limpios los vasos para recibir al Espíritu Santo](../r/70548f1247.md) — San Cirilo de Jerusalén · Catequesis 3 1-3: PG 33, 426-430
- **19 de marzo. SAN JOSÉ, Esposo de la Virgen María** — [Protector y custodio fiel](../r/4cce2cca16.md) — San Bernardino de Siena · Sermón 2, Sobre san José: Opera omnia 7,16. 27-30
- **19 de marzo SAN JOSÉ, Esposo de la Virgen María** — [Protector y custodio fiel](../r/4cce2cca16.md) — San Bernardino de Siena · Sermón 2, Sobre san José: Opera omnia 7,16. 27-30
- **23 de marzo. Santo Toribio de Mogrovejo, Obispo** — [Disponibles para toda obra buena](../r/83e64cb458.md) — Concilio Vaticano II · Núms. 12-13.16
- **23 de marzo Santo Toribio de Mogrovejo, Obispo** — [Disponibles para toda obra buena](../r/83e64cb458.md) — Concilio Vaticano II · Núms. 12-13.16
- **25 de marzo. LA ANUNCIACIÓN DEL SEÑOR** — [El ministerio de nuestra reconciliación](../r/b8b4044fec.md) — San León Magno · Carta 28, a Flaviano, 3-4: PL 54, 763-767
- **25 de marzo LA ANUNCIACIÓN DEL SEÑOR** — [El ministerio de nuestra reconciliación](../r/b8b4044fec.md) — San León Magno · Carta 28, a Flaviano, 3-4: PL 54, 763-767

## Abril

- **2 de abril. San Francisco de Paula, Ermitaño** — [Convertíos con sinceridad](../r/ea1b735205.md) — San Francisco de Paula · Carta del año 1486: A. Galuzzi, Origini dell'Ordine dei Minimi, Roma 1967, pp.121-122
- **2 de abril San Francisco de Paula, Ermitaño** — [Convertíos con sinceridad](../r/ea1b735205.md) — San Francisco de Paula · Carta del año 1486: A. Galuzzi, Origini dell'Ordine dei Minimi, Roma 1967, pp.121-122
- **4 de abril. San Isidoro de Sevilla, Obispo y Doctor de la Iglesia** — [El obispo debe tener su puerta abierta a todo el que llegue](../r/bec7de5d5e.md) — San Isidoro de Sevilla · Cap. 5,1. 2: PL 83, 785
- **4 de abril San Isidoro de Sevilla, Obispo y Doctor de la Iglesia** — [El obispo debe tener su puerta abierta a todo el que llegue](../r/bec7de5d5e.md) — San Isidoro de Sevilla · Cap. 5,1. 2: PL 83, 785
- **5 de abril. San Vicente Ferrer, Presbítero** — [Del modo de predicar](../r/441538d456.md) — San Vicente Ferrer · Cap. 13: edición Garganta-Forcada, pp. 513-514
- **7 de abril. San Juan Bautista de la Salle, Presbítero** — [El amor de Cristo nos apremia](../r/ef363b5269.md) — San Juan Bautista de la Salle · Meditación 201
- **7 de abril San Juan Bautista de la Salle, Presbítero** — [El amor de Cristo nos apremia](../r/ef363b5269.md) — San Juan Bautista de la Salle · Meditación 201
- **11 de abril. San Estanislao, Obispo y Mártir** — [La lucha por la fe](../r/068c24c3a0.md) — San Cipriano de Cartago · Carta 58, 8-9.11: CSEL 3, 663-666
- **11 de abril San Estanislao, Obispo y Mártir** — [La lucha por la fe](../r/068c24c3a0.md) — San Cipriano de Cartago · Carta 58, 8-9.11: CSEL 3, 663-666
- **13 de abril. San Martín I, Papa y Mártir** — [El Señor está cerca, ¿por qué me voy a preocupar?](../r/1db0476b40.md) — San Martín · Carta 17: PL 87, 203-204
- **13 de abril San Martín I, Papa y Mártir** — [El Señor está cerca, ¿por qué me voy a preocupar?](../r/1db0476b40.md) — San Martín · Carta 17: PL 87, 203-204
- **17 de abril. Beata Mariana de Jesús Navarro, Virgen** — [La Iglesia nos ofrece a Cristo en la Eucaristía](../r/eecf988e6c.md) — Beata Mariana de Jesús · Ed. Madrid 1965, pág. 254
- **17 de abril Beata Mariana de Jesús Navarro, Virgen** — [La Iglesia nos ofrece a Cristo en la Eucaristía](../r/eecf988e6c.md) — Beata Mariana de Jesús · Ed. Madrid 1965, pág. 254
- **21 de abril. San Anselmo, Obispo y Doctor de la Iglesia** — [Que te conozca y te ame para que encuentre en ti mi alegría](../r/f1557cda4b.md) — San Anselmo de Canterbury · Caps. 14. 16. 26: Opera omnia, edición Schmitt, Seckau [Austria] 1938,1,111-113.121-122
- **21 de abril San Anselmo, Obispo y Doctor de la Iglesia** — [Que te conozca y te ame para que encuentre en ti mi alegría](../r/f1557cda4b.md) — San Anselmo de Canterbury · Caps. 14. 16. 26: Opera omnia, edición Schmitt, Seckau [Austria] 1938,1,111-113.121-122
- **23 de abril. San Jorge, Mártir** — [Protegido inexpugnablemente con el estandarte de la cruz](../r/be481cb2ad.md) — San Pedro Damiani · Sermón 3, Sobre san Jorge: PL 144, 567-571
- **23 de abril San Jorge, Mártir** — [Protegido inexpugnablemente con el estandarte de la cruz](../r/be481cb2ad.md) — San Pedro Damiani · Sermón 3, Sobre san Jorge: PL 144, 567-571
- **24 de abril. San Fidel de Sigmaringa, Presbítero y Mártir** — [Hombre fiel por su nombre y por su vida](../r/6742f68988.md) — Actas y escritos anónimos
- **24 de abril San Fidel de Sigmaringa, Presbítero y Mártir** — [Hombre fiel por su nombre y por su vida](../r/6742f68988.md) — Actas y escritos anónimos
- **25 de abril. SAN MARCOS, Evangelista** — [La predicación de la verdad](../r/565890ef23.md) — San Ireneo de Lyon · Libro 1,10,1-3: PG 7, 550-554
- **25 de abril SAN MARCOS, Evangelista** — [La predicación de la verdad](../r/565890ef23.md) — San Ireneo de Lyon · Libro 1,10,1-3: PG 7, 550-554
- **26 de abril. San Isidoro, Obispo y Doctor de la Iglesia** — [El obispo debe tener su puerta abierta a todo el que llegue](../r/bec7de5d5e.md) — San Isidoro de Sevilla · Cap. 5,1. 2: PL 83, 785
- **26 de abril San Isidoro, Obispo y Doctor de la Iglesia** — [El obispo debe tener su puerta abierta a todo el que llegue](../r/bec7de5d5e.md) — San Isidoro de Sevilla · Cap. 5,1. 2: PL 83, 785
- **26 de abril. San Isidoro, Obispo y Doctor de la Iglesia** — [Superaba a todo el mundo en sabiduría y, más aún, en obras de caridad](../r/0775337ac3.md) — San Isidoro de Sevilla · PL 81,15-17
- **26 de abril San Isidoro, Obispo y Doctor de la Iglesia** — [Superaba a todo el mundo en sabiduría y, más aún, en obras de caridad](../r/0775337ac3.md) — San Isidoro de Sevilla · PL 81,15-17
- **28 de abril. San Pedro Chanel, Presbítero y Mártir** — [La sangre de los mártires es semilla de cristianos](../r/d09503e9f3.md) — Actas y escritos anónimos
- **28 de abril San Pedro Chanel, Presbítero y Mártir** — [La sangre de los mártires es semilla de cristianos](../r/d09503e9f3.md) — Actas y escritos anónimos
- **29 de abril. Santa Catalina de Siena, Virgen y Doctora de la IglesiaPatrona de Europa** — [Gusté y vi](../r/54eb3be049.md) — Santa Catalina de Siena · Cap. 167, Acción de gracias a la Santísima Trinidad: edición latina, Ingolstadt 1583, ff. 290v-291
- **29 de abril Santa Catalina de Siena, Virgen y Doctora de la IglesiaPatrona de Europa** — [Gusté y vi](../r/54eb3be049.md) — Santa Catalina de Siena · Cap. 167, Acción de gracias a la Santísima Trinidad: edición latina, Ingolstadt 1583, ff. 290v-291

## Mayo

- **1 de mayo. San José, Obrero** — [Sobre la actividad humana en todo el mundo](../r/a04ff4c74d.md) — Concilio Vaticano II · Núms. 33-34
- **1 de mayo San José, Obrero** — [Sobre la actividad humana en todo el mundo](../r/a04ff4c74d.md) — Concilio Vaticano II · Núms. 33-34
- **2 de mayo. San Atanasio, Obispo y Doctor de la Iglesia** — [De la encarnación del Verbo](../r/d9ad87be06.md) — San Atanasio de Alejandría · Sermón sobre la encarnación del Verbo, 8-9: PG 25,110-111
- **2 de mayo San Atanasio, Obispo y Doctor de la Iglesia** — [De la encarnación del Verbo](../r/d9ad87be06.md) — San Atanasio de Alejandría · Sermón sobre la encarnación del Verbo, 8-9: PG 25,110-111
- **3 de mayo. SAN FELIPE Y SANTIAGO, Apóstoles** — [La predicación apostólica](../r/3507799aac.md) — Tertuliano · Caps. 20,1-9; 21, 3; 22, 8-10: CCL 1, 201-204
- **3 de mayo SAN FELIPE Y SANTIAGO, Apóstoles** — [La predicación apostólica](../r/3507799aac.md) — Tertuliano · Caps. 20,1-9; 21, 3; 22, 8-10: CCL 1, 201-204
- **4 de mayo. Beato José María Rubio, Presbítero** — [Humildad y oración](../r/6c4e388f42.md) — Beato José María Rubio · Escritos del P. José María Rubio, Apostolado de la Prensa, Madrid 1932, pp. 159-160
- **4 de mayo Beato José María Rubio, Presbítero** — [Humildad y oración](../r/6c4e388f42.md) — Beato José María Rubio · Escritos del P. José María Rubio, Apostolado de la Prensa, Madrid 1932, pp. 159-160
- **10 de mayo. San Juan de Ávila, Presbítero** — [El sacerdote debe ser santo](../r/054f297271.md) — San Juan de Ávila · Plática enviada al padre Francisco Gómez, S. I:, para ser predicada en el Sínodo diocesano de Córdoba del año 1563: BAC 304, Obras completas del santo maestro Juan de Ávila, 3, pp. 364-365. 370. 373
- **10 de mayo San Juan de Ávila, Presbítero** — [El sacerdote debe ser santo](../r/054f297271.md) — San Juan de Ávila · Plática enviada al padre Francisco Gómez, S. I:, para ser predicada en el Sínodo diocesano de Córdoba del año 1563: BAC 304, Obras completas del santo maestro Juan de Ávila, 3, pp. 364-365. 370. 373
- **12 de mayo. San Nereo y San Aquiles, Mártires** — [La pasión de Cristo no se limita únicamente a Cristo](../r/c2fa285511.md) — San Agustín de Hipona · SALMO 61, 4: CCL 39, 773-775
- **12 de mayo San Nereo y San Aquiles, Mártires** — [La pasión de Cristo no se limita únicamente a Cristo](../r/c2fa285511.md) — San Agustín de Hipona · SALMO 61, 4: CCL 39, 773-775
- **13 de mayo. LA BIENAVENTURADA VIRGEN MARÍA DE FÁTIMA** — [María sola abraza al que todo el universo no abarca](../r/18a6be2e7f.md) — San Efrén · Sermón 3 de diversis: Opera omnia, III syr. et lat., Roma 1743, 607
- **13 de mayo LA BIENAVENTURADA VIRGEN MARÍA DE FÁTIMA** — [María sola abraza al que todo el universo no abarca](../r/18a6be2e7f.md) — San Efrén · Sermón 3 de diversis: Opera omnia, III syr. et lat., Roma 1743, 607
- **14 de mayo. SAN MATÍAS, Apóstol** — [Muéstranos, Señor, cuál es el elegido](../r/c3b74fdd55.md) — San Juan Crisóstomo · Homilía 3, 1. 2. 3: PG 60, 33-36. 38
- **14 de mayo SAN MATÍAS, Apóstol** — [Muéstranos, Señor, cuál es el elegido](../r/c3b74fdd55.md) — San Juan Crisóstomo · Homilía 3, 1. 2. 3: PG 60, 33-36. 38
- **15 de mayo. San Isidro, Labrador** — [Sembrad siempre buenas obras](../r/353503c8c8.md) — San Agustín de Hipona · Sermón Morin 11, sobre las bienaventuranzas
- **15 de mayo San Isidro, Labrador** — [Sembrad siempre buenas obras](../r/353503c8c8.md) — San Agustín de Hipona · Sermón Morin 11, sobre las bienaventuranzas
- **17 de mayo. San Pascual Bailón, Religioso** — [La Eucaristía, vínculo de paz y de unidad](../r/d393e9f40d.md) — Papa León XIII · 28 de noviembre de 1897
- **17 de mayo** — [La Eucaristía, vínculo de paz y de unidad](../r/d393e9f40d.md) — Papa León XIII · 28 de noviembre de 1897
- **18 de mayo. San Juan I, Papa y Mártir** — [Porque la vida de Jesucristo sea manifestada en nosotros](../r/f403aeea37.md) — San Juan de Ávila · Carta 58, a unos amigos suyos: BAC 313, Obras completas del santo maestro Juan de Ávila, 5, pp. 298-299
- **18 de mayo San Juan I, Papa y Mártir** — [Porque la vida de Jesucristo sea manifestada en nosotros](../r/f403aeea37.md) — San Juan de Ávila · Carta 58, a unos amigos suyos: BAC 313, Obras completas del santo maestro Juan de Ávila, 5, pp. 298-299
- **20 de mayo. San Bernardino de Siena, Presbítero** — [El Nombre de Jesús, luz de los predicadores](../r/e8c6cdba6c.md) — San Bernardino de Siena · Sermón 49, sobre el glorioso nombre de Jesucristo, cap. 2: Opera omnia 4, 505-506
- **20 de mayo San Bernardino de Siena, Presbítero** — [El Nombre de Jesús, luz de los predicadores](../r/e8c6cdba6c.md) — San Bernardino de Siena · Sermón 49, sobre el glorioso nombre de Jesucristo, cap. 2: Opera omnia 4, 505-506
- **21 de mayo. San Cristóbal Magallanes, Presbítero, y Compañeros, Mártires** — [El que dé testimonio de la verdad será mártir de Cristo](../r/3f9a1fd8c0.md) — San Cesáreo de Arlés · Sermón 225, 1-2: CCL 104, 888-889
- **21 de mayo San Cristóbal Magallanes, Presbítero, y Compañeros, Mártires** — [El que dé testimonio de la verdad será mártir de Cristo](../r/3f9a1fd8c0.md) — San Cesáreo de Arlés · Sermón 225, 1-2: CCL 104, 888-889
- **22 de mayo. Santa Joaquina Vedruna, Religiosa** — [El amor lo puede todo](../r/f00fa1090a.md) — Actas y escritos anónimos
- **22 de mayo Santa Joaquina Vedruna, Religiosa** — [El amor lo puede todo](../r/f00fa1090a.md) — Actas y escritos anónimos
- **24 de mayo. SANTA MARÍA, Auxilio de los Cristianos** — [Mira a María, estrella del mar](../r/323913d51e.md) — San Bernardo de Claraval · Hom. 11 super Missus est, 17: PL 183, 7013-71A
- **24 de mayo SANTA MARÍA, Auxilio de los Cristianos** — [Mira a María, estrella del mar](../r/323913d51e.md) — San Bernardo de Claraval · Hom. 11 super Missus est, 17: PL 183, 7013-71A
- **25 de mayo. San Beda el Venerable, Presbítero y Doctor de la Iglesia** — [Deseo ver a Cristo](../r/7150e5a01f.md) — San Beda · Núms. 4-6: PL 90, 64-66
- **25 de mayo San Beda el Venerable, Presbítero y Doctor de la Iglesia** — [Deseo ver a Cristo](../r/7150e5a01f.md) — San Beda · Núms. 4-6: PL 90, 64-66
- **26 de mayo. San Felipe Neri, Presbítero** — [Estad siempre alegres en el Señor](../r/be75181c92.md) — San Agustín de Hipona · Sermón 171,1-3. 5: PL 38, 933-935
- **26 de mayo San Felipe Neri, Presbítero** — [Estad siempre alegres en el Señor](../r/be75181c92.md) — San Agustín de Hipona · Sermón 171,1-3. 5: PL 38, 933-935
- **27 de mayo. San Agustín de Cantorbery, Obispo** — [Los ingleses han sido revestidos por la luz de la santa fe](../r/fedb6ce324.md) — San Gregorio Magno · Libro 9, 36: MGH, Epistolae 2, 305-306
- **27 de mayo San Agustín de Cantorbery, Obispo** — [Los ingleses han sido revestidos por la luz de la santa fe](../r/fedb6ce324.md) — San Gregorio Magno · Libro 9, 36: MGH, Epistolae 2, 305-306
- **30 de mayo. San Fernando** — [El poder temporal puesto al servicio de Dios y de la Iglesia](../r/a21903eec0.md) — Actas y escritos anónimos
- **30 de mayo San Fernando** — [El poder temporal puesto al servicio de Dios y de la Iglesia](../r/a21903eec0.md) — Actas y escritos anónimos
- **31 de mayo. LA VISITACIÓN DE LA VIRGEN MARÍA** — [María proclama la grandeza del Señor por las obras que ha hecho en ella](../r/28e9c7e8f9.md) — San Beda el Venerable · Libro 1, 4: CCL 122, 25-26. 30
- **31 de mayo LA VISITACIÓN DE LA VIRGEN MARÍA** — [María proclama la grandeza del Señor por las obras que ha hecho en ella](../r/28e9c7e8f9.md) — San Beda el Venerable · Libro 1, 4: CCL 122, 25-26. 30

## Junio

- **1 de junio. San Justino, Mártir** — [Sigo las verdaderas doctrinas de los cristianos](../r/e86943ce2b.md) — San Justino · Caps. 1-5: cf. PG 6,1366-1371
- **1 de junio San Justino, Mártir** — [Sigo las verdaderas doctrinas de los cristianos](../r/e86943ce2b.md) — San Justino · Caps. 1-5: cf. PG 6,1366-1371
- **2 de junio. San Marcelino y San Pedro, Mártires** — [Los que son compañeros de Cristo en el sufrir también lo son en el buen ánimo](../r/f4e240914f.md) — Orígenes · Núms. 41-42: PG 11, 618-619
- **2 de junio San Marcelino y San Pedro, Mártires** — [Los que son compañeros de Cristo en el sufrir también lo son en el buen ánimo](../r/f4e240914f.md) — Orígenes · Núms. 41-42: PG 11, 618-619
- **3 de junio. San Carlos Luanga y Compañeros, Mártires** — [La gloria de los mártires, signo de regeneración](../r/c7750dd522.md) — San Pablo VI · AAS 56 (1964), 905-906
- **3 de junio San Carlos Luanga y Compañeros, Mártires** — [La gloria de los mártires, signo de regeneración](../r/c7750dd522.md) — San Pablo VI · AAS 56 (1964), 905-906
- **5 de junio. San Bonifacio, Obispo y Mártir** — [Pastor solícito que vela sobre la grey de Cristo](../r/be331c07b3.md) — San Bonifacio · Carta 78: MGH, Epistolae, 3, 352. 354
- **5 de junio San Bonifacio, Obispo y Mártir** — [Pastor solícito que vela sobre la grey de Cristo](../r/be331c07b3.md) — San Bonifacio · Carta 78: MGH, Epistolae, 3, 352. 354
- **6 de junio. San Norberto, Obispo** — [](../r/f9f3790f54.md) — Actas y escritos anónimos
- **6 de junio San Norberto, Obispo** — [](../r/f9f3790f54.md) — Actas y escritos anónimos
- **9 de junio. San Efrén, Diácono y Doctor de la Iglesia** — [Los designios divinos son figura del mundo espiritual](../r/3bffdef142.md) — San Efrén · Sermón 3, De fine et admonitione; 2, 4-5: edición Lamy, 3, 216-222
- **9 de junio San Efrén, Diácono y Doctor de la Iglesia** — [Los designios divinos son figura del mundo espiritual](../r/3bffdef142.md) — San Efrén · Sermón 3, De fine et admonitione; 2, 4-5: edición Lamy, 3, 216-222
- **11 de junio. SAN BERNABÉ, Apóstol** — [Vosotros sois la luz del mundo](../r/487d673a65.md) — San Cromacio de Aquilea · Tratado 5,1. 3-4: CCL 9, 405-407
- **11 de junio SAN BERNABÉ, Apóstol** — [Vosotros sois la luz del mundo](../r/487d673a65.md) — San Cromacio de Aquilea · Tratado 5,1. 3-4: CCL 9, 405-407
- **13 de junio San Antonio de Padua, Presbítero y Doctor de la Iglesia** — [La palabra tiene fuerza cuando va acompañada de las obras](../r/d22e844e93.md) — San Antonio de Padua · I, 226
- **15 de junio Santa María Micaela del Santísimo Sacramento** — [Nada hay comparable a la dicha de servir a Dios](../r/764c816e47.md) — Santa María Micaela · Cf. Archivo de la Santa, en Madrid
- **19 de junio San Romualdo, Abad** — [Se negó a sí mismo para seguir a Cristo](../r/b8e63fc831.md) — San Pedro Damiani · Caps. 31 y 69: PL 144, 982-983.1005-1006
- **21 de junio San Luis Gonzaga, Religioso** — [Cantaré eternamente las misericordias del Señor](../r/bb33ac5a90.md) — San Luis Gonzaga · Acta Sanctorum Iunii 5, 878
- **22 de junio San Paulino de Nola, Obispo** — [Dios infunde su amor en los suyos por toda la tierra, por obra del Espíritu Santo](../r/58f9d7b911.md) — San Paulino de Nola · Carta 3, a Alipio,1. 5. 6: CSEL 29,13-14.17-18
- **24 de junio NATIVIDAD DE SAN JUAN BAUTISTA** — [La voz que clama en el desierto](../r/9bad57d0fc.md) — San Agustín de Hipona · Sermón 293, 1-3: PL 38, 1327-1328
- **26 de junio San Pelayo, Mártir** — [La castidad sin la caridad no tiene valor](../r/ad7c8157ac.md) — San Bernardo de Claraval · Carta 42, a Enrique, arzobispo de Sens [Tratado sobre las costumbres y el ministerio de los obispos]), 3, 8: PL 182, 816-817
- **26 de junio San Josémaría Escrivá de Balaguer, Presbítero** — [Conducir en medio del mundo una vida verdaderamente contemplativa](../r/d49c4ea199.md) — San Josemaría Escrivá · Hacia la santidad, ed. Palabra, Madrid 1973, pp. 7-9, 12-13, 20-21, 23-24, 32-33, 40-41, 52
- **27 de junio San Cirilo de Alejandría, Obispo y Doctor de la Iglesia** — [Defensor de la maternidad divina de la virgen María](../r/3b24f12532.md) — San Cirilo de Alejandría · Carta 1: PG 77,14-18. 27-30
- **28 de junio San Ireneo, Obispo y Mártir** — [La gloria de Dios consiste en que el hombre viva, y la vida del hombre consiste en la visión de Dios](../r/24a9abe2f2.md) — San Ireneo de Lyon · Libro 4, 20, 5-7: SC 100, 640-642. 644-648
- **29 de junio SAN PEDRO Y SAN PABLO, Apóstoles** — [Estos mártires, en su predicación, daban testimonio de lo que habían visto](../r/2f712d8edb.md) — San Agustín de Hipona · Sermón 295, 1-2. 4. 7-8: PL 38, 1348-1352

## Julio

- **3 de julio SANTO TOMÁS, Apóstol** — [¡Señor mío y Dios mío!](../r/18d5ad7e62.md) — San Gregorio Magno · Homilía 26, 7-9: PL 76, 1201-1202
- **4 de julio Santa Isabel de Portugal** — [Dichosos los que trabajan por la paz](../r/e108731d63.md) — San Pedro Crisólogo · Sobre la paz: PL 52,347-348
- **5 de julio San Antonio María Zaccaría, Presbítero** — [El discípulo del apóstol Pablo](../r/a3d222ed9a.md) — San Antonio María Zaccaría · J. A. Gabutio, Historia Congregationis Clericorum Regularium sancti Pauli, 1, 8
- **6 de julio Santa María Goretti, Virgen y Mártir** — [Nada temo, porque tú vas conmigo](../r/e3b561ace2.md) — Papa Pío XII · AAS 42 (1950), 581-582
- **9 de julio San Agustín Zhao Rong, Presbítero, y Compañeros, Mártires** — [La sangre de los mártires da testimonio de la fe cristiana](../r/e30d32dc17.md) — San Juan Pablo II · AAS 92, 2000, 849-850
- **11 de julio SAN BENITO, Abad, Patrono de Europa** — [No antepongan nada absolutamente a Cristo](../r/c944e80402.md) — San Benito · Prólogo, 4-22; cap. 72, I-12: CSEL 75, 2-5.162-163
- **13 de julio San Enrique** — [Proveía a la paz y tranquilidad de la Iglesia](../r/48d1a10586.md) — Actas y escritos anónimos · MGH, Scriptores 4, 792-799
- **14 de julio San Camilo de Lelis, Presbítero** — [Servidor de Cristo en la persona de los hermanos](../r/511d93b32e.md) — Actas y escritos anónimos · S. Cicatelli, Vita del P. Camillo de Lellis, Viterbo 1615
- **15 de julio San Buenaventura, Obispo y Doctor de la Iglesia** — [La sabiduría misteriosa revelada por el Espíritu Santo](../r/58fbf6a843.md) — San Buenaventura · Opúsculo sobre el itinerario de la mente hacia Dios, 7,1,2,6: Opera omnia 5, 312-313
- **16 de julio Nuestra Señora del Carmen** — [María, antes de concebir corporalmente, concibió en su espíritu](../r/19a318fd82.md) — San León Magno · Sermón 1 en la Natividad del Señor, 2. 3: PL 54,191-192
- **20 de julio San Apolinar, Obispo y Mártir** — [El mártir reina y vive](../r/f44ec989d7.md) — San Pedro Crisólogo · Sermón 128, 1-3: CCL 24A, 789-791
- **21 de julio San Lorenzo de Brindis, Presbítero y Doctor de la Iglesia** — [La predicación es una función apostólica](../r/d1e2fed48e.md) — San Lorenzo de Brindis · Sermón cuaresmal 2: Opera omnia 5,1, Núms. 48. 50. 52
- **22 de julio Santa María Magdalena** — [Ardía en deseos de Cristo, a quien pensaba que se lo habían llevado](../r/ae5efbefb4.md) — San Gregorio Magno · Homilía 25,1-2. 4-5: PL 76,1189-1193
- **23 de julio SANTA BRÍGIDA, Religiosa, Patrona de Europa** — [Elevación de la mente a Cristo Salvador](../r/73ef712659.md) — Santa Brígida · Oración 2: Revelationum S. Birgittae libri, 2, Roma 1628, pp. 408-410
- **24 de julio San Sarbelio (Charbel) Makllüf, Presbítero** — [Los que están cerca de Dios han sido constituidos médicos de almas](../r/fc78f96a57.md) — San Ammonas · Ep 12: PO 10/6, 1973, 603-607
- **26 de julio Santos Joaquín y Ana, Padres de la Virgen María** — [Por sus frutos los conoceréis](../r/acd120a7f7.md) — San Juan Damasceno · Sermón 6, Sobre la Natividad de la Virgen María, 2. 4. 5. 6: PG 96, 663. 667. 670
- **28 de julio Nuestra Señora de la Paz** — [Naturaleza de la paz](../r/376ee1621b.md) — Concilio Vaticano II · n. 78
- **29 de julio Santa Marta** — [Dichosos los que pudieron hospedar al Señor en su casa](../r/92817b23ce.md) — San Agustín de Hipona · Sermón 103,1-2. 6: PL 38, 613. 615
- **30 de julio San Pedro Crisólogo, Obispo y Doctor de la Iglesia** — [El misterio de la Encarnación](../r/1b5c4949b3.md) — San Pedro Crisólogo · Sermón 148: PL 52, 596-598
- **31 de julio San Ignacio de Loyola, Presbítero** — [Examinad si los espíritus provienen de Dios](../r/3270b9a50b.md) — San Ignacio · Cap. 1, 5-9: Acta Sanctorum Iulii 7 [1868], 647

## Agosto

- **1 de agosto San Alfonso María de Ligorio, obispo y doctor de la Iglesia** — [El amor a Cristo](../r/a31945179e.md) — San Alfonso María de Ligorio · Tratado sobre la práctica del amor a Jesucristo, edición latina, Roma 1909, pp. 9-14
- **1 de Agosto San Alfonso María de Ligorio, obispo y doctor de la Iglesia** — [El amor a Cristo](../r/a31945179e.md) — San Alfonso María de Ligorio · Tratado sobre la práctica del amor a Jesucristo, edición latina, Roma 1909, pp. 9-14
- **2 de agosto San Eusebio de Vercelli, obispo** — [He corrido hasta la meta, he mantenido la fe](../r/3769d68cf2.md) — San Eusebio de Vercelli · Carta 2,1, 3-2, 3; 10,1-11,1: CCL 9,104-105.109
- **4 de agosto San Juan María Vianney, presbítero** — [Hermosa obligación del hombre: orar y amar](../r/2678b3de36.md) — San Juan María Vianney · A. Monnin, Esprit du Curé d'Ars, París 1899, pp. 87-89
- **5 de agosto La Dedicación de la Basílica de Santa María** — [Alabanzas de la Madre de Dios](../r/09a87d2250.md) — San Cirilo de Alejandría · Homilía 4: PG 77, 991. 995-996
- **6 de agosto LA TRANSFIGURACIÓN DEL SEÑOR** — [¡Qué bien se está aquí!](../r/29e7d03d62.md) — San Anastasio Sinaíta · Núms. 6-10: Mélanges d'archéologie et d'histoire 67 (1955), 241-244
- **7 de agosto San Sixto, papay compañeros, mártires** — [Sabemos que los soldados de Cristo no son destruidos sino coronados](../r/7aadec9b6e.md) — San Cipriano de Cartago · Carta 80: CSEL 3, 839-840
- **8 de agosto Santo Domingo de Guzmán, presbítero** — [Hablaba con Dios o de Dios](../r/64341a1ba6.md) — Actas y escritos anónimos · Libellus de principiis Ordinis Praedicatorum; Acta canonizationis sancti Dominici: Monumenta Ordinis Praedicatorum historica 16, Roma 1935, pp: 30ss.146-147
- **Mes de agosto** — [La puerta de la vida se abre a los que creen en el Crucificado](../r/14dfaee560.md) — Santa Teresa Benedicta de la Cruz
- **10 de agosto San Lorenzo, diácono y mártir** — [Administró la Sangre sagrada de Cristo](../r/2d45b0d77d.md) — San Agustín de Hipona · Sermón 304, 1-4: PL 38, 1395-1397
- **11 de agosto Santa Clara, virgen** — [Atiende a la pobreza, la humildad y la caridad de Cristo](../r/c0c0f979b4.md) — Santa Clara · Escritos de santa Clara, edición Ignacio Omaechevarría, Madrid 1970, pp. 339-341
- **12 de agosto Santa Juana Francisca de Chantal, religiosa** — [Es fuerte el amor como la muerte](../r/49ed6516bb.md) — Actas y escritos anónimos · Françoise-Madeleine de Chaugy, Mémoires sur la vie et les vertus de sainte Jeanne- Françoise de Chantal, III, 3: 3.a edición, París 1853, pp. 306-307
- **13 de agosto San Ponciano, papay San Hipólito, presbítero, mártires** — [Fe inquebrantable](../r/9dba0b4911.md) — San Cipriano de Cartago · Carta 10, 2-3. 5: CSEL 3, 491-492. 494-495
- **14 de agosto San Maximiliano María Kolbe, presbítero y mártir** — [El ideal de la vida apostólica es la salvación y santificación de las almas](../r/b3f383e146.md) — San Maximiliano María Kolbe · Gli scritti di Massimiliano Kolbe eroe di Oswiecim e beato della Chiesa, vol. I, Città di Vita, Florencia 1975, pp. 44-46. 113-114
- **15 de agosto LA ASUNCIÓN DE LA VIRGEN MARÍA** — [Tu cuerpo es santo y sobremanera glorioso](../r/76c41f39be.md) — Papa Pío XII · AAS 42 [1950), 760-762. 767-769
- **16 de agosto San Esteban de Hungría** — [Hijo mío, escucha la corrección de tu padre](../r/bf33170d9e.md) — San Esteban · Caps. 1. 2.10: PL 151,1236-1237.1242-1244
- **18 de agosto San Roque** — [No puede ocultarse la luz de los cristianos](../r/fdd1c7e7d5.md) — San Juan Crisóstomo · Homilía 20, 4: PG 60,162-164
- **19 de agosto San Juan Eudes, presbítero** — [Fuente de salvación y de vida verdadera](../r/641b034a73.md) — San Juan Eudes · Libro 1, 5: Opera omnia 6,107.113-115
- **20 de agosto San Bernardo, abad y doctor de la Iglesia** — [Amo porque amo, amo por amar](../r/850374fb91.md) — San Bernardo de Claraval · Sermón 83, 4-6: OPERA OMNIA, edición cisterciense, 2[1958], 300-302
- **21 de agosto San Pío X, papa** — [La voz de la Iglesia que resuena dulcemente](../r/c0afaadb69.md) — San Pío X · AAS 3 [1911), 633-635
- **22 de agosto Santa María Virgen, Reina** — [Reina del mundo y de la paz](../r/295d6dd29c.md) — San Amadeo de Lausana · Homilía 7: SC 72, 188. 190.192. 200
- **23 de agosto Santa Rosa de Lima, virgenPatrona de América Latina** — [Conozcamos el amor de Cristo, que excede todo conocimiento](../r/2647f393eb.md) — Santa Rosa de Lima · Al médico Castillo: edición L. Getino, La patrona de América, Madrid 1928, pp. 54-55
- **24 de agosto San Bartolomé, apóstol** — [Lo débil de Dios es más fuerte que los hombres](../r/d86318ca65.md) — San Juan Crisóstomo · Homilía 4, 3. 4: PG 61, 34-36
- **25 de agosto San Luis, rey de Francia** — [El rey justo hace estable el país](../r/045e51d163.md) — San Luis · Acta Sanctorum Augusti 5 [1868), 546
- **26 de agosto Santa Teresa de Jesús Jornet e Ibars, virgen, Patrona de la Ancianidad** — [Hemos de imitar la pobreza de Jesús](../r/7b8d5e9f9b.md) — Santa Teresa de Jesús · Carta 201: Cartas. Copias auténticas, t. 1. Archivo general de la Congregación, Valencia: Causa de beatificación y canonización de la sierva de Dios Teresa de Jesús Jornet e lbars).
- **27 de agosto Santa Mónica** — [Alcancemos la sabiduría eterna](../r/92c6c73b5f.md) — San Agustín de Hipona · Libro 9,10, 23-11, 28: CSEL 33, 215-219
- **28 de agosto San Agustín, obispo y doctor de la Iglesia** — [¡Oh eterna verdad, verdadera caridad y cara eternidad!](../r/89c0804da9.md) — San Agustín de Hipona · Libros 7, 10. 18; 10, 27: CSEL 33, 157-163. 255
- **29 de agosto El Martirio de San Juan Bautista** — [Precursor del nacimiento y de la muerte de Cristo](../r/1b3c5bc863.md) — San Beda el Venerable · Homilía 23: CCL 122, 354. 356-357
- **30 de agosto Santa Rosa de Lima, virgen, Patrona de Lima, del Perú y de América Latina** — [Conozcamos el amor de Cristo, que excede todo conocimiento](../r/2647f393eb.md) — Santa Rosa de Lima · Al médico Castillo: edición L. Getino, La patrona de América, Madrid 1928, pp. 54-55

## Septiembre

- **1 de septiembre Bienaventurada Virgen María de los Ángeles del Puig** — [Por amor a Cristo, cuando hablo de Él, ni a mí mismo me perdono](../r/c02be0247c.md) — San Gregorio Magno · Libro 1,11, 4-6: CCL 142,170-172
- **8 de septiembre La Natividad de la Santísima Virgen María** — [Lo antiguo ha pasado, lo nuevo ha comenzado](../r/33dfb5308a.md) — San Andrés de Creta · Sermón 1: PG 97, 806-810
- **9 de septiembre San Pedro Claver, presbítero** — [Enviado para dar la Buena Noticia a los que sufren, para vendar los corazones desgarrados, para proclamar la amnistía a los cautivos.](../r/1d47679640.md) — San Pedro Claver · Epist. diei 31 maii 1627 ad Superiorem suum data; Edit (in lingua hispanica) A. Valtierra, S.L., San Pedro Claver, Cartagena, 1964, pp. 140-141
- **11 de septiembre Nuestra Señora de Coromoto** — [Piensa en María e invócala en todos los momentos](../r/a29a40b93f.md) — San Bernardo de Claraval · Homilía 2, 17, 1-33: SCh 390, 1993, 168-170
- **13 de septiembre San Juan Crisóstomo, obispo y doctor de la Iglesia** — [Para mí la vida es Cristo, y una ganancia el morir](../r/45f2159664.md) — San Juan Crisóstomo · Homilía antes de partir en exilio, 1-3: PG 52, 427-430
- **14 de septiembre LA EXALTACIÓN DE LA SANTA CRUZ** — [La cruz es la gloria y exaltación de Cristo](../r/1985e28089.md) — San Andrés de Creta · Sermón 10, Sobre la Exaltación de la santa cruz: PG 97, 1018-1019. 1022-1023
- **15 de septiembre Nuestra Señora de los Dolores** — [La madre estaba junto a la cruz](../r/d69f701fca.md) — San Bernardo de Claraval · Sermón en el Domingo infraoctava de la Asunción, 14-15: Opera Omnia, edición cisterciense, 5 (1968), (273-274
- **16 de septiembre San Cornelio, papa, y Cipriano, obispo, mártires** — [Una fe generosa y firme](../r/fbfbe6ebca.md) — San Cipriano de Cartago · Carta 60,1-2. 5: CSEL 3, 691-692. 694-695
- **18 de septiembre San Juan Macías, religioso** — [En el mundo, pero no del mundo](../r/8682879c02.md) — San Gregorio Magno · Libro 2, homilía 36,11-13: PL 76,1272-1274
- **19 de septiembre San Jenaro, obispo y mártir** — [Soy obispo para vosotros, soy cristiano con vosotros](../r/8598d9c073.md) — San Agustín de Hipona · Sermón 340,1: PL 38,1483-1484
- **Mes de septiembre** — [La fe es coronada por el amor y la perseverancia](../r/0ae24f8323.md) — San Andrés Kim Taegon · Pro Corea. Documenta. ed. Mission Catholique Séoul, Seúl/París 1938, vol. 1, 74-75
- **21 de septiembre SAN MATEO, apóstol y evangelista** — [Jesús lo vio y, porque lo amó, lo eligió](../r/3e1e13b480.md) — San Beda el Venerable · Homilía 21: CCL 122,149-151
- **22 de septiembre Beato José Aparicio Sanz y Compañeros, mártires** — [](../r/eacbbc81c5.md) — Sin identificar
- **23 de septiembre San Pío de Pietrelcina, presbítero** — [Piedras del edificio eterno](../r/db3002c2e5.md) — San Pío de Pietrelcina · Edición 1994: II, 87-90, n. 8
- **24 de septiembre Nuestra Señora de la Merced** — [La maternidad de María en la economía de la gracia](../r/190be06986.md) — Concilio Vaticano II · Núms. 61-62
- **26 de septiembre San Cosme y San Damián, mártires** — [Preciosa es la muerte de los mártires, comparada con el precio de la muerte de Cristo](../r/ec8c61e83f.md) — San Agustín de Hipona · Sermón 329: En el natalicio de los mártires, 1-2: PL 38,1454-1455
- **27 de septiembre San Vicente de Paúl, presbítero** — [El servicio a los pobres ha de ser preferido a todo](../r/f4e8746467.md) — San Vicente de Paúl · Carta 2.546: Correspondance, entretiens, documents, París 1922-1925, 7
- **28 de septiembre San Wenceslao, mártir** — [Cuando un rey juzga lealmente a los desvalidos, su trono está siempre firme](../r/811539dbd2.md) — Actas y escritos anónimos · Edición M. Weingart, Praga 1934, 974-983
- **29 de septiembre SANTOS ARCÁNGELES MIGUEL, GABRIEL Y RAFAEL** — [El nombre de "ángel" designa la función, no el ser](../r/f1cecca40a.md) — San Gregorio Magno · Homilía 34, 8-9: PL 76,1250-1251
- **30 de septiembre San Jerónimo, presbítero y doctor de la Iglesia** — [Ignorar las Escrituras es ignorar a Cristo](../r/d02922eeb5.md) — San Jerónimo · Núms. 1. 2: CCL 73,1-3

## Octubre

- **1 de octubre Santa Teresa del Niño Jesús, virgen y doctora de la Iglesia** — [En el corazón de la Iglesia, yo seré el amor](../r/199a075336.md) — Santa Teresa del Niño Jesús · Manuscrits autobiographiques, Lisieux 1957, 227-229
- **2 de octubre Santos Ángeles Custodios** — [Que te guarden en tus caminos](../r/f5f990ea88.md) — San Bernardo de Claraval · Sermón 12 sobre el salmo 90 «Qui habitat», 3, 6-8: Opera omnia, edición cisterciense, 4 [1966], 458-462
- **3 de octubre San Francisco de Borja, presbítero** — [Sólo son grandes antes Dios los que se tienen por pequeños](../r/ea2adada04.md) — San Francisco de Borja · Carta 7, año 1545: Monumenta historica Societatis Iesu, Madrid 1908, III, pp. 9-10
- **4 de octubre San Francisco de Asís** — [Debemos ser sencillos, humildes y puros](../r/7e2f62c5d1.md) — San Francisco de Asís · Opúsculos, edición Quaracchi, Florencia [1949], 87-94
- **Mes de octubre** — [Acción de gracias y petición del pueblo cristiano](../r/c2ee26b2e1.md) — San Clemente I, papa · Caps. 59, 2-60, 4: Funk 1,135-141
- **6 de octubre San Bruno, presbítero** — [Se alegra mi espíritu en el Señor](../r/a3f7308201.md) — San Bruno · Núms. 1-3: SC 88, 82-84
- **7 de octubre Nuestra Señora del Rosario** — [Conviene meditar los misterios de salvación](../r/47a8c5ac73.md) — San Bernardo de Claraval · Sermón sobre el acueducto: Opera omnia, edición cisterciense, 5 [1968], 282-283
- **8 de octubre San Luis Beltrán, presbítero** — [Id y haced discípulos de todos los pueblos](../r/f857dc5975.md) — Concilio Vaticano II · Núms. 4-5
- **9 de octubre San Dionisio, obispo, y Compañeros, mártires** — [Sé un testigo fiel y valeroso](../r/39d638a42e.md) — San Ambrosio de Milán · Cap. 20, 47-50: CSEL 62, 467-469
- **10 de octubre Santo Tomás de Villanueva, obispo** — [Santidad e integridad de vida, virtudes indispensables del buen prelado](../r/c5a518b588.md) — Santo Tomás de Villanueva · Jn, 10, 1-11: Divi Thomae a Villanueva, Opera omnia, Manila, 1822, pp. 324-325
- **12 de octubre NUESTRA SEÑORA DEL PILAR** — [El Pilar, lugar privilegiado de oración t de gracia](../r/12e42598a5.md) — Actas y escritos anónimos
- **12 de octubre NUESTRA SEÑORA DEL PILAR** — [Eficacia pastoral del culto tributado a la Virgen](../r/bfb9dd4e7e.md) — San Pablo VI · AAS 66 [1974),113-168
- **14 de octubre San Calixto I, papa y mártir** — [En la persecución se inflige la muerte, pero sigue la inmortalidad](../r/9863921d18.md) — San Cipriano de Cartago · Cap. 13: CSEL 3, 346-347
- **15 de octubre Santa Teresa de Jesús, virgen y doctora de la Iglesia** — [Acordémonos del amor de Cristo](../r/c5303cd3e6.md) — Santa Teresa de Jesús · Cap. 22, 6-7. 12. 14
- **16 de octubre Santa Eduvigis, religiosa** — [Tendía siempre hacia Dios](../r/3d4c2ac009.md) — Actas y escritos anónimos · Acta Sanctorum Octobris 8, 1853, 201-202
- **17 de octubre San Ignacio de Antioquía, obispo y mártir** — [Soy trigo de Dios, y he de ser molido por los dientes de las fieras](../r/12228c3735.md) — San Ignacio de Antioquía · Caps. 4, 1-2; 6, 1-8, 3: Funk 1, 217-223
- **18 de octubre SAN LUCAS, evangelista** — [El Señor viene detrás de sus predicadores](../r/1a23f13cd3.md) — San Gregorio Magno · Homilía 17,1-3: PL 76,1139
- **19 de octubre San Pedro de Alcántara, presbítero** — [Pobreza, austeridad y dulzura de Pedro](../r/6237f64728.md) — Santa Teresa de Jesús · Cap. 27,16-20
- **22 de octubre San Juan Pablo II, papa** — [¡No tengáis miedo! ¡Abrid las puertas a Cristo!](../r/18f57e55ec.md) — San Juan Pablo II · 22 de octubre 1978
- **23 de octubre San Juan de Capistrano, presbítero** — [La vida de los clérigos virtuosos ilumina y serena](../r/b6b2d876b3.md) — San Juan de Capistrano · Parte 1, Venecia 1580, 2
- **24 de octubre San Antonio María Claret, obispo** — [Nos apremia el amor de Cristo](../r/dd13e3753f.md) — San Antonio María Claret · L'egoismo vinto, Roma 1869, 60; Autobiografía, cap. 34
- **28 de octubre SAN SIMÓN Y SAN JUDAS, apóstoles** — [Como el Padre me ha enviado, así también os envío yo](../r/eae33b1529.md) — San Cirilo de Alejandría · Libro 12, cap. 1: PG 74, 707-710

## Noviembre

- **1 de noviembre TODOS LOS SANTOS** — [Apresurémonos hacia los hermanos que nos esperan](../r/5983526009.md) — San Bernardo de Claraval · Sermón 2: Opera omnia, edición cisterciense, 5 (1968), 364-368
- **2 de noviembre CONMEMORACIÓN DE TODOS LOS FIELES DIFUNTOS** — [Muramos con Cristo, y viviremos con Él](../r/67e74c703e.md) — San Ambrosio de Milán · Libro 2, 40. 41. 46. 47.132.133: CSEL 73, 270-274. 323-324
- **3 de noviembre San Martín de Porres, religioso** — [Martín de la caridad](../r/5be67790ca.md) — San Juan XXIII · Día 6 de mayo de 1962: AAS 54 [1962], 306-309
- **6 de noviembre Mártires de España del Siglo XX** — [Todos, por el bautismo, hemos sido hechos templos de Dios](../r/eace2796dd.md) — San Cesáreo de Arlés · Sermón 229,1-3: CCL 104, 905-908
- **10 de noviembre San León Magno, papa y doctor de la Iglesia** — [El especial servicio de nuestro ministerio](../r/0a12847b12.md) — San León Magno · Sermón 4,1-2: PL 54,148-149
- **11 de noviembre San Martín de Tours, obispo** — [Martín, pobre y humilde](../r/f59b7706a1.md) — Sin identificar · Carta 3, 6. 9-10. 11.14-17. 21: SC 133, 336-344
- **12 de noviembre San Josafat, obispo y mártir** — [Derramó su sangre por la unidad de la Iglesia](../r/57601a8dee.md) — Papa Pío XI · AAS 15 [1923], 573-582
- **13 de noviembre San Leandro, obispo** — [Gozo de la unidad de la Iglesia](../r/a37f865ee6.md) — San Leandro · PL 72, 894-895
- **15 de noviembre San Alberto Magno, obispo y doctor de la Iglesia** — [Pastor y doctor para la edificación del Cuerpo de Cristo](../r/e4c27abffa.md) — San Alberto Magno · Lc 22,19: Opera omnia, París 1890-1899, 23, 672-674
- **16 de noviembre Santa Margarita de Escocia** — [Santidad del matrimonio y de la familia](../r/29ededa159.md) — Concilio Vaticano II · Núm. 48
- **17 de noviembre Santa Isabel de Hungría** — [Isabel reconoció y amó a Cristo en la persona de los pobres](../r/1096e82e1a.md) — Actas y escritos anónimos · Al Sumo pontífice, año 1232: A. Wyss, Hessisches Urkundenbuch 1, Leipzig 1879, 31-35
- **18 de noviembre La Dedicación de las Basílicas de los Apóstoles San Pedro y San Pablo** — [Pedro y Pablo, dos vástagos plantados por Dios](../r/fb437b6c70.md) — San León Magno · Sermón 82, En el natalicio de los apóstoles Pedro y Pablo, 1, 6-7: PL 54, 426-428
- **21 de noviembre La Presentación de la Santísima Virgen** — [Dio fe al mensaje divino y concibió por su fe](../r/8710ce6aa9.md) — San Agustín de Hipona · Sermón 25, 7-8: PL 46, 937-938
- **22 de noviembre Santa Cecilia, virgen y mártir** — [Cantad a Dios con maestría y con júbilo](../r/134d9d8640.md) — San Agustín de Hipona · Salmo 32, sermón 1, 7-8: CCL 38, 253-254
- **23 de noviembre San Clemente I, papa y mártir** — [Maravillosos son los dones de Dios](../r/37a5d3ed03.md) — San Clemente I, papa · Caps. 35,1-5; 36,1-2; 37,1. 4-5; 38,1-2. 4: Funk 1,105-109
- **24 de noviembre San Andrés Dung-Lac y Compañeros, mártires** — [Alabad al Señor, todas las naciones](../r/9889934434.md) — San Pablo Le-Bao-Tinh · Launay, A.: Le clergé tonkinois et ses prétres martyrs, MEP París. 1925, pp. 80-83).
- **25 de noviembre Santa Catalina de Alejandría, virgen y mártir** — [¿Cómo seguir a Cristo?](../r/4059fdf75c.md) — San Cesáreo de Arlés · Sermón 159, 1. 3-6: CCL 104, 650. 652-654
- **30 de noviembre. SAN ANDRÉS, APÓSTOL** — [Hemos encontrado al Mesías](../r/9f96e41641.md) — San Juan Crisóstomo · Homilía 19,1: PG 59,120-121
- **30 de noviembre SAN ANDRÉS, APÓSTOL** — [Hemos encontrado al Mesías](../r/9f96e41641.md) — San Juan Crisóstomo · Homilía 19,1: PG 59,120-121

## Diciembre

- **3 de diciembre. San Francisco Javier, Presbítero** — [¡Ay de mí si no anuncio el Evangelio!](../r/33106bab51.md) — San Francisco Javier · Cartas 4 [1542]... y 5 [1544]: BAC 101, Cartas y escritos de san Francisco Javier, pp. 107-108. 115-116
- **4 de diciembre. San Juan Damasceno, Presbítero y Doctor de la Iglesia** — [Me llamaste, Señor, para servir a tus hijos](../r/577f72f6e6.md) — San Juan Damasceno · Cap. l: PG 95, 417-419
- **6 de diciembre. San Nicolás, Obispo** — [Que la fuerza del amor supere el pesar por la muerte](../r/7c42633cea.md) — San Agustín de Hipona · Tratado 123, 5: CCL 36, 678-680
- **7 de diciembre. San Ambrosio, Obispo y Doctor de la Iglesia** — [Que el encanto de tu palabra cautive el favor del pueblo](../r/4b08893a78.md) — San Ambrosio de Milán · Carta 2,1-2. 4-5. 7: PL 16 [edición 1845], 847-881
- **8 de diciembre. LA INMACULADA CONCEPCIÓN DE SANTA MARÍA VIRGEN** — [¡Oh Virgen, por tu bendición queda bendita toda criatura!](../r/5db8eda892.md) — San Anselmo de Canterbury · Sermón 52: PL 158, 955-956
- **9 de diciembre. San Juan Diego de Cuauhtlatoazin** — [La Virgen María consoló a Juan Diego](../r/f955545fd0.md) — San Juan Pablo II · México, 31 de julio de 2002).
- **10 de diciembre. Santa Eulalia de Mérida Virgen y Mártir** — [Los mártires están reservados para la diadema del Señor](../r/db808d8174.md) — San Cipriano de Cartago · Cap. 2: PL 4, 479-480
- **11 de diciembre. San Dámaso I, papa** — [Damos culto a los mártires con un culto de amor y participación](../r/63dab05df0.md) — San Agustín de Hipona · Lib. 20, 21: CSEL 25, 562-563
- **MES DE DiCIEMBRE** — [La voz de la tórtola se ha escuchado en nuestra tierra](../r/381f17998a.md) — Actas y escritos anónimos · «Nicán Mupohua», 12ª edición, Buena Prensa, México, D. F., 1971, pp. 3-19. 21
- **14 de diciembre. San Juan de la Cruz Presbítero y Doctor de la Iglesia** — [Conocimiento del misterio escondido en Cristo Jesús](../r/9eaf4dc293.md) — San Juan de la Cruz · Canciones 37, 4 y 36, 13, declaración
- **17 de Diciembre** — [El misterio de nuestra reconciliación](../r/04acdc5a17.md) — San León Magno · Carta 31, 2-3: PL 54, 791-793
- **18 de Diciembre** — [Dios ha revelado su caridad por medio de su Hijo](../r/6eb29ef724.md) — Carta a Diogneto · Caps. 8, 5-9, 6 Funck 1, 325-327
- **19 de Diciembre** — [La economía de la encarnación redentora](../r/86d68262d2.md) — San Ireneo de Lyon · Lib. 3, 20, 2-3: SC 34, 342-344
- **20 de Diciembre** — [Todo el mundo espera la respuesta de María](../r/9e664bdca7.md) — San Bernardo de Claraval · Homilía 4, 8-9: Opera Omnia, Edit. Cister. 4, 1966, 53-54
- **21 de Diciembre** — [La visitación de santa María Virgen](../r/d737449272.md) — San Ambrosio de Milán · Lib. 2, 19.22-23.26-27: CCL 14, 39-42
- **21 de diciembre. San Pedro Canisio Presbítero y Doctor de la Iglesia** — [Una plegaria de San Pedro Canisio](../r/e2930f2779.md) — San Pedro Canisio · Edición O. Braunsberger, Petri Canisii Epistulae et Acta, I, Friburgo de Brisgovia 1896, pp. 53-55
- **22 de Diciembre** — [Cántico de María](../r/5cfdcbf569.md) — San Beda el Venerable · Lib. 1, 46-55: CCL 120, 37-39
- **23 de Diciembre** — [Manifestación del misterio escondido](../r/3f715f3c02.md) — San Hipólito de Roma · Caps. 9-12: PG 10, 815-819
- **23 de diciembre. San Juan de Kety, Presbítero** — [Dios era el mismo en su corazón y en sus labios](../r/0945932565.md) — Sin identificar · 2 de febrero de 1767: Bullarii romani continuatio IV parte II, Prato 1843, pp.1314-1316
- **24 de Diciembre** — [La fidelidad brota de la tierra y la justicia mira desde el cielo](../r/16ce118d06.md) — San Agustín de Hipona · Sermón 185 PL 38, 997-999
- **25 de Diciembre. LA NATIVIDAD DEL SEÑOR** — [Reconoce, cristiano, tu dignidad](../r/b95c5cacec.md) — San León Magno · Sermón 1 en la Navidad del Señor 13: PL 54, 190-193
- **25 de Diciembre. LA NATIVIDAD DEL SEÑOR** — [Mirad: la virgen concebirá y dará a luz un hijo, y le pondrá por nombre Emmanuel](../r/d752733d49.md) — San Pedro Crisólogo · Sermón 145: PL 52, 588
- **25 de Diciembre. LA NATIVIDAD DEL SEÑOR** — [Hoy nos ha nacido un Salvador](../r/59135e1d09.md) — San Elredo de Rievaulx · Sermón 1 de la Natividad del Señor : PL 195, 226-227
- **25 de Diciembre. LA NATIVIDAD DEL SEÑOR** — [El Dueño de todo vino en forma de siervo](../r/44914f3857.md) — Sin identificar · En la Natividad del Salvador Edic Schwartz, ACO t. 3, parte 1,157-159.
- **25 de Diciembre. LA NATIVIDAD DEL SEÑOR** — [El Verbo se hizo carne y puso su morada entre nosotros](../r/b9eb587bee.md) — San Basilio Magno · 2, 6; PG 31, 1459-1462. 1471-1474
- **26 de diciembre. San Esteban, protomártir** — [Las armas de la caridad](../r/5fdf0ebeba.md) — San Fulgencio de Ruspe · Sermón 3,1-3. 5-6: CCL 91 A, 905-909
- **26 de diciembre. San Esteban, Protomártir** — [Las armas de la caridad](../r/5fdf0ebeba.md) — San Fulgencio de Ruspe · Sermón 3,1-3. 5-6: CCL 91 A, 905-909
- **26 de diciembre. San Esteban, protomártir** — [Dichosos los perseguidos por mi causa](../r/e0034f37e5.md) — San Gregorio de Nisa · Discurso 27, 9: PG 44, 1291-1295. 1299-1302
- **27 de Diciembre. San Juan Apóstol y Evangelista** — [La misma Vida se ha manifestado en la carne](../r/97ed0ea4b9.md) — San Agustín de Hipona · Tratado 1,1. 3: PL 35,1978.1980
- **27 de diciembre. San Juan Apóstol y Evangelista** — [La misma Vida se ha manifestado en la carne](../r/97ed0ea4b9.md) — San Agustín de Hipona · Tratado 1,1. 3: PL 35,1978.1980
- **27 de Diciembre. San Juan Apóstol y Evangelista** — [Juan es aquel a quien Cristo amó con amor de predilección](../r/5fa731094e.md) — San Gregorio Palamás · Homilía 20: PG 151, 266.271
- **28 de Diciembre. Santos Inocentes** — [Todavía no hablan, y ya confiesan a Cristo](../r/d7169f3b32.md) — San Quodvultdeus · Sermón 2 sobre el Símbolo: PL 40, 655
- **28 de diciembre. Santos Inocentes** — [Todavía no hablan, y ya confiesan a Cristo](../r/d7169f3b32.md) — San Quodvultdeus · Sermón 2 sobre el Símbolo: PL 40, 655
- **28 de Diciembre. Santos Inocentes** — [Están de pie delante del Cordero contemplando su gloria](../r/f89423ada3.md) — San Beda el Venerable · Homilía 1, 10: CCL 122, 68. 71-72
- **29 de Diciembre. Día V - Octava de Navidad** — [Exultemos y alegrémonos en ti](../r/9fec4075d4.md) — San Gregorio de Nisa · Hom 1: PG 44, 765-766.783.786
- **29 de diciembre. Santo Tomás Becket, Obispo y Mártir** — [Nadie recibe el premio si no compite conforme al reglamento](../r/8ea94cc172.md) — Santo Tomás Becket · Carta 74: PL 190, 533-536
- **30 de Diciembre. Día VI - Octava de Navidad** — [Oración al buen pastor](../r/166af8ea5a.md) — San Gregorio de Nisa · Cap. 2: PG 44, 802
- **31 de Diciembre. Día VII - Octava de Navidad** — [Dios se ha manifestado en la carne](../r/12af9921bd.md) — San Gregorio de Nisa · Homilía 5: PG 44, 859-862. 863. 874. 875
- **31 de diciembre. San Silvestre I, Papa** — [La paz de Constantino](../r/355e1ea0d9.md) — Eusebio de Cesarea · Lib. 10,1-3: PG 20, 842-847

## Otras fiestas de santos

- **El mejor homenaje a María: amar a Dios y al prójimo** — [Con la claridad de tu mente iluminas la gracia de tu cuerpo](../r/5f40c7680c.md) — San Ambrosio de Milán · Cap. 12, 68. 74-75; 13, 77-78: PL 16 [edición 1845], 281. 283. 285-286
- **Mes de julio** — [La maternidad de María en la economía de la gracia](../r/190be06986.md) — Concilio Vaticano II · Núms. 61-62
- **El mismo día 8 de febrero. Santa Josefina Bakhita, Virgen** — [Bienaventurados los limpios de corazón porque ellos verán a Dios](../r/7681e334e8.md) — San Agustín de Hipona · Sermón 53, 1-6: Revue bénédictine 104, 1994, 21-24
- **El mismo día 8 de febrero Santa Josefina Bakhita, Virgen** — [Bienaventurados los limpios de corazón porque ellos verán a Dios](../r/7681e334e8.md) — San Agustín de Hipona · Sermón 53, 1-6: Revue bénédictine 104, 1994, 21-24
- **Mes de febrero** — [Hagamos el elogio de los hombres ilustres](../r/7ae9f1b7dd.md) — Actas y escritos anónimos · Monumenta Ordinis Servorum Beatae Maríae Virginis, 1, 3. 5. 6. 9.11: pp. 71 ss.
- **Mes de abril** — [Superaba a todo el mundo en sabiduría y, más aún, en obras de caridad](../r/0775337ac3.md) — San Isidoro de Sevilla · PL 81,15-17
- **Mes de abril** — [Del modo de predicar](../r/441538d456.md) — San Vicente Ferrer · Cap. 13: edición Garganta-Forcada, pp. 513-514
- **Del prólogo de san Braulio de Zaragoza, obispo, a las obras de san Isidoro** — [Del modo de predicar](../r/441538d456.md) — San Vicente Ferrer · Cap. 13: edición Garganta-Forcada, pp. 513-514
- **Lunes después del II domingo de Pascua** — [Del modo de predicar](../r/441538d456.md) — San Vicente Ferrer · Cap. 13: edición Garganta-Forcada, pp. 513-514
- **El mismo día 13 de abril. San Hermenegildo, Mártir** — [La caridad, garantía de la unidad de la Iglesia](../r/b0982856d5.md) — San Juan Crisóstomo · Homilía antes de partir en exilio: PG 52, 427*-430
- **El mismo día 13 de abril San Hermenegildo, Mártir** — [La caridad, garantía de la unidad de la Iglesia](../r/b0982856d5.md) — San Juan Crisóstomo · Homilía antes de partir en exilio: PG 52, 427*-430
- **El mismo día 23 de abril. San Adalberto, Obispo y Mártir** — [Se abrazó a la cruz con todo su cuerpo](../r/6888b00d7f.md) — Actas y escritos anónimos · Acta Sanctorum, Aprilis, III, pp. 186-187).
- **El mismo día 23 de abril San Adalberto, Obispo y Mártir** — [Se abrazó a la cruz con todo su cuerpo](../r/6888b00d7f.md) — Actas y escritos anónimos · Acta Sanctorum, Aprilis, III, pp. 186-187).
- **Mes de abril** — [Fue un prelado de grandísima caridad y amor de Dios](../r/45f4053157.md) — Actas y escritos anónimos · Archivo Secreto Vaticano, Riti-Proces., vol. 1581).
- **El mismo día 28 de abril. San Luis María Griñón de Montfort, Presbítero** — [Todo tuyo](../r/ae951caf61.md) — San Luis María Grignion de Montfort · nn. 120-121.125-126: oeuvres completes, Seuil, Paris 1966, 562-563.566-567). (cf. Obras completas, BAC, n. 451).
- **El mismo día 28 de abril San Luis María Griñón de Montfort, Presbítero** — [Todo tuyo](../r/ae951caf61.md) — San Luis María Grignion de Montfort · nn. 120-121.125-126: oeuvres completes, Seuil, Paris 1966, 562-563.566-567). (cf. Obras completas, BAC, n. 451).
- **Mes de abril** — [La Iglesia está fundada sobre la piedra que confesó Pedro](../r/7a51c183a2.md) — San Agustín de Hipona · Tratado 124, 5: CCL 36, 684-685
- **Jueves de la II semana de Pascua. La Santa Faz de Nuestro Señor Jesucristo** — [Brille sobre nosotros la luz de tu rostro, Señor](../r/21fc37b410.md) — San Ambrosio de Milán · PL 14. 1185
- **Jueves de la II semana de Pascua** — [Brille sobre nosotros la luz de tu rostro, Señor](../r/21fc37b410.md) — San Ambrosio de Milán · PL 14. 1185
- **Jueves de la II semana de Pascua. La Santa Faz de Nuestro Señor Jesucristo** — [El hombre debe imitar a su Creador. Esto es un don de Dios](../r/8bfdd611d3.md) — San León Magno · Homilías sobre el Año Litúrgico, 1 [12]. ed. M. Garrido Bonaño, OSB. BAC. Madrid, 1969, p. 45-46
- **Jueves de la II semana de Pascua** — [El hombre debe imitar a su Creador. Esto es un don de Dios](../r/8bfdd611d3.md) — San León Magno · Homilías sobre el Año Litúrgico, 1 [12]. ed. M. Garrido Bonaño, OSB. BAC. Madrid, 1969, p. 45-46
- **El mismo día 12 de mayo. San Pancracio, Mártir** — [Con él estaré en la tribulación](../r/68f5f8db1b.md) — San Bernardo de Claraval · Sermón 17 sobre el salmo 90: Tú que habitas, 4, 6: Opera omnia, edición cisterciense, 4 [1966), 489-491
- **El mismo día 12 de mayo San Pancracio, Mártir** — [Con él estaré en la tribulación](../r/68f5f8db1b.md) — San Bernardo de Claraval · Sermón 17 sobre el salmo 90: Tú que habitas, 4, 6: Opera omnia, edición cisterciense, 4 [1966), 489-491
- **El mismo día 22 de mayo. Santa Rita de Casia, Religiosa** — [Las palabras de Jesucristo permanecen en nosotros](../r/911754a371.md) — San Agustín de Hipona · Tratado 81, 4: CCL 36, 531-532
- **El mismo día 22 de mayo Santa Rita de Casia, Religiosa** — [Las palabras de Jesucristo permanecen en nosotros](../r/911754a371.md) — San Agustín de Hipona · Tratado 81, 4: CCL 36, 531-532
- **El mismo día 25 de mayo. San Gregorio VII, Papa** — [Una Iglesia libre, casta y católica](../r/34885c585c.md) — San Gregorio · Carta 64 extra Registrum: PL 148, 709-710
- **El mismo día 25 de mayo San Gregorio VII, Papa** — [Una Iglesia libre, casta y católica](../r/34885c585c.md) — San Gregorio · Carta 64 extra Registrum: PL 148, 709-710
- **El mismo día 25 de mayo. Santa María Magdalena de Pazzi, Virgen** — [Ven, Espíritu Santo](../r/42d74366c9.md) — Santa María Magdalena de Pazzi · Manuscritos III, 186. 264; IV, 716: Opere di santa María Magdalena de' Pazzi, Florencia 1965, 4, pp. 200. 269; 6, p.194
- **El mismo día 25 de mayo Santa María Magdalena de Pazzi, Virgen** — [Ven, Espíritu Santo](../r/42d74366c9.md) — Santa María Magdalena de Pazzi · Manuscritos III, 186. 264; IV, 716: Opere di santa María Magdalena de' Pazzi, Florencia 1965, 4, pp. 200. 269; 6, p.194
- **El mismo día 25 de mayo. Santa Vicenta María López Vicuña, Virgen** — [La caridad](../r/a1d0a2e9f3.md) — Santa Vicenta María López Vicuña · Cartas I, Madrid 1976, c. 407
- **El mismo día 25 de mayo Santa Vicenta María López Vicuña, Virgen** — [La caridad](../r/a1d0a2e9f3.md) — Santa Vicenta María López Vicuña · Cartas I, Madrid 1976, c. 407
- **Cuando se celebra como solemnidad:** — [R. Amémonos unos a otros, ya que el amor es de Dios * y todo el que ama ha nacido de Dios y conoce a Dios.](../r/98c5f7d321.md) — Sin identificar
- **El mismo día 26 de mayo. Santa Mariana de Jesús Paredes** — [No sólo buscaba su propia santificación, sino la salvación del prójimo](../r/ed5558d4de.md) — Papa Pío XII · 9 de junio de 1950).
- **El mismo día 26 de mayo Santa Mariana de Jesús Paredes** — [No sólo buscaba su propia santificación, sino la salvación del prójimo](../r/ed5558d4de.md) — Papa Pío XII · 9 de junio de 1950).
- **Sábado anterior al segundo domingo de mayo. NUESTRA SEÑORA DE LOS DESAMPARADOS** — [María, elegida para ser nuestra abogada](../r/98f163b2ae.md) — Santo Tomás de Villanueva · Sermón 3, de la Natividad de la B. V.M. Sermones de la Virgen, Madrid 1952, pp. 208-212).
- **Sábado anterior al segundo domingo de mayo, NUESTRA SEÑORA DE LOS DESAMPARADOS** — [María, elegida para ser nuestra abogada](../r/98f163b2ae.md) — Santo Tomás de Villanueva · Sermón 3, de la Natividad de la B. V.M. Sermones de la Virgen, Madrid 1952, pp. 208-212).
- **El mismo día 20 de enero San Fabián, Papa y Mártir** — [Fabián nos da ejemplo de fe y de fortaleza](../r/2f0e69b904.md) — San Cipriano de Cartago · Cartas 9,1; 8, 2-3: CSEL 3, 488-489. 487-488
- **El mismo día 20 de enero San Sebastián, Mártir** — [Testimonio fiel de Cristo](../r/086fdbf619.md) — San Ambrosio de Milán · Cap. 20, 43-45. 48: CSEL 62, 466-468
- **El mismo día 3 de febrero San Óscar, Obispo** — [Hay que anunciar, con toda libertad, el misterio de Cristo](../r/8a41c7d109.md) — Concilio Vaticano II · Núms. 23-24
- **Jueves después de Pentecostés JESUCRISTO, SUMO Y ETERNO SACERDOTE** — [Cristo, sacerdote y víctima](../r/ea78c8c7bd.md) — Papa Pío XII · AAS 39 [1947], 552-553
- **Mes de mayo** — [María conservaba todas estas cosas en su corazón](../r/37ad439682.md) — San Lorenzo Justiniano · Sermón X, en la fiesta de la Purificación de la Santísima Virgen María: Opera 2, Venecia 1751, 38-39
- **El mismo día 22 de junio San Juan Fisher, Obispo, y Santo Tomás Moro, Mártires** — [Me pongo totalmente en manos de Dios con absoluta esperanza y confianza](../r/6b6d1b1273.md) — Santo Tomás Moro · The English Works of Sir Thomas More, Londres 1557, p.1454
- **Mes de junio** — [Habiendo sufrido por envidia, se han convertido en un magnífico ejemplo](../r/25c228b1bc.md) — San Clemente I, papa · Caps. 5,1-7, 4: Funk 1, 67-71
- **El mismo día 14 de julio San Francisco Solano, Presbítero** — [¡Dios, vida mía, qué suave eres: seas siempre bendito!](../r/b3b0350d74.md) — Actas y escritos anónimos · Acta Sanctorum julii V, París 1868, pp. 884-886).
- **25 de julioSANTIAGO, APÓSTOL, PATRONO DE ESPAÑA** — [Partícipes de la pasión de Cristo](../r/051b1721c1.md) — San Juan Crisóstomo · Homilía 65, 2-4: PG 58, 619-622
- **Mes de julio** — [Partícipes de la pasión de Cristo](../r/051b1721c1.md) — San Juan Crisóstomo · Homilía 65, 2-4: PG 58, 619-622
- **El mismo día 2 de agosto San Pedro Julián Eymard, presbítero** — [Eucaristía: Sacramento de vida](../r/93f52ebe30.md) — San Pedro Julián Eymard · La Présence réelle, vol. 1, París, 1950, pp. 270-271 et 307-308).
- **El mismo día 7 de agosto San Cayetano, presbítero** — [Cristo habite por la fe en nuestros corazones](../r/29658abbf5.md) — San Cayetano · Carta a Elisabet Porto: Studi e Testi 177, Ciudad del Vaticano 1954, pp. 50-51
- **El mismo día 19 de agosto San Ezequiel Moreno, obispo** — [Tú eres mi fortaleza y refugio](../r/5d89e65ef9.md) — San Ezequiel Moreno · Toribio Minguella, O.A. R., Cartas Pastorales, Circulares y otros Escritos del Ilmo. y Rmo. Sr. D. Fr. Ezequiel Moreno y Díaz, Madrid, 1908, pp. 171.173-4).
- **El mismo día 25 de agosto San José Calasanz, presbítero** — [Procuremos vivir unidos a Cristo y agradarle sólo a Él](../r/c4ff714cf0.md) — San José de Calasanz · Memorial al cardenal M. A. Tonti, 1621: Ephemerides Calasantiae 36, 9-10, Roma 1967, pp. 473-474; L. Picanyol, Epistolario di S. Giuseppe Calasanzio, 9 volúmenes, edición calasancia, Roma 1951-1956, passim
- **Mes de septiembre** — [Tratándose de un asunto tan claro, no hay por qué pensarlo más](../r/e58894e986.md) — San Cipriano de Cartago · Cap. 3-6: CSEL 3,112-114
- **El mismo día 16 de septiembre San Juan Macías, religioso** — [Inclina mi corazón a tus preceptos](../r/a963061ee9.md) — San Roberto Belarmino · Grado 1: Opera omnia 6, edición de 1862, 214
- **El mismo día 28 de septiembre San Lorenzo Ruiz y Compañeros, mártires** — ["Qué hermosos son sobre los montes los pies del mensajero que trae la Buena Nueva" (Is 52,7).](../r/182d49209e.md) — San Juan Pablo II · Ecclesia, núm. 2346, 21 noviembre 1987, pp. 25 y 27, nn. 5-7. L'Osservatore Romano, edición española, 25 octubre 1987).
- **El mismo día 9 de octubre San Juan Leonardi, presbítero** — [Te han explicado, hombre, lo que Dios desea de ti](../r/ed41d2c2c8.md) — San Juan Leonardi · Cartas por la reforma universal de toda la Iglesia: en el Archivo de la Orden de Clérigos Regulares de la Madre de Dios
- **El mismo día 10 de octubre San Luis Beltrán, presbítero** — [Estuve enfermo, y me visitasteis](../r/3ee6be000e.md) — San Pablo VI · 25 de enero de 1970: AAS 62, 1970, 82-88
- **Mes de octubre** — [Necesidad de la oración](../r/d1b0a650be.md) — Santa Teresa de Jesús · Cap. 8,1-4
- **El mismo día 16 de octubre Santa Margarita María de Alacoque, virgen** — [Debemos conocer el amor de Cristo, que excede todo conocimiento](../r/6368dac48a.md) — Santa Margarita María de Alacoque · Vie et oeuvres 2, París 1915, 321. 336. 493. 554
- **Mes de octubre** — [No moriré sino por ti, Jesús, que te dignaste morir por mi](../r/44d1167ac8.md) — San Juan de Brébeuf · The Jesuit Relations and Allied Documents, The Burrow Brothers Co, Cleveland 1898, 164.166
- **El mismo día 19 de octubre San Pablo de la Cruz, presbítero** — [Predicamos a Cristo crucificado](../r/4b924471f4.md) — San Pablo de la Cruz · Carta 1, 43; 2, 440. 825
- **Cuando se celebra como solemnidad:** — [Martín de la caridad](../r/5be67790ca.md) — San Juan XXIII · Día 6 de mayo de 1962: AAS 54 [1962], 306-309
- **Mes de noviembre** — [Defensor y restaurador de la fe](../r/8d0e6ef591.md) — San Isidoro de Sevilla · Cap. 41: PL 83, 1103-1104
- **El mismo día 16 de noviembre Santa Gertrudis, virgen** — [Tuviste sobre mí designios de paz y no de aflicción](../r/28e0b01b3e.md) — Santa Gertrudis · Libro 2, 23,1. 3. 5. 8.10: SC 139, 330-340
- **El mismo día 23 de noviembre San Columbano, abad** — [La grandeza del hombre consiste en su semejanza con Dios, con tal de que la conserve](../r/1309b291b5.md) — San Columbano · Instrucción 11, Sobre el amor, 1-2: Opera, Dublín 1957, pp, 106-107
