# San Andrés Kim Taegon

None · None · 1 lecturas

- [La fe es coronada por el amor y la perseverancia](../r/0ae24f8323.md) — San Andrés Kim Taegon · Pro Corea. Documenta. ed. Mission Catholique Séoul, Seúl/París 1938, vol. 1, 74-75 · Propio de los santos — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
