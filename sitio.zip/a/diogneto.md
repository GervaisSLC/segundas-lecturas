# Carta a Diogneto

2nd c. · Letter to Diognetus · 2 lecturas

- [Dios ha revelado su caridad por medio de su Hijo](../r/6eb29ef724.md) — Carta a Diogneto · Caps. 8, 5-9, 6 Funck 1, 325-327 · 18 de Diciembre — Santoral, año par
- [Los cristianos en el mundo](../r/56f27a83e1.md) — Carta a Diogneto · Capítulos 5-6: Funck 1, 397-401 · Martes de la semana V de Pascua (semana 5), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
