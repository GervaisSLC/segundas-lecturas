# San Vicente Ferrer

1350–1419 · St. Vincent Ferrer · 1 lecturas

- [Del modo de predicar](../r/441538d456.md) — San Vicente Ferrer · Cap. 13: edición Garganta-Forcada, pp. 513-514 · 5 de abril. San Vicente Ferrer, Presbítero — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
