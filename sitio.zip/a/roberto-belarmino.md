# San Roberto Belarmino

1542–1621 · St. Robert Bellarmine · 1 lecturas

- [Inclina mi corazón a tus preceptos](../r/a963061ee9.md) — San Roberto Belarmino · Grado 1: Opera omnia 6, edición de 1862, 214 · El mismo día 16 de septiembre San Juan Macías, religioso — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
