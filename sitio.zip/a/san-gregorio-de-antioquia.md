# San Gregorio de Antioquía

None · None · 1 lecturas

- [Éste es mi Hijo, el amado, mi predilecto](../r/df1cf7e154.md) — San Gregorio de Antioquía · Homilía 2, 5. 6. 9. 10 en el Bautismo de Cristo: PG 88, 1875-1879. 1882-1883 · Domingo después del 6 de Enero. EL BAUTISMO DEL SEÑOR — Adviento y Navidad, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
