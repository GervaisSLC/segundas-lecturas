# San Benito

c. 480–547 · St. Benedict · 1 lecturas

- [No antepongan nada absolutamente a Cristo](../r/c944e80402.md) — San Benito · Prólogo, 4-22; cap. 72, I-12: CSEL 75, 2-5.162-163 · 11 de julio SAN BENITO, Abad, Patrono de Europa — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
