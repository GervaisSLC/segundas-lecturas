# San Anastasio Sinaíta

d. c. 700 · St. Anastasius of Sinai · 1 lecturas

- [¡Qué bien se está aquí!](../r/29e7d03d62.md) — San Anastasio Sinaíta · Núms. 6-10: Mélanges d'archéologie et d'histoire 67 (1955), 241-244 · 6 de agosto LA TRANSFIGURACIÓN DEL SEÑOR — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
