# San Proclo de Constantinopla

d. 446 · St. Proclus of Constantinople · 2 lecturas

- [Venía a salvar, pero le era también necesario morir](../r/ed41f518b9.md) — San Proclo de Constantinopla · Sermón 1 en alabanza de santa María, 4. 5. 6. 9. 10 : PG 65, 683-687. 690-691 · 7 de Enero — Santoral, año par
- [El amigo de los hombres se ha hecho hombre, naciendo de la Virgen](../r/c519c14650.md) — San Proclo de Constantinopla · Sobre la Natividad del Señor, 1-2: PG 65, 843-846 · Común de Santa maría virgen — Comunes, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
