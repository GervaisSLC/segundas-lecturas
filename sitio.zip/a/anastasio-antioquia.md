# San Anastasio de Antioquía

d. 599 · St. Anastasius of Antioch · 2 lecturas

- [Cristo transformará nuestro cuerpo humilde](../r/c5d99279f1.md) — San Anastasio de Antioquía · Sermón 5, Sobre la resurrección de Cristo, 6-7. 9: PG 89, 1358-1359.1361-1362 · Oficio de Difuntos, año par
- [Era necesario que el Mesías padeciera para entrar en su gloria](../r/1f49734426.md) — San Anastasio de Antioquía · Sermón 4, 1-2: PG 89, 1347-1349 · Martes de la Octava de Pascua — Cuaresma y Pascua, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
