# Eusebio de Cesarea

c. 260–339 · Eusebius of Caesarea · 5 lecturas

- [Una voz grita en el desierto](../r/4cf2a921bf.md) — Eusebio de Cesarea · Cap 40: PG 24, 366-367 · Domingo de la semana II de Adviento (semana 2), año par
- [La paz de Constantino](../r/355e1ea0d9.md) — Eusebio de Cesarea · Lib. 10,1-3: PG 20, 842-847 · 31 de diciembre. San Silvestre I, Papa — Santoral, año par
- [Y tal convenía que fuese nuestro Pontífice: santo, inocente, sin mancha](../r/76e6c169aa.md) — Eusebio de Cesarea · Lib. 5, 3: PG 22, 366-367 · Semana IV de Cuaresma — Cuaresma y Pascua, año par
- [Con razón en estos días desbordamos de gozo, como si ya estuviéramos con el Esposo](../r/9068ddd6c2.md) — Eusebio de Cesarea · Tratado 4-5: PG 24, 698-699 · Martes de la Octava de Pascua — Cuaresma y Pascua, año par
- [Constantemente somos saciados con el cuerpo del Salvador y constantemente participamos de la sangre del Cordero](../r/50961e1f2f.md) — Eusebio de Cesarea · Tratado 7. 9. 10-12: PG 24, 702-706 · Jueves de la Octava de Pascua — Cuaresma y Pascua, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
