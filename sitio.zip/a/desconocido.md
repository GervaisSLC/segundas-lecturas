# Sin identificar

None · None · 18 lecturas

- [El Dueño de todo vino en forma de siervo](../r/44914f3857.md) — Sin identificar · En la Natividad del Salvador Edic Schwartz, ACO t. 3, parte 1,157-159. · 25 de Diciembre. LA NATIVIDAD DEL SEÑOR — Santoral, año par
- [Venga también ahora la Palabra del Señor a quienes la esperamos en silencio](../r/5f39d26e02.md) — Sin identificar · Sermón 1: SC 192, 45. 52. 60 · 4 de Enero — Santoral, año par
- [Dios era el mismo en su corazón y en sus labios](../r/0945932565.md) — Sin identificar · 2 de febrero de 1767: Bullarii romani continuatio IV parte II, Prato 1843, pp.1314-1316 · 23 de diciembre. San Juan de Kety, Presbítero — Santoral, año par
- [Derramaré sobre vosotros un agua pura, y os daré un corazón nuevo](../r/161f6bc7e1.md) — Sin identificar · Domingo de Pascua de la Resurrección del Señor — Cuaresma y Pascua, año par
- [R. Amémonos unos a otros, ya que el amor es de Dios * y todo el que ama ha nacido de Dios y conoce a Dios.](../r/98c5f7d321.md) — Sin identificar · Cuando se celebra como solemnidad: — Santoral, año par
- [El bautismo, figura de la pasión de Cristo](../r/b34c016f27.md) — Sin identificar · Catequesis 20 [Mistagógica 2], 4-6: PG 33, 1079-1082 · Jueves de la Octava de Pascua — Cuaresma y Pascua, año impar
- [La unción del Espíritu Santo](../r/5586a31718.md) — Sin identificar · Catequesis 21 [Mistagógica 3], 1-3: PG 33, 1087-1091 · Viernes de la Octava de Pascua — Cuaresma y Pascua, año impar
- [El pan celestial y la bebida de salvación](../r/dd269a4df0.md) — Sin identificar · Catequesis 22 [Mistagógica 4], 1. 3-6. 9: PG 33, 1098-1106 · Sábado de la Octava de Pascua — Cuaresma y Pascua, año impar
- [Fundemos en Cristo nuestra fe](../r/5abe0bb926.md) — Sin identificar · Hom 21: PLS 3, 854-855 · Domingo de la semana IX del Tiempo Ordinario (semana 9), año impar
- [Dios no nos pide otra cosa que la conversión](../r/322d41302c.md) — Sin identificar · PG 61, 745-751 · Domingo de la semana XI del Tiempo Ordinario (semana 11), año impar
- [Cristo es rey y sacerdote eterno](../r/bb6ef23e3c.md) — Sin identificar · Tratado 39-40: CCL 69, 340-341 · Sábado de la semana XIII del Tiempo Ordinario (semana 13), año impar
- [Los apóstoles predicaban a Jesús crucificado](../r/ddc0985751.md) — Sin identificar · 14, 7-8: ed. E. M. Buytaert, Spicilegium S. Lovaniense 26 [1953], 326-328 · Lunes de la semana VII del Tiempo Ordinario (semana 7), año par
- [La sabiduría de Dios nos mezcló su vino y puso su mesa](../r/2e681c01ed.md) — Sin identificar · Cap 9: PG 87, 1,1299-1303 · Miércoles de la semana XIV del Tiempo Ordinario (semana 14), año par
- [Jesucristo es el mismo ayer y hoy y siempre](../r/97d65785e5.md) — Sin identificar · PLS 4, 34-35 · Viernes de la semana XXIII del Tiempo Ordinario (semana 23), año impar
- [La perfecta conversión a Dios](../r/dc871aa846.md) — Sin identificar · Hom. en la dedicación de una iglesia : Opera omnia, t. 1, 1888, 701-702 · Semana XXXI DEL TIEMPO ORDINARIO, año impar
- [](../r/eacbbc81c5.md) — Sin identificar · 22 de septiembre Beato José Aparicio Sanz y Compañeros, mártires — Santoral, año impar
- [Martín, pobre y humilde](../r/f59b7706a1.md) — Sin identificar · Carta 3, 6. 9-10. 11.14-17. 21: SC 133, 336-344 · 11 de noviembre San Martín de Tours, obispo — Santoral, año impar
- [Cristo, como buen pastor, intercede por nosotros, miserables](../r/9c2948857b.md) — Sin identificar · Parte 2, 3-4: Ed. J. Leclercq, 1946, 125-126 · Martes de la semana XXXIII del Tiempo Ordinario (semana 33), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
