# Santa María Bernarda Soubirous

None · None · 1 lecturas

- [La Señora me habló](../r/0b0cc88cd1.md) — Santa María Bernarda Soubirous · Carta al padre Gondrand, año 1861: cf. A. Ravier, Les ècrits de sainte Bernadette Soubirous, París 1961, pp. 53-59 · 11 de febrero. NUESTRA SEÑORA DE LOURDES — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
