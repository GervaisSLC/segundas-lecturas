# San Hipólito de Roma

c. 170–235 · St. Hippolytus of Rome · 4 lecturas

- [Manifestación del misterio escondido](../r/3f715f3c02.md) — San Hipólito de Roma · Caps. 9-12: PG 10, 815-819 · 23 de Diciembre — Santoral, año par
- [La Palabra hecha carne nos diviniza](../r/e92981101e.md) — San Hipólito de Roma · Cap. 10, 33-34: PG 16, 3452-3453 · 30 de Diciembre. Día VI - Octava de Navidad — Santoral, año impar
- [David fue figura de Cristo](../r/fc932760ff.md) — San Hipólito de Roma · Homilía 1, 1-4. 2 sobre David y Goliat: CSCO 264 [Scriptores Iberici t. 16] 1-3 · Lunes de la semana XIV del Tiempo Ordinario (semana 14), año impar
- [Los santos profetas se han convertido en ojos para nosotros](../r/9408ff87e1.md) — San Hipólito de Roma · Tratado 2: Edit CSCO vol 264 [Scriptores Iberici t. 16], 55 · Lunes de la semana XXIX del Tiempo Ordinario (semana 29), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
