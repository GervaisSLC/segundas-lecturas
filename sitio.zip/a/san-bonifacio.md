# San Bonifacio

None · None · 1 lecturas

- [Pastor solícito que vela sobre la grey de Cristo](../r/be331c07b3.md) — San Bonifacio · Carta 78: MGH, Epistolae, 3, 352. 354 · 5 de junio. San Bonifacio, Obispo y Mártir — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
