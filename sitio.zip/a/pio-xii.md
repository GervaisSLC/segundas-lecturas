# Papa Pío XII

1876–1958 · Pope Pius XII · 5 lecturas

- [La esposa es el sol de la familia](../r/b6123f0872.md) — Papa Pío XII · Discorsi e radiomessaggi, 11 de marzo de 1942:3,385-390 · Común de santas mujeres — Comunes, año par
- [No sólo buscaba su propia santificación, sino la salvación del prójimo](../r/ed5558d4de.md) — Papa Pío XII · 9 de junio de 1950). · El mismo día 26 de mayo. Santa Mariana de Jesús Paredes — Santoral, año par
- [Cristo, sacerdote y víctima](../r/ea78c8c7bd.md) — Papa Pío XII · AAS 39 [1947], 552-553 · Jueves después de Pentecostés JESUCRISTO, SUMO Y ETERNO SACERDOTE — Santoral, año impar
- [Nada temo, porque tú vas conmigo](../r/e3b561ace2.md) — Papa Pío XII · AAS 42 (1950), 581-582 · 6 de julio Santa María Goretti, Virgen y Mártir — Santoral, año impar
- [Tu cuerpo es santo y sobremanera glorioso](../r/76c41f39be.md) — Papa Pío XII · AAS 42 [1950), 760-762. 767-769 · 15 de agosto LA ASUNCIÓN DE LA VIRGEN MARÍA — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
