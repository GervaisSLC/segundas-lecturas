# San Ireneo de Lyon

c. 130–202 · St. Irenaeus of Lyons · 17 lecturas

- [Cuando venga Cristo, Dios será visto por todos los hombres](../r/354f766de9.md) — San Ireneo de Lyon · Lib 4, 20, 4-5: SC 100, 634-640 · Miércoles de la semana III de Adviento (semana 3), año par
- [La economía de la encarnación redentora](../r/86d68262d2.md) — San Ireneo de Lyon · Lib. 3, 20, 2-3: SC 34, 342-344 · 19 de Diciembre — Santoral, año par
- [Eva y María](../r/f168e743bd.md) — San Ireneo de Lyon · Lib. 5,19, 1; 20, 2; 21, 1: SC 153, 248-250. 260-264 · Viernes de la semana II de Adviento (semana 2), año impar
- [La amistad de Dios](../r/823ba7d8e6.md) — San Ireneo de Lyon · Lib. 4, 13—14, 1: SC 100, 534-540 · Sábado después de Ceniza — Cuaresma y Pascua, año par
- [La alianza del Señor](../r/c65064c94e.md) — San Ireneo de Lyon · Lib. 4,16, 1-5: SC 100, 564-572 · Viernes de la semana II de Cuaresma (semana 2), año par
- [El envío del Espíritu Santo](../r/5942ae421e.md) — San Ireneo de Lyon · Libro 3, 17, 1-3: SC 34, 302-306 · Domingo de Pentecostés — Cuaresma y Pascua, año par
- [La predicación de la verdad](../r/565890ef23.md) — San Ireneo de Lyon · Libro 1,10,1-3: PG 7, 550-554 · 25 de abril. SAN MARCOS, Evangelista — Santoral, año par
- [La oblación pura de la Iglesia](../r/6cc80a5fe1.md) — San Ireneo de Lyon · Lib. 4, 18, 1-2. 4. 5: SC 100, 596-598. 606. 610-612 · Sábado de la semana I de Cuaresma (semana 1), año impar
- [La eucaristía, arras de la resurrección](../r/25954fa224.md) — San Ireneo de Lyon · Lib. 5, 2, 2-3: SC 153, 30-38 · Miércoles de la semana III de Pascua (semana 3), año impar
- [Cristo, primicias de nuestra resurrección](../r/f0844ab785.md) — San Ireneo de Lyon · Lib. 3, 19, 1. 3-20, 1: SC 34, 332. 336-338 · Domingo de la semana VI del Tiempo Ordinario (semana 6), año impar
- [Trayéndose a sí mismo, Cristo nos trajo toda novedad](../r/369a33f64a.md) — San Ireneo de Lyon · Lib 4, 34, 1.2.3: SC 100, 846-848; 850-854 · Domingo de la semana VIII del Tiempo Ordinario (semana 8), año impar
- [La gloria de Dios consiste en que el hombre viva, y la vida del hombre consiste en la visión de Dios](../r/24a9abe2f2.md) — San Ireneo de Lyon · Libro 4, 20, 5-7: SC 100, 640-642. 644-648 · 28 de junio San Ireneo, Obispo y Mártir — Santoral, año impar
- [La economía del madero nos ha manifestado al Verbo, que estaba oculto a nuestros ojos](../r/62832f273e.md) — San Ireneo de Lyon · Lib. 5, 17, 3-4: SC 153, 230-234 · Domingo de la semana XIX del Tiempo Ordinario (semana 19), año impar
- [Tanto en la ley como en el evangelio, el primero y principal mandamiento es amar a Dios](../r/23eb3ac28c.md) — San Ireneo de Lyon · Lib 4, 12,1—13,3: SC 100, 508-516 · Domingo de la semana XXII del Tiempo Ordinario (semana 22), año impar
- [Quiero misericordia y no sacrificios](../r/5b23edcf95.md) — San Ireneo de Lyon · Lib. 4, 17, 4-6: SC 100, 590-594 · Tiempo Ordinario, año impar
- [Yo soy la resurrección y la vida](../r/7b0c930c6e.md) — San Ireneo de Lyon · Lib 4, 5, 2—5, 4: SC 100, 428-436 · Semana XXXII DEL TIEMPO ORDINARIO, año impar
- [El Padre es conocido por la manifestación del Hijo](../r/e86b5adad4.md) — San Ireneo de Lyon · Lib 4, 6, 3.5.6.7: SC 100, 442.446.448-454 · Sábado de la semana XXVIII del Tiempo Ordinario (semana 28), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
