# San Efrén

c. 306–373 · St. Ephrem the Syrian · 5 lecturas

- [Vigilad, pues vendrá de nuevo](../r/3664f76eff.md) — San Efrén · Cap. 18, 15-17: SC 121, 325-328 · Jueves de la semana I de Adviento (semana 1), año par
- [María sola abraza al que todo el universo no abarca](../r/18a6be2e7f.md) — San Efrén · Sermón 3 de diversis: Opera omnia, III syr. et lat., Roma 1743, 607 · 13 de mayo. LA BIENAVENTURADA VIRGEN MARÍA DE FÁTIMA — Santoral, año par
- [Los designios divinos son figura del mundo espiritual](../r/3bffdef142.md) — San Efrén · Sermón 3, De fine et admonitione; 2, 4-5: edición Lamy, 3, 216-222 · 9 de junio. San Efrén, Diácono y Doctor de la Iglesia — Santoral, año par
- [La cruz de Cristo, salvación del género humano](../r/420a588dce.md) — San Efrén · Sermón 20, 3-4.9: Opera, ed. Lamy, 1, 152-158. 166-168 · Jueves de la semana III de Pascua (semana 3), año impar
- [La palabra de Dios, fuente inagotable de vida](../r/99d985a24e.md) — San Efrén · Cap 1, 18-19: SC 121, 52-53 · Domingo de la semana XIV del Tiempo Ordinario (semana 14), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
