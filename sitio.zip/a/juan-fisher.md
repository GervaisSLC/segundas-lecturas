# San Juan Fisher

1469–1535 · St. John Fisher · 2 lecturas

- [Las maravillas de Dios](../r/0875a6071c.md) — San Juan Fisher · Opera omnia, edic. 1597, pp. 1588-1589 · Viernes de la semana II de Cuaresma (semana 2), año impar
- [Si alguno peca, tenemos a uno que abogue ante el Padre](../r/9365cce2d2.md) — San Juan Fisher · Comentario sobre el Salmo 129, Opera omnia, ed. 1579 p. 1610 · Domingo de la semana III de Cuaresma (semana 3) - Año A: Jn 4, 5-42, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
