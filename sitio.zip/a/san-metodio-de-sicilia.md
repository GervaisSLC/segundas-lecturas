# San Metodio de Sicilia

None · None · 1 lecturas

- [Su bondad provenía del mismo Dios, fuente de todo bien](../r/4a33254134.md) — San Metodio de Sicilia · Analecta Bollandiana 68, 76-78 · 5 de febrero. Santa Águeda, Virgen y Mártir — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
