# San Hipólito de Roma

None · None · 2 lecturas

- [¡Venid al bautismo de la inmortalidad!](../r/bd9d6ef23f.md) — San Hipólito de Roma · En la santa Teofanía : PG 10, 858-859 · Domingo después del 6 de Enero. EL BAUTISMO DEL SEÑOR — Adviento y Navidad, año par
- [El agua y el Espíritu](../r/deca38d75e.md) — San Hipólito de Roma · Sermón 2.6-8.10: PG 10.854.858-859.862 · 8 de Enero o Martes después del Domingo de Epifanía — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
