# San Andrés de Creta

c. 650–740 · St. Andrew of Crete · 4 lecturas

- [Bendito el que viene, como rey, en nombre del Señor](../r/1d1605e628.md) — San Andrés de Creta · Sermón 9 sobre el domingo de Ramos : PG 97, 990-994 · Domingo de Ramos en la Pasión del Señor — Cuaresma y Pascua, año par
- [Lo antiguo ha pasado, lo nuevo ha comenzado](../r/33dfb5308a.md) — San Andrés de Creta · Sermón 1: PG 97, 806-810 · 8 de septiembre La Natividad de la Santísima Virgen María — Santoral, año impar
- [La cruz es la gloria y exaltación de Cristo](../r/1985e28089.md) — San Andrés de Creta · Sermón 10, Sobre la Exaltación de la santa cruz: PG 97, 1018-1019. 1022-1023 · 14 de septiembre LA EXALTACIÓN DE LA SANTA CRUZ — Santoral, año impar
- [Mira a tu rey, que viene a ti justo y victorioso](../r/b775312098.md) — San Andrés de Creta · Sermón 9, sobre el domingo de Ramos : PG 97, 1002 · Martes de la semana XIX del Tiempo Ordinario (semana 19), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
