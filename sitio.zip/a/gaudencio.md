# San Gaudencio de Brescia

d. c. 410 · St. Gaudentius of Brescia · 2 lecturas

- [La rica herencia del nuevo Testamento](../r/3194ec0b23.md) — San Gaudencio de Brescia · Tratado 2, CSEL 68, 30-32 · Jueves de la semana II de Pascua (semana 2), año impar
- [La eucaristía, Pascua del Señor](../r/f73693864a.md) — San Gaudencio de Brescia · Tratado 2: CSEL 68, 26. 29-30 · Sábado de la semana V de Pascua (semana 5), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
