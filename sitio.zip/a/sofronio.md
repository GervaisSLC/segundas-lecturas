# San Sofronio de Jerusalén

c. 560–638 · St. Sophronius of Jerusalem · 2 lecturas

- [La bendición del Padre ha brillado para los hombres por medio de María](../r/d7928279c6.md) — San Sofronio de Jerusalén · Sermón 2, en la Anunciación de la Santísima Virgen, 21-22. 26: PG 87, 3, 3242. 3250 · Común de Santa maría virgen — Comunes, año par
- [Acojamos la luz clara y eterna](../r/eea7e82284.md) — San Sofronio de Jerusalén · Sermón 3, Sobre el Hypapanté, 6. 7: PG 87, 3, 3291-3293 · 2 de febrero LA PRESENTACIÓN DEL SEÑOR — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
