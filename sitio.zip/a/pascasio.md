# San Pascasio Radberto

c. 785–865 · St. Paschasius Radbertus · 2 lecturas

- [Velad, para estar preparados](../r/560f5ec606.md) — San Pascasio Radberto · Lib. 11, cap 24: PL 120, 799-800 · Domingo de la semana I de Adviento (semana 1), año par
- [¡Fijaos qué esperanza tan cierta de salvación se ha dado a los creyentes!](../r/b267d1cb80.md) — San Pascasio Radberto · Lib. 4, cap. 6: PL 120, 280-281 · Sábado de la semana XX del Tiempo Ordinario (semana 20), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
