# Clemente de Alejandría

c. 150–215 · Clement of Alexandria · 11 lecturas

- [En seguir a Cristo está nuestra salvación](../r/f42ba11338.md) — Clemente de Alejandría · Lib. 1, cap. 6, 2627. 3031: SC 70, 159. 161. 167 · Domingo de la semana III de Pascua (semana 3) - Año A: Lc 24, 13-35, año par
- [Yo soy vuestro preceptor](../r/0f206e38b9.md) — Clemente de Alejandría · Lib 1, cap 7: PG 8, 315-318 · Martes de la semana XIII del Tiempo Ordinario (semana 13), año par
- [Hemos de honrar a Dios durante toda la vida](../r/5a0b00949d.md) — Clemente de Alejandría · Lib 7, cap 7: PG 9, 450-451.458-459 · Jueves de la semana XIII del Tiempo Ordinario (semana 13), año par
- [Revistámonos con las armas de la paz](../r/fcb1f322ec.md) — Clemente de Alejandría · Exhortación a los paganos, Cap. 11; PG 8, 235-238 · Viernes de la semana XXI del Tiempo Ordinario (semana 21), año impar
- [Adorar a Dios mediante la verdadera santidad de las obras y del conocimiento](../r/d770b471d1.md) — Clemente de Alejandría · Lib. 6: PG 9, 295-298 · Domingo de la semana XXIII del Tiempo Ordinario (semana 23), año impar
- [La verdadera penitencia consiste en no recaer en las mismas faltas](../r/43d600ead2.md) — Clemente de Alejandría · 39-40: PG 9, 643-646 · Domingo de la semana XXVI del Tiempo Ordinario (semana 26), año impar
- [Si quieres ser perfecto](../r/c16b0fcd99.md) — Clemente de Alejandría · Caps 5.10: PG 9, 610.614 · Domingo de la semana XXVIII del Tiempo Ordinario (semana 28), año impar
- [Acojamos la luz y hagámonos discípulos del Señor](../r/d870d7bad4.md) — Clemente de Alejandría · Cap 11: PG 8, 230-234 · Semana XXX DEL TIEMPO ORDINARIO, año impar
- [Llevemos desde ahora una vida sobria, honrada y religiosa aguardando la aparición gloriosa del gran Dios](../r/b42ff5f42f.md) — Clemente de Alejandría · Cap 1: PG 8, 59-63 · Jueves de la semana XXIII del Tiempo Ordinario (semana 23), año par
- [El hombre inmortal es un magnífico himno de Dios](../r/4abea81449.md) — Clemente de Alejandría · Cap 10: PG 8, 223-228 · Viernes de la semana XXVIII del Tiempo Ordinario (semana 28), año par
- [Dichosos los que derraman su sangre por causa de Dios](../r/430d190746.md) — Clemente de Alejandría · Lib 4, 7: PG 8, 1255.1259.1263.1266.1267 · Miércoles de la semana XXXII del Tiempo Ordinario (semana 32), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
