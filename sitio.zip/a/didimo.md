# Dídimo de Alejandría

c. 313–398 · Didymus the Blind · 3 lecturas

- [El misterio del agua](../r/901aba4fc6.md) — Dídimo de Alejandría · Lib. 2, 13-14: PG 39, 691-698 · Jueves de la semana V de Cuaresma (semana 5), año par
- [El bautismo nos hace inmortales y nos deifica](../r/f7c9c0463f.md) — Dídimo de Alejandría · Lib. 2, 14: PG 39, 710-718 · Viernes de la Octava de Pascua — Cuaresma y Pascua, año par
- [El Espíritu Santo nos renueva en el bautismo](../r/ea8251735b.md) — Dídimo de Alejandría · Libro 2, 12: PG 39, 667-674 · Domingo de la semana VI de Pascua (semana 6) - Año A: Jn 14, 15-21, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
