# San Lorenzo de Brindis

1559–1619 · St. Lawrence of Brindisi · 4 lecturas

- [Llora Cristo por la sinagoga, a la que tanto amaba](../r/6d03db7ff2.md) — San Lorenzo de Brindis · Homilía en el domingo noveno de Pentecostés 2, 6-7: Opera omnia, t. 8, 514-517 · Domingo de la semana XVI del Tiempo Ordinario (semana 16), año impar
- [Todo lo ha hecho bien](../r/0a55e767ce.md) — San Lorenzo de Brindis · Homilía 1 en el domingo XI de Pentecostés, 1.9.11.12: Opera omnia, t. 8, 124.134.136-138 · Domingo de la semana XXIII del Tiempo Ordinario (semana 23), año impar
- [Tú, cristiano, eres la moneda del impuesto](../r/dcd3aa2f3d.md) — San Lorenzo de Brindis · Homilía l,2.3.4.6 en el domingo 22 después de Pentecostés: Opera omnia, t. 8, 335-336.339-340.346 · Semana XXIX DEL TIEMPO ORDINARIO, año impar
- [Tanto amó Dios al mundo](../r/edc954382f.md) — San Lorenzo de Brindis · Hom. 1, 5-6 en el lunes después de Pentecostés: Opera omnia, t. 8, 1943, 85-87 · Domingo de la semana XXIX del Tiempo Ordinario (semana 29), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
