# San Juan Eudes

1601–1680 · St. John Eudes · 2 lecturas

- [Fuente de salvación y de vida verdadera](../r/641b034a73.md) — San Juan Eudes · Libro 1, 5: Opera omnia 6,107.113-115 · 19 de agosto San Juan Eudes, presbítero — Santoral, año impar
- [El misterio de Cristo en nosotros y en la Iglesia](../r/233f2e3ced.md) — San Juan Eudes · Parte 3, 4: Opera omnia 1, 310-312 · Viernes de la semana XIX del Tiempo Ordinario (semana 19), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
