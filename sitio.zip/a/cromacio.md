# San Cromacio de Aquilea

d. c. 407 · St. Chromatius of Aquileia · 1 lecturas

- [Vosotros sois la luz del mundo](../r/487d673a65.md) — San Cromacio de Aquilea · Tratado 5,1. 3-4: CCL 9, 405-407 · 11 de junio. SAN BERNABÉ, Apóstol — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
