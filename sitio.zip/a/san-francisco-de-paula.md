# San Francisco de Paula

None · None · 1 lecturas

- [Convertíos con sinceridad](../r/ea1b735205.md) — San Francisco de Paula · Carta del año 1486: A. Galuzzi, Origini dell'Ordine dei Minimi, Roma 1967, pp.121-122 · 2 de abril. San Francisco de Paula, Ermitaño — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
