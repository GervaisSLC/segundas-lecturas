# Adviento y Navidad — año impar

[Volver al calendario](index.md) · [Guía para IAs](../llms.txt)

## Semana I de Adviento

- **Domingo de la semana I de Adviento (semana 1)** — [Velad, para estar preparados](../r/560f5ec606.md) — San Pascasio Radberto · Lib. 11, cap 24: PL 120, 799-800
- **Domingo de la semana I de Adviento (semana 1)** — [A Dios no le gusta condenar, sino salvar](../r/7509359350.md) — San Agustín de Hipona · Sermón 18, 1-2: CCL 61, 245-246
- **Domingo de la semana I de Adviento (semana 1)** — [Aguardamos al Salvador](../r/8f5f226f2b.md) — San Bernardo de Claraval · Sermón 4 de Adviento 1, 3-4: Opera omnia, edit. cister. 4, 1966, 182-185
- **Domingo de la semana I de Adviento (semana 1)** — [Este tiempo nos recuerda las dos venidas del Señor](../r/753cda82c5.md) — San Elredo de Rievaulx · Sermón 1 sobre la venida del Señor: PL 195, 209-210
- **Lunes de la semana I de Adviento (semana 1)** — [El cimiento de nuestro edificio es Cristo](../r/e5660b242c.md) — San Hilario de Poitiers · Sal 14, 4-5: CSEL 22, 86-88
- **Martes de la semana I de Adviento (semana 1)** — [Visión escatológica de la Iglesia](../r/bdd8c1c2cd.md) — San Cirilo de Alejandría · Lib. 1, 2: PG 70, 67-71
- **Miércoles de la semana I de Adviento (semana 1)** — [Mira, llego en seguida y traigo conmigo mi salario, para pagar a cada uno su propio trabajo](../r/8f821e61bc.md) — Pedro de Blois · Sermón 3 sobre la venida del Señor: PL 207, 569-572
- **Jueves de la semana I de Adviento (semana 1)** — [Mira, yo envío mi mensajero delante de ti](../r/ad27e05cbb.md) — San Odilón de Cluny · Sermón 10, sobre San Juan Bautista: PL 142, 1019-1020
- **Viernes de la semana I de Adviento (semana 1)** — [Nos llamamos cristianos y en Cristo está puesta toda nuestra esperanza](../r/cdef373edf.md) — San Cirilo de Alejandría · Lib. 3, t. 5: PG 70, 850-851
- **Sábado de la semana I de Adviento (semana 1)** — [Todavía hoy la voz de Juan nos interpela](../r/ee9adb7ce7.md) — San Máximo de Turín · Sermón 88, 1-3: CCL 23, 359-360

## Semana II de Adviento

- **Domingo de la semana II de Adviento (semana 2)** — [Convertíos, porque está cerca el Reino de los cielos](../r/6aaa580a0d.md) — San Agustín de Hipona · Serm. 109 1 : PL 38,636
- **Domingo de la semana II de Adviento (semana 2)** — [Allanad los senderos del Señor](../r/ab8b4447c4.md) — Orígenes · Hom. 22, 1-2: SC 87, 301-302
- **Domingo de la semana II de Adviento (semana 2)** — [Todos verán la salvación de Dios](../r/d22adc551d.md) — San Bernardo de Claraval · Sermón 1 en el Adviento, 9-10: Opera omnia, edit. Cist. 4, 1966, 167-169
- **Domingo de la semana II de Adviento (semana 2)** — [Adelantémonos a la salida del sol, salgamos a su encuentro](../r/66ee500bf9.md) — San Ambrosio de Milán · Sermón 19, 30-32: CSEL 62, 437-439
- **Lunes de la semana II de Adviento (semana 2)** — [El Hijo entregará al reinado de Dios, a los que él llamó al reino](../r/b007b76509.md) — San Hilario de Poitiers · Lib. 11, 36-40: PL 10, 423-425
- **Martes de la semana II de Adviento (semana 2)** — [Cristo regirá como pastor las naciones que se le han confiado](../r/e1cb98b2ce.md) — San Hilario de Poitiers · Sal 2, 31.34 35.37: CSEL 22, 60.63.64.65
- **Miércoles de la semana II de Adviento (semana 2)** — [Su gloria llenará la tierra](../r/c13c788e3c.md) — San Cirilo · Lib. 4, or. 1: PG 70, 859-861
- **Jueves de la semana II de Adviento (semana 2)** — [Por la fe en Cristo hemos sacudido el enojoso y pesado yugo del pecado](../r/86fea11605.md) — San Cirilo de Alejandría · Lib 3, t l: PG 70, 563-566
- **Viernes de la semana II de Adviento (semana 2)** — [Eva y María](../r/f168e743bd.md) — San Ireneo de Lyon · Lib. 5,19, 1; 20, 2; 21, 1: SC 153, 248-250. 260-264
- **Sábado de la semana II de Adviento (semana 2)** — [Vino el perdón, y saltaron las cadenas del pecado](../r/5551e2ec10.md) — San Ambrosio de Milán · 45, 16-17: CSEL 64, 340-342

## Semana III de Adviento

- **Domingo de la semana III de Adviento (semana 3)** — [¿Eres tú el que ha de venir o tenemos que esperar a otro?](../r/e89752cee2.md) — San Ambrosio de Milán · Lib. 5, 93-95.99-102.109: CCL 14, 165-166.167-168.171-177
- **Domingo de la semana III de Adviento (semana 3)** — [En medio de vosotros hay uno que no conocéis](../r/c891ecfb3c.md) — Ruperto de Deutz · Lib. III, cap 3: SC 165, 26-28
- **Domingo de la semana III de Adviento (semana 3)** — [Seamos un edificio sólido, que ninguna tormenta consiga derribar](../r/1851822d39.md) — Orígenes · Hom. 26, 3-5: SC 87, 341-343
- **Domingo de la semana III de Adviento (semana 3)** — [El deseado de las naciones](../r/2ad10d5549.md) — San Agustín de Hipona · Sermón 20,1: Comentario al Salmo 118, 81
- [Los hombres de fe son los que reciben la bendición con Abrahán el fiel](../r/d83ed7ae20.md) — San Cirilo de Alejandría · Num. 7, 72: PG 71, 774-775
- **Martes de la semana III de Adviento (semana 3)** — [Vendrá el Señor y su doctrina superará a la ley](../r/75064d122e.md) — San Cirilo de Alejandría · Núm. 3, 32: PG 72, 330-331
- **Miércoles de la semana III de Adviento (semana 3)** — [Cuando entregare el reino a Dios Padre, Cristo reinará con los que son reyes](../r/1fb6dd186e.md) — San Hilario de Poitiers · Salmo 60, 5-6: CSEL 22, 205-207
- **Jueves de la semana III de Adviento (semana 3)** — [Cristo es el camino para los que buscan a Dios](../r/32418a9c47.md) — San Ambrosio de Milán · Sermón 11, 4-6: CSEL 62, 234-236
- **Viernes de la semana III de Adviento (semana 3)** — [El Verbo de Dios vino por su benignidad hacia nosotros](../r/55d9831093.md) — San Atanasio de Alejandría · Núm. 8-9: PG 25, 110-111

## Navidad y su Octava

- **Domingo dentro de la Octava de Navidad. LA SAGRADA FAMILIA DE JESÚS, MARÍA Y JOSÉ** — [Junto al Niño Jesús están María y José](../r/6ac6ae87ce.md) — San Juan Crisóstomo · Homilía sobre el día de Navidad: PG 56, 392
- **Domingo dentro de la Octava de Navidad. LA SAGRADA FAMILIA DE JESÚS, MARÍA Y JOSÉ** — [Al asumir la condición de esclavo, Cristo, en cierto modo, fue contado entre los siervos](../r/667d1c59bd.md) — San Cirilo de Alejandría · Homilía 12: PG 77, 1042. 1047. 1050
- **Domingo dentro de la Octava de Navidad. LA SAGRADA FAMILIA DE JESÚS, MARÍA Y JOSÉ** — [Angustiados buscamos a Jesús](../r/fcd955ab28.md) — Orígenes · Homilía 18, 2-5: Edit GCS 9, 112-113
- **Año C (1): Lc 2, 41-52** — [Las armas de la caridad](../r/5fdf0ebeba.md) — San Fulgencio de Ruspe · Sermón 3,1-3. 5-6: CCL 91 A, 905-909
- **Año C (1): Lc 2, 41-52** — [Dichosos los perseguidos por mi causa](../r/e0034f37e5.md) — San Gregorio de Nisa · Discurso 27, 9: PG 44, 1291-1295. 1299-1302
- **Domingo dentro de la Octava de Navidad. LA SAGRADA FAMILIA DE JESÚS, MARÍA Y JOSÉ** — [El ejemplo de Nazaret](../r/be0ff28b89.md) — San Pablo VI · Alocución en Nazaret, 5 de enero de 1964
- **Domingo dentro de la Octava de Navidad. LA SAGRADA FAMILIA DE JESÚS, MARÍA Y JOSÉ** — [Jesús crecía en sabiduría, edad y gracia](../r/1ff7c8bb58.md) — San Beda el Venerable · Hom. 1, 19: CCL. 122. 134-135. 138-139

## Ferias posteriores a la Epifanía

- **Domingo después del 6 de Enero. EL BAUTISMO DEL SEÑOR** — [Del seno de la Virgen nació el que es Siervo y Señor a la vez](../r/eee161dda5.md) — San Ambrosio de Milán · 4-5 : CCL 64, 52-53
- **Domingo después del 6 de Enero. EL BAUTISMO DEL SEÑOR** — [Vino a nosotros el que es el esplendor de la gloria del Padre](../r/7316e75b00.md) — San Gregorio de Neocesarea · Homilía 4 en la santa Teofanía: PG 10, 1182-1183
- **Domingo después del 6 de Enero. EL BAUTISMO DEL SEÑOR** — [Éste es mi Hijo, el amado, mi predilecto](../r/df1cf7e154.md) — San Gregorio de Antioquía · Homilía 2, 5. 6. 9. 10 en el Bautismo de Cristo: PG 88, 1875-1879. 1882-1883
- **Domingo después del 6 de Enero. EL BAUTISMO DEL SEÑOR** — [¡Venid al bautismo de la inmortalidad!](../r/bd9d6ef23f.md) — San Hipólito de Roma · En la santa Teofanía : PG 10, 858-859

## Ferias anteriores a la Epifanía

- [El doble precepto de la caridad](../r/415a57d86e.md) — San Agustín de Hipona · Tratado 17, 7-9: CCL 36, 174-175
- [Misterio siempre nuevo](../r/9421a345dc.md) — San Máximo el Confesor · Centuria 1, 8-13: PG 90, 1182-86
- [Seremos saciados con la visión de la Palabra](../r/55b6bf2fd1.md) — San Agustín de Hipona · Sermón 194, 3-4: PL 38, 1016-1017
- [El bautismo de Cristo](../r/acb09b1995.md) — San Gregorio Nacianceno · Disertación 39, en las santas Luminarias, 14-16.20: PG 36, 350-351.354.358-359
