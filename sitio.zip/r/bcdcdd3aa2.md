# Demos al Señor, que recibe en la persona de cada pobre

**San Paulino de Nola** (c. 354–431) · Tercera lectura del Oficio de Lectura

- id: `bcdcdd3aa2`
- Fuente: De las cartas de san Paulino de Nola
- Cita patrística: Carta 34,2-4: CSEL 29, 305-306
- Ciclo dominical: B · Evangelio Mc 12, 38-44
- Se lee: Semana XXXII DEL TIEMPO ORDINARIO, año impar; Domingo de la semana XXXII del Tiempo Ordinario (semana 32), año par
- Escritura: [Mc 12, 38-44](../escritura/mc.md) (evangelio del domingo); [Lc 16, 9](../escritura/lc.md) (responsorio); [Tb 4, 10](../escritura/tb.md) (responsorio); [Tb 12, 9](../escritura/tb.md) (responsorio)
- Temas (automáticos): [Misericordia y pobres](../temas/misericordia.md), [Trabajo y bienes](../temas/trabajo.md), [Esperanza y vida eterna](../temas/esperanza.md), [Juicio y venida de Cristo](../temas/juicio.md)
- Cómo citar: San Paulino de Nola, Carta 34,2-4: CSEL 29, 305-306, «Demos al Señor, que recibe en la persona de cada pobre». Liturgia de las Horas, Oficio de Lectura, tercera lectura, Semana XXXII DEL TIEMPO ORDINARIO, año impar. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-bcdcdd3aa2](../index.html#r-bcdcdd3aa2)
- Autor: [San Paulino de Nola](../a/paulino-nola.md)

## Texto

¿Tienes algo —dice el Apóstol— que no hayas recibido? Por tanto, amadísimos, no seamos avaros de nuestros bienes como si nos perteneciesen, sino negociemos con ellos como con un préstamo. Se nos ha confiado la administración y el uso temporal de los bienes comunes, no la eterna posesión de una cosa privada. Si en la tierra la consideras tuya sólo temporalmente, podrás hacerla tuya eternamente en el cielo. Si recuerdas a aquellos empleados del evangelio que recibieron unos talentos de su Señor y lo que el propietario, a su regreso, dio a cada uno en recompensa, reconocerás cuánto más ventajoso es depositar el dinero en la mesa del Señor para hacerlo fructificar, que conservarlo intacto con una fidelidad estéril; comprenderás que el dinero celosamente conservado, sin el menor rendimiento para el propietario, se tradujo para el empleado negligente en un enorme despilfarro y en un aumento de su castigo.

Recordemos también a aquella viuda, que olvidándose de sí misma y preocupada únicamente por los pobres, pensando sólo en el futuro, dio todo lo que tenía para vivir, como lo atestigua el mismo juez. Los demás —dice— han echado de lo que les sobra; pero ésta, más pobre tal vez que muchos pobres —ya que toda su fortuna se reducía a dos reales—, pero en su corazón más espléndida que todos los ricos, puesta su esperanza en solas las riquezas de la eterna recompensa y ambicionando para sí solo los tesoros celestiales, renunció a todos los bienes que proceden de la tierra y a la tierra retornan. Echó lo que tenía, con tal de poseer los bienes invisibles. Echó lo corruptible, para adquirir lo inmortal. No minusvaloró aquella pobrecilla los medios previstos y establecidos por Dios en orden a la consecución del premio futuro; por eso tampoco el legislador se olvidó de ella y el árbitro del mundo anticipó su sentencia: en el evangelio hace el elogio de la que coronará en el juicio.

Negociemos, pues, al Señor con los mismos dones del Señor; nada poseemos que de él no hayamos recibido, sin cuya voluntad ni siquiera existiríamos. Y sobre todo, ¿cómo podremos considerar algo nuestro, nosotros que, en virtud de una hipoteca importante y peculiar, no nos pertenecemos, y no ya tan sólo porque hemos sido creados por Dios, sino por haber sido por él redimidos?

Congratulémonos por haber sido comprados a gran precio, al precio de la sangre del propio Señor, dejando por eso mismo de ser personas viles y venales, ya que la libertad consistente en ser libres de la justicia es más vil que la misma esclavitud. El que así es libre, es esclavo del pecado y prisionero de la muerte. Restituyamos, pues, sus dones al Señor; démosle a él, que recibe en la persona de cada pobre; demos, insisto, con alegría, para recibir de él la plenitud del gozo, como él mismo ha dicho.

## Responsorio (Lc 16, 9; Tb 4, 10; 12,9)

R. Yo os digo: * Haceos amigos con el dinero injusto, para que, cuando llegue a faltar, os reciban en las moradas eternas.  
V. La limosna libra de la muerte y purifica de todo pecado; ella impide caer en las tinieblas.  
R. Haceos amigos con el dinero injusto, para que, cuando llegue a faltar, os reciban en las moradas eternas.  

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
