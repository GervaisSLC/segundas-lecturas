# San Justino

c. 100–165 · St. Justin Martyr · 2 lecturas

- [El baño de regeneración](../r/73763c8cac.md) — San Justino · Cap. 61: PG 6, 419-422 · Viernes de la semana III de Pascua (semana 3), año par
- [Sigo las verdaderas doctrinas de los cristianos](../r/e86943ce2b.md) — San Justino · Caps. 1-5: cf. PG 6,1366-1371 · 1 de junio. San Justino, Mártir — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
