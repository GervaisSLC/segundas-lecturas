# En el Bautismo, Cristo es quien bautiza

**San Ildefonso de Toledo** (607–667) · Segunda lectura del Oficio de Lectura

- id: `f0cdccf1a9`
- Fuente: Del libro de san Ildefonso, obispo, sobre el conocimiento del bautismo
- Cita patrística: Caps. 15-16: PL 96,117-118
- Se lee: 23 de enero San Ildefonso, Obispo — Santoral, año impar; 23 de enero San Ildefonso, Obispo — Santoral, año par
- Escritura: [Rm 6, 3. 10](../escritura/rm.md) (responsorio)
- Temas (automáticos): [Bautismo](../temas/bautismo.md), [Humildad](../temas/humildad.md)
- Cómo citar: San Ildefonso de Toledo, Caps. 15-16: PL 96,117-118, «En el Bautismo, Cristo es quien bautiza». Liturgia de las Horas, Oficio de Lectura, segunda lectura, 23 de enero San Ildefonso, Obispo — Santoral, año impar. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-f0cdccf1a9](../index.html#r-f0cdccf1a9)
- Autor: [San Ildefonso de Toledo](../a/ildefonso.md)

## Texto

Vino el Señor para ser bautizado por el siervo. Por humildad, el siervo lo apartaba, diciendo: Soy yo el que necesito que tú me bautices, ¿y tú acudes a mí? Pero, por justicia, el Señor se lo ordenó, respondiendo: Déjalo ahora. Está bien que cumplamos así todo lo que Dios quiere.

Después de esto, declinó el bautismo de Juan, que era bautismo de penitencia y sombra de la verdad, y empezó el bautismo de Cristo, que es la verdad, en el cual se obtiene la remisión de los pecados, aun cuando no bautizase Cristo, sino sus discípulos. En este caso, bautiza Cristo, pero no bautiza. Y las dos cosas son verdaderas: bautiza Cristo, porque es él quien purifica, pero no bautiza, porque no es él quien baña. Sus discípulos, en aquel tiempo, ponían las acciones corporales de su ministerio, como hacen también ahora los ministros, pero Cristo ponía el auxilio de su majestad divina. Nunca deja de bautizar el que no cesa de purificar; y, así, hasta el fin de los siglos, Cristo es el que bautiza, porque es siempre él quien purifica.

Por tanto, que el hombre se acerque con fe al humilde ministro, ya que éste está respaldado por tan gran maestro. El maestro es Cristo. Y la eficacia de este sacramento reside no en las acciones del ministro, sino en el poder del maestro, que es Cristo.

## Nota

> Memoria. En América Latina: Memoria libre

> Ildefonso, nacido en Toledo de noble familia, sobre el año 606, profesó muy joven en el monasterio de Agalí, en las afueras de su ciudad natal, uno de los más insignes de la España visigoda. En el año 657 sucedió a san Eugenio en la silla metropolitana. Desarrolló una gran labor catequética defendiendo la virginidad de María y exponiendo la verdadera doctrina sobre el bautismo. Murió el 23 de enero del año 667. Su cuerpo fue trasladado a Zamora.

## Responsorio (Rm 6, 3. 10)

R. Los que por el bautismo nos incorporamos a Cristo * Fuimos incorporados a su muerte.  
V. Su morir fue un morir al pecado, su vivir es un vivir para Dios.  
R. Fuimos incorporados a su muerte.  

## Oración

Dios todopoderoso, que hiciste a san Ildefonso insigne defensor de la virginidad de María; concede a los que creemos en este privilegio de la Madre de tu Hijo, sentirnos amparados por su poderosa y materna intercesión. Por Jesucristo nuestro Señor.

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
