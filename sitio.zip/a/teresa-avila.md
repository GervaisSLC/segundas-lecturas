# Santa Teresa de Jesús

1515–1582 · St. Teresa of Ávila · 3 lecturas

- [Acordémonos del amor de Cristo](../r/c5303cd3e6.md) — Santa Teresa de Jesús · Cap. 22, 6-7. 12. 14 · 15 de octubre Santa Teresa de Jesús, virgen y doctora de la Iglesia — Santoral, año impar
- [Necesidad de la oración](../r/d1b0a650be.md) — Santa Teresa de Jesús · Cap. 8,1-4 · Mes de octubre — Santoral, año impar
- [Pobreza, austeridad y dulzura de Pedro](../r/6237f64728.md) — Santa Teresa de Jesús · Cap. 27,16-20 · 19 de octubre San Pedro de Alcántara, presbítero — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
