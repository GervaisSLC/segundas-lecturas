# San Juan de Dios

None · None · 1 lecturas

- [Jesucristo es fiel, lo provee todo](../r/2f14ed18c3.md) — San Juan de Dios · Archivo general de la Orden Hospitalaria, Cuaderno: De las cartas..., ff. 23v-24r, 27rv: O. Marcos, Cartas y escritos de nuestro glorioso padre san Juan de Dios, Madrid 1935, pp. 18-19. 48-50 · 8 de marzo. San Juan de Dios, Religioso — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
