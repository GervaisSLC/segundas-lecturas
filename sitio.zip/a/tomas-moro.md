# Santo Tomás Moro

1478–1535 · St. Thomas More · 1 lecturas

- [Me pongo totalmente en manos de Dios con absoluta esperanza y confianza](../r/6b6d1b1273.md) — Santo Tomás Moro · The English Works of Sir Thomas More, Londres 1557, p.1454 · El mismo día 22 de junio San Juan Fisher, Obispo, y Santo Tomás Moro, Mártires — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
