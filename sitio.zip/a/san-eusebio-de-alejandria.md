# San Eusebio de Alejandría

None · None · 1 lecturas

- [Este día os trajo el comienzo de toda gracia](../r/00fe1ffb8c.md) — San Eusebio de Alejandría · Sermón 6, 1. 3. 6: PG 86, 415-418. 422 · Semana XXIX DEL TIEMPO ORDINARIO, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
