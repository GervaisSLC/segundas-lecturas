# San Macario

None · None · 1 lecturas

- [¡Ay del alma en la que no habita Cristo!](../r/70a0489e16.md) — San Macario · 28, PG 34, 710-711 · Jueves de la semana V del Tiempo Ordinario (semana 5), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
