# Santo Tomás de Aquino

1225–1274 · St. Thomas Aquinas · 5 lecturas

- [¡Oh banquete precioso y admirable!](../r/6f01011f6d.md) — Santo Tomás de Aquino · Opúsculo 57, En la fiesta del Cuerpo de Cristo, lect. 1-4 · Domingo después de la Santísima Trinidad EL SANTÍSIMO CUERPO Y SANGRE DE CRISTO — Solemnidades del Señor, año impar
- [En la cruz hallamos el ejemplo de todas las virtudes](../r/b545ad6f4f.md) — Santo Tomás de Aquino · Conferencia 6 sobre el Credo · 28 de enero Santo Tomás de Aquino, Presbítero y Doctor de la Iglesia — Santoral, año impar
- [El camino para llegar a la vida verdadera](../r/b2065445a8.md) — Santo Tomás de Aquino · Cap 14, lec. 2 · Sábado de la semana XVII del Tiempo Ordinario (semana 17), año par
- [El resto de Israel pastará y se tenderá sin sobresaltos](../r/ded54e0dc5.md) — Santo Tomás de Aquino · Cap. 10, lección 3 · Domingo de la semana XXVIII del Tiempo Ordinario (semana 28), año impar
- [Me saciaré de tu semblante](../r/a30f280228.md) — Santo Tomás de Aquino · Opúsculos teológicos 2, Turín 1954, pp. 216-217 · Sábado de la semana XIX del Tiempo Ordinario (semana 19), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
