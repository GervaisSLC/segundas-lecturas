# San Gregorio Palamás

1296–1359 · St. Gregory Palamas · 5 lecturas

- [Juan es aquel a quien Cristo amó con amor de predilección](../r/5fa731094e.md) — San Gregorio Palamás · Homilía 20: PG 151, 266.271 · 27 de Diciembre. San Juan Apóstol y Evangelista — Santoral, año par
- [Amemos el camino angosto y trillado que conduce a la verdadera vida](../r/e3c9e99f5c.md) — San Gregorio Palamás · Homilía 10 : PG 151, 111-114 · Martes de la semana XXIX del Tiempo Ordinario (semana 29), año impar
- [¿Qué no hizo nuestro Creador para lograr nuestra enmienda?](../r/1d20141cad.md) — San Gregorio Palamás · Homilía 3 : PG, 151, 35 · Miércoles de la semana XXX del Tiempo Ordinario (semana 30), año impar
- [¡Ojalá que en el siglo futuro nos hallemos también nosotros agregados a la muchedumbre de los salvados!](../r/261713739a.md) — San Gregorio Palamás · Homilía 26 : PG 151, 339-342 · Semana XXXIII DEL TIEMPO ORDINARIO, año impar
- [Dios es admirable en sus santos](../r/4a4a71e856.md) — San Gregorio Palamás · Hom. 25 : PG 151, 322-323 · Martes de la semana XXX del Tiempo Ordinario (semana 30), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
