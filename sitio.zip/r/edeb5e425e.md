# El justo siembra para el espíritu, y del Espíritu cosechará vida eterna

**Orígenes** (c. 185–254) · Tercera lectura del Oficio de Lectura

- id: `edeb5e425e`
- Fuente: Del comentario de Orígenes, presbítero, sobre el evangelio de san Mateo
- Cita patrística: nn. 68-69: PG 13, 1709-1710
- Ciclo dominical: A · Evangelio Mt 25, 14-30
- Se lee: Semana XXXIII DEL TIEMPO ORDINARIO, año impar; Domingo de la semana XXXIII del Tiempo Ordinario (semana 33), año par
- Escritura: [Mt 25, 14-30](../escritura/mt.md) (evangelio del domingo); [2 Pe 1, 3. 10](../escritura/2pe.md) (responsorio); [Ef 2, 10](../escritura/ef.md) (responsorio)
- Temas (automáticos): [Misericordia y pobres](../temas/misericordia.md), [Esperanza y vida eterna](../temas/esperanza.md), [Pecado y redención](../temas/salvacion.md), [Penitencia y conversión](../temas/conversion.md)
- Cómo citar: Orígenes, nn. 68-69: PG 13, 1709-1710, «El justo siembra para el espíritu, y del Espíritu cosechará vida eterna». Liturgia de las Horas, Oficio de Lectura, tercera lectura, Semana XXXIII DEL TIEMPO ORDINARIO, año impar. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-edeb5e425e](../index.html#r-edeb5e425e)
- Autor: [Orígenes](../a/origenes.md)

## Texto

Mi impresión, a propósito del presente pasaje, es ésta: que el justo siembra para el espíritu, y del Espíritu cosechará vida eterna. En realidad, todo lo que «otro», es decir, el hombre justo, siembra y recoge para la vida eterna, lo cosecha Dios, pues el justo es posesión de Dios, que siega donde no siembra, sino el justo.

Lógicamente diremos también que el justo reparte limosna a los pobres y que el Señor recoge en sus graneros todo lo que el justo ha repartido en limosnas a los pobres. Segando lo que no sembró y recogiendo lo que no esparció, considera y estima como ofrecido a sí mismo todo lo que se sembró o se esparció en los fieles pobres, diciendo a los que hicieron el bien al prójimo: Venid vosotros, benditos de mi Padre; heredad el reino preparado para vosotros desde la creación del mundo, porque tuve hambre y me disteis de comer, etc. Y porque quiere segar donde no sembró y recoger donde no esparció, al no encontrar nada dirá a los que no le dieron la oportunidad de segar y recoger: Apartaos de mí, malditos; id al fuego eterno preparado por el Padre para el diablo y sus ángeles, porque tuve hambre y no me disteis de comer, etc. Porque realmente es duro, como dice Mateo, o austero, según la expresión de Lucas, pero sólo para los que abusan de la misericordia de Dios por propia negligencia y no para su conversión, como dice el Apóstol: Fíjate en la bondad y en la severidad de Dios; para los que cayeron, severidad; para ti, su bondad, con tal que no te salgas de su bondad.

Pues para el que piensa que Dios es bueno, seguro de conseguir su perdón si se convierte a él, para él Dios es bueno. Pero para el que considera que Dios es bueno, hasta el punto de no preocuparse de los pecados de los pecadores, para ese Dios no es bueno, sino exigente. Pues Dios arde en ira contra los pecados de los hombres que le desprecian. Sin embargo, para que no dé la impresión de que Cristo siega lo que no hemos sembrado y recoge lo que no hemos esparcido, sembremos para el espíritu y esparzamos en los pobres, y no escondamos el talento de Dios en la tierra.

Porque no es buena esa clase de temor ni nos libra de aquellas tinieblas exteriores, si fuéremos condenados como empleados negligentes y holgazanes. Negligentes, porque no hemos hecho uso de la acendrada moneda de las palabras del Señor, con las cuales hubiéramos podido negociar y regatear el mensaje cristiano, y adquirir los más profundos misterios de la bondad de Dios. Holgazanes, porque no hemos traficado con la palabra de Dios la salvación, nuestra o la de los demás, cuando hubiéramos debido depositar el dinero de nuestro Señor, es decir, sus palabras, en el banco de los oyentes, que, como banqueros, todo lo examinan, todo lo someten a prueba, para quedarse con el dogma bueno y verdadero, rechazando el malo y falso, de suerte que cuando vuelva el Señor pueda recibir la palabra que nosotros hemos encomendado a otros con los intereses y, por añadidura, con los frutos producidos por quienes de nosotros recibieron la palabra. Pues toda moneda, esto es, toda palabra que lleva grabada la impronta real de Dios y la imagen de su Verbo, es legítima.

## Responsorio (2Pe 1, 3. 10; Ef 2, 10)

R. Dios nos llamó con su gloria y poder. * Por tanto, hermanos, poned el mayor empeño en afianzar vuestra vocación y vuestra elección.  
V. Somos en efecto hechura suya, creados en Cristo Jesús, en orden a las buenas obras que Dios dispuso de antemano para que las practicáramos.  
R. Por tanto, hermanos, poned el mayor empeño en afianzar vuestra vocación y vuestra elección.  

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
