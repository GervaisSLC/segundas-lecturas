# San Juan Damasceno

c. 675–749 · St. John Damascene · 2 lecturas

- [Me llamaste, Señor, para servir a tus hijos](../r/577f72f6e6.md) — San Juan Damasceno · Cap. l: PG 95, 417-419 · 4 de diciembre. San Juan Damasceno, Presbítero y Doctor de la Iglesia — Santoral, año par
- [Por sus frutos los conoceréis](../r/acd120a7f7.md) — San Juan Damasceno · Sermón 6, Sobre la Natividad de la Virgen María, 2. 4. 5. 6: PG 96, 663. 667. 670 · 26 de julio Santos Joaquín y Ana, Padres de la Virgen María — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
