# San Eulogio de Córdoba

d. 859 · St. Eulogius of Córdoba · 1 lecturas

- [El Señor nos ayuda en la tribulación y nos da fortaleza en los combates](../r/c6ba7cec23.md) — San Eulogio de Córdoba · Documentum Martyrii, 25, epílogo: PL 115, 834 · 9 de enero. San Eulogio de Córdoba, Presbítero y Mártir — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
