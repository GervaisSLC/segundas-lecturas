# San León Magno

c. 400–461 · St. Leo the Great · 37 lecturas

- [El misterio de nuestra reconciliación](../r/04acdc5a17.md) — San León Magno · Carta 31, 2-3: PL 54, 791-793 · 17 de Diciembre — Santoral, año par
- [Reconoce, cristiano, tu dignidad](../r/b95c5cacec.md) — San León Magno · Sermón 1 en la Navidad del Señor 13: PL 54, 190-193 · 25 de Diciembre. LA NATIVIDAD DEL SEÑOR — Santoral, año par
- [Y verán los confines de la tierra la victoria de nuestro Dios](../r/c1839c131d.md) — San León Magno · Tratado 36 ,1-2 CCL 138, 195-196 · 9 de Enero o Miércoles después del Domingo de Epifanía — Santoral, año par
- [María, antes de concebir corporalmente, concibió en su espíritu](../r/19a318fd82.md) — San León Magno · Sermón 1 en la Natividad del Señor, 2. 3: PL 54,191-192 · Común de Santa maría virgen — Comunes, año par
- [En Pedro permanece lo que Cristo instituyó](../r/9066b6bf8b.md) — San León Magno · Sermón 3 en el aniversario de su consagración episcopal, 2-3: PL 54,145-146 · Común de pastores — Comunes, año par
- [El nacimiento del Señor es el nacimiento de la paz](../r/70b8f9f18e.md) — San León Magno · Sermón 6, 2-3 en la Natividad del Señor: PL 54, 213-216 · 31 de Diciembre. Día VII - Octava de Navidad — Santoral, año impar
- [Dios ha manifestado su salvación en todo el mundo](../r/a416ab5165.md) — San León Magno · Sermón en la Epifanía del Señor 3, 1-3. 5: PL 54, 240-244 · 6 de Enero. LA EPIFANÍA DEL SEÑOR — Santoral, año impar
- [Purificación espiritual por el ayuno y la misericordia](../r/1429eb9b65.md) — San León Magno · Sermón sobre la Cuaresma, 1-2; PL 54, 285-287 · Jueves después de Ceniza — Cuaresma y Pascua, año par
- [La ley se dio por medio de Moisés, la gracia y la verdad vinieron por medio de Jesucristo](../r/b1d42366fc.md) — San León Magno · Sermón 51, 3-4.8: PL 54, 310-311.313 · Semana II de Cuaresma — Cuaresma y Pascua, año par
- [Del bien de la caridad](../r/4d875d01f1.md) — San León Magno · Sermón 10, 3-5 sobre la Cuaresma: PL 54, 299-301 · Martes de la semana IV de Cuaresma (semana 4), año par
- [Demos gracias por la divina economía](../r/ec232e6688.md) — San León Magno · Sermón 73, 1-2: CCL 138A, 450-452 · Martes de la semana VI de Pascua (semana 6), año par
- [La ascensión de Cristo es nuestra propia exaltación](../r/2803c22368.md) — San León Magno · Sermón sobre la Ascensión, 73, 3-5: CCL A 452-454 · Miércoles de la semana VI de Pascua (semana 6), año par
- [Lo que fue visible en nuestro Redentor, ha pasado a los ritos sacramentales](../r/2516d02265.md) — San León Magno · Tratado 74 (1-2: CCL 138A 455-457 · Solemnidad — Cuaresma y Pascua, año par
- [La Ascensión del Señor alimenta nuestra fe](../r/3d60196d53.md) — San León Magno · Sermón 2 sobre la Ascensión, 1-4: PL 54, 397-399 · Ascensión - Año A: Mt 28, 16-20 — Cuaresma y Pascua, año par
- [Por el camino del amor, también nosotros podemos ascender hasta Cristo](../r/48a896fb12.md) — San León Magno · Tratado 74, 5: CCL 138 A, 459-461 · Después de la Ascensión — Cuaresma y Pascua, año par
- [Me he hecho Hijo del hombre, para que vosotros podáis ser hijos de Dios](../r/4834ea815e.md) — San León Magno · Tratado 77, 4-6: CCL 138A, 490-493 · Domingo de Pentecostés — Cuaresma y Pascua, año par
- [El Espíritu de la verdad os guiará hasta la verdad plena](../r/3007a374ff.md) — San León Magno · Tratado 75, 1-3: CCL 138A, 465-468 · Domingo de Pentecostés — Cuaresma y Pascua, año par
- [La Iglesia de Cristo se levanta sobre la firmeza de la fe de Pedro](../r/cb45c59739.md) — San León Magno · Sermón 4 en el aniversario de su consagración episcopal, 2-3: PL 54,149-151 · 22 de febrero. La Cátedra del Apóstol San Pedro — Santoral, año par
- [El ministerio de nuestra reconciliación](../r/b8b4044fec.md) — San León Magno · Carta 28, a Flaviano, 3-4: PL 54, 763-767 · 25 de marzo. LA ANUNCIACIÓN DEL SEÑOR — Santoral, año par
- [El hombre debe imitar a su Creador. Esto es un don de Dios](../r/8bfdd611d3.md) — San León Magno · Homilías sobre el Año Litúrgico, 1 [12]. ed. M. Garrido Bonaño, OSB. BAC. Madrid, 1969, p. 45-46 · Jueves de la II semana de Pascua. La Santa Faz de Nuestro Señor Jesucristo — Santoral, año par
- [En la inmolación de Cristo está la verdadera Pascua y el único sacrificio](../r/d1a5390486.md) — San León Magno · Sermón 60, 1-2, sobre la Pasión del Señor: CCL 138A, 363-365 · Martes de la semana IV de Cuaresma (semana 4), año impar
- [Contemplación de la pasión del Señor](../r/930a5a9d33.md) — San León Magno · Sermón 15, 3-4 sobre la Pasión del Señor: PL 54, 366-367 · Sábado de la semana IV de Cuaresma (semana 4), año impar
- [La cruz de Cristo, fuente de todas las bendiciones y origen de todas las gracias](../r/9052cd18d7.md) — San León Magno · Tratado 59, 4-6: CCL 138A, 354-359 · Triduo pascual — Cuaresma y Pascua, año impar
- [Entended el misterio de un amor tan grande](../r/990f39ebd7.md) — San León Magno · Sermón 2, 3-5 en la resurrección del Señor: CCL 138A, 443-446 · Domingo de la semana II de Pascua (semana 2) - Año A: Jn 20, 19-31, año impar
- [Cristo vive en su Iglesia](../r/fd859a409a.md) — San León Magno · Sermón 12, 3. 6. 7 sobre la Pasión del Señor: CCL 138A, 383-384. 386-388 · Miércoles de la semana II de Pascua (semana 2), año impar
- [El momento es apremiante](../r/3847ae03e0.md) — San León Magno · Tratado 90, 2-3: CCL 138A, 558-561 · Martes de la semana VI del Tiempo Ordinario (semana 6), año impar
- [Tu bienhechor te quiere espléndido](../r/fd2cdd2f44.md) — San León Magno · Tratado 17, 1-4: CCL 138, 68-71 · Domingo de la semana VII del Tiempo Ordinario (semana 7), año impar
- [Dios mismo será su más preciado galardón, él que es la encarnación del precepto](../r/3b303920c9.md) — San León Magno · Sermón 16, 1-2: CCL 138, 61-62 · Miércoles de la semana IX del Tiempo Ordinario (semana 9), año impar
- [Somos templo del Dios vivo](../r/0a8742f347.md) — San León Magno · 1.2.3.4: CCL 138A, 252.253.254.255 · Martes de la semana XII del Tiempo Ordinario (semana 12), año par
- [Meteré mi ley en su pecho](../r/ce0979b035.md) — San León Magno · Sermón 95, 1-2: CCL 138A, 582-584 · Lunes de la semana XXXIV del Tiempo Ordinario (semana 34), año impar
- [Dichosos los pobres en el espíritu](../r/39e3b6c454.md) — San León Magno · Sermón 95, 2-3: CCL 138A, 584-585 · Martes de la semana XXXIV del Tiempo Ordinario (semana 34), año impar
- [La dicha del reino de Cristo](../r/eec49d0442.md) — San León Magno · Sermón 95, 4-5: CCL 138A, 585-587 · Miércoles de la semana XXXIV del Tiempo Ordinario (semana 34), año impar
- [Feliz el alma que ambiciona este manjar](../r/c9c0bb105e.md) — San León Magno · Sermón 95, 6-7: CCL 138A, 587-588 · Jueves de la semana XXXIV del Tiempo Ordinario (semana 34), año impar
- [Mucha paz tienen los que aman tu nombre, Señor](../r/8144211397.md) — San León Magno · Sermón 95, 8-9: CCL 138 A, 588-590 · Viernes de la semana XXXIV del Tiempo Ordinario (semana 34), año impar
- [El especial servicio de nuestro ministerio](../r/0a12847b12.md) — San León Magno · Sermón 4,1-2: PL 54,148-149 · 10 de noviembre San León Magno, papa y doctor de la Iglesia — Santoral, año impar
- [Pedro y Pablo, dos vástagos plantados por Dios](../r/fb437b6c70.md) — San León Magno · Sermón 82, En el natalicio de los apóstoles Pedro y Pablo, 1, 6-7: PL 54, 426-428 · 18 de noviembre La Dedicación de las Basílicas de los Apóstoles San Pedro y San Pablo — Santoral, año impar
- [Cual sea el trabajo de cada uno, tal será su ganancia](../r/41cb16cc22.md) — San León Magno · Serm. 92, 1.2.3: PL 54, 454-455 · Domingo de la semana XXIII del Tiempo Ordinario (semana 23), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
