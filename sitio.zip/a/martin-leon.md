# San Martín de León

c. 1130–1203 · St. Martin of León · 4 lecturas

- [En su último discurso, Cristo consolidó más firmemente el amor en el corazón de sus discípulos con la palabra y el ejemplo](../r/1b03f878b0.md) — San Martín de León · Sermón 21 en la Cena del Señor : PL 208, 839-840 · Viernes de la semana XX del Tiempo Ordinario (semana 20), año impar
- [Todas estas cosas tuvieron en Cristo su cumplimiento](../r/430ac70c53.md) — San Martín de León · Sermón 26, en la resurrección del Señor: PL 208, 938-939 · Sábado de la semana XXIII del Tiempo Ordinario (semana 23), año impar
- [El vástago legítimo es el Verbo, coeterno siempre con Dios Padre](../r/18088bc160.md) — San Martín de León · Sermón 1 en el Adviento del Señor : PL 208, 31-33. 38 · Semana XXX DEL TIEMPO ORDINARIO, año impar
- [Viene el Deseado de todas las naciones](../r/a4e3adfbb5.md) — San Martín de León · Sermón 2 : PL 208, 37-39 · Viernes de la semana XXXI del Tiempo Ordinario (semana 31), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
