# Protector y custodio fiel

**San Bernardino de Siena** (1380–1444) · Segunda lectura del Oficio de Lectura

- id: `4cce2cca16`
- Fuente: De los sermones de san Bernardino de Siena, presbítero
- Cita patrística: Sermón 2, Sobre san José: Opera omnia 7,16. 27-30
- Se lee: 19 de marzo. SAN JOSÉ, Esposo de la Virgen María — Santoral, año par; 19 de marzo. SAN JOSÉ, Esposo de la Virgen María — Santoral, año impar; 19 de marzo SAN JOSÉ, Esposo de la Virgen María — Santoral, año impar; 19 de marzo SAN JOSÉ, Esposo de la Virgen María — Santoral, año par
- Escritura: [Hb 11, 1-16](../escritura/hb.md) (primera lectura del día); [Gn 45, 8](../escritura/gn.md) (responsorio); [Gn 50, 20](../escritura/gn.md) (responsorio); [Sal 27, 7](../escritura/sal.md) (responsorio); [Sal 117, 14](../escritura/sal.md) (responsorio)
- Temas (automáticos): [Eucaristía](../temas/eucaristia.md), [Creación](../temas/creacion.md)
- Cómo citar: San Bernardino de Siena, Sermón 2, Sobre san José: Opera omnia 7,16. 27-30, «Protector y custodio fiel». Liturgia de las Horas, Oficio de Lectura, segunda lectura, 19 de marzo. SAN JOSÉ, Esposo de la Virgen María — Santoral, año par. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-4cce2cca16](../index.html#r-4cce2cca16)
- Autor: [San Bernardino de Siena](../a/bernardino.md)

## Texto

La norma general que regula la concesión de gracias singulares a una criatura racional determinada es la de que, cuando la gracia divina elige a alguien para un oficio singular o para ponerle en un estado preferente, le concede todos aquellos carismas que son necesarios para el ministerio que dicha persona ha de desempeñar.

Esta norma se ha verificado de un modo excelente en san José, que hizo las veces de padre de nuestro Señor Jesucristo y que fue verdadero esposo de la Reina del universo y Señora de los ángeles. José fue elegido por el eterno Padre como protector y custodio fiel de sus principales tesoros, esto es, de su Hijo y de su Esposa, y cumplió su oficio con insobornable fidelidad. Por eso le dice el Señor: Eres un empleado fiel y cumplidor; pasa al banquete de tu Señor.

Si relacionamos a José con la Iglesia universal de Cristo, ¿no es este el hombre privilegiado y providencial, por medio del cual la entrada de Cristo en el mundo se desarrolló de una manera ordenada y sin escándalos? Si es verdad que la Iglesia entera es deudora a la Virgen Madre por cuyo medio recibió a Cristo, después de María es san José a quien debe un agradecimiento y una veneración singular.

José viene a ser el broche del antiguo Testamento, broche en el que fructifica la promesa hecha a los patriarcas y los profetas. Sólo él poseyó de una manera corporal lo que para ellos había sido mera promesa.

No cabe duda de que Cristo no sólo no se ha desdicho de la familiaridad y respeto que tuvo con él durante su vida mortal como si fuera su padre, sino que la habrá completado y perfeccionado en el cielo.

Por eso, también con razón, se dice más adelante: Pasa al banquete de tu Señor. Aun cuando el gozo significado por este banquete es el que entra en el corazón del hombre, el Señor prefirió decir: Pasa al banquete, a fin de insinuar místicamente que dicho gozo no es puramente interior, sino que circunda y absorbe por doquier al bienaventurado, como sumergiéndole en el abismo infinito de Dios.

Acuérdate de nosotros, bienaventurado José, e intercede con tu oración ante aquel que pasaba por hijo tuyo; intercede también por nosotros ante la Virgen, tu esposa, madre de aquel que con el Padre y el Espíritu Santo vive y reina por los siglos de los siglos. Amén.

## Responsorio (Gn 45, 8; 50,20; Sal 27, 7; 117, 14)

R. Dios me constituyó como padre del rey y como señor de toda su casa, * me elevó para hacer llegar la salvación a muchos pueblos. (T. P. Aleluya.)  
V. El Señor ha sido el auxilio y refugio que me ha salvado.  
R. Me elevó para hacer llegar la salvación a muchos pueblos. (T. P. Aleluya.)  

## Oración

Dios todopoderoso, que confiaste los primeros misterios de la salvación de los hombres a la fiel custodia de san José; haz que, por su intercesión, la Iglesia los conserve fielmente y los lleve a plenitud en su misión salvadora. Por nuestro Señor Jesucristo.

## Primera lectura del día

**De la carta a los Hebreos 11, 1-16** — *La fe de los antiguos padres*

Hermanos: La fe es fundamento de lo que se espera, y garantía de lo que no se ve.

Por ella son recordados los antiguos.

Por la fe sabemos que el universo fue configurado por la palabra de Dios, de manera que lo visible procede de lo invisible.

Por la fe, Abel ofreció a Dios un sacrificio mejor que Caín; por ella, Dios mismo, al recibir sus dones, lo acreditó como justo; por ella sigue hablando después de muerto.

Por la fe fue arrebatado Henoc, sin pasar por la muerte; no lo encontraron, porque Dios lo había arrebatado; en efecto, antes de ser arrebatado se le acreditó que había complacido a Dios, y sin fe es imposible complacerlo, pues el que se acerca a Dios debe creer que existe y que recompensa a quienes lo buscan.

Por la fe, advertido Noé de lo que aún no se veía, tomó precauciones y construyó un arca para salvar a su familia; por ella condenó al mundo y heredó la justicia que viene de la fe.

Por la fe obedeció Abrahán a la llamada y salió hacia la tierra que iba a recibir en heredad. Salió sin saber adónde iba. Por fe vivió como extranjero en la tierra prometida, habitando en tiendas, y lo mismo Isaac y Jacob, herederos de la misma promesa, mientras esperaba la ciudad de sólidos cimientos cuyo arquitecto y constructor iba a ser Dios. Por la fe también Sara, siendo estéril, obtuvo vigor para concebir cuando ya le había pasado la edad, porque consideró fiel al que se lo prometía. Y así, de un hombre, marcado ya por la muerte, nacieron hijos numerosos, como las estrellas del cielo y como la arena incontable de las playas.

Con fe murieron todos estos, sin haber recibido las promesas, sino viéndolas y saludándolas de lejos, confesando que eran huéspedes y peregrinos en la tierra. Es claro que los que así hablan están buscando una patria; pues si añoraban la patria de donde habían salido, estaban a tiempo para volver. Pero ellos ansiaban una patria mejor, la del cielo. Por eso Dios no tiene reparo en llamarse su Dios: porque les tenía preparada una ciudad.

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
