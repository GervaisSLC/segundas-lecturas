# Obediencia y voluntad de Dios

36 lecturas (tema asignado automáticamente).

[Todos los temas](index.md) · [Guía para IAs](../llms.txt)

- [Eva y María](../r/f168e743bd.md) — San Ireneo de Lyon · Lib. 5,19, 1; 20, 2; 21, 1: SC 153, 248-250. 260-264 · Viernes de la semana II de Adviento (semana 2), año impar
- [La Palabra hecha carne nos diviniza](../r/e92981101e.md) — San Hipólito de Roma · Cap. 10, 33-34: PG 16, 3452-3453 · 30 de Diciembre. Día VI - Octava de Navidad — Santoral, año impar
- [La voluntad de Cristo, norma de nuestra vida](../r/a74cf9f7aa.md) — San Gregorio de Nisa · PG 46, 262-263 · Jueves de la semana III de Pascua (semana 3), año par
- [El lugar: junto al Padre; el camino: Cristo](../r/39a356a679.md) — San Ambrosio de Milán · Cap 12, 52-55: CSEL 32, 747-750 · Domingo de la semana V de Pascua (semana 5), año par
- [La cruz es voluntad del Padre, gloria del Hijo, gozo del Espíritu Santo](../r/13be837936.md) — San Juan Crisóstomo · Homilías sobre el nuevo Testamento : PG 51, 34-35 · Semana VII de Pascua — Cuaresma y Pascua, año par
- [Sigo las verdaderas doctrinas de los cristianos](../r/e86943ce2b.md) — San Justino · Caps. 1-5: cf. PG 6,1366-1371 · 1 de junio. San Justino, Mártir — Santoral, año par
- [Abiertamente se nos predica el misterio de Cristo](../r/7c29394bc3.md) — San Cirilo de Alejandría · Lib. 3, cap. 3: PG 73, 427-434 · Semana II de Cuaresma — Cuaresma y Pascua, año impar
- [Os hace falta constancia para cumplir la voluntad de Dios y alcanzar la promesa](../r/e24c0953b8.md) — San Juan Crisóstomo · Homilía 21, 2-3: PG 63, 150-152 · Semana V de Cuaresma — Cuaresma y Pascua, año impar
- [Cristo, que es la vida, quiso morir para hacernos digna morada de Dios](../r/219e92b59e.md) — San Hilario de Poitiers · Tratado 6-7 sobre el Salmo 131: CSEL 22, 666-667 · Martes Santo — Cuaresma y Pascua, año impar
- [El que hace la voluntad de Dios permanece para siempre](../r/3ba330fd62.md) — San Agustín de Hipona · Tratado 2, 8. 9. 11. 14: SC 75, 166-181 · Martes de la semana VI de Pascua (semana 6), año impar
- [El error es múltiple; la virtud, una](../r/c9144e902c.md) — San Juan Crisóstomo · Homilía 3, 1: PG 60, 411-412 · Martes de la semana I del Tiempo Ordinario (semana 1), año impar
- [Asumió Cristo la obediencia para inoculárnosla a nosotros](../r/d224627c36.md) — San Ambrosio de Milán · Comentario 4-6 sobre el salmo 61: PL 14, 1224-1225 · Martes de la semana II del Tiempo Ordinario (semana 2), año impar
- [Todos los miembros de la Iglesia ofrecen la hostia viva](../r/97e05e1649.md) — Orígenes · Lib. 91: PG 14, 1204-1205. 1206-1207 · Lunes de la semana IV del Tiempo Ordinario (semana 4), año impar
- [Venga a nosotros tu reino, hágase tu voluntad](../r/8b192cfbaf.md) — San Cipriano de Cartago · Tratado 13-14: CSEL 3, 275-277 · Viernes de la semana XI del Tiempo Ordinario (semana 11), año impar
- [No anteponer nada a Cristo](../r/e416f734b4.md) — San Cipriano de Cartago · Tratado 15-16: CSEL 3, 277-279 · Sábado de la semana XI del Tiempo Ordinario (semana 11), año impar
- [Pedimos de modo que nuestra oración recabe la salvación de todos](../r/ed27a80d31.md) — San Cipriano de Cartago · Tratado 17-18: CSEL 3, 279-281 · Domingo de la semana XII del Tiempo Ordinario (semana 12), año impar
- [A una orden de Cristo se produce la calma](../r/84e338d484.md) — San Agustín de Hipona · Sermón 43, 1-3: PL 38, 424-425 · Domingo de la semana XII del Tiempo Ordinario (semana 12), año impar
- [Aplicaos, hermanos, a meditar las palabras de Dios](../r/f462a86078.md) — San Gregorio Magno · Lib. 2, homilía 3, 18. 19. 21: CCL 142, 250. 252. 253. 254 · Sábado de la semana XIV del Tiempo Ordinario (semana 14), año impar
- [Preciosa la sabiduría que nos da a conocer a Dios](../r/8ea4f062f5.md) — San Bernardo de Claraval · Sermón 7, en la Epifanía: Opera omnia, ed. Cister 1970, 671, 26-27 · Domingo de la semana XVII del Tiempo Ordinario (semana 17), año impar
- [Abrahán, llamado amigo, fue hallado fiel](../r/7b98ac4792.md) — San Clemente I, papa · 9-11: Funk 1, 73-75 · Jueves de la semana II del Tiempo Ordinario (semana 2), año par
- [El Señor del universo ha querido que reinara la paz y la concordia](../r/c78db01ded.md) — San Clemente I, papa · 18-20: Funk 1, 85-89 · Domingo de la semana III del Tiempo Ordinario (semana 3), año par
- [No nos apartamos nunca de la voluntad de Dios](../r/182965a898.md) — San Clemente I, papa · 21, 1—22, 5; 23, 1-2: Funk 1, 89-93 · Lunes de la semana III del Tiempo Ordinario (semana 3), año par
- [Obedezcamos a su nombre santísimo y glorioso](../r/2b24452bb1.md) — San Clemente I, papa · 56, 1-2.16; 57, 1-2; 58,1-2: Funk 1, 131-135 · Viernes de la semana IV del Tiempo Ordinario (semana 4), año par
- [Llegaréis a vuestra plenitud, según la plenitud total de Cristo](../r/f9b2209e6f.md) — Actas y escritos anónimos · 18, 7-11: PG 34, 639-642 · Viernes de la semana VI del Tiempo Ordinario (semana 6), año par
- [Estáis salvados por gracia](../r/085faee859.md) — San Policarpo de Esmirna · Caps 1, 1-2,3: Funk 1, 267-269 · Domingo de la semana X del Tiempo Ordinario (semana 10), año par
- [Revistámonos con las armas de la paz](../r/fcb1f322ec.md) — Clemente de Alejandría · Exhortación a los paganos, Cap. 11; PG 8, 235-238 · Viernes de la semana XXI del Tiempo Ordinario (semana 21), año impar
- [Sobre la verdadera humildad](../r/bd20d73331.md) — San Elredo de Rievaulx · Edit C.H. Talbot, SSOC vol 1, 78-80 · Domingo de la semana XXII del Tiempo Ordinario (semana 22), año impar
- [Vamos a subir al monte del Señor](../r/5d62be4f4f.md) — San Agustín de Hipona · Comentario sobre el Salmo 47, 7: CCL 38, 543-545 · Martes de la semana XXVII del Tiempo Ordinario (semana 27), año impar
- [¿Quién es el sabio capaz de entender estas cosas?](../r/8e328d63f4.md) — Balduino de Canterbury · Parte 2, 1: SC 93, 194-200 · Sábado de la semana XXVIII del Tiempo Ordinario (semana 28), año impar
- [Sobre los grados de la contemplación](../r/7c47dd64b0.md) — San Bernardo de Claraval · Sermón 5, 4-5: Opera omnia, Edit Cist. 6, 1, 1970, 103-104 · Jueves de la semana XXIX del Tiempo Ordinario (semana 29), año impar
- [El ideal de la vida apostólica es la salvación y santificación de las almas](../r/b3f383e146.md) — San Maximiliano María Kolbe · Gli scritti di Massimiliano Kolbe eroe di Oswiecim e beato della Chiesa, vol. I, Città di Vita, Florencia 1975, pp. 44-46. 113-114 · 14 de agosto San Maximiliano María Kolbe, presbítero y mártir — Santoral, año impar
- [Hemos de imitar la pobreza de Jesús](../r/7b8d5e9f9b.md) — Santa Teresa de Jesús · Carta 201: Cartas. Copias auténticas, t. 1. Archivo general de la Congregación, Valencia: Causa de beatificación y canonización de la sierva de Dios Teresa de Jesús Jornet e lbars). · 26 de agosto Santa Teresa de Jesús Jornet e Ibars, virgen, Patrona de la Ancianidad — Santoral, año impar
- [Predicamos a Cristo crucificado](../r/4b924471f4.md) — San Pablo de la Cruz · Carta 1, 43; 2, 440. 825 · El mismo día 19 de octubre San Pablo de la Cruz, presbítero — Santoral, año impar
- [Dio fe al mensaje divino y concibió por su fe](../r/8710ce6aa9.md) — San Agustín de Hipona · Sermón 25, 7-8: PL 46, 937-938 · 21 de noviembre La Presentación de la Santísima Virgen — Santoral, año impar
- [No sabemos pedir lo que nos conviene](../r/551dcea6e8.md) — San Agustín de Hipona · Carta 130, 14, 25-26 a Proba: CSEL 44, 68-71 · Jueves de la semana XXIV del Tiempo Ordinario (semana 24), año par
- [Vivo yo, pero no soy yo, es Cristo quien vive en mí](../r/f77a852684.md) — San Basilio Magno · Lib 1, 2.3: PG 31,1515-1519 · Domingo de la semana XXVIII del Tiempo Ordinario (semana 28), año par
