# Te serviré predicándote

**San Hilario de Poitiers** (c. 310–367) · Segunda lectura del Oficio de Lectura

- id: `c8c8b91dce`
- Fuente: Del tratado de san Hilario, obispo, sobre la Trinidad
- Cita patrística: Libro 1, 37-38: PL 10, 48-49
- Se lee: 13 de enero San Hilario, obispo y Doctor de la Iglesia — Santoral, año impar; 13 de enero San Hilario, obispo y Doctor de la Iglesia — Santoral, año par
- Escritura: [1 Jn 4, 2-3. 6. 15](../escritura/1jn.md) (responsorio)
- Temas (automáticos): [Misión y evangelización](../temas/mision.md), [Fe](../temas/fe.md), [Misericordia y pobres](../temas/misericordia.md)
- Cómo citar: San Hilario de Poitiers, Libro 1, 37-38: PL 10, 48-49, «Te serviré predicándote». Liturgia de las Horas, Oficio de Lectura, segunda lectura, 13 de enero San Hilario, obispo y Doctor de la Iglesia — Santoral, año impar. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-c8c8b91dce](../index.html#r-c8c8b91dce)
- Traducción inglesa antigua (dominio público, no litúrgica): https://www.newadvent.org/fathers/330201.htm
- Autor: [San Hilario de Poitiers](../a/hilario.md)

## Texto

Yo tengo plena conciencia de que es a ti, Dios Padre omnipotente, a quien debo ofrecer la obra principal de mi vida, de tal suerte que todas mis palabras y pensamientos hablen de ti.

Y el mayor premio que puede reportarme esta facultad de hablar, que tú me has concedido, es el de servirte predicándote a ti y demostrando al mundo, que lo ignora, o a los herejes, que lo niegan, lo que tú eres en realidad: Padre; Padre, a saber, del Dios unigénito.

Y, aunque es ésta mi única intención, es necesario para ello invocar el auxilio de tu misericordia, para que hinches con el soplo de tu Espíritu las velas de nuestra fe y nuestra confesión, extendidas para ir hacia ti, y nos impulses así en el camino de la predicación que hemos emprendido. Porque merece toda confianza aquel que nos ha prometido: Pedid, y se os dará; buscad, y encontraréis; llamad, y se os abrirá.

Somos pobres y, por esto, pedimos que remedies nuestra indigencia; nosotros ponemos nuestro esfuerzo tenaz en penetrar las palabras de tus profetas y apóstoles y llamamos con insistencia para que se nos abran las puertas de la comprensión de tus misterios; pero el darnos lo que pedimos, el hacerte encontradizo cuando te buscamos y el abrir cuando llamamos, eso depende de ti.

Cuando se trata de comprender las cosas que se refieren a ti, nos vemos como frenados por la pereza y torpeza inherentes a nuestra naturaleza y nos sentimos limitados por nuestra inevitable ignorancia y debilidad; pero el estudio de tus enseñanzas nos dispone para captar el sentido de las cosas divinas, y la sumisión de nuestra fe nos hace superar nuestras culpas naturales.

Confiamos, pues, que tú harás progresar nuestro tímido esfuerzo inicial y que, a medida que vayamos progresando, lo afianzarás, y que nos llamarás a compartir el espíritu de los profetas y apóstoles; de este modo, entenderemos sus palabras en el mismo sentido en que ellos las pronunciaron y penetraremos en el verdadero significado de su mensaje.

Nos disponemos a hablar de lo que ellos anunciaron de un modo velado: que tú, el Dios eterno, eres el Padre del Dios eterno unigénito, que tú eres el único no engendrado y que el Señor Jesucristo es el único engendrado por ti desde toda la eternidad, sin negar, por esto, la unicidad divina, ni dejar de proclamar que el Hijo ha sido engendrado por ti, que eres un solo Dios, confesando, al mismo tiempo, que el que ha nacido de ti, Padre, Dios verdadero, es también Dios verdadero como tú.

Otórganos, pues, un modo de expresión adecuado y digno, ilumina nuestra inteligencia, haz que no nos apartemos de la verdad de la fe; haz también que nuestras palabras sean expresión de nuestra fe, es decir, que nosotros, que por los profetas y apóstoles te conocemos a ti, Dios Padre, y al único Señor Jesucristo, y que argumentamos ahora contra los herejes que esto niegan, podamos también celebrarte a ti como Dios en el que no hay unicidad de persona y confesar a tu Hijo, en todo igual a ti.

## Nota

> Nació en Poitiers a principios del siglo IV; hacia el año 350 fue elegido obispo de su ciudad; luchó con valentía contra los arrianos y fue desterrado por el emperador Constancio. Escribió varias obras llenas de sabiduría y de doctrina, destinadas a consolidar la fe católica y a la interpretación de la sagrada Escritura. Murió el año 367.

> Del Común de pastores o del Común de doctores de la Iglesia.

## Responsorio (1 Jn 4, 2-3. 6. 15)

R. Todo espíritu que reconozca a Jesucristo, que ha venido en la carne, es de Dios; pero el espíritu que no reconozca a Jesús no es de Dios. * En eso distinguimos al espíritu de la verdad y al espíritu del error.  
V. Quien confiese que Jesús es el Hijo de Dios, Dios permanece en él y él en Dios.  
R. En eso distinguimos al espíritu de la verdad y al espíritu del error.  

## Oración

Concédenos, Dios todopoderoso, progresar cada día en el conocimiento de la divinidad de tu Hijo y proclamarla con firmeza, como lo hizo, con celo infatigable, tu obispo y doctor san Hilario. Por Jesucristo nuestro Señor.

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
