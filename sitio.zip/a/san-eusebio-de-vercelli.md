# San Eusebio de Vercelli

None · None · 1 lecturas

- [He corrido hasta la meta, he mantenido la fe](../r/3769d68cf2.md) — San Eusebio de Vercelli · Carta 2,1, 3-2, 3; 10,1-11,1: CCL 9,104-105.109 · 2 de agosto San Eusebio de Vercelli, obispo — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
