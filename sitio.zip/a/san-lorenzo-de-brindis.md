# San Lorenzo de Brindis

None · None · 1 lecturas

- [La predicación es una función apostólica](../r/d1e2fed48e.md) — San Lorenzo de Brindis · Sermón cuaresmal 2: Opera omnia 5,1, Núms. 48. 50. 52 · 21 de julio San Lorenzo de Brindis, Presbítero y Doctor de la Iglesia — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
