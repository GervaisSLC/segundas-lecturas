# Carta de Bernabé

2nd c. · Epistle of Barnabas · 4 lecturas

- [La esperanza de la vida, principio y término de nuestra fe](../r/25b6a5afa4.md) — Carta de Bernabé · Caps. 1, 1-8; 2, 1-5: Funk 1, 3-7 · Lunes de la semana XXII del Tiempo Ordinario (semana 22), año impar
- [La nueva ley de nuestro Señor](../r/030e029d3e.md) — Carta de Bernabé · Caps. 2, 6-10; 3, 1. 3, 4, 10-14: Funk 1, 7-9. 13 · Martes de la semana XXII del Tiempo Ordinario (semana 22), año impar
- [La segunda creación](../r/800e42d611.md) — Carta de Bernabé · Caps. 5, 1-8; 6, 11-16: Funk 1, 13-15. 19-21 · Miércoles de la semana XXII del Tiempo Ordinario (semana 22), año impar
- [El camino de la luz](../r/d2a8a4e203.md) — Carta de Bernabé · Cap. 19, 1-3. 5-7. 8-12: Funk 1, 53-57 · Jueves de la semana XXII del Tiempo Ordinario (semana 22), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
