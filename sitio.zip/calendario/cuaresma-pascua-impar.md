# Cuaresma y Pascua — año impar

[Volver al calendario](index.md) · [Guía para IAs](../llms.txt)

## Semana de Ceniza

- **Miércoles de Ceniza** — [Convertíos](../r/f1ef327991.md) — San Clemente I, papa · Caps. 7, 4-8, 5-9. 1; 13, 1-4; 19, 2: Funck 1, 71-73.77-78.87
- **Jueves después de Ceniza** — [Ayunamos por nuestros pecados, pues vamos a acercarnos a los sagrados misterios](../r/bd3dfce7fa.md) — San Juan Crisóstomo · Discurso 3, contra los judíos: PG 48, 867-868
- **Viernes después de Ceniza** — [Cinco caminos de penitencia](../r/b336a04d57.md) — San Juan Crisóstomo · Homilía 2, 6: PG 49, 263-264
- **Sábado después de Ceniza** — [Rasgad los corazones, no las vestiduras](../r/889c5a098c.md) — San Pablo VI · AAS t. 58. 1966, 178-179

## Semana I de Cuaresma

- [En Cristo fuimos tentados, en él vencimos al diablo](../r/de2cf91fb5.md) — San Agustín de Hipona · Comentario sobre el salmo 60, 2-3: CCL 39, 766
- [El cristiano dispone de medios para superar las tentaciones](../r/ea0a56ed1a.md) — San Gregorio Nacianceno · Discurso 40, 10: PG 36, 370-371
- [Jesús fue tentado por el diablo para que la Iglesia aprendiera que a Cristo se llega a través de muchas tribulaciones y tentaciones](../r/f5f6e62054.md) — Orígenes · Hom 3: GCS t. 8, 221, 19-223, 5
- [¿Quién será capaz de explicar el vínculo del amor divino?](../r/ce13c14964.md) — San Clemente I, papa · 49-50: Funck 1, 123-125
- **Domingo de la semana I de Cuaresma (semana 1) - Año A: Mt 4, 1-11** — [Yo salvaré a mi pueblo](../r/0acb14e1ad.md) — Concilio Vaticano II · Núms. 2.16
- **Martes de la semana I de Cuaresma (semana 1)** — [¿Qué es lo que Dios no ha hecho por nosotros?](../r/03a7000c34.md) — San Juan Crisóstomo · Hom. 14, 8: PG 60, 534-535
- **Miércoles de la semana I de Cuaresma (semana 1)** — [Hay que amar solamente a Dios](../r/c962725789.md) — Diádoco de Fótice · Caps. 12. 13. 14: PG 65, 1171- 1172
- **Jueves de la semana I de Cuaresma (semana 1)** — [Cristo vive siempre para interceder en nuestro favor](../r/8973766e14.md) — San Fulgencio de Ruspe · Carta 14, 36-37: CCL 91, 429-431
- **Viernes de la semana I de Cuaresma (semana 1)** — [Imitemos el estilo pastoral que empleó el mismo Señor](../r/28774edc68.md) — San Asterio de Amasea · Homilía 13, PG 40, 355-358. 362
- **Sábado de la semana I de Cuaresma (semana 1)** — [La oblación pura de la Iglesia](../r/6cc80a5fe1.md) — San Ireneo de Lyon · Lib. 4, 18, 1-2. 4. 5: SC 100, 596-598. 606. 610-612

## Semana II de Cuaresma

- [La ley se dio por medio de Moisés, la gracia y la verdad vinieron por medio de Jesucristo](../r/b1d42366fc.md) — San León Magno · Sermón 51, 3-4.8: PL 54, 310-311.313
- [Hablaban de la muerte que Jesús iba a consumar en Jerusalén](../r/a3bfdc045d.md) — San Cirilo de Alejandría · Homilía 9 en la transfiguración del Señor: PG 77, 1011-1014
- [Sólo Jesús es la luz verdadera y eterna](../r/d1b313970e.md) — San Ambrosio de Milán · Comentario sobre el salmo 45, 2: PL 14, 1188-1189
- [Abiertamente se nos predica el misterio de Cristo](../r/7c29394bc3.md) — San Cirilo de Alejandría · Lib. 3, cap. 3: PG 73, 427-434
- **Domingo de la semana II de Cuaresma (semana 2) - Año A: Mt 17, 1-9** — [Santidad del matrimonio y de la familia](../r/939a0a6b7a.md) — Concilio Vaticano II · Núm. 48
- **Martes de la semana II de Cuaresma (semana 2)** — [Después de Moisés y la ley, Cristo se ha hecho nuestro guía](../r/6ed72fabc2.md) — San Cirilo de Alejandría · Lib. 8: PG 68, 574- 575
- **Miércoles de la semana II de Cuaresma (semana 2)** — [Si creció el pecado, más desbordante fue la gracia](../r/5cdcd1cf90.md) — San Bernardo de Claraval · Sermón 61, 3-5: Opera omnia, edic. cisterciense, 2, 1958, 150-151
- **Jueves de la semana II de Cuaresma (semana 2)** — [Ama al Señor y sigue sus caminos](../r/13baf76547.md) — San Juan Mediocre de Nápoles · Sermón 7: PLS 4, 785-786
- **Viernes de la semana II de Cuaresma (semana 2)** — [Las maravillas de Dios](../r/0875a6071c.md) — San Juan Fisher · Opera omnia, edic. 1597, pp. 1588-1589
- **Sábado de la semana II de Cuaresma (semana 2)** — [El misterio de la muerte](../r/fe2805e65e.md) — Concilio Vaticano II · Núms. 18. 22

## Semana III de Cuaresma

- [Llega una mujer de Samaria a sacar agua](../r/e18bd75a0d.md) — San Agustín de Hipona · Tratado 15, 10-12.16-17: CCL 36, 154-156
- [Somos las piedras vivas con las que se edifica el templo de Dios](../r/2f18b12780.md) — San Agustín de Hipona · Comentario sobre el salmo 130, nn. 1-3: CCL 40, 1198-1200
- [Convertíos y creed en la Buena Noticia](../r/291db60636.md) — San Pablo VI · AAS t. 58, 1966, pp. 179-180
- [Siendo como era Dios y Señor, no rehusó asumir la condición de esclavo](../r/11f2e6f0fe.md) — San Juan Crisóstomo · Homilía 2, 3: PG 63, 23. 24-25
- **Domingo de la semana III de Cuaresma (semana 3) - Año A: Jn 4, 5-42** — [Si alguno peca, tenemos a uno que abogue ante el Padre](../r/9365cce2d2.md) — San Juan Fisher · Comentario sobre el Salmo 129, Opera omnia, ed. 1579 p. 1610
- **Martes de la semana III de Cuaresma (semana 3)** — [Cristo, pontífice y mediador](../r/95854fee59.md) — San Cirilo de Alejandría · Lib. 11, cap. 8: PG 74, 506-507
- **Miércoles de la semana III de Cuaresma (semana 3)** — [Cristo se ofreció a sí mismo por nosotros y se sometió espontáneamente a la muerte](../r/d43a1332eb.md) — San Cirilo de Alejandría · Lib. 3: PG 68, 290-291
- **Jueves de la semana III de Cuaresma (semana 3)** — [Cristo se hizo pontífice misericordioso](../r/8409d5862f.md) — San Cirilo de Alejandría · Homilía pascual 26, 3: PG 77, 926
- **Viernes de la semana III de Cuaresma (semana 3)** — [Eficacia de la oración](../r/a0995eb2f0.md) — San Juan Crisóstomo · Homilía 2, 4-5: PG 61, 397- 399
- **Sábado de la semana III de Cuaresma (semana 3)** — [Jesucristo ora por nosotros, ora en nosotros y es invocado por nosotros](../r/6605249262.md) — San Agustín de Hipona · Comentario sobre el Salmo 85, n. 1: CCL 39, 1176-1177

## Semana IV de Cuaresma

- [La carne de nuestro barro recibe la luz de la vida eterna, mediante el sacramento del bautismo](../r/5ba10226c2.md) — San Ambrosio de Milán · Carta 80,1-6: PL 16, 1271- 1272
- [Dios no perdonó a su propio Hijo, sino que lo entregó a la muerte por nosotros](../r/9126879a10.md) — San Juan Crisóstomo · 17, 1-8: PG 52, 516-518
- [Me alejé mucho, y tú estabas aquí](../r/20f6f15993.md) — San Agustín de Hipona · Comentario sobre el salmo 138, nn. 5-6: CCL 40, 1992-1993
- [Estableció a Melquisedec como imagen y figura de Cristo](../r/9adba4eed8.md) — San Cirilo de Alejandría · Lib. 2, 7-9: PG 69, 99-106
- **Domingo de la semana IV de Cuaresma (semana 4) - Año A: Jn 9, 1-41** — [Él mismo se ofreció por nosotros](../r/9acbac990e.md) — San Fulgencio de Ruspe · Cap. 22, 62: CCL 91A, 726. 750-751
- **Martes de la semana IV de Cuaresma (semana 4)** — [En la inmolación de Cristo está la verdadera Pascua y el único sacrificio](../r/d1a5390486.md) — San León Magno · Sermón 60, 1-2, sobre la Pasión del Señor: CCL 138A, 363-365
- **Miércoles de la semana IV de Cuaresma (semana 4)** — [Al que no había pecado, Dios lo hizo expiar nuestros pecados](../r/fc6166a93c.md) — San Juan Crisóstomo · Homilía 11, 3-4: PG 61, 478-480
- **Jueves de la semana IV de Cuaresma (semana 4)** — [Sin derramamiento de sangre no hay perdón](../r/1c8148e765.md) — Orígenes · Lib. 3, 8: PG 14, 950-951
- **Viernes de la semana IV de Cuaresma (semana 4)** — [Cristo no se arrogó el sacerdocio: lo aceptó](../r/895fc9c055.md) — San Ambrosio de Milán · Carta 67, 47-50: PL 16, 1253-1254
- **Sábado de la semana IV de Cuaresma (semana 4)** — [Contemplación de la pasión del Señor](../r/930a5a9d33.md) — San León Magno · Sermón 15, 3-4 sobre la Pasión del Señor: PL 54, 366-367

## Semana V de Cuaresma

- [Era necesaria la muerte de Lázaro para que, con Lázaro ya en el sepulcro, resucitase la fe de los discípulos](../r/aff6915957.md) — San Pedro Crisólogo · Sermón 6 : PL 52, 375-377
- [Cristo brotó en medio de nosotros como una espiga de trigo; murió y produce mucho fruto](../r/71e9db2881.md) — San Cirilo de Alejandría · 2: PG 69, 619-623
- [Observa los misterios de Dios y la clemencia de Cristo](../r/c99be23c72.md) — San Ambrosio de Milán · Carta 26 11-20: PL 16, 1088-1090
- [Os hace falta constancia para cumplir la voluntad de Dios y alcanzar la promesa](../r/e24c0953b8.md) — San Juan Crisóstomo · Homilía 21, 2-3: PG 63, 150-152
- **Domingo de la semana V de Cuaresma (semana 5) - Año A: Jn 11, 1-45** — [Por nuestra salvación, Cristo se hizo obediente al Padre](../r/1d0b4f4639.md) — San Cirilo de Alejandría · Homilía Pascual 5, 7: PG 77, 495-498
- **Martes de la semana V de Cuaresma (semana 5)** — [Todo se escribió como ya ocurrido, pero preanunciando el futuro](../r/c15094bce5.md) — San Agustín de Hipona · Sermón 22, 1: Edit. Maurist. t. 5, 116-118
- **Miércoles de la semana V de Cuaresma (semana 5)** — [Es una sola la muerte en favor del mundo y una sola la resurrección de entre los muertos](../r/ea2526ef25.md) — San Basilio Magno · Capítulo 15, 35: PG 32, 127-130
- **Jueves de la semana V de Cuaresma (semana 5)** — [Para aprender a correr rectamente, fijémonos en Cristo](../r/1e7f383072.md) — San Juan Crisóstomo · Homilía 28, 2: PG 63, 195
- **Viernes de la semana V de Cuaresma (semana 5)** — [La plenitud del amor](../r/24728f67a7.md) — San Agustín de Hipona · Tratado 84, 1-2: CCL 36, 536-538
- **Sábado de la semana V de Cuaresma (semana 5)** — [Jesús, para consagrar al pueblo con su propia sangre, murió fuera de las murallas](../r/85e2ec453e.md) — San Juan Crisóstomo · Homilía 33, 3-4: PG 63, 229-230

## Semana Santa

- **Domingo de Ramos en la Pasión del Señor** — [Bendito el que viene, como rey, en nombre del Señor](../r/1d1605e628.md) — San Andrés de Creta · Sermón 9 sobre el domingo de Ramos : PG 97, 990-994
- **Domingo de Ramos en la Pasión del Señor** — [Mirad al Rey justo](../r/141ee5d69e.md) — San Cirilo de Alejandría · Lib 4, orat 2: PG 70, 967-970
- **Domingo de Ramos en la Pasión del Señor** — [Si aquella sangre no hubiese sido derramada, el mundo no hubiera sido redimido](../r/ef03a2b0aa.md) — San Agustín de Hipona · Tratado 37, 9-10: CCL 36, 336-338
- **Domingo de Ramos en la Pasión del Señor** — [La pasión de Cristo y su preciosa cruz son seguridad y muro inaccesible para quien cree en él.](../r/78ac7b9d75.md) — San Cirilo de Alejandría · Lib. 4, or. 4: PG 70, 1066-1067
- **Domingo de Ramos - Año A: Mt 21, 1-11** — [La muerte de Cristo se ha convertido en espiga de trigo](../r/baebf3a56e.md) — Orígenes · Homilía 10, 1-3: PG 13, 358-362
- **Martes Santo** — [Cristo, que es la vida, quiso morir para hacernos digna morada de Dios](../r/219e92b59e.md) — San Hilario de Poitiers · Tratado 6-7 sobre el Salmo 131: CSEL 22, 666-667
- **Miércoles Santo** — [Dios me libre de gloriarme si no es en la cruz de nuestro Señor Jesucristo](../r/ec509944c5.md) — Beato Guerrico de Igny · Sermón 2, 1 en el Domingo de Ramos: PL 185, 130-131
- **Jueves Santo** — [El cordero inmolado nos ha hecho pasar de la muerte a la vida](../r/9a88925868.md) — San Melitón de Sardes · Núms. 65-71: SC 123, 95-101

## Triduo pascual

- **Sábado Santo** — [El descenso del Señor al abismo](../r/7f9072e0fa.md) — Actas y escritos anónimos · PG 43, 439. 451. 462-463
- [La cruz de Cristo, fuente de todas las bendiciones y origen de todas las gracias](../r/9052cd18d7.md) — San León Magno · Tratado 59, 4-6: CCL 138A, 354-359
- [Hemos sido sacrificados con Cristo](../r/0de6d2ffd6.md) — San Cirilo de Alejandría · Lib. 12: PG 74, 650-654

## Semana I de Pascua

- **Domingo de Pascua de la Resurrección del Señor** — [Derramaré sobre vosotros un agua pura, y os daré un corazón nuevo](../r/161f6bc7e1.md) — Sin identificar
- **Domingo de Pascua de la Resurrección del Señor** — [Cristo, una vez resucitado de entre los muertos, ya no muere más](../r/2de3a46031.md) — San Pablo
- **Lunes de la Octava de Pascua** — [Alabanza de Cristo](../r/478f38dfc4.md) — San Melitón de Sardes · Homilía 2-7. 100-103: SC 123, 60-64. 120-122
- **Martes de la Octava de Pascua** — [Era necesario que el Mesías padeciera para entrar en su gloria](../r/1f49734426.md) — San Anastasio de Antioquía · Sermón 4, 1-2: PG 89, 1347-1349
- **Miércoles de la Octava de Pascua** — [Cristo, autor de la resurrección y de la vida](../r/7a644be5b5.md) — Actas y escritos anónimos · Sermón 35, 6-9: PL 17 [ed. 1879], 696-697
- **Jueves de la Octava de Pascua** — [El bautismo, figura de la pasión de Cristo](../r/b34c016f27.md) — Sin identificar · Catequesis 20 [Mistagógica 2], 4-6: PG 33, 1079-1082
- **Viernes de la Octava de Pascua** — [La unción del Espíritu Santo](../r/5586a31718.md) — Sin identificar · Catequesis 21 [Mistagógica 3], 1-3: PG 33, 1087-1091
- **Sábado de la Octava de Pascua** — [El pan celestial y la bebida de salvación](../r/dd269a4df0.md) — Sin identificar · Catequesis 22 [Mistagógica 4], 1. 3-6. 9: PG 33, 1098-1106

## Semana II de Pascua

- **Domingo de la Octava de Pascua** — [Los que gozan de la presencia de Cristo, es lógico que estén tranquilos](../r/72cf11214d.md) — San Cirilo de Alejandría · Lib. 12, Cap. 1: PG 74, 703-706
- **Domingo de la Octava de Pascua** — [El Señor ama a sus discípulos, y, sin embargo, los envía al mundo a padecer](../r/2bbaebe809.md) — San Gregorio Magno · Homilía 26, 1-2: PL 76, 1197-1198
- **Domingo de la Octava de Pascua** — [Gran mérito tiene nuestra fe](../r/105f657142.md) — San Agustín de Hipona · Sermón 88, 1-2: Edit Maurist t. 5 469-470
- **Sábado de la semana II de Pascua (semana 2)** — [La economía de la salvación](../r/f248d4d4d4.md) — Concilio Vaticano II · Núms. 5-6
- **Domingo de la Octava de Pascua** — [La nueva creación en Cristo](../r/6379fd7d82.md) — San Agustín de Hipona · Sermón 8, 1, 4 en la Octava de Pascua: PL 46, 838.841
- **Domingo de la semana II de Pascua (semana 2) - Año A: Jn 20, 19-31** — [Entended el misterio de un amor tan grande](../r/990f39ebd7.md) — San León Magno · Sermón 2, 3-5 en la resurrección del Señor: CCL 138A, 443-446
- **Martes de la semana II de Pascua (semana 2)** — [Sacramento de unidad y de caridad](../r/48a38a24fa.md) — San Fulgencio de Ruspe · Lib. 2, 11-12: CCL 91, 46-48
- **Miércoles de la semana II de Pascua (semana 2)** — [Cristo vive en su Iglesia](../r/fd859a409a.md) — San León Magno · Sermón 12, 3. 6. 7 sobre la Pasión del Señor: CCL 138A, 383-384. 386-388
- **Jueves de la semana II de Pascua (semana 2)** — [La rica herencia del nuevo Testamento](../r/3194ec0b23.md) — San Gaudencio de Brescia · Tratado 2, CSEL 68, 30-32
- **Viernes de la semana II de Pascua (semana 2)** — [Preciosa y vivificante es la cruz de Cristo](../r/cfe15187f0.md) — San Teodoro de Studion · PG 99, 691-694. 695

## Semana III de Pascua

- **Domingo de la semana III de Pascua (semana 3)** — [Dichosos los que crean sin haber visto](../r/6c0243ea7f.md) — San Cirilo de Alejandría · Lib. 12, cap. 1: PG 74, 730-735
- **Domingo de la semana III de Pascua (semana 3)** — [Interrogando a Pedro, el Señor nos interroga a todos](../r/5ccc1963f5.md) — San Agustín de Hipona · Sermón Güelferbitano 16 (2-3: PLS 2, 580-581
- **Domingo de la semana III de Pascua (semana 3)** — [La voz de las almas es su amoroso deseo](../r/3f8aa0ddbf.md) — San Gregorio Magno · Lib. 2, 11: SC 32, 188-190
- **Domingo de la semana III de Pascua (semana 3)** — [Sermón 234 (1-2: Edit Maurist t. 5, 987-988)](../r/eac61a56e4.md) — San Agustín de Hipona
- **Domingo de la semana III de Pascua (semana 3) - Año A: Lc 24, 13-35** — [Raza elegida, sacerdocio real](../r/f079f8544b.md) — San Beda el Venerable · Capítulo 2: PL 93, 50-51
- **Martes de la semana III de Pascua (semana 3)** — [Somos justificados por la gracia](../r/06c9c2a7ec.md) — San Juan Crisóstomo · Lib. 4: PG 73, 606-607
- **Miércoles de la semana III de Pascua (semana 3)** — [La eucaristía, arras de la resurrección](../r/25954fa224.md) — San Ireneo de Lyon · Lib. 5, 2, 2-3: SC 153, 30-38
- **Jueves de la semana III de Pascua (semana 3)** — [La cruz de Cristo, salvación del género humano](../r/420a588dce.md) — San Efrén · Sermón 20, 3-4.9: Opera, ed. Lamy, 1, 152-158. 166-168
- **Viernes de la semana III de Pascua (semana 3)** — [Cristo entregó su cuerpo para la vida de todos](../r/eaa5a84367.md) — San Cirilo de Alejandría · Lib. 4, cap. 2: PG 73, 563- 566
- **Sábado de la semana III de Pascua (semana 3)** — [Esperamos la eterna felicidad de la ciudad celeste](../r/d3547436b4.md) — San Agustín de Hipona · Carta 137, 16: PL 33, 523-524

## Semana IV de Pascua

- **Domingo de la semana IV de Pascua (semana 4)** — [Cristo, el buen Pastor](../r/aa65a3247f.md) — San Gregorio Magno · Homilía 14 sobre los evangelios, 3-6: PL 76, 1129-1130
- **Domingo de la semana IV de Pascua (semana 4)** — [Del cielo vino el Pastor para reconducir las ovejas descarriadas a los pastos de la vida](../r/8d7fa4584f.md) — San Pedro Crisólogo · Sermón 6 (CCL 24, 44-47
- **Domingo de la semana IV de Pascua (semana 4)** — [La encarnación del Verbo y el sacramento de la Eucaristía nos hacen partícipes de la naturaleza divina](../r/89efb41c8a.md) — San Hilario de Poitiers · Lib 8, 13-16: CCL 62A, 325-328
- **Domingo de la semana IV de Pascua (semana 4)** — [La Iglesia es en Cristo como un sacramento o señal de la íntima unión con Dios](../r/f3dec6e5a8.md) — Concilio Vaticano II · Núms. 1-3
- **Domingo de la semana IV de Pascua (semana 4) - Año A: Jn 10, 1-10** — [El Espíritu, dador de vida](../r/6e44231b61.md) — San Basilio Magno · Cap. 15, 35-36: PG 32, 130-131
- **Martes de la semana IV de Pascua (semana 4)** — [Sé tú mismo el sacrificio y el sacerdote de Dios](../r/b5c37bd1d9.md) — San Pedro Crisólogo · Sermón 108 :PL 52, 499-500
- **Miércoles de la semana IV de Pascua (semana 4)** — [Cristo, luz de las naciones y cabeza de la Iglesia](../r/aa13df71aa.md) — San Agustín de Hipona · Sermón 137, 1-3: PL 38, 754-756
- **Jueves de la semana IV de Pascua (semana 4)** — [En Cristo murió nuestra culpa, no nuestra vida](../r/22d283df4d.md) — San Ambrosio de Milán · Lib. 1, 108-111: PL 16, 759-760
- **Viernes de la semana IV de Pascua (semana 4)** — [Sin motivo padece persecución, el que es combatido siendo inocente](../r/3b515f48c1.md) — San Ambrosio de Milán · Sermón 21, 6-9: PL 15, 1581-1583
- **Sábado de la semana IV de Pascua (semana 4)** — [Cristo, día sin ocaso](../r/7dd62bc313.md) — San Máximo de Turín · Sermón 53, 1-2. 4: CCL 23, 214-216

## Semana V de Pascua

- **Domingo de la semana V de Pascua (semana 5)** — [El lugar: junto al Padre; el camino: Cristo](../r/39a356a679.md) — San Ambrosio de Milán · Cap 12, 52-55: CSEL 32, 747-750
- **Domingo de la semana V de Pascua (semana 5)** — [Yo soy la vid, vosotros los sarmientos](../r/fd8dc977cf.md) — San Cirilo de Alejandría · Lib 10, 2: PG 74, 331-334
- **Domingo de la semana V de Pascua (semana 5)** — [El mandamiento nuevo](../r/90887759f2.md) — San Agustín de Hipona · Tratado 65, 1-3: CCL 36, 490-492
- **Domingo de la semana V de Pascua (semana 5)** — [El aleluya pascual](../r/7d316b21f6.md) — San Agustín de Hipona · Salmo 148, 1-2: CCL 40, 2165-2166
- **Domingo de la semana V de Pascua (semana 5) - Año A: Jn 14, 1-12** — [De la plenitud del Verbo todos hemos recibido](../r/12ab1036e1.md) — San Ambrosio de Milán · Sermón 20, 54-55: CSEL 62, 471-472
- **Martes de la semana V de Pascua (semana 5)** — [Los cristianos en el mundo](../r/56f27a83e1.md) — Carta a Diogneto · Capítulos 5-6: Funck 1, 397-401
- **Miércoles de la semana V de Pascua (semana 5)** — [Primogénito de la nueva creación](../r/29738f4708.md) — San Gregorio de Nisa · Sermón 1: PG 46, 603-606. 626-627
- **Jueves de la semana V de Pascua (semana 5)** — [Somos hijos de Dios y constituimos una familia en Cristo](../r/fff850c4a1.md) — Concilio Vaticano II · Cap. 7, 50-51
- **Viernes de la semana V de Pascua (semana 5)** — [Los sacramentos vitales](../r/552b0fdedc.md) — San Cipriano de Cartago · Carta 63, 8-9: CSEL 3, parte 2, 706-708
- **Sábado de la semana V de Pascua (semana 5)** — [La eucaristía, Pascua del Señor](../r/f73693864a.md) — San Gaudencio de Brescia · Tratado 2: CSEL 68, 26. 29-30

## Semana VI de Pascua

- **Domingo de la semana VI de Pascua (semana 6)** — [No os dejaré desamparados](../r/d75fddcbb0.md) — San Juan Crisóstomo · Homilía 75, 1: PG 59, 403-405
- **Domingo de la semana VI de Pascua (semana 6)** — [Amamos a Cristo en la medida en que guardamos sus mandamientos](../r/fdb02dc490.md) — San Agustín de Hipona · Tratado sobre el evangelio de san Juan, 82, 1-4: CCL 36, 532-534
- **Domingo de la semana VI de Pascua (semana 6)** — [Si no tengo amor, no soy nada](../r/f442fae2c7.md) — San Bernardo de Claraval · Sermón sobre el Cantar de los cantares, 27, 8-10: Opera omnia, Edit Cisterc 1, 1957, 187-189
- **Domingo de la semana VI de Pascua (semana 6)** — [El amor cubre la multitud de los pecados](../r/cb4d49e820.md) — San Agustín de Hipona · Tratado 1, 5-6: SC 75, 124-126
- **Domingo de la semana VI de Pascua (semana 6) - Año A: Jn 14, 15-21** — [En la unidad de la caridad consiste el amor fraterno](../r/52b53c044d.md) — San Agustín de Hipona · Tratado 1, 9. 12: SC 75, 132-144
- **Martes de la semana VI de Pascua (semana 6)** — [El que hace la voluntad de Dios permanece para siempre](../r/3ba330fd62.md) — San Agustín de Hipona · Tratado 2, 8. 9. 11. 14: SC 75, 166-181
- **Miércoles de la semana VI de Pascua (semana 6)** — [Es el momento final](../r/b164a79c2a.md) — San Agustín de Hipona · Tratado 3, 1. 3. 4. 5: SC 75, 186-194
- **Donde la Ascensión se celebra el Domingo** — [La unción del Espíritu](../r/4be3f46943.md) — San Agustín de Hipona · Tratado 4, 1-2: SC 75, 218-220
- **Donde la Ascensión se celebra el JUEVES VII DE PASCUA** — [La unción del Espíritu](../r/4be3f46943.md) — San Agustín de Hipona · Tratado 4, 1-2: SC 75, 218-220
- **Viernes de la semana VI de Pascua (semana 6) antes de la Ascensión** — [Toda la vida del buen cristiano es un santo deseo](../r/c942faa4bc.md) — San Agustín de Hipona · Tratado 4, 4-6: SC 75, 224-232
- **Sábado de la semana VI de Pascua (semana 6) después de la Ascensión** — [Toda la vida del buen cristiano es un santo deseo](../r/c942faa4bc.md) — San Agustín de Hipona · Tratado 4, 4-6: SC 75, 224-232
- **Sábado de la semana VI de Pascua (semana 6) antes de la Ascensión** — [No amemos de palabra y de boca, sino de verdad y con obras](../r/c54ed23a22.md) — San Agustín de Hipona · Tratado 5, 11-13: SC 75, 266-271

## La Ascensión del Señor

- **Solemnidad** — [Lo que fue visible en nuestro Redentor, ha pasado a los ritos sacramentales](../r/2516d02265.md) — San León Magno · Tratado 74 (1-2: CCL 138A 455-457
- **Solemnidad** — [Creemos en Jesús, a quien no hemos visto](../r/3f8f65031e.md) — San Agustín de Hipona · Tratado 4 sobre la primera carta de san Juan, 2-3: SC 75, 220-224
- **Solemnidad** — [Nuestro Señor Jesucristo nos ha inaugurado un camino nuevo y vivo](../r/a102ae9b6f.md) — San Cirilo de Alejandría · Lib 9: PG 74, 182-183
- **Solemnidad** — [Últimas palabras de Cristo antes de subir al cielo](../r/9ae5524e17.md) — San Agustín de Hipona · Tratado 10, 9: SC 75, 432-436

## Semana VII de Pascua

- **Domingo de la semana VII de Pascua (semana 7)** — [La cruz es voluntad del Padre, gloria del Hijo, gozo del Espíritu Santo](../r/13be837936.md) — San Juan Crisóstomo · Homilías sobre el nuevo Testamento : PG 51, 34-35
- **Domingo de la semana VII de Pascua (semana 7)** — [Les di a ellos la gloria que me diste](../r/82d00ca2ca.md) — San Gregorio de Nisa · Homilía 15 : PG 44, 1115-1118
- **Domingo de la semana VII de Pascua (semana 7)** — [Jesucristo ruega no sólo por los Doce, sino por todos aquellos que, en diversas épocas, han de creer por la palabra de ellos](../r/c1178a9714.md) — San Cirilo de Alejandría · Lib 11, cap 11: PG 74, 551-554
- **Domingo de la semana VII de Pascua (semana 7)** — [Pregunta a tu corazón si hay en él un lugar para el amor fraterno](../r/8fde50d24c.md) — San Agustín de Hipona · Tratado 6, 9-10: SC 75, 296-300
- **Domingo de la semana VII de Pascua (semana 7) - Año A: Jn 17, 1-11a** — [Por medio del Espíritu Santo el alma es purificada y alimentada](../r/1c186349b4.md) — San Agustín de Hipona · Tratado 6, 11: SC 75, 300-304
- **Martes de la semana VII de Pascua (semana 7)** — [Después de la partida de Cristo, era necesario el Consolador](../r/c7c17308bb.md) — San Agustín de Hipona · Tratado 94, 1-3: CCL 36, 561-563
- **Miércoles de la semana VII de Pascua (semana 7)** — [Por la caridad nos amamos mutuamente, por la caridad amamos a Dios](../r/0ba6533013.md) — San Agustín de Hipona · Tratado 87, 1: CCL 36, 543-544
- **Jueves de la semana VII de Pascua (semana 7)** — [Dos vidas](../r/5c33060ba1.md) — San Agustín de Hipona · Tratado 124, 5. 7: CCL 36, 685-687
- **Viernes de la semana VII de Pascua (semana 7)** — [El amor de Dios, que ha sido derramado en nuestros corazones con el Espíritu Santo nos dará valentía para ser sus testigos](../r/eaa81b8909.md) — San Agustín de Hipona · Tratado 92, 1-2: CCL 36, 555-556
- **Sábado de la semana VII de Pascua (semana 7)** — [La fuerza del Espíritu Santo](../r/906732113c.md) — San Juan Crisóstomo · Homilía 2, 1 en la solemnidad de Pentecostés: PG 50, 463-465

## Pentecostés

- **Domingo de Pentecostés** — [El envío del Espíritu Santo](../r/5942ae421e.md) — San Ireneo de Lyon · Libro 3, 17, 1-3: SC 34, 302-306
- **Domingo de Pentecostés** — [En vosotros se realiza lo que se preanunciaba en los días de la venida del Espíritu Santo](../r/890db2a56e.md) — San Agustín de Hipona · Sermón 271 : PL 38, 1245-1246
- **Domingo de Pentecostés** — [Me he hecho Hijo del hombre, para que vosotros podáis ser hijos de Dios](../r/4834ea815e.md) — San León Magno · Tratado 77, 4-6: CCL 138A, 490-493
- **Domingo de Pentecostés** — [El Espíritu de la verdad os guiará hasta la verdad plena](../r/3007a374ff.md) — San León Magno · Tratado 75, 1-3: CCL 138A, 465-468
