# Realmente, para Dios la muerte es un sueño

**San Pedro Crisólogo** (c. 380–450) · Tercera lectura del Oficio de Lectura

- id: `be5df8c8d9`
- Fuente: De los sermones de san Pedro Crisólogo
- Cita patrística: Sermón 34, 1.5: CCL 34,193.197-199
- Ciclo dominical: B · Evangelio Mc 5, 21-43
- Se lee: Domingo de la semana XIII del Tiempo Ordinario (semana 13), año impar; Domingo de la semana XIII del Tiempo Ordinario (semana 13), año par
- Escritura: [Mc 5, 21-43](../escritura/mc.md) (evangelio del domingo); [1 Pe 2, 21](../escritura/1pe.md) (responsorio); [Mt 8, 17](../escritura/mt.md) (responsorio)
- Temas (automáticos): [Muerte y difuntos](../temas/muerte.md), [Misión y evangelización](../temas/mision.md), [Cruz y Pasión](../temas/cruz.md)
- Cómo citar: San Pedro Crisólogo, Sermón 34, 1.5: CCL 34,193.197-199, «Realmente, para Dios la muerte es un sueño». Liturgia de las Horas, Oficio de Lectura, tercera lectura, Domingo de la semana XIII del Tiempo Ordinario (semana 13), año impar. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-be5df8c8d9](../index.html#r-be5df8c8d9)
- Autor: [San Pedro Crisólogo](../a/pedro-crisologo.md)

## Texto

Todas las perícopas evangélicas, carísimos hermanos, nos ofrecen los grandes bienes de la vida presente y de la futura. Pero la lectura de hoy es un compendio perfecto de esperanza, y la exclusión de cualquier motivo de desesperación.

Pero hablemos ya del jefe de la sinagoga, que, mientras conduce a Cristo a la cabecera de su hija, deja expedito el camino para que la mujer se acerque a Cristo. La lectura evangélica de hoy comienza así: Se acercó un jefe de la sinagoga, y al verlo se le echó a sus pies, rogándole con insistencia: Señor mi niña está en las últimas; ven, pon las manos sobre ella, para que se cure y viva. Conocedor del futuro como era, a Cristo no se le ocultaba que iba a producirse el encuentro con la susodicha mujer: de ella había de aprender el jefe de los judíos que a Dios no hay que moverlo de sitio, ni llevarlo de camino, ni exigirle una presencia corporal, sino creer que Dios está presente en todas partes, íntegramente y siempre; que puede hacerlo con sola una orden, sin esfuerzo; infundir ánimo, no deprimirlo; ahuyentar la muerte no con la mano, sino con su poder; prolongar la vida no con el arte, sino con el mandato.

Mi niña está en las últimas; ven. Que es como si dijera: Aún conserva el calor de la vida, aún se notan síntomas de animación, todavía respira, todavía el señor de la casa tiene una hija, todavía no ha descendido a la región de los muertos; por tanto, date prisa, no dejes que se le vaya el alma. En su ignorancia, creyó que Cristo no podía resucitar a la muerta sino tomándola de la mano. Esta es la razón por la cual Cristo, cuando, al llegar a la casa, vio que a la niña se la lloraba como perdida, para mover a la fe a los ánimos infieles, dijo que la niña no estaba muerta, sino dormida, a fin de infundirles esperanza, pensando que era más fácil despertar del sueño que de la muerte. La niña —dice— no está muerta, está dormida.

Y realmente, para Dios la muerte es un sueño, pues Dios devuelve más rápidamente a la vida que despierta un hombre del sueño a un dormido; y tarda menos Dios en infundir el calor vivificante a unos miembros fríos con el frío de la muerte de lo que puede tardar un hombre en infundir el vigor a los cuerpos sepultados en el sueño. Escucha al Apóstol: En un instante, en un abrir y cerrar de ojos, los muertos despertarán. El bienaventurado Apóstol, al no hallar palabras capaces de expresar la velocidad de la resurrección, acudió a los ejemplos. Porque, ¿cómo hubiera podido imprimir celeridad al discurso allí donde la potencia divina se adelanta incluso a esa misma celeridad? ¿O en qué sentido podía expresarse en categorías de tiempo, allí donde se nos otorga una realidad eterna no sometida al tiempo? Así como el tiempo dio paso a la temporalidad, así excluyó el tiempo la eternidad.

Año C: Lc 9, 51-62

TERCERA LECTURA

Del sermón de san Bernardo de Claraval, para el domingo de las kalendas de noviembre

(Sermón 1, 2: Opera omnia, Edit Cister t. 5, 305)

Sigámoslo con el empeño de una vida santa

En distintas ocasiones y de muchas maneras no sólo habló Dios por los profetas, sino que fue visto por los profetas. Lo conoció David hecho poco inferior a los ángeles; Jeremías lo vio incluso viviendo entre los hombres; Isaías nos asegura que lo vio unas veces sobre un trono excelso, y otras no sólo inferior a los ángeles o entre los hombres, sino como leproso, es decir, no sólo en la carne, sino en una carne pecadora como la nuestra.

También tú, si deseas verlo sublime, cuida de ver primero a Jesús humilde. Vuelve primero los ojos a la serpiente elevada en el desierto, si deseas ver al Rey sentado en su trono. Que esta visión te humille, para que aquélla exalte al humillado. Que ésta reprima y cure tu hinchazón, para que aquélla colme y sacie tu deseo. ¿Lo ves anonadado? Que no sea ociosa esta visión, pues no podrías ociosamente contemplar al exaltado. Cuando lo vieres tal cual es, serás semejante a él; sé ya desde ahora semejante a él, viéndolo tal cual por ti se ha hecho él.

Pues si ni en la humildad desdeñas ser semejante a él, seguramente te esperará también la semejanza con él en la gloria. Nunca permitirá él que sea excluido de la comunión en la gloria el que haya participado en su tribulación. Finalmente, hasta tal punto no desdeña admitir consigo en el reino a quien hubiere compartido su pasión, que el ladrón que le confesó en la cruz estuvo aquel mismo día con él en el paraíso. He aquí por qué dijo también a los Apóstoles: Vosotros sois los que habéis perseverado conmigo en mis pruebas y yo os transmito el reino. Y dado que si sufrimos con él también reinaremos con él, sea entre tanto, hermanos, nuestra meditación Cristo, y éste crucificado. Grabémosle como un sello en nuestro corazón, como un sello en nuestro brazo. Abracémosle con los brazos de un amor recíproco, sigámoslo con el empeño de una vida santa. Este es el camino por el que se nos muestra él mismo, que es la salvación de Dios, pero no ya privado de belleza y esplendor, sino con tanta claridad, que su gloria llena la tierra.

## Responsorio (1Pe 2, 21; Mt 8, 17)

R. Cristo padeció por nosotros * dejándonos un ejemplo para que sigamos sus huellas.  
V. Él tomó nuestras flaquezas y cargó con nuestras enfermedades.  
R Dejándonos un ejemplo para que sigamos sus huellas.  

## Oración

Padre de bondad, que por la gracia de la adopción nos has hecho hijos de la luz; concédenos vivir fuera de las tinieblas del error y permanecer siempre en el esplendor de la verdad. Por nuestro Señor Jesucristo.

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
