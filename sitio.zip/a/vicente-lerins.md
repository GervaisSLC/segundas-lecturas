# San Vicente de Lerins

d. c. 445 · St. Vincent of Lérins · 1 lecturas

- [El progreso del dogma cristiano](../r/49144faee1.md) — San Vicente de Lerins · Capítulo 23: PL 50, 667-668 · Viernes de la semana V del Tiempo Ordinario (semana 5), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
