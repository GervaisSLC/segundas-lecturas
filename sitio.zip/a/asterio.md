# San Asterio de Amasea

d. c. 410 · St. Asterius of Amasea · 3 lecturas

- [Él nos amó primero](../r/cfe704d151.md) — San Asterio de Amasea · Núms. 9-11: SC 61, 90-96 · Semana III de Adviento — Adviento y Navidad, año par
- [Debemos buscar la inteligencia de la fe en el Espíritu Santo](../r/b70aa2a23c.md) — San Asterio de Amasea · PL 180, 384 · Común de doctores de la iglesia — Comunes, año par
- [Imitemos el estilo pastoral que empleó el mismo Señor](../r/28774edc68.md) — San Asterio de Amasea · Homilía 13, PG 40, 355-358. 362 · Viernes de la semana I de Cuaresma (semana 1), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
