# San Hilario de Poitiers

c. 310–367 · St. Hilary of Poitiers · 16 lecturas

- [¡Oh Dios, que te alaben los pueblos!](../r/5f4bc601f1.md) — San Hilario de Poitiers · 3-5 : CSEL 22, 271-273 · 6 de Enero. LA EPIFANÍA DEL SEÑOR — Santoral, año par
- [Dios edifica y guarda su ciudad](../r/288c413097.md) — San Hilario de Poitiers · Núms. 7-10: PL 9, 696-697 · Común de pastores — Comunes, año par
- [El cimiento de nuestro edificio es Cristo](../r/e5660b242c.md) — San Hilario de Poitiers · Sal 14, 4-5: CSEL 22, 86-88 · Lunes de la semana I de Adviento (semana 1), año impar
- [El Hijo entregará al reinado de Dios, a los que él llamó al reino](../r/b007b76509.md) — San Hilario de Poitiers · Lib. 11, 36-40: PL 10, 423-425 · Lunes de la semana II de Adviento (semana 2), año impar
- [Cristo regirá como pastor las naciones que se le han confiado](../r/e1cb98b2ce.md) — San Hilario de Poitiers · Sal 2, 31.34 35.37: CSEL 22, 60.63.64.65 · Martes de la semana II de Adviento (semana 2), año impar
- [Cuando entregare el reino a Dios Padre, Cristo reinará con los que son reyes](../r/1fb6dd186e.md) — San Hilario de Poitiers · Salmo 60, 5-6: CSEL 22, 205-207 · Miércoles de la semana III de Adviento (semana 3), año impar
- [Del verdadero temor de Dios](../r/f2d6cd7f2c.md) — San Hilario de Poitiers · Sobre el salmo 127, 1-3: CSEL 24, 628-630 · Jueves de la semana II de Cuaresma (semana 2), año par
- [La encarnación del Verbo y el sacramento de la Eucaristía nos hacen partícipes de la naturaleza divina](../r/89efb41c8a.md) — San Hilario de Poitiers · Lib 8, 13-16: CCL 62A, 325-328 · Domingo de la semana IV de Pascua (semana 4), año par
- [El don del Padre en Cristo](../r/864ac189c6.md) — San Hilario de Poitiers · Libro 2, 1, 33. 35: PL 10, 50-51. 73-75 · Viernes de la semana VII de Pascua (semana 7), año par
- [Cristo, que es la vida, quiso morir para hacernos digna morada de Dios](../r/219e92b59e.md) — San Hilario de Poitiers · Tratado 6-7 sobre el Salmo 131: CSEL 22, 666-667 · Martes Santo — Cuaresma y Pascua, año impar
- [Cristo promulga el código de la vida celestial](../r/48f93d7eba.md) — San Hilario de Poitiers · Cap. 4, 1-3. 9: PL 9, 931-934 · Domingo de la semana IV del Tiempo Ordinario (semana 4), año impar
- [Paraos en el camino del Señor](../r/25374fe54b.md) — San Hilario de Poitiers · Tratado sobre el Salmo 127, 2-3. 6: CSEL 22, 629-632 · Lunes de la semana X del Tiempo Ordinario (semana 10), año impar
- [Te serviré predicándote](../r/c8c8b91dce.md) — San Hilario de Poitiers · Libro 1, 37-38: PL 10, 48-49 · 13 de enero San Hilario, obispo y Doctor de la Iglesia — Santoral, año impar
- [La multitud de los creyentes no era sino un solo corazón y una sola alma](../r/4ff59ffcd4.md) — San Hilario de Poitiers · 132, PLS 1, 244-245 · Lunes de la semana VI del Tiempo Ordinario (semana 6), año par
- [Muy a gusto hemos de presumir de nuestras debilidades, para que así resida en nosotros la fuerza de Dios](../r/50970e6693.md) — San Hilario de Poitiers · Tratado 3. 7. 11 sobre el Salmo 15: PL 9, 892. 894. 896. 897 · Jueves de la semana XXX del Tiempo Ordinario (semana 30), año impar
- [Toda la alabanza del Padre viene del Hijo](../r/6a6033e644.md) — San Hilario de Poitiers · Lib. 3, 15-16: PL 10, 84-85 · Sábado de la semana XXXIV del Tiempo Ordinario (semana 34), año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
