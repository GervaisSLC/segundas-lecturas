# San Alfonso María de Ligorio

1696–1787 · St. Alphonsus Liguori · 1 lecturas

- [El amor a Cristo](../r/a31945179e.md) — San Alfonso María de Ligorio · Tratado sobre la práctica del amor a Jesucristo, edición latina, Roma 1909, pp. 9-14 · 1 de agosto San Alfonso María de Ligorio, obispo y doctor de la Iglesia — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
