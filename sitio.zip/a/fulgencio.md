# San Fulgencio de Ruspe

c. 467–533 · St. Fulgentius of Ruspe · 7 lecturas

- [Las armas de la caridad](../r/5fdf0ebeba.md) — San Fulgencio de Ruspe · Sermón 3,1-3. 5-6: CCL 91 A, 905-909 · 26 de diciembre. San Esteban, protomártir — Santoral, año par
- [Criado fiel y solícito](../r/c754ee4157.md) — San Fulgencio de Ruspe · Sermón 1, 2-3: CCL 91 A, 889-890 · Común de pastores — Comunes, año par
- [Cristo vive siempre para interceder en nuestro favor](../r/8973766e14.md) — San Fulgencio de Ruspe · Carta 14, 36-37: CCL 91, 429-431 · Jueves de la semana I de Cuaresma (semana 1), año impar
- [Él mismo se ofreció por nosotros](../r/9acbac990e.md) — San Fulgencio de Ruspe · Cap. 22, 62: CCL 91A, 726. 750-751 · Domingo de la semana IV de Cuaresma (semana 4) - Año A: Jn 9, 1-41, año impar
- [Sacramento de unidad y de caridad](../r/48a38a24fa.md) — San Fulgencio de Ruspe · Lib. 2, 11-12: CCL 91, 46-48 · Martes de la semana II de Pascua (semana 2), año impar
- [La caridad trabaja en el mundo, descansa en Dios](../r/04c3565c0a.md) — San Fulgencio de Ruspe · Sermón 5, 5-6: CCL 91A, 921-923 · Martes de la semana IX del Tiempo Ordinario (semana 9), año impar
- [La participación del cuerpo y sangre de Cristo nos santifica](../r/04f4dd0742.md) — San Fulgencio de Ruspe · Cap 28, 16-19: CCL 91A, 813-814 · Jueves de la semana XI del Tiempo Ordinario (semana 11), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
