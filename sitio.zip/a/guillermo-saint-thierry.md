# Guillermo de Saint-Thierry

c. 1085–1148 · William of Saint-Thierry · 1 lecturas

- [La palabra todopoderosa vino desde el trono real](../r/0a14e9d96e.md) — Guillermo de Saint-Thierry · 10: SC 61, 91-94 · Sábado de la semana XXXI del Tiempo Ordinario (semana 31), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
