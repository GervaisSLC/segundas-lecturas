# San Cayetano

None · None · 1 lecturas

- [Cristo habite por la fe en nuestros corazones](../r/29658abbf5.md) — San Cayetano · Carta a Elisabet Porto: Studi e Testi 177, Ciudad del Vaticano 1954, pp. 50-51 · El mismo día 7 de agosto San Cayetano, presbítero — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
