# San Esteban

None · None · 1 lecturas

- [Hijo mío, escucha la corrección de tu padre](../r/bf33170d9e.md) — San Esteban · Caps. 1. 2.10: PL 151,1236-1237.1242-1244 · 16 de agosto San Esteban de Hungría — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
