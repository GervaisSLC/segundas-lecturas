# San Raimundo de Peñafort

None · None · 1 lecturas

- [Que el Dios del amor y de la paz purifique vuestros corazones](../r/2e76c8c221.md) — San Raimundo de Peñafort · Monumenta Ordinis Praedicatorum Historica 6, 2, Roma 1901, pp. 84-85 · 7 de enero. San Raimundo de Peñafort, Presbítero — Santoral, año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
