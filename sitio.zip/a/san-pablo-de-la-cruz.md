# San Pablo de la Cruz

None · None · 1 lecturas

- [Predicamos a Cristo crucificado](../r/4b924471f4.md) — San Pablo de la Cruz · Carta 1, 43; 2, 440. 825 · El mismo día 19 de octubre San Pablo de la Cruz, presbítero — Santoral, año impar

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
