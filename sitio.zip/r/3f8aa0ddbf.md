# La voz de las almas es su amoroso deseo

**San Gregorio Magno** (c. 540–604) · Segunda lectura del Oficio de Lectura

- id: `3f8aa0ddbf`
- Fuente: De los tratados morales sobre el libro de Job de san Gregorio Magno, papa
- Cita patrística: Lib. 2, 11: SC 32, 188-190
- Se lee: Domingo de la semana III de Pascua (semana 3), año impar
- Escritura: [Ap 6, 1-17](../escritura/ap.md) (primera lectura del día); [Ap 6, 9-10](../escritura/ap.md) (responsorio)
- Temas (automáticos): [Resurrección](../temas/resurreccion.md)
- Cómo citar: San Gregorio Magno, Lib. 2, 11: SC 32, 188-190, «La voz de las almas es su amoroso deseo». Liturgia de las Horas, Oficio de Lectura, segunda lectura, Domingo de la semana III de Pascua (semana 3), año impar. Leccionario Bienal (textos de la CEE).
- Abrir en la app: [../index.html#r-3f8aa0ddbf](../index.html#r-3f8aa0ddbf)
- Autor: [San Gregorio Magno](../a/gregorio-magno.md)

## Texto

La petición de venganza expresada por las almas, ¿qué otra cosa es sino el deseo del juicio final y de la resurrección de los cuerpos? Las grandes voces de las almas son su gran deseo. Cuanto menos vivo es el deseo, tanto menos grita. Y cuanto más fuerte es la voz que hace llegar a los oídos del Espíritu infinito, tanto más plenamente se sumerge en su deseo. El lenguaje de las almas es precisamente su deseo. Pues si el deseo no fuera una especie de lenguaje, no diría el profeta: Señor, tú escuchas los deseos de los humildes.

Ahora bien: siendo así que el talante del que pide suele estar en los antípodas del de aquel a quien se elevan las peticiones, y estando las almas de los santos tan unidas a Dios allá en el hondón del corazón, que en esta unión hallan su descanso, ¿cómo puede afirmarse que piden, cuando nos consta que su voluntad está en perfecta sintonía con la voz de Dios? ¿Cómo puede afirmarse que piden, cuando conocen con seguridad la voluntad de Dios y no ignoran el porvenir?

Pues bien: de las almas radicadas en Dios se afirma que piden algo, no en el sentido de que deseen nada que discrepe de la voluntad de aquel en cuya contemplación están inmersas, sino en el sentido de que cuanto más ardientemente le están unidas, tanto más impulsadas se sienten por él a pedirle, lo que saben que él está dispuesto a hacer. Así que sacian su sed en el mismo que provoca su sed; y de un modo para nosotros todavía incomprensible, se sacian ya con la precomprensión de aquello de que hambrean en la plegaria. No irían de acuerdo con la voluntad del Creador, si no pidieran lo que vieren era su voluntad; le estarían menos estrechamente unidas, si llamaran con escaso interés a la puerta del que está dispuesto a dar.

A las cuales el oráculo divino les dijo: Tened calma todavía por un poco, hasta que se complete el número de vuestros compañeros de servicio y hermanos vuestros. Decir a unas almas anhelantes: Tened calma todavía por un poco, es hacerles gustar ya, en medio de su ardiente deseo, las primicias de una pacificante consolación; es hacer que la voz de las almas sea su amoroso deseo; es hacer que la respuesta de Dios sea la confirmación en sus deseos, mediante la certeza de la retribución. Su respuesta de que deben esperar un poco hasta que se complete el número de sus hermanos, tiene la misión de inducirles a la aceptación voluntaria de la caritativa moratoria; de modo que, mientras aspiran a la resurrección de la carne, se gocen con el aumento de sus hermanos.

## Responsorio (Ap 6, 9-10)

R. Vi debajo del altar las almas de los degollados a causa de la palabra de Dios y del testimonio que habían dado y gritaban con fuerte voz: * ¿Hasta cuándo, Señor, vas a estar sin tomar venganza por nuestra sangre? Aleluya.  
V. Debajo del trono de Dios todos los santos gritan:  
R. ¿Hasta cuándo, Señor, vas a estar sin tomar venganza por nuestra sangre? Aleluya.  

## Primera lectura del día

**Del libro del Apocalipsis 6, 1-17** — *El libro de Dios es abierto por el Cordero*

Yo, Juan, vi que el Cordero abrió el primero de los siete sellos, miré y oí a uno de los vivientes que decía con voz de trueno:

«Ven».

Y vi un caballo blanco; el jinete tenía un arco, se le dio una corona y salió como vencedor y para vencer otra vez.

Cuando abrió el segundo sello, oí al segundo viviente que decía:

«Ven».

Salió otro caballo, rojo, y al jinete se le dio poder para quitar la paz de la tierra y hacer que los hombres se degüellen unos a otros; se le dio también una gran espada.

Cuando abrió el tercer sello, oí al tercer viviente que decía:

«Ven».

Y vi un caballo negro; el jinete tenía en la mano una balanza. Y oí como una voz en medio de los cuatro vivientes que decía:

«Una medida de trigo, un denario; tres medidas de cebada, un denario; al aceite y al vino no los dañes».

Cuando abrió el cuarto sello, oí la voz del cuarto viviente que decía:

«Ven».

Y vi un caballo amarillento; el jinete se llamaba Muerte, y el Abismo lo seguía. Se les dio potestad sobre la cuarta parte de la tierra, para matar con espada, hambre, epidemias y con las fieras salvajes.

Cuando abrió el quinto sello, vi debajo del altar las almas de los degollados por causa de la Palabra de Dios y del testimonio que mantenían. Y gritaban con voz potente:

«¿Hasta cuándo, Dueño santo y veraz, vas a estar sin hacer justicia y sin vengar nuestra sangre de los habitantes de la tierra?».

A cada uno de ellos se le dio una túnica blanca, y se les dijo que tuvieran paciencia todavía un poco, hasta que se completase el número de sus compañeros y hermanos que iban a ser martirizados igual que ellos.

Vi cuando abrió el sexto sello: se produjo un gran terremoto, el sol se puso negro como un sayal de pelo, la luna entera se tiñó de sangre, y las estrellas del cielo cayeron a la tierra como caen los higos de una higuera cuando la sacude un huracán. Desapareció el cielo como un libro que se enrolla, y montes e islas se desplazaron de su lugar. Los reyes de la tierra, los magnates, los generales, los ricos, los poderosos y todos, esclavos y libres, se escondieron en las cuevas y entre las rocas. Y decían a los montes y a las rocas: «Caed sobre nosotros y ocultadnos de la vista del que está sentado en el trono y de la ira del Cordero, porque ha llegado el gran Día de su ira, y ¿quién podrá mantenerse en pie?».

---

Leccionario Bienal del Oficio de Lectura, ed. P. Alfertson Cedano, textos de la Conferencia Episcopal Española. Publicado con permiso. · [Guía para IAs](../llms.txt)
