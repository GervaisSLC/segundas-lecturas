# San Zenón de Verona

d. c. 371 · St. Zeno of Verona · 1 lecturas

- [Job era figura de Cristo](../r/e1071ac4f3.md) — San Zenón de Verona · Tratado 15, 2: PL 11, 441-443 · Martes de la semana XVI del Tiempo Ordinario (semana 16), año par

[Todos los autores](../autores.md) · [Guía para IAs](../llms.txt)
