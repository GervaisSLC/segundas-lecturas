# Oficio de difuntos — año par

[Volver al calendario](index.md) · [Guía para IAs](../llms.txt)

## Oficio de Difuntos

- [Cristo transformará nuestro cuerpo humilde](../r/c5d99279f1.md) — San Anastasio de Antioquía · Sermón 5, Sobre la resurrección de Cristo, 6-7. 9: PG 89, 1358-1359.1361-1362
- [Cristo resucitado, esperanza de todos los creyentes](../r/f7ced45d54.md) — San Braulio de Zaragoza · Carta 19: PL 80, 665-666
- [Cristo resucitó para que no dude el cristiano de la propia resurrección](../r/70bb6bef66.md) — San Odilón de Cluny · Sermón 5: PL 142, 1004-1005
